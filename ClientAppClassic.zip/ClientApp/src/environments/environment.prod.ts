export const environment = {
  production: true,
  version: "1.16.0",
};
