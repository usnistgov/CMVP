import { Component, OnInit, Input } from "@angular/core";
import { SectionService } from "../../services/section.service";
import { FormArray, FormControl, FormGroup } from "@angular/forms";
import * as _ from "underscore";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ImageDialogComponent } from "../image-dialog/image-dialog.component";

@Component({
  selector: "app-shared-security-policy",
  templateUrl: "./shared-security-policy.component.html",
  styleUrls: ["./shared-security-policy.component.scss"],
})
export class SharedSecurityPolicyComponent implements OnInit {
  tables = [];
  openedSection;
  formGroups = {};
  editingRow;
  editingTable;
  @Input()
  readOnly = null;

  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService
  ) {}

  ngOnInit() {
    this.tables = [];
    for (let sectionNb in this.sectionService.securityPolicyTables) {
      if (
        Object.prototype.hasOwnProperty.call(
          this.sectionService.securityPolicyTables,
          sectionNb
        )
      ) {
        // do stuff
        const section = this.sectionService.securityPolicyTables[sectionNb];

        section.forEach((question) => {
          if (question.type === "files") {
            this.tables.push({
              form: this.sectionService.sections[sectionNb].controls[
                question.question
              ],
              question: question.question,
              type: question.type,
              title: question.title,
              position: question.position,
            });
          } else {
            this.tables.push({
              form: question.form
                ? question.form
                : this.sectionService.sections[sectionNb].controls[
                    question.question
                  ],
              details: question.details,
              question: question.question,
              type: question.type,
              formGroup: question.formGroup,
              disabled: question.form ? true : false,
              title: question.title,
              position: question.position,
              condition: question.condition,
            });
            if (!this.formGroups[question.question]) {
              this.formGroups[question.question] = {};
            }
            this.formGroups[question.question][question.position] =
              question.formGroup;
          }
        });
      }
    }
    this.tables = this.tables.sort((a, b) => a.position - b.position);
  }

  hasCondition(table) {
    let res = false;
    if (table.condition && table.condition.path.length > 0) {
      let obj = this.sectionService.vendorFormGroup.getRawValue();
      table.condition.path.forEach((p) => {
        obj = obj[p];
      });
      if (obj && table.condition.values.includes(obj)) {
        res = true;
      }
    } else {
      return true;
    }
    return res;
  }

  openSection(section) {
    this.openedSection = this.sectionService.sections[section.key];
    this.tables = [];
    section.value.forEach((question) => {
      this.tables.push({
        form: this.sectionService.sections[section.key].controls[
          question.question
        ],
        details: question.details,
        question: question.question,
        type: question.type,
        formGroup: question.formGroup,
      });
      this.formGroups[question.question] = question.formGroup;
    });
  }
  addToFormArray(question, formGroup, ArrayControlName, position) {
    let formGroupObj = {};
    for (let index in formGroup.value) {
      formGroupObj[index] = new FormControl(formGroup.value[index]);
    }
    const fg = new FormGroup(formGroupObj);
    const table = this.tables.find(
      (x) => x.question === question && x.position === position
    );
    if (table) {
      let array = table.form.get(ArrayControlName) as FormArray;
      array.push(fg);
    }

    formGroup.reset();
  }
  editFormInArray(index, question) {
    this.editingRow = index;
    this.editingTable = question;
  }
  deleteRow(form, arrayName, index) {
    const array = form.get(arrayName) as FormArray;
    array.removeAt(index);
  }
  saveRow() {
    this.editingRow = null;
    this.editingTable = null;
  }
  getRowAsArray(form, arrayName) {
    return form.get(arrayName) as FormArray;
  }

  openImageDialog(form) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "700px";

    const dialogRef = this.dialog.open(ImageDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      if (data) {
        (<FormArray>form.controls.files).push(
          new FormControl({ file: data.file, title: data.title })
        );
      }
    });
  }
}
