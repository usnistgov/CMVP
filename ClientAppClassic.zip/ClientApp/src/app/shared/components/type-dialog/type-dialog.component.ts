import { Component, OnInit, Inject } from "@angular/core";
import { MatDialogRef } from "@angular/material/dialog";

@Component({
  selector: "app-type-dialog",
  templateUrl: "./type-dialog.component.html",
  styleUrls: ["./type-dialog.component.scss"],
})
export class TypeDialogComponent implements OnInit {
  type;
  constructor(public dialogRef: MatDialogRef<TypeDialogComponent>) {}

  ngOnInit() {}
  onNoClick(): void {
    this.dialogRef.close(this.type);
  }
}
