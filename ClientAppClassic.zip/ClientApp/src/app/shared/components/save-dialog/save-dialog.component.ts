import { Component, OnInit } from "@angular/core";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { DatePipe } from "@angular/common";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { reject } from "q";
import { ConverterService } from "../../services/converter.service";
import { PdfService } from "../../services/pdf.service";
import { environment } from "src/environments/environment";
import { MatDialogRef } from "@angular/material/dialog";

@Component({
  selector: "app-save-dialog",
  templateUrl: "./save-dialog.component.html",
  styleUrls: ["./save-dialog.component.scss"],
})
export class SaveDialogComponent implements OnInit {
  files = [];
  selectedFiles = [];
  selectedType = "json";
  constructor(
    private converterService: ConverterService,
    public pdfService: PdfService,
    public datepipe: DatePipe,
    public formService: FormService,
    public sectionService: SectionService,
    private dialogRef: MatDialogRef<SaveDialogComponent>
  ) {}

  ngOnInit() {
    this.updateGeneratedFiles(this.selectedType);
  }
  updateGeneratedFiles(type) {
    this.files = [
      {
        label: "Vendor File",
        files: [
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_vendor.${type}`,
            selected: true,
          },
        ],
      },
      {
        label: "Reports",
        files: [
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section1.${type}`,
            selected: true,
            section: "1",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section2.${type}`,
            selected: true,
            section: "2",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section3.${type}`,
            selected: true,
            section: "3",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section4.${type}`,
            selected: true,
            section: "4",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section5.${type}`,
            selected: true,
            section: "5",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section6.${type}`,
            selected: true,
            section: "6",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section7.${type}`,
            selected: true,
            section: "7",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section8.${type}`,
            selected: true,
            section: "8",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section9.${type}`,
            selected: true,
            section: "9",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section10.${type}`,
            selected: true,
            section: "10",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section11.${type}`,
            selected: true,
            section: "11",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section12.${type}`,
            selected: true,
            section: "12",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_sectionA.${type}`,
            selected: true,
            section: "A",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_sectionB.${type}`,
            selected: true,
            section: "B",
          },
        ],
      },
    ];
  }

  async downloadPackage() {
    const self = this;
    const jszip = new JSZip();
    const folder = jszip.folder(
      self.formService.getFileName(
        self.sectionService.vendorFormGroup.getRawValue()
      )
    );

    // Report files
    if (this.selectedType === "json") {
      this.saveReportsAsJson(folder);
    } else if (this.selectedType === "xml") {
      this.saveReportsAsXml(folder);
    }

    // Vendor files
    if (this.files[0].files[0].selected) {
      if (this.selectedType === "json") {
        this.saveFormAsJson(folder);
      } else if (this.selectedType === "xml") {
        this.saveFormAsXml(folder);
      }
    }

    jszip.generateAsync({ type: "blob" }).then(function (content) {
      // see FileSaver.js

      saveAs(
        content,
        `${self.formService.getFileName(
          self.sectionService.vendorFormGroup.getRawValue()
        )}.zip`
      );
    });
  }

  saveReportsAsTxt(jszip) {
    const txt = this.formService.prepareSectionInfoTxt();
    const blob = new Blob([txt], { type: "text/plain" });
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_report.txt", blob);
  }

  saveReportsAsJson(jszip) {
    let selectedSections = this.files[1].files.filter((f) => f.selected);
    selectedSections.forEach((sec) => {
      let data = this.sectionService.sections[sec.section].value;
      if (sec.section === "B") {
        data["TEB.01.01"] = {
          ...data["TEB.01.01"],
          ...this.sectionService.securityPolicyContent,
        };
      }
      const blob = new Blob(
        [JSON.stringify(this.sectionService.sections[sec.section].value)],
        { type: "text/json" }
      );
      const filename = this.formService.getFileName(
        this.sectionService.vendorFormGroup.getRawValue()
      );
      jszip.file(filename + `_report_section${sec.section}.json`, blob);
    });
  }

  saveReportsAsXml(jszip) {
    let selectedSections = this.files[1].files.filter((f) => f.selected);
    selectedSections.forEach((sec) => {
      const blob = new Blob(
        [
          this.converterService.convertReportsToXml(
            this.sectionService.sections[sec.section].value
          ),
        ],
        { type: "text/xml" }
      );
      const filename = this.formService.getFileName(
        this.sectionService.vendorFormGroup.getRawValue()
      );
      jszip.file(filename + `_report_section${sec.section}.xml`, blob);
    });
  }
  saveFormAsJson(jszip) {
    if (
      this.sectionService.vendorFormGroup.value &&
      this.sectionService.vendorFormGroup.value["module"] &&
      this.sectionService.vendorFormGroup.value["module"].date
    ) {
      this.sectionService.vendorFormGroup.value["module"].date =
        this.datepipe.transform(
          this.sectionService.vendorFormGroup.value["module"].date,
          "yyyy-MM-dd"
        );
    }
    let date = JSON.parse(
      JSON.stringify(this.sectionService.vendorFormGroup.value["module"].date)
    );
    let data = this.sectionService.vendorFormGroup.getRawValue();
    data.references = this.sectionService.references.value;
    data.webCryptikVersion = environment.version;
    data.module.date = date;
    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });

    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_vendor.json", blob);
  }

  saveFormAsXml(jszip) {
    if (
      this.sectionService.vendorFormGroup.getRawValue() &&
      this.sectionService.vendorFormGroup.getRawValue()["module"] &&
      this.sectionService.vendorFormGroup.getRawValue()["module"].date
    ) {
      this.sectionService.vendorFormGroup.getRawValue()["module"].date =
        this.datepipe.transform(
          this.sectionService.vendorFormGroup.getRawValue()["module"].date,
          "yyyy-MM-dd"
        );
    }
    const blob = new Blob(
      [
        this.converterService.convertGeneralInfoToXml(
          this.sectionService.vendorFormGroup.getRawValue()
        ),
      ],
      { type: "text/xml" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_vendor.xml", blob);
  }

  async getBlob(pdf) {
    let promise = await new Promise((resolve, reject) => {
      pdf.getBlob((blob) => {
        resolve(blob);
      });
    }).catch((err) => {
      reject(err);
    });

    return promise;
  }

  async save() {
    await this.downloadPackage();
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }
}
