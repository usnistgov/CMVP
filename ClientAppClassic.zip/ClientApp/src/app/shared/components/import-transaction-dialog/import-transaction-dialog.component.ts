import {
    ChangeDetectionStrategy,
    Component,
    Input,
    OnInit,
    Output,
    EventEmitter,
    SimpleChanges,
  } from "@angular/core";
  import { FormGroup } from "@angular/forms";
  import { MatDatepickerInputEvent } from "@angular/material/datepicker";
  import { MatDialogRef } from "@angular/material/dialog";
  import { SectionService } from "../../services/section.service";
  import { FormService } from "../../services/form.service";
  import { DatePipe } from "@angular/common";
  import * as JSZip from "jszip";
  import pdfMake from "pdfmake/build/pdfmake";
  import pdfFonts from "pdfmake/build/vfs_fonts";
  
  import { PdfService } from "../../services/pdf.service";
  import { TransactionService } from "../../services/transaction.service";
  
  pdfMake.vfs = pdfFonts.pdfMake.vfs;
  @Component({
    selector: "app-import-transaction-dialog",
    templateUrl: "./import-transaction-dialog.component.html",
  })
  export class ImportTransactionDialogComponent implements OnInit {
    uploadedFiles = {
      transaction: null,
      vendor: null,
      reports: [],
      sections: {},
    };
    sections = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "14"];
    importError = false;
    constructor(
      public pdfService: PdfService,
      public datepipe: DatePipe,
      public formService: FormService,
      public sectionService: SectionService,
      private transactionService: TransactionService,
      private dialogRef: MatDialogRef<ImportTransactionDialogComponent>
    ) {}
  
    ngOnInit() {}
    removeVendorFile() {
      this.uploadedFiles.vendor = null;
    }
    addVendorFile(event) {
      let self = this;
      let input = event.target;
      for (let index = 0; index < input.files.length; index++) {
        let reader = new FileReader();
        reader.onload = () => {
  
          self.uploadedFiles.vendor = {
            name: input.files[index].name,
            data: reader.result.toString(),
          };
        };
        reader.readAsText(input.files[index]);
      }
    }
  
    removeReportsFile(i) {
      this.uploadedFiles.reports.splice(i, 1);
    }
  
    addReportsFile(event) {
      let self = this;
      let input = event.target;
      for (let index = 0; index < input.files.length; index++) {
        let reader = new FileReader();
        reader.onload = () => {
  
          self.uploadedFiles.reports.push({
            name: input.files[index].name,
            data: reader.result.toString(),
          });
        };
        reader.readAsText(input.files[index]);
      }
    }
  
    async save() {
      this.importError = false;
      try {
        if (this.uploadedFiles.transaction) {
          if (this.uploadedFiles.transaction.name.endsWith("_transaction.json")) {
            
            this.transactionService.importTransaction(this.uploadedFiles.transaction.data);
          }
        }
        if (this.uploadedFiles.reports) {
          this.uploadedFiles.reports.forEach((report) => {
            let section = report.name.split("_");
            section = section[section.length - 1];
            if (section) {
              section = section.split(".");
              if (section.length === 2) {
                const sectionNumber = section[0].replace("section", "");
                const type = section[1];
  
                if (type === "xml") {
                  this.formService.parseReportSectionData(
                    this.sectionService.sections[sectionNumber],
                    report.data,
                    "xml"
                  );
                } else if (type === "json") {
                  this.formService.parseReportSectionData(
                    this.sectionService.sections[sectionNumber],
                    report.data,
                    "json"
                  );
                }
              }
            }
          });
        }
        this.dialogRef.close(this.uploadedFiles);
      } catch (error) {
        console.log(error);
        this.importError = true;
      }
    }
  
    close() {
      this.dialogRef.close();
    }
  
  
    async extractZip(event) {
      let file =event.target.files[0];
  
      try {
        const zip = new JSZip();
        const zipContent = await zip.loadAsync(file);
        const jsonFiles = zipContent.files;
        Object.keys(jsonFiles).forEach(async filename => {
          if(filename.endsWith(".json")) {
            const fileContent = await jsonFiles[filename].async('string');
            if (filename.endsWith('_transaction.json')) {
              this.uploadedFiles.transaction = {
                name: filename,
                data: fileContent,
              };
            } else {
              this.uploadedFiles.reports.push({
                name: filename,
                data: fileContent,
              })
            }
          }
    
        });
      } catch (error) {
        console.error('Error reading ZIP file:', error);
      }
    }
    removeTransactionFile() {
      this.uploadedFiles.transaction = null;
    }
  }
  