import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  SimpleChanges,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { DatePipe } from "@angular/common";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { reject } from "q";
import { ConverterService } from "../../services/converter.service";
import { PdfService } from "../../services/pdf.service";
import { MatDialogRef } from "@angular/material/dialog";

pdfMake.vfs = pdfFonts.pdfMake.vfs;
@Component({
  selector: "app-image-dialog",
  templateUrl: "./image-dialog.component.html",
  styleUrls: ["./image-dialog.component.scss"],
})
export class ImageDialogComponent implements OnInit {
  file;
  title;
  constructor(
    private converterService: ConverterService,
    public pdfService: PdfService,
    public datepipe: DatePipe,
    public formService: FormService,
    public sectionService: SectionService,
    private dialogRef: MatDialogRef<ImageDialogComponent>
  ) {}

  ngOnInit() {}

  addFiles(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.file = {
          name: input.files[index].name,
          data: reader.result,
        };
      };
      reader.readAsDataURL(input.files[index]);
    }
  }

  async save() {
    this.dialogRef.close({ file: this.file, title: this.title });
  }

  close() {
    this.dialogRef.close();
  }
}
