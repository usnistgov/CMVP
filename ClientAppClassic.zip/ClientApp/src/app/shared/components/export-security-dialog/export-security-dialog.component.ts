import { Component, OnInit, Input, Inject } from "@angular/core";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { DatePipe } from "@angular/common";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import { reject } from "q";
import { ConverterService } from "../../services/converter.service";
import { PdfService } from "../../services/pdf.service";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
  selector: "app-export-security-dialog",
  templateUrl: "./export-security-dialog.component.html",
  styleUrls: ["./export-security-dialog.component.scss"],
})
export class ExportSecurityDialogComponent implements OnInit {
  selectedType = "json";
  @Input() tables;
  constructor(
    private converterService: ConverterService,
    public pdfService: PdfService,
    public datepipe: DatePipe,
    public formService: FormService,
    public sectionService: SectionService,
    private dialogRef: MatDialogRef<ExportSecurityDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data
  ) {}

  ngOnInit() {}

  async save() {
    let tables = [
      this.data[2],
      this.data[3],
      this.data[4],
      this.data[5],
      this.data[6],
      this.data[7],
      this.data[8],
      this.data[11],
      this.data[12],
      this.data[13],
      this.data[14],
      this.data[15],
      this.data[16],
      this.data[17],
      this.data[18],
      this.data[19],
      this.data[20],
    ];
    let results = [];
    tables.forEach((table, i) => {
      let tableData = JSON.parse(JSON.stringify(table.form.value));
      delete tableData["assessment"];
      delete tableData["references"];
      delete tableData["reval-assessment"];
      delete tableData["test-status"];
      delete tableData["notes"];
      delete tableData["section1-level"];
      delete tableData["section2-level"];
      delete tableData["section3-level"];
      delete tableData["section4-level"];
      delete tableData["section5-level"];
      delete tableData["section6-level"];
      delete tableData["section7-level"];
      delete tableData["section8-level"];
      delete tableData["section9-level"];
      delete tableData["section10-level"];
      delete tableData["section11-level"];
      delete tableData["section12-level"];

      let res = {};
      res[`Table${i + 2}`] = { ...tableData, position: table.position };
      results.push(res);
      // results.push({
      //   name: table.title,
      //   data: tableData
      // })
    });

    if (this.selectedType === "json") {
      this.saveAsJson(results);
    } else if (this.selectedType === "xml") {
      this.saveAsXml(results);
    }

    this.dialogRef.close();
  }

  saveAsJson(results) {
    const blob = new Blob([JSON.stringify(results)], { type: "text/json" });
    saveAs(blob, "security_policy.json");
  }

  saveAsXml(results) {
    const d = this.converterService.convertSecurityToXml(results);
    const blob = new Blob([d], { type: "text/xml" });
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );

    saveAs(blob, "security_policy.xml");
  }

  close() {
    this.dialogRef.close();
  }
}
