import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  SimpleChanges,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { DatePipe } from "@angular/common";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { reject } from "q";
import { ConverterService } from "../../services/converter.service";
import { PdfService } from "../../services/pdf.service";
import { environment } from "src/environments/environment";
import { ToastrService } from "ngx-toastr";
import { MatDialogRef } from "@angular/material/dialog";

pdfMake.vfs = pdfFonts.pdfMake.vfs;
@Component({
  selector: "app-submission-dialog",
  templateUrl: "./submission-dialog.component.html",
  styleUrls: ["./submission-dialog.component.scss"],
})
export class SubmissionDialogComponent implements OnInit {
  files = [];
  uploadedFiles = [];
  changeLetterFile;
  signatureFile;
  physicalReportFile;
  revalidationReportFile;
  entropyReportFile;
  commentsFile;

  selectedType = "json";
  constructor(
    private converterService: ConverterService,
    public pdfService: PdfService,
    public datepipe: DatePipe,
    public formService: FormService,
    public sectionService: SectionService,
    private dialogRef: MatDialogRef<SubmissionDialogComponent>,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.updateGeneratedFiles(this.selectedType);
  }
  updateGeneratedFiles(type) {
    const subLevel =
      this.sectionService.vendorFormGroup.getRawValue().module
        .Module_submission_code;
    if (
      subLevel === "FS" ||
      subLevel === "FCLC_OK" ||
      subLevel === "FCLC" ||
      subLevel === "sCMn"
    ) {
      this.files = [
        {
          label: "Assessment Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.pdf`,
            },
          ],
        },
        {
          label: "Vendor File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_vendor.${type}`,
            },
            // {
            //   name: `${this.formService.getFileName(
            //     this.sectionService.vendorFormGroup.getRawValue()
            //   )}_vendor.txt`
            // }
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_section<sectionNumber>.${type} (14 Files)`,
            },
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.txt`,
            },
          ],
        },
        // {
        //   label: "Security Policy",
        //   files: [
        //     {
        //       name: `${this.formService.getFileName(
        //         this.sectionService.vendorFormGroup.getRawValue()
        //       )}_140sp.pdf`
        //     }
        //   ]
        // },
        {
          label: "Draft Certificate",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_140crt.pdf`,
            },
          ],
        },
      ];
    } else if (
      subLevel === "IUTA" ||
      subLevel === "IUTB" ||
      subLevel === "IUTC" ||
      subLevel === "IUTR" ||
      subLevel === "IUTM" ||
      subLevel === "sHLD" ||
      subLevel === "DRPT" ||
      subLevel === "RQFG" ||
      subLevel === "STAT" ||
      subLevel === "OTHR"
    ) {
      this.files = [
        {
          label: "Vendor File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_vendor.${type}`,
            },
            // {
            //   name: `${this.formService.getFileName(
            //     this.sectionService.vendorFormGroup.getRawValue()
            //   )}_vendor.txt`
            // }
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_sectionB.${type}`,
            },
          ],
        },
      ];
    } else if (subLevel === "VU" || subLevel === "OE" || subLevel === "QU") {
      this.files = [
        {
          label: "Assessment Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.pdf`,
            },
          ],
        },
        {
          label: "Vendor File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_vendor.${type}`,
            },
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_section<sectionNumber>.${type} (14 Files)`,
            },
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.txt`,
            },
          ],
        },
      ];
    } else if (subLevel === "UP" || subLevel === "UPOEM") {
      this.files = [
        {
          label: "Assessment Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.pdf`,
            },
          ],
        },
        {
          label: "Vendor File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_vendor.${type}`,
            },
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_section<sectionNumber>.${type} (14 Files)`,
            },
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.txt`,
            },
          ],
        },
        {
          label: "Draft Certificate",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_140crt.pdf`,
            },
          ],
        },
      ];
    } else if (subLevel === "ENT" || subLevel === "EU") {
      this.files = [
        {
          label: "Vendor File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_vendor.${type}`,
            },
          ],
        },
      ];
    }
  }

  addFiles(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.uploadedFiles.push({
          name:
            this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            ) +
            "_" +
            input.files[index].name,
          data: reader.result,
        });
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }

  addChangeLetter(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.changeLetterFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_change_letter.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeChangeLetter() {
    this.changeLetterFile = null;
  }

  addSignature(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.signatureFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_signature.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeSignature() {
    this.signatureFile = null;
  }

  addPhysicalReport(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.physicalReportFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_physicalreport.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removePhysicalReport() {
    this.physicalReportFile = null;
  }
  addRevalidationReport(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        self.revalidationReportFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_revalidation_report.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeRevalidationReport() {
    this.revalidationReportFile = null;
  }
  addEntropyReport(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        self.entropyReportFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_entropyReport.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeEntropyReport() {
    this.entropyReportFile = null;
  }
  addComments(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        const splits = input.files[index].name.split(".");
        const ext = splits[splits.length - 1];
        self.commentsFile = {
          // name: "comments.pdf",
          // name: input.files[index].name,
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_modulecomments.${ext}`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeComments() {
    this.commentsFile = null;
  }

  async downloadPackage() {
    try {
      const self = this;
      const jszip = new JSZip();
      const folder = jszip.folder(
        self.formService.getFileName(
          self.sectionService.vendorFormGroup.getRawValue()
        )
      );
      const subLevel =
        this.sectionService.vendorFormGroup.getRawValue().module
          .Module_submission_code;
      if (
        subLevel === "FS" ||
        subLevel === "FCLC_OK" ||
        subLevel === "FCLC" ||
        subLevel === "sCMn"
      ) {
        // Report files
        if (this.selectedType === "json") {
          this.saveReportsAsJson(folder);
        } else if (this.selectedType === "xml") {
          this.saveReportsAsXml(folder);
        }
        this.saveReportsAsTxt(folder);
        await this.saveDraft(folder);
        await this.saveFormAsPdf(folder);
      } else if (
        subLevel === "IUTA" ||
        subLevel === "IUTB" ||
        subLevel === "IUTC" ||
        subLevel === "IUTR" ||
        subLevel === "IUTM" ||
        subLevel === "sHLD" ||
        subLevel === "DRPT" ||
        subLevel === "RQFG" ||
        subLevel === "STAT" ||
        subLevel === "OTHR"
      ) {
        if (this.selectedType === "json") {
          this.saveSectionBAsJson(folder);
        } else if (this.selectedType === "xml") {
          this.saveSectionBAsXml(folder);
        }
      }

      // Vendor files
      if (this.selectedType === "json") {
        this.saveFormAsJson(folder);
      } else if (this.selectedType === "xml") {
        this.saveFormAsXml(folder);
      }

      // User files
      this.addImportedFiles(jszip);

      jszip.generateAsync({ type: "blob" }).then(function (content) {
        // see FileSaver.js

        saveAs(
          content,
          `${self.formService.getFileName(
            self.sectionService.vendorFormGroup.getRawValue()
          )}.zip`
        );
      });
    } catch (error) {
      this.toastr.error("Error while creating package.");
    }
  }

  saveReportsAsTxt(jszip) {
    const txt = this.formService.prepareSectionInfoTxt();
    const blob = new Blob([txt], { type: "text/plain" });
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_report.txt", blob);
  }
  async saveDraft(jszip) {
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    const data = this.sectionService.getPdfDraft();

    const pdf = pdfMake.createPdf(data);
    const pdfBlob = await this.getBlob(pdf);

    jszip.file(filename + "_140crt.pdf", pdfBlob);
  }

  saveReportsAsJson(jszip) {
    for (let key in this.sectionService.sections) {
      let data = this.sectionService.sections[key].value;
      if (key === "B") {
        data["TEB.01.01"] = {
          ...data["TEB.01.01"],
          ...this.sectionService.securityPolicyContent,
        };
      }
      const blob = new Blob(
        [JSON.stringify(this.sectionService.sections[key].value)],
        { type: "text/json" }
      );
      const filename = this.formService.getFileName(
        this.sectionService.vendorFormGroup.getRawValue()
      );
      jszip.file(filename + `_report_section${key}.json`, blob);
    }
  }

  saveReportsAsXml(jszip) {
    let res = {};
    for (let key in this.sectionService.sections) {
      const blob = new Blob(
        [
          this.converterService.convertReportsToXml(
            this.sectionService.sections[key].value
          ),
        ],
        { type: "text/xml" }
      );
      const filename = this.formService.getFileName(
        this.sectionService.vendorFormGroup.getRawValue()
      );
      jszip.file(filename + `_report_section${key}.xml`, blob);
    }
  }
  saveFormAsJson(jszip) {
    if (
      this.sectionService.vendorFormGroup.value &&
      this.sectionService.vendorFormGroup.value["module"] &&
      this.sectionService.vendorFormGroup.value["module"].date
    ) {
      this.sectionService.vendorFormGroup.value["module"].date =
        this.datepipe.transform(
          this.sectionService.vendorFormGroup.value["module"].date,
          "yyyy-MM-dd"
        );
    }
    let date = JSON.parse(
      JSON.stringify(this.sectionService.vendorFormGroup.value["module"].date)
    );
    let data = this.sectionService.vendorFormGroup.getRawValue();
    data.references = this.sectionService.references.value;
    data.webCryptikVersion = environment.version;
    data.module.date = date;

    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_vendor.json", blob);
  }

  saveFormAsXml(jszip) {
    if (
      this.sectionService.vendorFormGroup.getRawValue() &&
      this.sectionService.vendorFormGroup.getRawValue()["module"] &&
      this.sectionService.vendorFormGroup.getRawValue()["module"].date
    ) {
      this.sectionService.vendorFormGroup.getRawValue()["module"].date =
        this.datepipe.transform(
          this.sectionService.vendorFormGroup.getRawValue()["module"].date,
          "yyyy-MM-dd"
        );
    }
    const blob = new Blob(
      [
        this.converterService.convertGeneralInfoToXml(
          this.sectionService.vendorFormGroup.getRawValue()
        ),
      ],
      { type: "text/xml" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_vendor.xml", blob);
  }

  async saveFormAsPdf(jszip) {
    const data = this.pdfService.getPdfData();
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );

    const pdf = pdfMake.createPdf(data);
    const pdfBlob = await this.getBlob(pdf);

    jszip.file(filename + "_report.pdf", pdfBlob);
  }

  async getBlob(pdf) {
    let promise = await new Promise((resolve, reject) => {
      pdf.getBlob((blob) => {
        resolve(blob);
      });
    }).catch((err) => {
      reject(err);
    });

    return promise;
  }

  addImportedFiles(jszip) {
    this.uploadedFiles.forEach((f) => {
      jszip.file(f.name, f.data, { binary: true });
    });
    if (this.changeLetterFile) {
      jszip.file(this.changeLetterFile.name, this.changeLetterFile.data, {
        binary: true,
      });
    }
    if (this.signatureFile) {
      jszip.file(this.signatureFile.name, this.signatureFile.data, {
        binary: true,
      });
    }
    if (this.physicalReportFile) {
      jszip.file(this.physicalReportFile.name, this.physicalReportFile.data, {
        binary: true,
      });
    }
    if (this.revalidationReportFile) {
      jszip.file(
        this.revalidationReportFile.name,
        this.revalidationReportFile.data,
        {
          binary: true,
        }
      );
    }
    if (this.entropyReportFile) {
      jszip.file(this.entropyReportFile.name, this.entropyReportFile.data, {
        binary: true,
      });
    }
    if (this.commentsFile) {
      jszip.file(this.commentsFile.name, this.commentsFile.data, {
        binary: true,
      });
    }
  }

  removeFile(i) {
    this.uploadedFiles.splice(i, 1);
  }
  async save() {
    await this.downloadPackage();
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }

  saveSectionBAsJson(jszip) {
    const blob = new Blob(
      [JSON.stringify(this.sectionService.sections["B"].value)],
      { type: "text/json" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + `_report_sectionB.json`, blob);
  }

  saveSectionBAsXml(jszip) {
    let res = {};
    const blob = new Blob(
      [
        this.converterService.convertReportsToXml(
          this.sectionService.sections["B"].value
        ),
      ],
      { type: "text/xml" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + `_report_sectionB.xml`, blob);
  }
}
