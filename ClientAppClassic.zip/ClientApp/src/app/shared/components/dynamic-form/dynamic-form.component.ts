import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  SimpleChanges,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MAT_DATE_FORMATS } from "@angular/material/core";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";

export const MY_FORMATS = {
  parse: {
    dateInput: "YYYY-MM-DD",
  },
  display: {
    dateInput: "YYYY-MM-DD",
    monthYearLabel: "YYYY",
    dateA11yLabel: "LL",
    monthYearA11yLabel: "YYYY",
  },
};

@Component({
  selector: "app-dynamic-form",
  templateUrl: "./dynamic-form.component.html",
  styleUrls: ["./dynamic-form.component.scss"],
  providers: [{ provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }],
})
export class DynamicFormComponent implements OnInit {
  @Input() formInputs = [];
  // @Input() vendorFormGroup: FormGroup;
  @Input() groupName;
  @Input() moduleType: String;
  @Input() validate;
  @Output()
  openSection: EventEmitter<String> = new EventEmitter<String>();
  validationResults;
  versionOptions = [
    {
      label: "1",
      value: "1",
    },
    {
      label: "2",
      value: "2",
    },
    {
      label: "3",
      value: "3",
    },
    {
      label: "4",
      value: "4",
    },
    {
      label: "5",
      value: "5",
    },
    {
      label: "6",
      value: "6",
    },
    {
      label: "7",
      value: "7",
    },
    {
      label: "8",
      value: "8",
    },
    {
      label: "9",
      value: "9",
    },
    {
      label: "10",
      value: "10",
    },
  ];
  constructor(
    public sectionService: SectionService,
    public formService: FormService
  ) {}

  ngOnInit() {}
  ngOnChanges(changes: SimpleChanges) {
    if (changes.validate) {
      if (changes.validate.currentValue) {
        this.findInvalidControls();
      } else {
        this.validationResults = null;
      }
    }
  }
  isVersionDisabled(version) {
    if (this.formService.updateVersionNumber) {
      const v = parseInt(version);
      if (v < this.formService.updateVersionNumber) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
  openSectionFn(section, link) {
    if (link) {
      this.openSection.emit(section);
    }
  }
  dateChange(type: string, event: MatDatepickerInputEvent<Date>) {}

  public findInvalidControls() {
    let invalid = [];
    const form = this.sectionService.vendorFormGroup.get(this.groupName);
    this.formInputs.forEach((input) => {
      if (form.get(input.controlName) && form.get(input.controlName).invalid) {
        invalid.push({ name: input.label });
      }
    });
    this.validationResults = invalid;
  }
}
