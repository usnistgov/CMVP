import { DatePipe, CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FlexLayoutModule } from "@angular/flex-layout";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { MatButtonModule } from "@angular/material/button";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatNativeDateModule } from "@angular/material/core";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatDialogModule } from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatSelectModule } from "@angular/material/select";
import { MatTooltipModule } from "@angular/material/tooltip";
import { NgxMatSelectSearchModule } from "ngx-mat-select-search";
import { ConfirmDialogComponent } from "./components/confirm-dialog/confirm-dialog.component";
import { ConfirmationDialogComponent } from "./components/confirmation-dialog/confirmation-dialog.component";
import { DisclaimerDialogComponent } from "./components/disclaimer-dialog/disclaimer-dialog.component";
import { DynamicFormComponent } from "./components/dynamic-form/dynamic-form.component";
import { ExportSecurityDialogComponent } from "./components/export-security-dialog/export-security-dialog.component";
import { ImageDialogComponent } from "./components/image-dialog/image-dialog.component";
import { ImportDialogComponent } from "./components/import-dialog/import-dialog.component";
import { SaveDialogComponent } from "./components/save-dialog/save-dialog.component";
import { SectionFormComponent } from "./components/section-form/section-form.component";
import { SharedSecurityPolicyComponent } from "./components/shared-security-policy/shared-security-policy.component";
import { SubmissionDialogComponent } from "./components/submission-dialog/submission-dialog.component";
import { TypeDialogComponent } from "./components/type-dialog/type-dialog.component";
import { MatExpansionModule } from "@angular/material/expansion";
import { MatInputModule } from "@angular/material/input";
import { MatGridListModule } from "@angular/material/grid-list";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatListModule } from "@angular/material/list";
import { MatRadioModule } from "@angular/material/radio";
import { MatMenuModule } from "@angular/material/menu";
import { MatCardModule } from "@angular/material/card";
import { VupComponent } from "./components/transactions/vup/vup.component";
import { ImportTransactionDialogComponent } from "./components/import-transaction-dialog/import-transaction-dialog.component";

@NgModule({
  declarations: [
    DynamicFormComponent,
    SharedSecurityPolicyComponent,
    ConfirmationDialogComponent,
    SectionFormComponent,
    SubmissionDialogComponent,
    SaveDialogComponent,
    ConfirmDialogComponent,
    ExportSecurityDialogComponent,
    ImageDialogComponent,
    ImportDialogComponent,
    DisclaimerDialogComponent,
    TypeDialogComponent,
    VupComponent,
    ImportTransactionDialogComponent
  ],
  providers: [DatePipe],
  imports: [
    CommonModule,
    MatExpansionModule,
    MatIconModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatGridListModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatRadioModule,
    NgxMatSelectSearchModule,
    FlexLayoutModule,
    MatMenuModule,
    MatDialogModule,
    MatCardModule,
    MatProgressSpinnerModule,
  ],
  exports: [
    CommonModule,
    MatExpansionModule,
    MatIconModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatGridListModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatRadioModule,
    NgxMatSelectSearchModule,
    FlexLayoutModule,
    DynamicFormComponent,
    SharedSecurityPolicyComponent,
    SectionFormComponent,
    MatMenuModule,
    MatDialogModule,
    MatCardModule,
    VupComponent
  ],
})
export class SharedModule {}
