import { Injectable } from "@angular/core";
import { DatePipe } from "@angular/common";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BehaviorSubject } from "rxjs";
import { filter, pairwise, tap } from "rxjs/operators";
import { SectionService } from "./section.service";

@Injectable({
    providedIn: "root",
})
export class TransactionService {
    form: FormGroup;
    lastConfirmedValue = new BehaviorSubject<any>(null);
    transactionTypeForm: FormGroup;
    revals = [];
    labs = [];
    usedCertificateNumber;
    cert;
    selectedReval;
    initialFormValues;
    deletedCollections = [];

    constructor(private _formBuilder: FormBuilder, public datepipe: DatePipe, private sectionService: SectionService) {
        this.transactionTypeForm = this._formBuilder.group({
            transactionCode: ["", Validators.required],
        });
        this.lastConfirmedValue.next(this.transactionTypeForm
            .get("transactionCode").value);

        this.transactionTypeForm.get("transactionCode").valueChanges.pipe(
            pairwise<string>(),
            filter(([prev, curr]) => prev !== null && prev !== '' && curr !== this.lastConfirmedValue.value),
            tap(([prev, curr]) => this.confirmChange(prev, curr))
        ).subscribe();
    }
    confirmChange(prevValue: string, currentValue: string): void {
        const confirmed = confirm('Do you want to proceed with this selection?');
        if (confirmed) {
            this.lastConfirmedValue.next(currentValue);
            this.clearData();
        } else {
            if (!this.lastConfirmedValue.value || this.lastConfirmedValue.value === '') {
                this.lastConfirmedValue.next(prevValue);
            }
            this.transactionTypeForm
                .get("transactionCode").setValue(this.lastConfirmedValue.value, { emitEvent: false }); // Revert the change without emitting an event
        }
    }
    clearData() {
        this.revals = [];
        this.labs = [];
        this.usedCertificateNumber = null;
        this.cert = null;
        this.selectedReval = null;
        this.initialFormValues = null;

    }

    populateVupForm(form, cert) {
        console.log(form, cert)
        const newCert = {
            vendorInfo: this.mapVendorToTransaction(cert.vendor),
            moduleInfo: this.mapModuleToTransaction(cert.module)
        }
            this.populateForm(form.get('payload').get('vendorInfo'), newCert.vendorInfo);
        this.populateForm(form.get('payload').get('moduleInfo'), newCert.moduleInfo);
    }
    mapModuleToTransaction(module) {
        return {
            description: module["module-description"],
            itar: module.itar,
            specialInstructions: module["special-instructions"]
        }
    }
    mapVendorToTransaction(vendor) {
        return {
            addressLine1: vendor['address-line-1'],
            addressLine2: vendor['address-line-2'],
            addressLine3: vendor['address-line-3'],
            city: vendor.city,
            contactName1: vendor['contact-name-1'],
            contactName2: vendor['contact-name-2'],
            contactName3: vendor['contact-name-3'],
            country: vendor.country,
            email1: vendor['email-1'],
            email2: vendor['email-2'],
            email3: vendor['email-3'],
            fax1: vendor['fax-1'],
            fax2: vendor['fax-2'],
            phone1: vendor['phone-1'],
            phone2: vendor['phone-2'],
            postalCode: vendor['postal-code'],
            productLink: vendor['product-link'],
            stateProvince: vendor['state-province'],
            vendorName: vendor['vendor-name'],
            website: vendor.website
            
        }
    }

    populateOeupForm(form, cert) {
        this.populateForm(form.get('payload').get('moduleInfo'), cert.moduleInfo);
        // this.br1Service.setBr1Data(cert);
        // this.br1Service.setCAVPData(cert.cavpCertSet);
        // this.br1Service.setSupplementalSettingList(cert.supplementalSettingList);
        // this.br1Service.populateSelectableAlgorithm();
    }

    populateForm(form, info) {
        Object.keys(form.controls).forEach(key => {
            if (info.hasOwnProperty(key)) {
                form.controls[key].setValue(info[key]);
            }
        });
    }
    formatDateForFileName(date) {
        if (date) {
            date = this.datepipe.transform(date, "yyMMddHHmm");
            return date;
        }
        return "";
    }

    async importTransaction(data: string) {
        // 1. get the transaction code to determine the type of transaction
        const transaction = JSON.parse(data);
        const transactionCode = transaction.transaction.transactionCode;
        switch (transactionCode) {
            case 'VUP':
                this.initializeVUPForm();
                break;
            default:
                break;
        }

        // 2. get the reval cert number and call getCert of the selected reval
        // 3. populate the form with the cert data
        this.selectedReval = transaction.payload.certificateNumber;
        await this.getCert();

        // 4. override the form with data from the imported transaction
        switch (transactionCode) {
            case 'VUP':
                this.importVUPForm(transaction);
                break;
            default:
                break;
        }




    }
    importVUPForm(transaction) {
        if (transaction.payload.vendorInfo) {
            this.populateForm(this.form.get('payload').get('vendorInfo'), transaction.payload.vendorInfo);
        }
        if (transaction.payload.moduleInfo) {
            this.populateForm(this.form.get('payload').get('moduleInfo'), transaction.payload.moduleInfo);
        }
        if (transaction.transaction.labInfo) {
            this.populateForm(this.form.get('transaction').get('labInfo'), transaction.transaction.labInfo);
        }
        this.form.get("payload").get("vendorInfo").get("addressLine3").setValue(transaction.payload.vendorInfo.addressLine3);
    }


    async getRevals(transaction) {
        let revals = await this.sectionService.getRevals(transaction);
        if (revals) {
            this.revals = <any[]>revals;
        }
    }
    async getLabs() {
        let labs = await this.sectionService.getLabs();
        if (labs) {
            this.labs = <any[]>labs;
        }
    }
    initializeVUPForm() {
        if (this.revals.length === 0) {
            this.getRevals("VUP");
            this.getLabs();
            this.form = this._formBuilder.group({
                schemaVersion: ['1.0.0'],
                transaction: this._formBuilder.group({
                    transactionCode: ['VUP'],
                    payloadFormat: ['NonBr1'],
                    labInfo: this._formBuilder.group({
                        labName: [''],
                        labCode: [{ value: '', disabled: true }],
                        labInternalId: [''],
                        signature1: [''],
                        title1: [''],
                        signature2: [''],
                        title2: [''],
                        signature3: [''],
                        title3: [''],
                        tester1Name: [''],
                        tester1Cvp: [''],
                        tester2Name: [''],
                        tester2Cvp: [''],
                        reviewer1Name: [''],
                        reviewer2Name: [''],
                    }),
                }),
                payload: this._formBuilder.group({
                    scenario: [''],
                    certificateNumber: [''],
                    moduleInfo: this._formBuilder.group({
                        description: [''],
                        itar: [false],
                        specialInstructions: ['']
                    }),
                    vendorInfo: this._formBuilder.group({
                        vendorName: [''],
                        addressLine1: [''],
                        addressLine2: [''],
                        addressLine3: [''],
                        city: [''],
                        stateProvince: [''],
                        postalCode: [''],
                        country: [''],
                        website: [''],
                        productLink: [''],
                        contactName1: [''],
                        email1: [''],
                        phone1: [''],
                        fax1: [''],
                        contactName2: [''],
                        email2: [''],
                        phone2: [''],
                        fax2: [''],
                        contactName3: [''],
                        email3: [''],
                        phone3: [''],
                        fax3: [''],
                    })
                })
            });
        }
        this.form
            .get("transaction")
            .get("labInfo")
            .get("labName")
            .valueChanges.subscribe((val) => {
                if (val) {
                    const lab = this.labs.find((l) => l.name == val);
                    if (lab) {
                        let code = lab.code;
                        this.form
                            .get("transaction")
                            .get("labInfo")
                            .get("labCode")
                            .setValue(code, { emitEvent: false });
                    }
                }
            });
    }
    async getCert() {
        let cert = await this.sectionService.getCert(this.selectedReval);
        if (cert) {
            this.cert = <any[]>cert;
            this.populateVupForm(this.form, cert);
            this.initialFormValues = this.form.get('payload').getRawValue();
            this.usedCertificateNumber = this.selectedReval;
        }
    }
}