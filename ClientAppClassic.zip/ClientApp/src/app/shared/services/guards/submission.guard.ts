import { Injectable } from "@angular/core";

import { FormService } from "../form.service";

@Injectable()
export class SubmissionGuard  {
  constructor(private formService: FormService) {}

  canActivate(): boolean {
    if (this.formService.type === "submission") {
      return true;
    } else {
      return false;
    }
  }
}
