import { Injectable } from "@angular/core";

import { FormService } from "../form.service";

@Injectable()
export class ArtifactGuard  {
  constructor(private formService: FormService) {}

  canActivate(): boolean {
    if (this.formService.type === "artifact") {
      return true;
    } else {
      return false;
    }
  }
}
