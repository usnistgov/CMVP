
import { Injectable } from '@angular/core';
import * as JsonToXML from "js2xmlparser";

@Injectable({
  providedIn: 'root'
})
export class ConverterService {
  constructor() { }

  convertGeneralInfoToXml(vendorInfo){
    const xml = JsonToXML.parse("general-info", vendorInfo)
    return xml;

  }
  convertReportsToXml(reports){
    const xml = JsonToXML.parse("section", reports)
    return xml;
  }

  convertSecurityToXml(data){
    const xml = JsonToXML.parse("Tables", data)
    return xml;
  }

}