import { Injectable } from "@angular/core";
import * as _ from "underscore";
import { sectionsList } from "../../../assets/sections-list";
import {
  UntypedFormGroup,
  UntypedFormControl,
  UntypedFormBuilder,
  Validators,
  UntypedFormArray,
} from "@angular/forms";
import { VendorForms } from "src/assets/vendor-forms";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: "root",
})
export class SectionService {
  sections = {};
  sectionsList = sectionsList;
  securityPolicyTables = {};
  hash;
  embodimentsMap = {
    "1": "Single Chip",
    "2": "Multi-Chip Embedded",
    "3": "Multi-Chip standalone",
  };
  vendorFormGroup: UntypedFormGroup;
  forms = VendorForms;
  securityPolicyContent = {
    entp: false,
    entnp: false,
  };
  table9AlgoOptions = [];
  filteredTable9AlgoOptions = [];
  references = new UntypedFormArray([]);
  cavpEndPoint = "/Endpoint/VendorValidations";
  entropyEndPoint = "/Endpoint/entropyvalidations";
  algoEndPoint = "/Endpoint/ValidationAlgorithms";
  labsEndPoint = "/Endpoint/Labs";
  CertsEndpoint = "/endpoint/certificatejson";
  RevalCertsEndpoint="/Endpoint/RevalidationCertificates"



  oeEndpoint =
    "https://csrc.nist.gov/csrcservices/public/cavp/RESTApi/ValidationJSON";

  constructor(private fb: UntypedFormBuilder, private http: HttpClient) {
    this.initModules();
    this.initSections();
  }

  initModules() {
    let group = {};

    this.forms.forEach((form) => {
      if (form.formInputs) {
        let g = {};
        form.formInputs.forEach((input) => {
          if (input.type === "checkboxes") {
            input.options.forEach((option) => {
              let validators = [];
              g[option.controlName] = new UntypedFormControl(false, validators);
            });
          } else if (input.type === "questionnaire") {
            input.questions.forEach((question) => {
              g[question.controlName] = new UntypedFormControl(
                question.default ? question.default : ""
              );
            });
          } else {
            let validators = [];
            if (input.required) {
              validators.push(Validators.required);
            }
            if (input.validators) {
              input.validators.forEach((validator) => {
                if (validator === "email") {
                  validators.push(Validators.email);
                }
                if (validator === "phone") {
                  validators.push(Validators.pattern("^([0-9]+-)*[0-9]+$"));
                }
                if (validator === "website") {
                  validators.push(
                    Validators.pattern(
                      "(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?"
                    )
                  );
                }
              });
            }

            if (input.maxLength) {
              validators.push(Validators.maxLength(input.maxLength));
            }
            if (input.minLength) {
              validators.push(Validators.minLength(input.minLength));
            }

            if (input.type === "checkbox") {
              g[input.controlName] = new UntypedFormControl(
                input.default ? input.default : false,
                validators
              );
            } else {
              g[input.controlName] = new UntypedFormControl(
                input.default !== undefined ? input.default : "",
                validators
              );
            }
            if (input.disabled) {
              g[input.controlName].disable();
            }
          }
        });
        group[form.group] = new UntypedFormGroup(g);
      }
    });
    this.vendorFormGroup = new UntypedFormGroup(group);
  }

  initSections() {
    this.sectionsList.forEach((section) => {
      let group = {};

      section.dtrs.forEach((row: any) => {
        let dtr = {};
        if (row.dtrId.startsWith("AS") || row.dtrId.startsWith("VE")) {
          dtr = {
            requirement: new UntypedFormControl(row.requirement),
            notes: new UntypedFormControl(""),
            "test-status": new UntypedFormControl("0"),
          };
        } else {
          dtr = {
            requirement: new UntypedFormControl(row.requirement),
            assessment: new UntypedFormControl(""),
            "test-status": new UntypedFormControl("0"),
            "reval-assessment": new UntypedFormControl(""),
            references: new UntypedFormControl([]),
            "page-number": new UntypedFormControl(""),
            tester: new UntypedFormControl(""),
            reviewer: new UntypedFormControl(""),
            review: new UntypedFormControl(""),
            "update-versions": new UntypedFormArray([]),
          };
        }
        if (row["tables"] && row["tables"].length > 0) {
          row["tables"].forEach((table) => {
            if (table["type"] === "select") {
              table.conditions.forEach((condition) => {
                // if (table.linkedTo) {
                //     dtr[condition.details.controlName] = this.vendorFormGroup.get(table.linkedTo).get(condition.details.controlName);
                // } else {
                //     dtr[condition.details.controlName] = new FormControl('');
                // }
                if (!this.securityPolicyTables[section.secId]) {
                  this.securityPolicyTables[section.secId] = [];
                }
                this.securityPolicyTables[section.secId].push({
                  question: row.dtrId,
                  details: condition.details,
                  type: "select",
                  title: table.title,
                  position: table.position,
                  form: table.linkedTo
                    ? this.vendorFormGroup.get(table.linkedTo)
                    : null,
                });
              });
            }
            if (table["type"] === "table") {
              table.conditions.forEach((condition) => {
                if (condition.details && condition.details.trs) {
                  condition.details.trs.forEach((tr) => {
                    tr.forEach((td) => {
                      if (td.type) {
                        if (table.linkedTo) {
                          // dtr[td.controlName] = this.vendorFormGroup
                          //   .get(table.linkedTo)
                          //   .get(td.controlName);
                        } else {
                          dtr[td.controlName] = new UntypedFormControl("");
                        }
                      }
                    });
                  });

                  if (!this.securityPolicyTables[section.secId]) {
                    this.securityPolicyTables[section.secId] = [];
                  }
                  this.securityPolicyTables[section.secId].push({
                    question: row.dtrId,
                    details: condition.details,
                    type: "table",
                    form: table.linkedTo
                      ? this.vendorFormGroup.get(table.linkedTo)
                      : null,
                    title: table.title,
                    position: table.position,
                  });
                }
              });
            }

            if (table["type"] === "dynamicTable") {
              table.conditions.forEach((condition) => {
                if (condition.details && condition.details.th) {
                  let formGroupObj = {};

                  condition.details.th.forEach((column) => {
                    if (column.type === "array") {
                      formGroupObj[column.controlName] = this.fb.array([]);
                    } else {
                      formGroupObj[column.controlName] = new UntypedFormControl("");
                    }
                  });
                  const formGroup = new UntypedFormGroup(formGroupObj);
                  dtr[condition.details.controlName] = this.fb.array([]);
                  if (!this.securityPolicyTables[section.secId]) {
                    this.securityPolicyTables[section.secId] = [];
                  }

                  this.securityPolicyTables[section.secId].push({
                    question: row.dtrId,
                    details: condition.details,
                    formGroup: formGroup,
                    type: "dynamicTable",
                    title: table.title,
                    position: table.position,
                    condition: condition.condition,
                  });
                }
              });
            }
          });
        }

        if (row["files"]) {
          dtr["files"] = this.fb.array([]);
          if (!this.securityPolicyTables[section.secId]) {
            this.securityPolicyTables[section.secId] = [];
          }
          this.securityPolicyTables[section.secId].push({
            question: row.dtrId,
            type: "files",
            title: row["files"].title,
            position: row["files"].position,
          });
        }
        group[row.dtrId] = new UntypedFormGroup(dtr);
      });
      this.sections[section.secId] = new UntypedFormGroup(group);
    });
  }

  checkStatus(sectionNumber, form) {
    // get drtids from form that have assessment and status passed. get dtrids of all level 1 from section. do difference, if result is empty then level passed
    const dtrids = _.filter(_.pairs(form.value), function (p) {
      return (
        p[1]["test-status"] === "Passed" &&
        p[1]["assessment"] &&
        p[1]["assessment"] !== ""
      );
    });
    const passed = _.map(dtrids, function (dtr) {
      return dtr[0];
    });
    const section = this.getSectionByNumber(sectionNumber);
    const level1 = _.where(section.dtrs, { level: "1" }).map(function (
      value: any
    ) {
      return value.dtrId;
    });

    const level1Res = _.difference(level1, passed);

    if (level1Res.length === 0) {
      const level2 = _.where(section.dtrs, { level: "2" }).map(function (
        value: any
      ) {
        return value.dtrId;
      });
      if (level2.length > 0) {
        // Check for level 2
      } else {
        return 1;
      }
    } else {
      return 0;
    }
  }

  getSectionByNumber(section): any {
    if (section) {
      return this.sectionsList.find((s) => s.secId === section.toString());
    }
  }

  unwrap(wrappedObject) {
    return wrappedObject.data;
  }

  getCAVPCerts(vendorName) {
    // const vendorName = this.vendorFormGroup.getRawValue().vendor["vendor-name"];
    if (vendorName && vendorName != "") {
      let promise = new Promise((resolve, reject) => {
        let apiURL = `${this.cavpEndPoint}/${vendorName}`;
        this.http
          .get(apiURL)
          .toPromise()
          .then((res) => {
            // Success
            resolve(this.unwrap(res));
          })
          .catch((err) => {
            console.log(err);
          });
      });
      return promise;
    } else {
      return Promise.resolve(null);
    }
  }
  getLabs() {
    let promise = new Promise((resolve, reject) => {
      // let apiURL = `${this.labsEndPoint}`;
      let apiURL = `assets/api-data/example-labs.json`;
      
      this.http
        .get(apiURL)
        .toPromise()
        .then((res) => {
          // Success
          resolve(this.unwrap(res));
        })
        .catch((err) => {
          console.log(err);
        });
    });
    return promise;
  }
  getEntropyCerts(vendorName) {
    if (vendorName && vendorName != "") {
      let promise = new Promise((resolve, reject) => {
        let apiURL = `${this.entropyEndPoint}/${vendorName}`;
        this.http
          .get(apiURL)
          .toPromise()
          .then((res) => {
            // Success
            resolve(this.unwrap(res));
          })
          .catch((err) => {
            console.log(err);
          });
      });
      return promise;
    } else {
      return Promise.resolve(null);
    }
  }

  getAlgorithms(prefix, number) {
    let promise = new Promise((resolve, reject) => {
      let apiURL = `${this.algoEndPoint}?prefix=${prefix}&number=${number}`;
      this.http
        .get(apiURL)
        .toPromise()
        .then((res) => {
          // Success
          resolve(this.unwrap(res));
        })
        .catch((err) => {
          console.log(err);
        });
    });
    return promise;
  }

  getOeAlgos(ValidationId) {
    let promise = new Promise((resolve, reject) => {
      let apiURL = `${this.oeEndpoint}/${ValidationId}`;
      this.http
        .get(apiURL)
        .toPromise()
        .then((res) => {
          // Success
          resolve(res);
        })
        .catch((err) => {
          console.log(err);
        });
    });
    return promise;
  }

  getCert(reval) {
    let promise = new Promise((resolve, reject) => {
      // let apiURL = `${this.CertsEndpoint}/${reval}`;
      let apiURL = `assets/api-data/example-certEndpoint.json`;
      this.http
        .get(apiURL)
        .toPromise()
        .then((res) => {
          // Success
          // resolve(this.unwrap(res));
          resolve(res);

        })
        .catch((err) => {
          console.log(err);
        });
    });
    return promise;
  }

  getRevals(transaction) {
    let promise = new Promise((resolve, reject) => {
      // let apiURL = `${this.RevalCertsEndpoint}/${transaction}`;
      let apiURL = `assets/api-data/example-revalCerts.json`;
      this.http
        .get(apiURL)
        .toPromise()
        .then((res) => {

          resolve(this.unwrap(res));
        })
        .catch((err) => {
          console.log(err);
        });
    });
    return promise;
  }



  getPdfDraft() {
    const americanFlag = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATYAAACjCAMAAAA3vsLfAAAAnFBMVEX///+yIjQ8O26vCybXoaWzKTmvECjQjpS7SlWxHC+wFCvJeoHCZGw2NWs6OW1xcJAwL2cuPXIdG1+5IC4sK2UvLmcpJ2Tx8fQjIWFFRHT4+Prp6e6+vszZ2eEhH2DGxtKurr9OTXrR0du3tsZfXoUVE1xTUn2goLVHRnWOjqd7e5loZ4uZmK8OC1qGhqGbm7EEAFiAgJ1ZWIC2Bh7cW2k+AAAJmklEQVR4nO1da5PiOBKs9eze3e6dZLVXlt/4BRhjmt5h/v9/Oz8ESKI3gq6LC0IeZcT0jKudH5QhQ6qU8oD3Orz9+YutACcbBk42FO6yUfLJyCj9pEg+KWLYq5AtrNjjEI/HRznCKnwUA8Neg2zEB/EwRp7n/KEowH9QA8W2XjbKxXsL20CoU4aI+D2K3mOhisREsIX2XXDl+cOybZeNJk1WpBBlUXUfJPGzLAMYfyiTi1TjTZAWWZPcdEOzbZfNo6yECb36pLFLNNWirTqJRD/fWDJ1tiHZ1svmebt8HI6vfz6RIAVIA/2DTPjjjflOqyHZK5AtiCAC4yuSbCFNYasPnFfjjdFGlw3Htl82MsBx16ZyvsgHMGyzJMnaUCuKtN0dYbtcSWOGZL/9+GYrrrKda+aJ834eDz1INU6CUnFa5oss0v1ZUFafidSC4tle+Ku1uD6ks3eXBp6X9F682f9y8WDztSySvid4theAvfAeQDl8f/Sz34HrS6XxSjSNuD1/X2OvTjYmjlAGoTZKGgYlHDU7SxMSjuMOQpLQr7PXJhvpZL1J7sWkkcXuPo/okC61dKBfZ69NNo9vZ5t6itVifJpq0VZdYpJwNrllSDDstcnmhbMjDYwRzn5WN2b0r8nP/qV/Zj3NXptsPIcSUuMTnKdj0ehnEH9ccprdkKfZq5FNOtgwPQd1JDtlVz97jOrgfFVDasLLPI5z6Sy+zF6LbGQrHemeeYT5y0VdL3/743cju0g/KxdMdFqECp/i2CuRjSaFUKbIIgb7+GD3opw8opCWg9x+YNhrkI0Q3gMZ4d1BCdkUxYZoWwfTPdBz7UYs23rZDkd/KKAbfP8+SLr1hwFgGPytUvT9oYNi8I+HuxhYtvWykUpeKd+LtC6WWnFQ/Kwvb1QauWj22y+/2Qr5kC42tWHaY7bY1NNGe8zY5PkN64pk299v8zaT5T/qy8ZxVT7C8GDs+1grtVUAlr0C2ULITtAYbe0z5DmcjbZ2A6cMDOuKY9svG+lLwffZdcTLX7zp47hvuFb0sj0XZa/7WRzbftnonk99xXoZ4rVhVo/LyLCW45bOv57cA79a16vJxbBXIJvWa4yjvbIOkv/cR+rnmfSzlYwwoNhrkO0GwvgBug3TN0JZ3MGBa1+VhLFdlu2YUXySvTLZyKnqSsg+uqq+b7vXVfeRQdlVJ3Xbveo6gK6r1G33Z9lrk40eigfrOn4yPVrXm8lVje/z7JXJ5tHN1NguzEXnJEenWVdPbCcxtgLHXplsHptyGoXhZ+Np4L3hZ8kkm5ERfJo9yfbjH7biUbY4i7YlaNtR48MH5TbKdDXYB/Q9fDAce0T4T2uhyCYdbF2GJD6ddD97OsUkLGulzzaOurxwfilDHNtbQQdkVqFb5k0y6cBkSsH3ZWph+l247OKx7qoUWf7g2OuQjQyp+uEugwlty5XLBSIdHrfdMWzrZaNc7Cq4xHqMlIspRiq4HiONL1DtzBAqim27bPRQNk0KWVN0qp8tmgagaQrVz3ZFk0HaNOXdhKHZtst2s6mVGt5g0qaqfTQaVnNNs65YtvWyeTSYGo3fY804MDJtuxPNYdB4bjQGusPAse2XzduMDw90RlphP92wN9IK3XhjZoRQcWz7ZaMXOIkm0vuzYZVut6kRyRVRI05w0Wcbjm2/bKQf+LievM6Naztt2tfUW2p0/xFTPvT6ohPHtl+2xbbKLlnYylFO11R+OFEZXp6vpckl32UnF8Veg2zak/TZoarjJ4eqRFl+UnyWvSrZCI99yHd6ZJSJXQ5+rFlXb/SzAKOfxbFHvP3LWnwSQk1H4xCZMdIIprrmZ6N0LI4/BvJ19iLbn7/biofZJo5zJrcSqp8V1VRLj+qTRpLZ5BYJwbAX2V7dbUTjkzTlcixKdxjLoSp9U/nTEOrT7NXJ1kIBkdAHLqKx2Boh1AGiCIxuyNPs1cgmhyrSbjcY34bEh2HXGYeqeF6EYZFzHHstslG5034ZuEc8uYt+WGJs5DiW+HChyo0eOceUxjLk8WX2WmTzZPRFO1R1bW+rh6pEIweuhFAR7BXIRillZwip9gaK8SpumvihGMKZmTUU23bZaHKpvQb6pL4oQ6z3hwPA4bCvlZFf6qSHxqsvd2OGZtsum0dLuWZQluh0OQc0hR+VGGkvbyxVY4ZkWy+bF882tUi0M3zxbFMrrfvIZpObHvVDVTj2248/bMWtTTk7UmPbfTP5WSODwGY/a7YpUWzyb2txbVMKSCsw+hnkCE0Dxgt3RAlVCqafRbHt74CQc0HiIZJjvMVIu82mM2KkJBpiUlzdGv1f2PbLRrfjDCCJjJFKk0+nIDyXH+mySPfj0p2K2wkrimevQDY1MerFWf0YI61l9EU7VNV1DM9eg2w3EMISOAntrBQlRJwgYeahqqAoAvNQ1ZPslclGzv25hezcn9QY6ak/Z9COv1KMmT8WAcYblZNWT7PXJhu9SJuqpviYtKmRus93Nbma8X2avTLZPBK3YzU7aCYsPGRjsY216RLPcQXd+D7PXpls3rgqB2jMGOl0xOxs+Fkx8YXhZ59lr002UcCxAP1dMtSD4giF7mfHh6/rzEju0+zVyHZ9iVNBWVCZMdIqYPQaM7r5WV8IX/ezz7PXIhtb+hc0meJWMjFKB/lKmSlbSsMlyUxuE4zcRUCwVyEb3croi/p8hZUWfZH92YevRCT77T/WQvbbQh5UUAuux0j5e5a9cz1GykUNVcDVBCCW/fbt1bvEaMgQap63ERRtqW27l3kOkOelFiMt2wKiNs/VECqSbX2bkkibWqrzhUub2qtPmnzpaXRRD1Uh2dbL5pFgsla93n0Mk6nRmOjBvs0kR6O/4BTJtl+2KUYK5kEgWk9Tozb87HwW7TGEimDbL9s4xopkmREj7cD3zUiuyDJSGWog2fbLRk5HQYNWDyiHbcJY0upZ730bUHHUT9Qi2fbLtgRDzRfTqTHSuxzXu1XdUOwVyPYKONl+OtnI62DzKsF/IV69ssTj/98rcHBwcHBwcHBwcHBwcHD4G7w6c20n4NUJfzsBr2742QknGwpONhScbCg42VBwsqHgZEPByYaCkw0FePVGrZ2AV7+byk68upPg4ODg4ODg4ODg4ODg8BPj1f9jlJ2AV///ZHbCtSlRcLKh4GRDwcmGgpMNBScbCk42FJxsKDjZUHCyoQC/OSDw6k6Cg4ODg4ODg4ODg4ODw0+MXx0QgG8OCLh+GwpONhScbCg42VBwsqHgZEPByYaCkw0FJxsKTjYUnGwo/Bc1+05RGpJWdwAAAABJRU5ErkJggg==`;
    const canadianFlag = `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0NDQ0NDQ0ODQ0NDQ0NDQ0NDRAODQ0NFREWFxURFRUYHSssGBslGxUVIT0hJikwLjo6FyEzOj8sOCktLjcBCgoKDg0OGhAQGC0mHiUyKy0tLSsrLS0rKy0tLS0tKy0tLSstKy0tKy0tLS0tLS0tLSstLS0tLSstLS0tLS0rLf/AABEIAKgBKwMBEQACEQEDEQH/xAAcAAEBAQEBAQEBAQAAAAAAAAAABwEGBQQDAgj/xAA+EAACAgEBAwkECAUDBQAAAAAAAQIDBBEFB3MGEhMhMVFhsrM0NUGBIjIzQnGRobEjUnKSwSWiwhQWgtHw/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAEFAwQGAgf/xAA0EQEAAQMBBAkDBAICAwAAAAAAAQIDBBEFMTNxBhIhMjRBgbHBIlHREyNhkRShQuFT8PH/2gAMAwEAAhEDEQA/AORKN9eAAAAAAAAAHRbvPfGBxLPRmZsfiQqdueBuenvC+ls+bgAAAAAAAAAAAAAAAAAAm++j2fC49vkNLN7sc3T9F+PXy+UoNB24AAAAAAAAAwPMtD0AAAAAAAAAOh3ev/WMHiWelMzY/EhU7b8Dc9PeF8jPUtnzfRuqAaoBqgGqAaoBqu8BqgGqAaoBqgGqAagNQGqAagNQJvvnl/AwuPb5EaWb3Y5uo6Lx+9Xy+UpNB2wAAAAAAAAAwPMtD0AAAAAAAAAOg3f+98HiWelMzY/EhU7b8Dc9Pddy2fOmjRDCEgQAAkAEj5s3OrodKslo77o0V+NjTaX+1nmaop3slqzXciqaY3RrPJ9JLH2gAkaBgAhASkAne+X7DC41vkRp5ndpdP0X41fL5Swr3aAAAAAAAAADCXmWkPQAAAAAAAAA6Dd/73weJZ6UzNj8SFTtvwNz0913LZ86ABAAAgJ1SEABK97O15LLxKKpaPFisl9yulL6HzSjr/5Ghl1z1oiPJ1/RzDiqxcuVx3vp9P8A32UvZmbHJx6ciH1b6oWrw50U9Pl2fI3qJ1pifu5S/am1dqtz5TMPpPTGEAAAACQAne+X7DC41vkRpZm6l0/RfjV8vlLDQdoAAAAAAAAAMJeZaQ9AAAAAAAAADoN3/vfB4lnpTM2PxIVW2/A3PT3hdy1fOQAEASBD58/OqxqpXXy5lUHHnT0bUdZJJvT4atdZEzFMayyWrVd2uKKI1l+lF0LIRsrlGcJLWM4NSjJd6a7SYmJ3IrpmierVGkv7lJRTbeiim232JLtY1eYiZ3P888oNovMzcnJ+FtsnDwrX0YL+1Ip66utXMvp+Bj/4+PRa+0dvOd6obp9pq7BljSf08SxpLXr6Kbcov8+cvkb2JXrRp9nH9Isb9PJ/UiOyuP8AcO3NtQPkntTHWRDF6WLyJqUlVF86ailq3LT6q/E89aNdNe1m/Qufpzd6v0x5vrJYdQAAJAgTvfL9hhca3yI08zdS6fovxq+XylhoO0AAAAAAAAAGB5loegAAAAAAAAB0G7/3vg8Sz0pmbH4kKnbfgbnp7wu5avnQAAAAh5/KLE/6jBy6fjZj2xX9XNen66Hi5T1qZhs4d2beRRX9phCdi7dzMGXOxb51ptOVfVKqf4wfV8+0qqLtVG59HysDHyo/dp9fP+3v7X3h5uViyxnXVS7Fzbba+drOD7YpP6uv4marKqqp0lV43R6xZv8A6vWmdN0S481nQPT5O7cv2dkLIo0fVzLK5a8y2D+6/wAu0927k251hpZ2DbzLX6dfpPnD2ttbwto5ScK5RxK31NUa9K142PrXy0M1eTXV/CuxOj+LY+qv6p/nd/X5enugxnPMy8iWsnXTGHOl1tysnq233/Q/U94ca1TVLV6TV9SzRajsjXX+v/qrm+4sCQkAgCU73y+z4XGt8iNLM7tLp+i/Gr5fKWGg7QAAAAAAAAAYHnRoegAAAAAAAAB0G7/3vg8Sz0pmbH4kKnbfgbnp7wu5avnQAAACdEGmvU+x9T/AhO5/nDaNHRZF9WmnRXW16d3Nm1/gpqo0ql9Uxq+vZpq+8RP+nznlnAAACsbncfTDyrdOuzJUNe+MIL/MmWGHT9Grh+k1euRRT9o95d+bbmwJAAAkTzfJ7PhcezyGlm92ObpujHGr5fKVmg7QCQAAAAAAAAAAAAAAAAAAAOg3fe98HiT9KZmx+JCp234G56e8LuWz5yEJCUASk+xN4NmPmZEclytwrcm6UGvpTx07Ho4/zR0+7+XcV9vJmK513Oxytgxdx6KrUaVxEa/aez3VPFya7q4W1TjZXYlKE4PWMov4pm/ExMaw5Cuiqiqaao0lCOW9PR7Vz46afx3P+5KX+Spvxpcqh9H2RX1sK3P8af08QxLIAAAha919XN2RQ9NHZZfN+P8AEaT/ACiWmLT+3D57t+vrZ1X8aezeWnLOrZ0XVVzbsyS+jXr9CpP71mn7dr8F1i9fiiNI3o2Xsi5mVdarso+/4fhuw2tbl4uRK+x2XRypOUpPr5soxa6vgup9XgRjXJrpnXeybfxaMe9TFuNImn2dkbCkAAE83yez4XHs8iNPN7sc3TdGOPXy+UrNB2gEgAAAAAAAAAAAAAAAAAAAdBu+98YPEn6UzNj8SFTtvwNz0913LaXzp4XKLlTRs2yqOTXd0dyfMurjGcFJPri1qmnpozDcvRbn6lhhbNuZlNU2pjWPKeyX443LrZFnZmRg+62uyv8AVx0IjItz5vdzYudR2zb/AKmJ9n47f5abPqxb5U5dN1zrnGmuqfPk7GtF2diT69X3EXL9EU9kveJsjJuXqYqtzEa9szGnZHNEEtCrfRHR8keVuRsyei1txZS1sob7O+cO6X6P9TPZvzbnTyVO09k282nXdXHn+X58uMynJ2hbk48+fVfXRNPTRp9GouLXwaa7CL9UVV6xul72PauWsWLVyNJiZ93gmFaAAAB33/eywtlYmHhtSynQnbb1OOO5Ny0XfPr/AAX6G3/kdS3FMb3LRsacrNrvXuyjXd5z/wBODtslOUpzk5zk3KUpNuUpPtbb7TUnt7ZdPTRTTHViNIjydhuy2/Tg5N1eTYqqciEf4kteZG2DemvdqpPr8EbWNciiqdVB0gwbmTbpqtU6zT5fxKlW8r9lQWrz8d/0z57/ACjqbn61uP8Ak5SnZeZVOkWp/rT3eXkbxtmRajS78mcmowjTTJc6T6klz9PieJyqN0b23TsHM0ma4imI+8/jV1tbbjFuLi2k3F9bi9Ow2FNMaTpqn2+T2fC49nkNPN7sc3S9GOPXy+UrNB2oAAAAAAAAAAAAAAAAAAAADoN3/vjB4lnpTM2PxIVO2/A3PT3hdy2fOni8sNiLaGDbRoulS6Shv7t0fq9fwT618zFdo69Ew3tnZc4uRTc8t08kCaabTTTTaafU012plRzfS4mJjWAJAkCAJAAAAAAAAgCXb7q9if8AUZcsuxa1YmnM17JZEl1fktX80bWJb1q632c30izf0rMWaZ7at/L/AL3LAWTiE83yez4XHs8hpZvdjm6boxxq+XylZoO1AAAAAAAAAAAAAAAAAAAAAdBu+974PEs9KZmx+JCp234G56e67lq+dAEQ3kbMWLtO1xWleSlkRS7FKTamv7k38yryKOrXzfQdg5E3sSInfT2fhy5gXQAAAAAAAAAAAAF55DbLWHs3Gra0nOCvt7+kn16fJaL5FtZo6tGj5ptTJ/yMquvy3Ryh7xmV6eb5PZ8Lj2eQ0s3uxzdN0Y49fL5Ss0HaASAAAAAAAAAAAAAAAAAAAB0G7/3vg8Sz0pmbH4kKnbfgbnp7ruWr508TbPKvAwZuvJtlCxLVQVNknJfBxemjXzMdd6ijvN/F2Zk5Ma2qdY5wkXLXlEtp5SthB11VQ6KpS+vJatuUtOzVvsK69ci5U7fZOz6sKzNNU6zM6vAMK1AAAAAAAAAAABjIkVzk5vGwnRVXmOWPdXCMJS5kp1T0WnOTjrp2djLK3lUaaVOFzej+RTcqqs/VE9v8w7fFyIXVwtrbcJrnRcoyg2u/SSTNqJ1jVQ10TRVNNW+HA75PZ8Lj2eQ083uxzdJ0X49zl8pWaDswJAAAAAAAAAAAAAAAAAAAA6Dd/wC98HiWelMzY/EhU7b8Dc9PeF3LZ86edtzYuNn1dDk1qa7YSXVZXL+aMvh/9qY67dNcaS2MbLu41fXtTp7T6I7ys5HZOzZOfXdit6Rvivq9ysX3X49n7FddsVUT/Dutm7YtZf0z9Nf2+/JzZgXIAAAAAAAAAAAP2wsS3IsjTRXK22b0jCC1b/8AS8SaaZmdIYr163ZpmuurSPurHI/d/Vi83IzebfkrSUK+2miX/KXj2d3eWFrGintq3uJ2lt2vI/bs/TR/ufw7k2nPp5vk9nwuPZ5DTze7HN0/RjjV8vlKzQdmBIAAAAAAAAAAAAAAAAAAAHQbv/fGDxLPSmZsfiQqdt+Buenuu5avnQSP5shGcXGUVKMk1KMknFp9qa+JExE7yJmJ1idJTTlfu5052Rs1dXXKeJr+tT/4v5dxpXsXzo/p1mzOkGmlvJns8qvz+U2lFpuLTjKLcZRaalGS7U0+xmjuddTVFUawwJAAAAAAAAPb5M8mMradmlK5lMXpZkTT6OHgv5peC/Qy2rNVyezd91bn7Us4dP1TrV5R5z+IWPk5ybxdm182iOs5JdJfPR22PxfwXguosrdqm3HY4LN2hezK+tcns+32eyZGkBKeb5PZ8Lj2eQ083uxzdN0Y49fL5Ss0HaASAAAAAAAAAAAAAAAAAAAB0G7/AN74PEs9KZmx+JCp234G56e67lq+dAAIAlzHK3kZjbSTsWlGUl9G+K6p9XUrF95ePb+xhu2Kbn8StdnbXu4c6b6Pt+Ea2ts27Dvnj3pK2trXmyUotPrTTXwaKyqiaKurLvsXJt5NqLlvdL5Dy2AAACAJAO65Ecg3mRhl5cubiy666oS+ncu9tfVj+v4G3Zxut9VU9jmdrbc/QmbNmPq85nyVjFxq6a41VQjXXBc2EILSMV4I34iIjSHGV3Kq6pqrnWZ836np5ABAnm+T2bC49nkNPN7sOm6Mcevl8pWaDtAJAAAAAAAAAAAAAAAAAAAA6Dd/73weJZ6UzNj8SFTtvwNz094XctnzoIAIAPk2rlToottrqnfZGP8ADqri5SnN9UVovhq+34dZFVUxEzEM1i3Fy5FNU6R5zKRR5DbZzLbLr6oVTtm7JzvuitZN/wAsdWvyK3/Hu1zrLto21gY1uLdudYjyiPmdIe1hbqZdTyM1LvjRU3/uk/8ABlpwp/5S0bvSj/x2/wC5/D3sLdvsurRzjbkNfG21pflDQzU4tuFbd6QZtfdmI5R+XH71tmY2JZhxxqK6IypuclXFR5zUo6Nv4mtlUxTNMUwu+j+Tev0XJuVTVMab5/iXeZHInZV8IuWJCEnFPnUuVT107fos2/8AHt1Ruc7RtfNtVTpcmY/nteHm7rMWWvQZV1TfYrFG2K/Z/qYqsOnylY2uk1+O/RE8uyXgZu7DPhq6bce9fBc6VU38mtP1MM4lcbtFla6S41Xfpqj/AHDo93VG0cGU8HMxbYUzcrKLVpZXXZ96DlFtJPtXjr3mfGiuj6aoVO3K8XJ0v2K413TG6f47Jd4bUOeAAACeb5PZ8Lj2eQ083uw6boxx6+XylZoO0AkAAAAAAAAAYBoGAaAAAAAADoN33vfB4lnpTM2PxIVO2/A3PT3XctXzoAAAgCQAAAle+j7bC4N/miaGZ3qXYdF+Hd9PlUafqw/oj+xvRuhyNfennL+yXkAEgQAAABO98vs+Fx7fIjTzO7HN03RjjV8vlLDRdqEAAAAAAAAEAAJYBoAAAAAAAHQbv/e+DxLPSmZsfiQqdt+Buenuu5avnQSBCAAEgAAEJXvo+2wuDf5omhm96l2PRjh3fRUafqQ/pj+xvRuhyNfennL+yXkAEgQAAABO98v2GFxrfIjTzO7S6fovxq+XylhoO0AAAAAAAAAGB5loegDANAAYBoAAB0G773vg8Sz0pmbH4kKnbfgbnp7ruWr50EgQBIANCAABCV75/tsLg3+aJoZvepdj0Y4d309pVGn6kP6Y/sb0bocjX3p5y/sl5AAAAAAATvfL9hhca3yI1Mzu0un6L8avl8pYV7tADANAAAAADAAeZaHoAAAAAAAAAdBu/wDe+DxLPSmZsfiQqdt+Buenuu5avnQAAEgQBIACB8mdsvFyXF5GNTe4pqLuqhY4p9qWq6uwiaYnfDLayLtqNLdc08p0fWiWIAAAAAkABAne+X7DC41vkRp5ndpdP0X41fL5Sw0HZgSAAAAAAAAYHmQPTQMA0DAAGgAMA6Ld6v8AWMHiWejMzY/EhU7b8Dc9PeF56PxLZ841b0fiDU6LxINTovEGp0fiDU6LxJNTo/EGp0fiDU6PxBqzo/EGrejBqdH4g1Oi8QanR+INTo/EGrOj8Qat6PxBqnO+aOlGFxrfIjSzO7DqOi8/vV8vlKjQdqAYBoADANAAAMDzL//Z`;
    const table5 = this.sections["B"].value["TEB.01.01"].approvedAlgorithms;
    const table0 =
      this.sections["B"].value["TEB.01.01"]
        .nonApprovedAllowedNoSecurityClaimedNotAllowed;
    const table6 =
      this.sections["B"].value["TEB.01.01"].vendorAffirmedApprovedAlgorithms;

    const table7 = this.sections["B"].value["TEB.01.01"].nonApprovedAlgorithms;
    const table8 =
      this.sections["B"].value["TEB.01.01"].nonApprovedAllowedNoSecurityClaimed;
    const table9 = this.sections["B"].value["TEB.01.01"].sfi;
    const table10 = this.sections["B"].value["TEB.01.01"].entropyCertificates;
    const table11 =
      this.sections["B"].value["TEB.01.01"]
        .nonApprovedAllowedNoSecurityClaimedNotAllowed;

    const levelsTables = this.securityPolicyTables["B"][0];
    let dd = {
      content: [
        {
          text: "FIPS 140-3",
          alignment: "center",
        },
        {
          text: "Validation Certificate",
          alignment: "center",
        },
        {
          text:
            "Certificate No. " +
            this.vendorFormGroup.getRawValue().module["validation-cert-number"],
          alignment: "center",
          margin: [0, 20],
        },
        {
          style: "tableExample",
          table: {
            widths: [200, "*", 200],
            body: [
              [
                {
                  image: americanFlag,
                  width: 200,
                },
                "",
                {
                  image: canadianFlag,
                  width: 200,
                },
              ],
              [
                "The National Institute of Standards and Technology of the United States of America",
                "",
                "The Canadian Centre for Cyber Security of the Government of Canada",
              ],
            ],
          },
        },
        {
          text: "The National Institute of Standards and Technology, as the United States FIPS 140-3 Cryptographic Module Validation Authority; and the Canadian Centre for Cyber Security, as the Canadian FIPS 140-3 Cryptographic Module Validation Authority; hereby validate the FIPS 140-3 testing results of the Cryptographic Module identified as:",
          alignment: "center",
          margin: [0, 5],
        },
        {
          text: this.vendorFormGroup.getRawValue().module["module-name"],
          alignment: "center",
          bold: true,
          fontSize: 14,
          margin: [0, 5],
        },
        {
          text: this.vendorFormGroup.getRawValue().module["certificate-caveat"],
          alignment: "center",
          margin: [0, 5],
        },

        {
          text: "in accordance with the Derived Test Requirements for FIPS 140-3, Security Requirements for Cryptographic Modules. FIPS 140-3 specifies the security requirements that are to be satisfied by a cryptographic module utilized within a security system protecting Sensitive Information (United States) or Protected Information (Canada) within computer and telecommunications systems (including voice systems).",
          alignment: "center",
          margin: [0, 5],
        },
        {
          text: "Products which use the above identified cryptographic module may be labeled as complying with the requirements of FIPS 140-3 so long as the product, throughout its life cycle, continues to use the validated version of the cryptographic module as specified in this certificate. The validation report contains additional details concerning test results. No reliability test has been performed and no warranty of the products by both agencies is either expressed or implied.",
          alignment: "center",
          margin: [0, 5],
        },
        {
          text: "This certificate includes details on the scope of conformance and validation authority signatures on the reverse.",
          alignment: "center",
          margin: [0, 5],
        },
        {
          text: this.vendorFormGroup.getRawValue().vendor["vendor-name"],
          alignment: "center",
          margin: [0, 5],
        },
        {
          text: `Hardware Version: ${
            this.vendorFormGroup.getRawValue().module["hardware-vs"]
          }`,
          alignment: "left",
        },
        {
          text: `Firmware Version: ${
            this.vendorFormGroup.getRawValue().module["firmware-vs"]
          } `,
          alignment: "left",
        },
        {
          text: `Software Version: ${
            this.vendorFormGroup.getRawValue().module["software-vs"]
          }`,
          alignment: "left",
        },

        {
          text: `(Embodiment: ${
            this.vendorFormGroup.getRawValue().module["Module_embodiment"]
              ? this.embodimentsMap[
                  this.vendorFormGroup.getRawValue().module["Module_embodiment"]
                ]
              : ""
          })`,
          alignment: "left",
        },
        {
          text: "Tested by the Cryptographic Module Testing accredited lab:",
          alignment: "left",
        },

        {
          text: `${this.vendorFormGroup.getRawValue().laboratory["lab-name"]}`,
          alignment: "left",
        },

        {
          text: `CRYPTIK version: ${environment.version}`,
          alignment: "left",
        },
        {
          text: `Tested Configuration(s): ${
            this.vendorFormGroup.getRawValue().module[
              "Module_operating_environment"
            ]
          }`,
          alignment: "left",
        },
        {
          text: "The testing levels are as follows:",
          alignment: "left",
          pageBreak: "after", // or after
        },
        {
          text: levelsTables.title.split(":")[1],
          alignment: "center",
          bold: true,
        },
        this.buildLevelsTablesPdf(levelsTables),
        {
          text: `Overall Level Achieved: ${this.securityPolicyTables["B"][0].form.value["overall-level"]}`,
          alignment: "center",
        },

        {
          text: "Approved Algorithms",
          alignment: "center",
        },

        this.buildTable5Pdf(table5),
        {
          text: "Vendor affirmed approved algorithms",
          alignment: "center",
        },
        this.buildTable6Pdf(table6),
        {
          text: "Non-Approved Algorithms Allowed in the Approved Mode of Operation",
          alignment: "center",
        },
        this.buildTable7Pdf(table7),

        {
          text: "Non-Approved Allowed in the Approved Mode of Operation with No Security Claimed",
          alignment: "center",
        },
        this.buildTable8Pdf(table8),
        {
          text: "Security function implementation (SFI)",
          alignment: "center",
        },
        this.buildTable9Pdf(table9),
        {
          text: "Entropy Certificates",
          alignment: "center",
        },
        this.buildTable10Pdf(table10),
        {
          text: "Non-Approved Algorithms Not Allowed In the approved Mode of Operation",
          alignment: "center",
        },
        this.buildTable11Pdf(table11),
        {
          style: "tableExample",
          margin: [0, 20, 0, 10],
          table: {
            widths: [200, "*", 200],
            body: [
              [
                [
                  {
                    text: "Signed on behalf of the Government of the United",
                    alignment: "center",
                  },
                  {
                    text: "Signature:________________________",
                  },
                  {
                    text: "Dated:________________________",
                  },
                  {
                    text: "Chief, Computer Security Division National Institute of Standards and Technology",
                    alignment: "center",
                  },
                ],
                "",
                [
                  {
                    text: "Signed on behalf of the Government of Canada",
                    alignment: "center",
                  },
                  {
                    text: "Signature:________________________",
                  },
                  {
                    text: "Dated:________________________",
                  },
                  {
                    text: "Director, Industry Program Group Canadian Centre for Cyber Security",
                    alignment: "center",
                  },
                ],
              ],
            ],
          },
        },
      ],
      styles: {},
      defaultStyle: {
        fontSize: 11,
      },
    };
    return dd;
  }

  buildLevelsTablesPdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [],
          },
        },
        { width: "*", text: "" },
      ],
    };
    t.columns[1].table.body.push(table.details.th);
    table.details.trs.forEach((tr) => {
      let row = [];
      tr.forEach((td) => {
        if (td.type) {
          row.push(table.form.value[td.controlName]);
        } else {
          row.push(td.label);
        }
      });
      t.columns[1].table.body.push(row);
    });
    return t;
  }
  buildTable0Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [["Algorithm/Function", "Use/Function"]],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      t.columns[1].table.body.push([row["algorithm"], row["useFunction"]]);
    });
    return t;
  }
  buildTable5Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [
              [
                "Vendor name",
                "CAVP Cert",
                "Algorithm and Standard",
                "Mode/Method",
                "Description/Key Size/Key Strength",
                "Use/Function",
              ],
            ],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      t.columns[1].table.body.push([
        row["vendorName"],
        row["CAVPCert"],
        row["algorithmAndStandard"],
        row["modeMethod"],
        row["descriptionKeySizeKeyStrength"],
        row["useFunction"],
      ]);
    });
    return t;
  }
  buildTable6Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [["Algorithm", "Caveat", "Use/Function"]],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      t.columns[1].table.body.push([
        row["algorithm"],
        row["caveat"],
        row["useFunction"],
      ]);
    });
    return t;
  }

  buildTable7Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [["Algorithm", "Caveat"]],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      t.columns[1].table.body.push([row["algorithm"], row["caveat"]]);
    });
    return t;
  }
  buildTable8Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [["Algorithm", "Caveat", "Use/Function"]],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      t.columns[1].table.body.push([
        row["algorithm"],
        row["caveat"],
        row["useFunction"],
      ]);
    });
    return t;
  }
  buildTable9Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [
              [
                "Name",
                "Type",
                "Description",
                "SF Properties [O]",
                "Algorithms/CAVP Cert",
              ],
            ],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      let algos = "";
      if (row["algorithms"]) {
        row["algorithms"].forEach((algo) => {
          algos += `${algo.label} `;
        });
      }
      t.columns[1].table.body.push([
        row["name"],
        row["type"],
        row["description"],
        row["sfProperties"],
        algos,
      ]);
    });
    return t;
  }
  buildTable10Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [["Vendor Name", "Certificate Number"]],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      t.columns[1].table.body.push([row["vendorName"], row["entropyCert"]]);
    });
    return t;
  }
  buildTable11Pdf(table) {
    let t = {
      margin: [0, 20, 0, 10],
      columns: [
        { width: "*", text: "" },
        {
          width: "auto",
          table: {
            body: [["Algorithm/Function", "Use/Function"]],
          },
        },
        { width: "*", text: "" },
      ],
    };
    table.forEach((row) => {
      t.columns[1].table.body.push([row["algorithm"], row["useFunction"]]);
    });
    return t;
  }
  // generateDraft() {
  //   const table5 = this.sections["B"].value["TEB.01.01"].approvedAlgorithms;
  //   const table6 = this.sections["B"].value["TEB.01.01"].nonApprovedAlgorithms;
  //   const table0 = this.securityPolicyTables["B"][10];
  //   const americanFlag = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATYAAACjCAMAAAA3vsLfAAAAnFBMVEX///+yIjQ8O26vCybXoaWzKTmvECjQjpS7SlWxHC+wFCvJeoHCZGw2NWs6OW1xcJAwL2cuPXIdG1+5IC4sK2UvLmcpJ2Tx8fQjIWFFRHT4+Prp6e6+vszZ2eEhH2DGxtKurr9OTXrR0du3tsZfXoUVE1xTUn2goLVHRnWOjqd7e5loZ4uZmK8OC1qGhqGbm7EEAFiAgJ1ZWIC2Bh7cW2k+AAAJmklEQVR4nO1da5PiOBKs9eze3e6dZLVXlt/4BRhjmt5h/v9/Oz8ESKI3gq6LC0IeZcT0jKudH5QhQ6qU8oD3Orz9+YutACcbBk42FO6yUfLJyCj9pEg+KWLYq5AtrNjjEI/HRznCKnwUA8Neg2zEB/EwRp7n/KEowH9QA8W2XjbKxXsL20CoU4aI+D2K3mOhisREsIX2XXDl+cOybZeNJk1WpBBlUXUfJPGzLAMYfyiTi1TjTZAWWZPcdEOzbZfNo6yECb36pLFLNNWirTqJRD/fWDJ1tiHZ1svmebt8HI6vfz6RIAVIA/2DTPjjjflOqyHZK5AtiCAC4yuSbCFNYasPnFfjjdFGlw3Htl82MsBx16ZyvsgHMGyzJMnaUCuKtN0dYbtcSWOGZL/9+GYrrrKda+aJ834eDz1INU6CUnFa5oss0v1ZUFafidSC4tle+Ku1uD6ks3eXBp6X9F682f9y8WDztSySvid4theAvfAeQDl8f/Sz34HrS6XxSjSNuD1/X2OvTjYmjlAGoTZKGgYlHDU7SxMSjuMOQpLQr7PXJhvpZL1J7sWkkcXuPo/okC61dKBfZ69NNo9vZ5t6itVifJpq0VZdYpJwNrllSDDstcnmhbMjDYwRzn5WN2b0r8nP/qV/Zj3NXptsPIcSUuMTnKdj0ehnEH9ccprdkKfZq5FNOtgwPQd1JDtlVz97jOrgfFVDasLLPI5z6Sy+zF6LbGQrHemeeYT5y0VdL3/743cju0g/KxdMdFqECp/i2CuRjSaFUKbIIgb7+GD3opw8opCWg9x+YNhrkI0Q3gMZ4d1BCdkUxYZoWwfTPdBz7UYs23rZDkd/KKAbfP8+SLr1hwFgGPytUvT9oYNi8I+HuxhYtvWykUpeKd+LtC6WWnFQ/Kwvb1QauWj22y+/2Qr5kC42tWHaY7bY1NNGe8zY5PkN64pk299v8zaT5T/qy8ZxVT7C8GDs+1grtVUAlr0C2ULITtAYbe0z5DmcjbZ2A6cMDOuKY9svG+lLwffZdcTLX7zp47hvuFb0sj0XZa/7WRzbftnonk99xXoZ4rVhVo/LyLCW45bOv57cA79a16vJxbBXIJvWa4yjvbIOkv/cR+rnmfSzlYwwoNhrkO0GwvgBug3TN0JZ3MGBa1+VhLFdlu2YUXySvTLZyKnqSsg+uqq+b7vXVfeRQdlVJ3Xbveo6gK6r1G33Z9lrk40eigfrOn4yPVrXm8lVje/z7JXJ5tHN1NguzEXnJEenWVdPbCcxtgLHXplsHptyGoXhZ+Np4L3hZ8kkm5ERfJo9yfbjH7biUbY4i7YlaNtR48MH5TbKdDXYB/Q9fDAce0T4T2uhyCYdbF2GJD6ddD97OsUkLGulzzaOurxwfilDHNtbQQdkVqFb5k0y6cBkSsH3ZWph+l247OKx7qoUWf7g2OuQjQyp+uEugwlty5XLBSIdHrfdMWzrZaNc7Cq4xHqMlIspRiq4HiONL1DtzBAqim27bPRQNk0KWVN0qp8tmgagaQrVz3ZFk0HaNOXdhKHZtst2s6mVGt5g0qaqfTQaVnNNs65YtvWyeTSYGo3fY804MDJtuxPNYdB4bjQGusPAse2XzduMDw90RlphP92wN9IK3XhjZoRQcWz7ZaMXOIkm0vuzYZVut6kRyRVRI05w0Wcbjm2/bKQf+LievM6Naztt2tfUW2p0/xFTPvT6ohPHtl+2xbbKLlnYylFO11R+OFEZXp6vpckl32UnF8Veg2zak/TZoarjJ4eqRFl+UnyWvSrZCI99yHd6ZJSJXQ5+rFlXb/SzAKOfxbFHvP3LWnwSQk1H4xCZMdIIprrmZ6N0LI4/BvJ19iLbn7/biofZJo5zJrcSqp8V1VRLj+qTRpLZ5BYJwbAX2V7dbUTjkzTlcixKdxjLoSp9U/nTEOrT7NXJ1kIBkdAHLqKx2Boh1AGiCIxuyNPs1cgmhyrSbjcY34bEh2HXGYeqeF6EYZFzHHstslG5034ZuEc8uYt+WGJs5DiW+HChyo0eOceUxjLk8WX2WmTzZPRFO1R1bW+rh6pEIweuhFAR7BXIRillZwip9gaK8SpumvihGMKZmTUU23bZaHKpvQb6pL4oQ6z3hwPA4bCvlZFf6qSHxqsvd2OGZtsum0dLuWZQluh0OQc0hR+VGGkvbyxVY4ZkWy+bF882tUi0M3zxbFMrrfvIZpObHvVDVTj2248/bMWtTTk7UmPbfTP5WSODwGY/a7YpUWzyb2txbVMKSCsw+hnkCE0Dxgt3RAlVCqafRbHt74CQc0HiIZJjvMVIu82mM2KkJBpiUlzdGv1f2PbLRrfjDCCJjJFKk0+nIDyXH+mySPfj0p2K2wkrimevQDY1MerFWf0YI61l9EU7VNV1DM9eg2w3EMISOAntrBQlRJwgYeahqqAoAvNQ1ZPslclGzv25hezcn9QY6ak/Z9COv1KMmT8WAcYblZNWT7PXJhu9SJuqpviYtKmRus93Nbma8X2avTLZPBK3YzU7aCYsPGRjsY216RLPcQXd+D7PXpls3rgqB2jMGOl0xOxs+Fkx8YXhZ59lr002UcCxAP1dMtSD4giF7mfHh6/rzEju0+zVyHZ9iVNBWVCZMdIqYPQaM7r5WV8IX/ezz7PXIhtb+hc0meJWMjFKB/lKmSlbSsMlyUxuE4zcRUCwVyEb3croi/p8hZUWfZH92YevRCT77T/WQvbbQh5UUAuux0j5e5a9cz1GykUNVcDVBCCW/fbt1bvEaMgQap63ERRtqW27l3kOkOelFiMt2wKiNs/VECqSbX2bkkibWqrzhUub2qtPmnzpaXRRD1Uh2dbL5pFgsla93n0Mk6nRmOjBvs0kR6O/4BTJtl+2KUYK5kEgWk9Tozb87HwW7TGEimDbL9s4xopkmREj7cD3zUiuyDJSGWog2fbLRk5HQYNWDyiHbcJY0upZ730bUHHUT9Qi2fbLtgRDzRfTqTHSuxzXu1XdUOwVyPYKONl+OtnI62DzKsF/IV69ssTj/98rcHBwcHBwcHBwcHBwcHD4G7w6c20n4NUJfzsBr2742QknGwpONhScbCg42VBwsqHgZEPByYaCkw0FePVGrZ2AV7+byk68upPg4ODg4ODg4ODg4ODg8BPj1f9jlJ2AV///ZHbCtSlRcLKh4GRDwcmGgpMNBScbCk42FJxsKDjZUHCyoQC/OSDw6k6Cg4ODg4ODg4ODg4ODw0+MXx0QgG8OCLh+GwpONhScbCg42VBwsqHgZEPByYaCkw0FJxsKTjYUnGwo/Bc1+05RGpJWdwAAAABJRU5ErkJggg==`;
  //   const canadianFlag = `data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0NDQ0NDQ0ODQ0NDQ0NDQ0NDRAODQ0NFREWFxURFRUYHSssGBslGxUVIT0hJikwLjo6FyEzOj8sOCktLjcBCgoKDg0OGhAQGC0mHiUyKy0tLSsrLS0rKy0tLS0tKy0tLSstKy0tKy0tLS0tLS0tLSstLS0tLSstLS0tLS0rLf/AABEIAKgBKwMBEQACEQEDEQH/xAAcAAEBAQEBAQEBAQAAAAAAAAAABwEGBQQDAgj/xAA+EAACAgEBAwkECAUDBQAAAAAAAQIDBBEFB3MGEhMhMVFhsrM0NUGBIjIzQnGRobEjUnKSwSWiwhQWgtHw/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAEFAwQGAgf/xAA0EQEAAQMBBAkDBAICAwAAAAAAAQIDBBEFMTNxBhIhMjRBgbHBIlHREyNhkRShQuFT8PH/2gAMAwEAAhEDEQA/AORKN9eAAAAAAAAAHRbvPfGBxLPRmZsfiQqdueBuenvC+ls+bgAAAAAAAAAAAAAAAAAAm++j2fC49vkNLN7sc3T9F+PXy+UoNB24AAAAAAAAAwPMtD0AAAAAAAAAOh3ev/WMHiWelMzY/EhU7b8Dc9PeF8jPUtnzfRuqAaoBqgGqAaoBqu8BqgGqAaoBqgGqAagNQGqAagNQJvvnl/AwuPb5EaWb3Y5uo6Lx+9Xy+UpNB2wAAAAAAAAAwPMtD0AAAAAAAAAOg3f+98HiWelMzY/EhU7b8Dc9Pddy2fOmjRDCEgQAAkAEj5s3OrodKslo77o0V+NjTaX+1nmaop3slqzXciqaY3RrPJ9JLH2gAkaBgAhASkAne+X7DC41vkRp5ndpdP0X41fL5Swr3aAAAAAAAAADCXmWkPQAAAAAAAAA6Dd/73weJZ6UzNj8SFTtvwNz0913LZ86ABAAAgJ1SEABK97O15LLxKKpaPFisl9yulL6HzSjr/5Ghl1z1oiPJ1/RzDiqxcuVx3vp9P8A32UvZmbHJx6ciH1b6oWrw50U9Pl2fI3qJ1pifu5S/am1dqtz5TMPpPTGEAAAACQAne+X7DC41vkRpZm6l0/RfjV8vlLDQdoAAAAAAAAAMJeZaQ9AAAAAAAAADoN3/vfB4lnpTM2PxIVW2/A3PT3hdy1fOQAEASBD58/OqxqpXXy5lUHHnT0bUdZJJvT4atdZEzFMayyWrVd2uKKI1l+lF0LIRsrlGcJLWM4NSjJd6a7SYmJ3IrpmierVGkv7lJRTbeiim232JLtY1eYiZ3P888oNovMzcnJ+FtsnDwrX0YL+1Ip66utXMvp+Bj/4+PRa+0dvOd6obp9pq7BljSf08SxpLXr6Kbcov8+cvkb2JXrRp9nH9Isb9PJ/UiOyuP8AcO3NtQPkntTHWRDF6WLyJqUlVF86ailq3LT6q/E89aNdNe1m/Qufpzd6v0x5vrJYdQAAJAgTvfL9hhca3yI08zdS6fovxq+XylhoO0AAAAAAAAAGB5loegAAAAAAAAB0G7/3vg8Sz0pmbH4kKnbfgbnp7wu5avnQAAAAh5/KLE/6jBy6fjZj2xX9XNen66Hi5T1qZhs4d2beRRX9phCdi7dzMGXOxb51ptOVfVKqf4wfV8+0qqLtVG59HysDHyo/dp9fP+3v7X3h5uViyxnXVS7Fzbba+drOD7YpP6uv4marKqqp0lV43R6xZv8A6vWmdN0S481nQPT5O7cv2dkLIo0fVzLK5a8y2D+6/wAu0927k251hpZ2DbzLX6dfpPnD2ttbwto5ScK5RxK31NUa9K142PrXy0M1eTXV/CuxOj+LY+qv6p/nd/X5enugxnPMy8iWsnXTGHOl1tysnq233/Q/U94ca1TVLV6TV9SzRajsjXX+v/qrm+4sCQkAgCU73y+z4XGt8iNLM7tLp+i/Gr5fKWGg7QAAAAAAAAAYHnRoegAAAAAAAAB0G7/3vg8Sz0pmbH4kKnbfgbnp7wu5avnQAAACdEGmvU+x9T/AhO5/nDaNHRZF9WmnRXW16d3Nm1/gpqo0ql9Uxq+vZpq+8RP+nznlnAAACsbncfTDyrdOuzJUNe+MIL/MmWGHT9Grh+k1euRRT9o95d+bbmwJAAAkTzfJ7PhcezyGlm92ObpujHGr5fKVmg7QCQAAAAAAAAAAAAAAAAAAAOg3fe98HiT9KZmx+JCp234G56e8LuWz5yEJCUASk+xN4NmPmZEclytwrcm6UGvpTx07Ho4/zR0+7+XcV9vJmK513Oxytgxdx6KrUaVxEa/aez3VPFya7q4W1TjZXYlKE4PWMov4pm/ExMaw5Cuiqiqaao0lCOW9PR7Vz46afx3P+5KX+Spvxpcqh9H2RX1sK3P8af08QxLIAAAha919XN2RQ9NHZZfN+P8AEaT/ACiWmLT+3D57t+vrZ1X8aezeWnLOrZ0XVVzbsyS+jXr9CpP71mn7dr8F1i9fiiNI3o2Xsi5mVdarso+/4fhuw2tbl4uRK+x2XRypOUpPr5soxa6vgup9XgRjXJrpnXeybfxaMe9TFuNImn2dkbCkAAE83yez4XHs8iNPN7sc3TdGOPXy+UrNB2gEgAAAAAAAAAAAAAAAAAAAdBu+98YPEn6UzNj8SFTtvwNz0913LaXzp4XKLlTRs2yqOTXd0dyfMurjGcFJPri1qmnpozDcvRbn6lhhbNuZlNU2pjWPKeyX443LrZFnZmRg+62uyv8AVx0IjItz5vdzYudR2zb/AKmJ9n47f5abPqxb5U5dN1zrnGmuqfPk7GtF2diT69X3EXL9EU9kveJsjJuXqYqtzEa9szGnZHNEEtCrfRHR8keVuRsyei1txZS1sob7O+cO6X6P9TPZvzbnTyVO09k282nXdXHn+X58uMynJ2hbk48+fVfXRNPTRp9GouLXwaa7CL9UVV6xul72PauWsWLVyNJiZ93gmFaAAAB33/eywtlYmHhtSynQnbb1OOO5Ny0XfPr/AAX6G3/kdS3FMb3LRsacrNrvXuyjXd5z/wBODtslOUpzk5zk3KUpNuUpPtbb7TUnt7ZdPTRTTHViNIjydhuy2/Tg5N1eTYqqciEf4kteZG2DemvdqpPr8EbWNciiqdVB0gwbmTbpqtU6zT5fxKlW8r9lQWrz8d/0z57/ACjqbn61uP8Ak5SnZeZVOkWp/rT3eXkbxtmRajS78mcmowjTTJc6T6klz9PieJyqN0b23TsHM0ma4imI+8/jV1tbbjFuLi2k3F9bi9Ow2FNMaTpqn2+T2fC49nkNPN7sc3S9GOPXy+UrNB2oAAAAAAAAAAAAAAAAAAAADoN3/vjB4lnpTM2PxIVO2/A3PT3hdy2fOni8sNiLaGDbRoulS6Shv7t0fq9fwT618zFdo69Ew3tnZc4uRTc8t08kCaabTTTTaafU012plRzfS4mJjWAJAkCAJAAAAAAAAgCXb7q9if8AUZcsuxa1YmnM17JZEl1fktX80bWJb1q632c30izf0rMWaZ7at/L/AL3LAWTiE83yez4XHs8hpZvdjm6boxxq+XylZoO1AAAAAAAAAAAAAAAAAAAAAdBu+974PEs9KZmx+JCp234G56e67lq+dAEQ3kbMWLtO1xWleSlkRS7FKTamv7k38yryKOrXzfQdg5E3sSInfT2fhy5gXQAAAAAAAAAAAAF55DbLWHs3Gra0nOCvt7+kn16fJaL5FtZo6tGj5ptTJ/yMquvy3Ryh7xmV6eb5PZ8Lj2eQ0s3uxzdN0Y49fL5Ss0HaASAAAAAAAAAAAAAAAAAAAB0G7/3vg8Sz0pmbH4kKnbfgbnp7ruWr508TbPKvAwZuvJtlCxLVQVNknJfBxemjXzMdd6ijvN/F2Zk5Ma2qdY5wkXLXlEtp5SthB11VQ6KpS+vJatuUtOzVvsK69ci5U7fZOz6sKzNNU6zM6vAMK1AAAAAAAAAAABjIkVzk5vGwnRVXmOWPdXCMJS5kp1T0WnOTjrp2djLK3lUaaVOFzej+RTcqqs/VE9v8w7fFyIXVwtrbcJrnRcoyg2u/SSTNqJ1jVQ10TRVNNW+HA75PZ8Lj2eQ083uxzdJ0X49zl8pWaDswJAAAAAAAAAAAAAAAAAAAA6Dd/wC98HiWelMzY/EhU7b8Dc9PeF3LZ86edtzYuNn1dDk1qa7YSXVZXL+aMvh/9qY67dNcaS2MbLu41fXtTp7T6I7ys5HZOzZOfXdit6Rvivq9ysX3X49n7FddsVUT/Dutm7YtZf0z9Nf2+/JzZgXIAAAAAAAAAAAP2wsS3IsjTRXK22b0jCC1b/8AS8SaaZmdIYr163ZpmuurSPurHI/d/Vi83IzebfkrSUK+2miX/KXj2d3eWFrGintq3uJ2lt2vI/bs/TR/ufw7k2nPp5vk9nwuPZ5DTze7HN0/RjjV8vlKzQdmBIAAAAAAAAAAAAAAAAAAAHQbv/fGDxLPSmZsfiQqdt+Buenuu5avnQSP5shGcXGUVKMk1KMknFp9qa+JExE7yJmJ1idJTTlfu5052Rs1dXXKeJr+tT/4v5dxpXsXzo/p1mzOkGmlvJns8qvz+U2lFpuLTjKLcZRaalGS7U0+xmjuddTVFUawwJAAAAAAAAPb5M8mMradmlK5lMXpZkTT6OHgv5peC/Qy2rNVyezd91bn7Us4dP1TrV5R5z+IWPk5ybxdm182iOs5JdJfPR22PxfwXguosrdqm3HY4LN2hezK+tcns+32eyZGkBKeb5PZ8Lj2eQ083uxzdN0Y49fL5Ss0HaASAAAAAAAAAAAAAAAAAAAB0G7/AN74PEs9KZmx+JCp234G56e67lq+dAAIAlzHK3kZjbSTsWlGUl9G+K6p9XUrF95ePb+xhu2Kbn8StdnbXu4c6b6Pt+Ea2ts27Dvnj3pK2trXmyUotPrTTXwaKyqiaKurLvsXJt5NqLlvdL5Dy2AAACAJAO65Ecg3mRhl5cubiy666oS+ncu9tfVj+v4G3Zxut9VU9jmdrbc/QmbNmPq85nyVjFxq6a41VQjXXBc2EILSMV4I34iIjSHGV3Kq6pqrnWZ836np5ABAnm+T2bC49nkNPN7sOm6Mcevl8pWaDtAJAAAAAAAAAAAAAAAAAAAA6Dd/73weJZ6UzNj8SFTtvwNz094XctnzoIAIAPk2rlToottrqnfZGP8ADqri5SnN9UVovhq+34dZFVUxEzEM1i3Fy5FNU6R5zKRR5DbZzLbLr6oVTtm7JzvuitZN/wAsdWvyK3/Hu1zrLto21gY1uLdudYjyiPmdIe1hbqZdTyM1LvjRU3/uk/8ABlpwp/5S0bvSj/x2/wC5/D3sLdvsurRzjbkNfG21pflDQzU4tuFbd6QZtfdmI5R+XH71tmY2JZhxxqK6IypuclXFR5zUo6Nv4mtlUxTNMUwu+j+Tev0XJuVTVMab5/iXeZHInZV8IuWJCEnFPnUuVT107fos2/8AHt1Ruc7RtfNtVTpcmY/nteHm7rMWWvQZV1TfYrFG2K/Z/qYqsOnylY2uk1+O/RE8uyXgZu7DPhq6bce9fBc6VU38mtP1MM4lcbtFla6S41Xfpqj/AHDo93VG0cGU8HMxbYUzcrKLVpZXXZ96DlFtJPtXjr3mfGiuj6aoVO3K8XJ0v2K413TG6f47Jd4bUOeAAACeb5PZ8Lj2eQ083uw6boxx6+XylZoO0AkAAAAAAAAAYBoGAaAAAAAADoN33vfB4lnpTM2PxIVO2/A3PT3XctXzoAAAgCQAAAle+j7bC4N/miaGZ3qXYdF+Hd9PlUafqw/oj+xvRuhyNfennL+yXkAEgQAAABO98vs+Fx7fIjTzO7HN03RjjV8vlLDRdqEAAAAAAAAEAAJYBoAAAAAAAHQbv/e+DxLPSmZsfiQqdt+Buenuu5avnQSBCAAEgAAEJXvo+2wuDf5omhm96l2PRjh3fRUafqQ/pj+xvRuhyNfennL+yXkAEgQAAABO98v2GFxrfIjTzO7S6fovxq+XylhoO0AAAAAAAAAGB5loegDANAAYBoAAB0G773vg8Sz0pmbH4kKnbfgbnp7ruWr50EgQBIANCAABCV75/tsLg3+aJoZvepdj0Y4d309pVGn6kP6Y/sb0bocjX3p5y/sl5AAAAAAATvfL9hhca3yI1Mzu0un6L8avl8pYV7tADANAAAAADAAeZaHoAAAAAAAAAdBu/wDe+DxLPSmZsfiQqdt+Buenuu5avnQAAEgQBIACB8mdsvFyXF5GNTe4pqLuqhY4p9qWq6uwiaYnfDLayLtqNLdc08p0fWiWIAAAAAkABAne+X7DC41vkRp5ndpdP0X41fL5Sw0HZgSAAAAAAAAYHmQPTQMA0DAAGgAMA6Ld6v8AWMHiWejMzY/EhU7b8Dc9PeF56PxLZ841b0fiDU6LxINTovEGp0fiDU6LxJNTo/EGp0fiDU6PxBqzo/EGrejBqdH4g1Oi8QanR+INTo/EGrOj8Qat6PxBqnO+aOlGFxrfIjSzO7DqOi8/vV8vlKjQdqAYBoADANAAAMDzL//Z`;
  //   const html = `
  //   <html>
  //     <head>
  //     <style>
  //     p {text-align: center;}

  //     .draft-container{
  //         width:850px;
  //         margin: auto;
  //         padding: 30px;
  //     }
  //     table {
  //       border-collapse: collapse;
  //       width: 100%;
  //       text-align: center;
  //     }

  //     table,
  //     th,
  //     td {
  //       border: 1px solid black;
  //     }
  //     </style>
  //     </head>
  //     <body>
  //   <div class="draft-container">
  //   <h2>Draft Certificate</h2>

  //   <p>
  //     FIPS 140-3<br />
  //     Validation Certificate<br />
  //     <br />
  //   </p>

  //   <p>
  //     Certificate No.
  //     ${this.vendorFormGroup.getRawValue().module["validation-cert-number"]}
  //   </p>

  //   <table width="850" align="center">
  //     <tr>
  //       <td width="300" align="left">
  //         <img src="${americanFlag}" alt="American Flag" />
  //       </td>
  //       <td width="250">&nbsp;</td>
  //       <td width="300" align="right">
  //         <img src="${canadianFlag}" alt="Canadian Flag" />

  //       </td>
  //     </tr>
  //     <tr>
  //       <td width="300" align="left">
  //         The National Institute of Standards and Technology of the United States
  //         of America
  //       </td>
  //       <td width="250">&nbsp;</td>
  //       <td width="300" align="right">
  //         The Canadian Centre for Cyber Security of the Government of Canada
  //       </td>
  //     </tr>
  //   </table>

  //   <p>
  //     The National Institute of Standards and Technology, as the United States
  //     FIPS 140-3 Cryptographic Module Validation Authority; and the Canadian
  //     Centre for Cyber Security, as the Canadian FIPS 140-3 Cryptographic Module
  //     Validation Authority; hereby validate the FIPS 140-3 testing results of the
  //     Cryptographic Module identified as:
  //   </p>
  //   <b>
  //     <p>
  //       ${this.vendorFormGroup.getRawValue().module["module-name"]}
  //     </p>
  //   </b>
  //   <p>
  //   ${this.vendorFormGroup.getRawValue().module["certificate-caveat"]}
  //   </p>
  //   <p>
  //     in accordance with the Derived Test Requirements for FIPS 140-3, Security
  //     Requirements for Cryptographic Modules. FIPS 140-3 specifies the security
  //     requirements that are to be satisfied by a cryptographic module utilized
  //     within a security system protecting Sensitive Information (United States) or
  //     Protected Information (Canada) within computer and telecommunications
  //     systems (including voice systems).
  //   </p>
  //   <p>
  //     Products which use the above identified cryptographic module may be labeled
  //     as complying with the requirements of FIPS 140-3 so long as the product,
  //     throughout its life cycle, continues to use the validated version of the
  //     cryptographic module as specified in this certificate. The validation report
  //     contains additional details concerning test results. No reliability test has
  //     been performed and no warranty of the products by both agencies is either
  //     expressed or implied.
  //   </p>
  //   <p>
  //     This certificate includes details on the scope of conformance and validation
  //     authority signatures on the reverse.
  //   </p>

  //   <p>${this.vendorFormGroup.getRawValue().vendor["vendor-name"]}</p>

  //     (Hardware Version:
  //     ${this.vendorFormGroup.getRawValue().module["hardware-vs"]}; Firmware
  //     Version: ${this.vendorFormGroup.getRawValue().module["firmware-vs"]} )

  //     (Software Version:
  //       ${this.vendorFormGroup.getRawValue().module["software-vs"]})

  //   <br />
  //   Tested by the Cryptographic Module Testing accredited lab: <br />
  //   ${this.vendorFormGroup.getRawValue().laboratory["lab-name"]}, NVLAP Lab
  //   Code
  //   ${this.vendorFormGroup.getRawValue().laboratory["nvlap-code"]} CRYPTIK
  //   version: ${environment.version}<br />
  //   The testing levels are as follows:
  //   ${this.buildTable0(table0)}
  //   <p>
  //     The following FIPS approved Cryptographic Algorithms are used:
  //   </p>
  //   ${this.buildTable5(table5)}

  //   <p>
  //     The cryptographic module also contains the following non-FIPS approved
  //   </p>
  //   ${this.buildTable6(table6)}

  //   <table width="800">
  //     <tr>
  //       <td width="300">
  //         Signed on behalf of the Government of the United States<br />
  //         Signature:___________________________________<br />
  //         Dated:________________________________<br />
  //         Chief, Computer Security Division<br />
  //         National Institute of Standards and Technology
  //       </td>
  //       <td width="200">&nbsp;</td>
  //       <td width="300">
  //         Signed on behalf of the Government of Canada<br />
  //         Signature:___________________________________<br />
  //         Dated:________________________________<br />
  //         Director, Industry Program Group<br />
  //         Canadian Centre for Cyber Security
  //       </td>
  //     </tr>
  //   </table>
  // </div>
  // `;
  //   return html;
  // }

  // buildTable0(table) {
  //   let html = "";
  //   if (table) {
  //     html = ` <div style="padding: 15px;">
  //     <div class="center-text">
  //       <h4>${table.title}</h4>
  //     </div>
  //     <table>`;
  //     table.details.th.forEach((th) => {
  //       html += `<th>
  //       ${th}
  //     </th>`;
  //     });
  //     table.details.trs.forEach((tr) => {
  //       html += `<tr>`;
  //       tr.forEach((td) => {
  //         html += `<td>`;

  //         if (td.type) {
  //           html += `<div  class="small-input">
  //             ${table.form.value[td.controlName]}
  //         </div>`;
  //         } else {
  //           html += ` <div *ngIf="!td.type">
  //           ${td.label}
  //         </div>`;
  //         }
  //         html += `</td>`;
  //       });
  //       html += `</tr>`;
  //     });
  //     html += `    </table>
  //     </div>`;
  //   }
  //   return html;
  // }

  buildTable5(table) {
    let html = "";
    if (table) {
      html = `<div >
      <table>
        <tr>
          <th>
            CAVP Cert
          </th>
          <th>
            Algorithm and Standard
          </th>
          <th>
            Mode/Method
          </th>
        </tr>`;
      table.forEach((row) => {
        html += `<tr>
          <td>${row["CAVPCert"]}</td>
          <td>${row["algorithmAndStandard"]}</td>
          <td>${row["modeMethod"]}</td>
        </tr>`;
      });
      html += ` </table>
      </div>`;
    }
    return html;
  }
  // buildTable6(table) {
  //   let html = "";
  //   if (table) {
  //     html = `  <div>
  //     <table>
  //       <tr>
  //         <th>
  //           Algorithm
  //         </th>
  //         <th>
  //           Caveat
  //         </th>
  //       </tr>`;
  //     table.forEach((row) => {
  //       html += `<tr>
  //         <td>${row["algorithm"]}</td>
  //         <td>${row["caveat"]}</td>
  //       </tr>`;
  //     });
  //     html += ` </table>
  //     </div>`;
  //   }
  //   return html;
  // }
}
