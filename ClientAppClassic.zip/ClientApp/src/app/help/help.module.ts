import { NgModule } from '@angular/core';

import { HelpRoutingModule } from './help-routing.module';
import { HelpComponent } from './help.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [HelpComponent],
  imports: [
    HelpRoutingModule,
    SharedModule
  ]
})
export class HelpModule { }
