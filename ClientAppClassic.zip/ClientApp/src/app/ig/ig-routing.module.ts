import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IgComponent } from './ig.component';


const routes: Routes = [{
  path: '',
  component: IgComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IgRoutingModule { }
