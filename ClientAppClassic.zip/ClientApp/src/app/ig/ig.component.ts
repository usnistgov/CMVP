import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: "app-ig",
  templateUrl: "./ig.component.html",
  styleUrls: ["./ig.component.scss"]
})
export class IgComponent implements OnInit {
  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    let anchor = this.route.snapshot.paramMap.get("anchor");
    const elmnt = document.getElementById(anchor);
    elmnt.scrollIntoView({ behavior: "auto", block: "start" });
  }
}
