import { NgModule } from '@angular/core';

import { IgRoutingModule } from './ig-routing.module';
import { IgComponent } from './ig.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [IgComponent],
  imports: [
    IgRoutingModule,
    SharedModule
  ]
})
export class IgModule { }
