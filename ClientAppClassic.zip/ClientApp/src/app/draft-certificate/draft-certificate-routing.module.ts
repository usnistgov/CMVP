import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DraftCertificateComponent } from './draft-certificate.component';


const routes: Routes = [{
  path: '',
  component: DraftCertificateComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DraftCertificateRoutingModule { }
