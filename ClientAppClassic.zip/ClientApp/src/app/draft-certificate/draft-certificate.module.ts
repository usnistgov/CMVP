import { NgModule } from '@angular/core';

import { DraftCertificateRoutingModule } from './draft-certificate-routing.module';
import { DraftCertificateComponent } from './draft-certificate.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [DraftCertificateComponent],
  imports: [
    DraftCertificateRoutingModule,
    SharedModule
  ]
})
export class DraftCertificateModule { }
