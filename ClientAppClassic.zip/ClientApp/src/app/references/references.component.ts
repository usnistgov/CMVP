import { Component, OnInit } from '@angular/core';
import { SectionService } from '../shared/services/section.service';
import { UntypedFormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from '../shared/services/validation.service';


@Component({
  selector: 'app-references',
  templateUrl: './references.component.html',
  styleUrls: ['./references.component.scss']
})
export class ReferencesComponent implements OnInit {

  editingRow;
  newRow = new UntypedFormControl('');
  constructor(public sectionService: SectionService, private validationService: ValidationService,
    private router: Router,) {

  }

  ngOnInit() {
    if(!this.validationService.selectedValidation){
      this.router.navigate(["/validations"]);
      return;
    }

  }
  editRow(index) {
    this.editingRow = index;
  }
  saveRow() {
    this.editingRow = null;
  }
  deleteRow(index) {
    this.sectionService.references.removeAt(index);

  }
  addToFormArray() {
    this.sectionService.references.push(new UntypedFormControl(this.newRow.value));
    this.newRow.reset();

  }

}
