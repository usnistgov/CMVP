import { NgModule } from "@angular/core";
import { Routes, RouterModule, ExtraOptions } from "@angular/router";

const routerOptions: ExtraOptions = {
  scrollPositionRestoration: "enabled",
  anchorScrolling: "enabled",
  scrollOffset: [0, 64],
};

const routes: Routes = [
  {
    path: "",
    loadChildren: () => import("./main/main.module").then((m) => m.MainModule),
  },

  {
    path: "help",
    loadChildren: () => import("./help/help.module").then((m) => m.HelpModule),
  },
  {
    path: "release-notes",
    loadChildren: () =>
      import("./release-notes/release-notes.module").then(
        (m) => m.ReleaseNotesModule
      ),
  },
  {
    path: "general-info",
    loadChildren: () => import("./home/home.module").then((m) => m.HomeModule),
  },
  {
    path: "draft-certificate",
    loadChildren: () =>
      import("./draft-certificate/draft-certificate.module").then(
        (m) => m.DraftCertificateModule
      ),
  },
  {
    path: "security-policy",
    loadChildren: () =>
      import("./security-policy/security-policy.module").then(
        (m) => m.SecurityPolicyModule
      ),
  },
  {
    path: "references",
    loadChildren: () =>
      import("./references/references.module").then((m) => m.ReferencesModule),
  },
  {
    path: "reports",
    loadChildren: () =>
      import("./reports/reports.module").then((m) => m.ReportsModule),
  },
  {
    path: "send-results",
    // canActivate: [SubmissionGuard],
    loadChildren: () =>
      import("./send-results/send-results.module").then(
        (m) => m.SendResultsModule
      ),
  },
  {
    path: "sections",
    loadChildren: () =>
      import("./section/section.module").then((m) => m.SectionModule),
  },
  {
    path: "artifact",
    // canActivate: [ArtifactGuard],
    loadChildren: () =>
      import("./artifact/artifact.module").then((m) => m.ArtifactModule),
  },
  {
    path: "ig",
    loadChildren: () => import("./ig/ig.module").then((m) => m.IgModule),
  },
  {
    path: "validations",
    loadChildren: () =>
      import("./validations/validations.module").then(
        (m) => m.ValidationsModule
      ),
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes, routerOptions)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
