import { Component, OnInit } from "@angular/core";
import { SectionService } from "../shared/services/section.service";
import { UntypedFormControl, UntypedFormGroup } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { ValidationService } from "../shared/services/validation.service";

@Component({
  selector: "app-reports",
  templateUrl: "./reports.component.html",
  styleUrls: ["./reports.component.scss"],
})
export class ReportsComponent implements OnInit {
  openedSection;
  openedSectionTitle;
  sectionFormGroup: UntypedFormGroup;
  sections = [
    {
      number: "1",
      tocTitle: "1. General",
      title: "SECTION 1: General",
      levelField: "section1-level",
    },
    {
      number: "2",
      tocTitle: "2. Cryptographic module specification",
      title: "SECTION 2: Cryptographic module specification",
      levelField: "section2-level",
    },
    {
      number: "3",
      tocTitle: "3. Cryptographic module interfaces",
      title: "SECTION 3: Cryptographic module interfaces",
      levelField: "section3-level",
    },
    {
      number: "4",
      tocTitle: "4. Roles, services, and authentication",
      title: "SECTION 4: Roles, services, and authentication",
      levelField: "section4-level",
    },
    {
      number: "5",
      tocTitle: "5. Software/Firmware security",
      title: "SECTION 5: Software/Firmware security",
      levelField: "section5-level",
    },
    {
      number: "6",
      tocTitle: "6. Operational environment",
      title: "SECTION 6: Operational environment",
      levelField: "section6-level",
    },
    {
      number: "7",
      tocTitle: "7. Physical security",
      title: "SECTION 7: Physical security",
      levelField: "section7-level",
    },
    {
      number: "8",
      tocTitle: "8. Non-invasive security",
      title: "SECTION 8: Non-invasive security",
      levelField: "section8-level",
    },
    {
      number: "9",
      tocTitle: "9. Sensitive security parameter management",
      title: "SECTION 9: Sensitive security parameter management",
      levelField: "section9-level",
    },
    {
      number: "10",
      tocTitle: "10. Self-tests",
      title: "SECTION 10: Self-tests",
      levelField: "section10-level",
    },
    {
      number: "11",
      tocTitle: "11. Life-cycle assurance",
      title: "SECTION 11: Life-cycle assurance",
      levelField: "section11-level",
    },
    {
      number: "12",
      tocTitle: "12. Mitigation of other attacks",
      title: "SECTION 12: Mitigation of other attacks",

      levelField: "section12-level",
    },
    {
      number: "A",
      tocTitle: "Appendix A",
      title: "Appendix A",
      levelField: "section13-level"
    },
    {
      number: "B",
      tocTitle: "Appendix B",
      title: "Appendix B",
      levelField: "section14-level"
    }

  ];

  // sections = ["1","2", "3", "4","5","6","7","8","9","10","11","12", "A", "B"];

  constructor(
    private route: ActivatedRoute,
    public sectionService: SectionService,
        private validationService: ValidationService,
        private router: Router,
  ) {}

  ngOnInit() {
    if(!this.validationService.selectedValidation){
      this.router.navigate(["/validations"]);
      return;
    }
    let sectionNumber = this.route.snapshot.paramMap.get("sectionNumber");
    const section = this.sections.find((s) => s.number === sectionNumber);
    if (section) {
      this.newOpenSection(section);
    } else {
      this.newOpenSection(this.sections[0]);
    }
  }

  newOpenSection(section, hash = null) {
    //display loader

    // this.isSectionOpen = !this.isSectionOpen;
    const sectionNumber = section.number;
    this.openedSection =
      this.openedSection === sectionNumber
        ? null
        : this.sectionService.getSectionByNumber(sectionNumber);
    if (this.openedSection) {
      this.openedSectionTitle = section.tocTitle;
      if (!this.sectionService.sections[sectionNumber]) {
        let group = {};

        this.openedSection.dtrs.forEach((row) => {
          let dtr = {
            assessment: new UntypedFormControl(""),
            "test-status": new UntypedFormControl("0"),
            "reval-assessment": new UntypedFormControl(""),
            tester: new UntypedFormControl(""),
            reviewer: new UntypedFormControl(""),
            review: new UntypedFormControl(""),
          };
          group[row.dtrId] = new UntypedFormGroup(dtr);
        });
        this.sectionService.sections[sectionNumber] = new UntypedFormGroup(group);
      }

      if (hash) {
        this.sectionService.hash = hash;
      } else {
        this.sectionService.hash = null;
      }
      this.sectionFormGroup = this.sectionService.sections[sectionNumber];
    } else {
      this.openedSectionTitle = null;
    }

    window.scroll(0, 0);
    //hide spinner
  }
  changeSection(e) {
    this.openedSection = null;
    this.openedSectionTitle = null;
    const section = this.sections.find((s) => s.number === e.sectionNumber);

    this.newOpenSection(section, e.hash);
  }
}
