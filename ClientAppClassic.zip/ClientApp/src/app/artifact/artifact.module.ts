import { NgModule } from '@angular/core';

import { ArtifactRoutingModule } from './artifact-routing.module';
import { ArtifactComponent } from './artifact.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [ArtifactComponent],
  imports: [
    ArtifactRoutingModule,
    SharedModule
  ]
})
export class ArtifactModule { }
