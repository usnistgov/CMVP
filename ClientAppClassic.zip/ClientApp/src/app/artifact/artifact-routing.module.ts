import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ArtifactComponent } from './artifact.component';


const routes: Routes = [{
  path: ':id',
  component: ArtifactComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ArtifactRoutingModule { }
