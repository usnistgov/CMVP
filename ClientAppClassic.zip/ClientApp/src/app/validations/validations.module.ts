import { NgModule } from "@angular/core";

import { ValidationsRoutingModule } from "./validations-routing.module";
import { RevalidationComponent } from "./revalidation/revalidation.component";
import { ValidationComponent } from "./validation/validation.component";
import { SharedModule } from "../shared/shared.module";


@NgModule({
  declarations: [
    RevalidationComponent,
    ValidationComponent,
  ],
  imports: [ValidationsRoutingModule, SharedModule],
})
export class ValidationsModule { }
