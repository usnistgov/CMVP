import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";

import { ValidationService } from "src/app/shared/services/validation.service";
import { Router } from "@angular/router";
import { ValidationTypes } from "src/assets/validation-types";

@Component({
  selector: "app-validation",
  templateUrl: "./validation.component.html",
  styleUrls: ["./validation.component.scss"],
})
export class ValidationComponent implements OnInit {
  validationTypes = ValidationTypes;
  selectedValidation: string;


  constructor(public validationService: ValidationService, private router: Router,) {
  }

  ngOnInit() {

  }

  selectValidation() {
    this.validationService.selectedValidation = this.selectedValidation;
    if (this.validationService.selectedValidation == "reval") {
      this.router.navigate(["/validations/revalidation"]);
    } else if (this.validationService.selectedValidation == "new") {
      this.router.navigate(["/general-info"]);
    }
  }


}
