import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { RevalidationComponent } from "./revalidation/revalidation.component";
import { ValidationComponent } from "./validation/validation.component";

const routes: Routes = [
  {
    path: "",
    component: ValidationComponent,
  },
  {
    path: "revalidation",
    component: RevalidationComponent,
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ValidationsRoutingModule {}
