import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-release-notes",
  templateUrl: "./release-notes.component.html",
  styleUrls: ["./release-notes.component.scss"],
})
export class ReleaseNotesComponent implements OnInit {
  constructor() {}

  ngOnInit() {}

  jumpTo(id) {
    const elmnt = document.getElementById(`${id}`);
    elmnt.scrollIntoView({ behavior: "auto", block: "start" });
  }
}
