import { NgModule } from "@angular/core";

import { ReleaseNotesRoutingModule } from "./release-notes-routing.module";
import { ReleaseNotesComponent } from "./release-notes.component";
import { SharedModule } from "../shared/shared.module";

@NgModule({
  declarations: [ReleaseNotesComponent],
  imports: [ReleaseNotesRoutingModule, SharedModule],
})
export class ReleaseNotesModule {}
