import { NgModule } from '@angular/core';

import { SecurityPolicyRoutingModule } from './security-policy-routing.module';
import { SecurityPolicyComponent } from './security-policy.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [SecurityPolicyComponent],
  imports: [
    SecurityPolicyRoutingModule,
    SharedModule
  ]
})
export class SecurityPolicyModule { }
