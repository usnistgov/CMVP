import { Component, OnInit, OnDestroy, HostListener } from "@angular/core";
import {
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
  UntypedFormArray,
} from "@angular/forms";
import { VendorForms } from "../../assets/vendor-forms";
import { Labs } from "../../assets/labs";
import { ToastrService } from "ngx-toastr";

import { FormService } from "../shared/services/form.service";
import { ConverterService } from "../shared/services/converter.service";
import { saveAs } from "file-saver";
import {
  trigger,
  state,
  style,
  transition,
  animate,
} from "@angular/animations";
// import * as sections from '../../assets/sections';
import { ConfirmationDialogComponent } from "../shared/components/confirmation-dialog/confirmation-dialog.component";
import { DatePipe } from "@angular/common";
import { SectionService } from "../shared/services/section.service";
import { Router, NavigationStart } from "@angular/router";
import { Subscription, Observable } from "rxjs";
import { PdfService } from "../shared/services/pdf.service";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { TransactionTypes } from "src/assets/transaction-types";
import { SubmissionTypes } from "src/assets/submission-types";
import { MatDialog } from "@angular/material/dialog";
import { ValidationService } from "../shared/services/validation.service";
pdfMake.vfs = pdfFonts.pdfMake.vfs;

@Component({
  selector: "app-home",
  animations: [
    trigger("openClose", [
      // ...
      state(
        "open",
        style({
          width: "100%",
          opacity: 1,
          // backgroundColor: 'yellow'
        })
      ),
      state(
        "closed",
        style({
          width: "0%",
          opacity: 0.5,
          padding: "0",
          display: "none",
          // backgroundColor: 'green'
        })
      ),
    ]),
  ],

  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"],
})
export class HomeComponent implements OnInit {
  forms = VendorForms;
  isSectionOpen = false;
  sectionFormGroup: UntypedFormGroup;
  sectionForm = [];
  validate;
  labs = [];
  transactionTypes = TransactionTypes;
  submissionTypes = SubmissionTypes;
  openedModule;
  sections = ["1", "2", "3"];
  securityPolicy = false;
  validationResults;
  answers = [
    {
      label: "1",
      value: "1",
      color: "yellow",
    },
    {
      label: "2",
      value: "2",
      color: "green",
    },
    {
      label: "3",
      value: "3",
      color: "blue",
    },
    {
      label: "4",
      value: "4",
      color: "orange",
    },
    {
      label: "NA",
      value: "NA",
      color: "purple",
    },
  ];
  questions = [
    {
      controlName: "section1-level",
      label: "1",
      link: "/section1",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
    {
      controlName: "section2-level",
      label: "2",
      link: "/section2",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
    {
      controlName: "section3-level",
      label: "3",
      link: "/section3",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
    {
      controlName: "section4-level",
      label: "4",
      link: "/section4",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
    {
      controlName: "section5-level",
      label: "5",
      link: "/section5",
      possibleAnswers: ["1", "2", "3", "4", "NA"],
      default: "NA",
    },
    {
      controlName: "section6-level",
      label: "6",
      link: "/section6",
      possibleAnswers: ["1", "2", "3", "4", "NA"],
      default: "1",
    },
    {
      controlName: "section7-level",
      label: "7",
      link: "/section7",
      possibleAnswers: ["1", "2", "3", "4", "NA"],
      default: "NA",
    },
    {
      controlName: "section8-level",
      label: "8",
      link: "/section8",
      possibleAnswers: ["1", "2", "3", "4", "NA"],
      default: "NA",
    },
    {
      controlName: "section9-level",
      label: "9",
      link: "/section9",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
    {
      controlName: "section10-level",
      label: "10",
      link: "/section10",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
    {
      controlName: "section11-level",
      label: "11",
      link: "/section11",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
    {
      controlName: "section12-level",
      label: "12",
      link: "/section12",
      possibleAnswers: ["1", "2", "3", "4", "NA"],
      default: "NA",
    },

    {
      controlName: "overall-level",
      label: "Overall",
      possibleAnswers: ["1", "2", "3", "4"],
      default: "1",
    },
  ];
  constructor(
    public pdfService: PdfService,
    public sectionService: SectionService,
    public formService: FormService,
    private converterService: ConverterService,
    public dialog: MatDialog,
    public datepipe: DatePipe,
    private validationService: ValidationService,
    private router: Router,

  ) {}

  ngOnInit() {
    if(!this.validationService.selectedValidation){
      this.router.navigate(["/validations"]);
      return;
    }
    this.openedModule = this.forms[0];
    this.onValueChanges();
    this.getLabs();
  }
  async getLabs() {
    let labs = await this.sectionService.getLabs();
    if (labs) {
      this.labs = <any[]>labs;
      this.formService.labs = labs;
      this.formService.labNames = [
        ...this.labs.map((l) => ({
          label: l.name,
          value: l.name,
        })),
      ];
    }
  }

  onValueChanges(): void {
    this.sectionService.vendorFormGroup
      .get("module")
      .get("Module_submission_code")
      .valueChanges.subscribe((val) => {
        this.sectionService.vendorFormGroup
          .get("module")
          .get("Module_submission_level")
          .setValue("5", { emitEvent: false });

        if (
          val === "FS" ||
          val === "FCLC_OK" ||
          val === "FCLC" ||
          val === "OE" ||
          val === "QU" ||
          val === "UP" ||
          val === "UPOEM" ||
          val === "VU"
        ) {
          this.sectionService.vendorFormGroup
            .get("module")
            .get("submission-type")
            .setValue(val, { emitEvent: false });
        } else {
          this.sectionService.vendorFormGroup
            .get("module")
            .get("submission-type")
            .setValue("FS", { emitEvent: false });
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("module-type")
      .valueChanges.subscribe((val) => {
        if (val === "Software") {
          this.formService.moduleType = "Software";
          this.sectionService.vendorFormGroup
            .get("module")
            .get("section7-level")
            .setValue("NA");
          this.sectionService.vendorFormGroup
            .get("module")
            .get("section5-level")
            .enable();
        } else if (val === "Hardware") {
          this.formService.moduleType = "Hardware";
          this.sectionService.vendorFormGroup
            .get("module")
            .get("section5-level")
            .setValue("NA");
          this.sectionService.vendorFormGroup
            .get("module")
            .get("section7-level")
            .enable();
        } else {
          this.formService.moduleType = val;
          this.sectionService.vendorFormGroup
            .get("module")
            .get("section5-level")
            .enable();
          this.sectionService.vendorFormGroup
            .get("module")
            .get("section7-level")
            .enable();
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("update-version-label")
      .valueChanges.subscribe((val) => {
        const number = parseInt(val);
        if (number) {
          for (const key in this.sectionService.sections) {
            const element = this.sectionService.sections[key];
            if (element && element.controls) {
              for (const control in element.controls) {
                if (control.startsWith("TE")) {
                  const fg = element.controls[control];
                  const fa = fg.controls["update-versions"] as UntypedFormArray;
                  const diff = number - fa.value.length;
                  if (diff > 0) {
                    for (let i = 0; i < diff; i++) {
                      fa.push(new UntypedFormControl(""));
                    }
                  } else if (number < fa.value.length) {
                    for (let i = 0; i < diff * -1; i++) {
                      fa.removeAt(fa.length - 1);
                    }
                  }
                }
              }
            }
          }
          // this.sectionService.sectionsList.forEach(section => {

          //   section.dtrs.forEach((row: any) => {
          //     if (row.dtrId.startsWith("TE") ) {
          //       console.log()
          //     }

          //     // group[row.dtrId] = new FormGroup(dtr);
          //   });
          //   // this.sections[section.secId] = new FormGroup(group);
          // });
        }
      });

    this.sectionService.vendorFormGroup
      .get("laboratory")
      .get("lab-name")
      .valueChanges.subscribe((val) => {
        if (val) {
          const lab = this.labs.find((l) => l.name == val);
          if (lab) {
            let code = lab.code;
            this.sectionService.vendorFormGroup
              .get("module")
              .get("lab-lc")
              .setValue(code, { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("itar")
      .valueChanges.subscribe((val) => {
        if (val) {
          this.sectionService.vendorFormGroup
            .get("module")
            .get("csec-tid")
            .setValue("ITAR", { emitEvent: false });
        } else {
          this.sectionService.vendorFormGroup
            .get("module")
            .get("csec-tid")
            .setValue("0000", { emitEvent: false });
        }
      });

    this.sectionService.vendorFormGroup
      .get("module")
      .get("section1-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section2-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section3-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section4-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section5-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section6-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section7-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section8-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section9-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section10-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section11-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
    this.sectionService.vendorFormGroup
      .get("module")
      .get("section12-level")
      .valueChanges.subscribe((val) => {
        if (val) {
          const min = this.getMinLevel();
          if (min) {
            this.sectionService.vendorFormGroup
              .get("module")
              .get("overall-level")
              .setValue(min.toString(), { emitEvent: false });
          }
        }
      });
  }

  getMinLevel() {
    const l1 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section1-level").value;
    const l2 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section2-level").value;
    const l3 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section3-level").value;
    const l4 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section4-level").value;
    const l5 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section5-level").value;
    const l6 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section6-level").value;
    const l7 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section7-level").value;
    const l8 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section8-level").value;
    const l9 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section9-level").value;
    const l10 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section10-level").value;
    const l11 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section11-level").value;
    const l12 = this.sectionService.vendorFormGroup
      .get("module")
      .get("section12-level").value;
    let list = [l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12];
    list = list.filter((l) => l && l !== "" && l !== "NA");
    list = list.map((l) => parseInt(l));
    return Math.min.apply(Math, list);
  }

  saveForm() {}

  saveFormAsJson() {
    if (
      this.sectionService.vendorFormGroup.getRawValue() &&
      this.sectionService.vendorFormGroup.getRawValue()["module"] &&
      this.sectionService.vendorFormGroup.getRawValue()["module"].date
    ) {
      this.sectionService.vendorFormGroup.getRawValue()["module"].date =
        this.datepipe.transform(
          this.sectionService.vendorFormGroup.getRawValue()["module"].date,
          "yyyy-MM-dd"
        );
    }
    const blob = new Blob(
      [JSON.stringify(this.sectionService.vendorFormGroup.getRawValue())],
      { type: "text/json" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );

    saveAs(blob, filename + ".json");
  }

  saveFormAsXml() {
    if (
      this.sectionService.vendorFormGroup.getRawValue() &&
      this.sectionService.vendorFormGroup.getRawValue()["module"] &&
      this.sectionService.vendorFormGroup.getRawValue()["module"].date
    ) {
      this.sectionService.vendorFormGroup.getRawValue()["module"].date =
        this.datepipe.transform(
          this.sectionService.vendorFormGroup.getRawValue()["module"].date,
          "yyyy-MM-dd"
        );
    }
    const blob = new Blob(
      [
        this.converterService.convertGeneralInfoToXml(
          this.sectionService.vendorFormGroup.getRawValue()
        ),
      ],
      { type: "text/xml" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );

    saveAs(blob, filename + ".xml");
  }

  changeSection(e) {
    this.newOpenSection(e.sectionNumber, e.hash);
  }

  newOpenSection(sectionNumber, hash = null) {
    if (hash) {
      this.sectionService.hash = hash;
    } else {
      this.sectionService.hash = null;
    }
    this.router.navigate(["/reports", { sectionNumber: sectionNumber }]);
  }

  findInvalidControls() {
    this.validate =
      Math.random().toString(36).substring(2, 15) +
      Math.random().toString(36).substring(2, 15);
  }
  validateIUTData() {
    let invalid = [];

    const moduleForm = this.sectionService.vendorFormGroup.get("module");
    const vendorForm = this.sectionService.vendorFormGroup.get("vendor");
    const labForm = this.sectionService.vendorFormGroup.get("laboratory");

    if (
      moduleForm.get("Module_submission_code") &&
      moduleForm.get("Module_submission_code").invalid
    ) {
      invalid.push({ name: "Transaction Type" });
    }
    if (labForm.get("laboratory") && labForm.get("laboratory").invalid) {
      invalid.push({ name: "Lab Name" });
    }
    if (
      moduleForm.get("submission-type") &&
      moduleForm.get("submission-type").invalid
    ) {
      invalid.push({ name: "Submission Type" });
    }
    if (moduleForm.get("cstl-tid") && moduleForm.get("cstl-tid").invalid) {
      invalid.push({ name: "TID for CSTL" });
    }
    if (moduleForm.get("csec-tid") && moduleForm.get("csec-tid").invalid) {
      invalid.push({ name: "CCCS TID" });
    }
    if (
      moduleForm.get("itar").value &&
      moduleForm.get("csec-tid").value !== "ITAR"
    ) {
      invalid.push({ name: "CCCS TID" });
    }
    if (
      moduleForm.get("module-name") &&
      moduleForm.get("module-name").invalid
    ) {
      invalid.push({ name: "Module Name(s)" });
    }
    if (
      vendorForm.get("vendor-name") &&
      vendorForm.get("vendor-name").invalid
    ) {
      invalid.push({ name: "Vendor Name" });
    }

    this.validationResults = invalid;
  }
  validateOtherData() {
    this.validationResults = null;
    let invalid = [];

    const moduleForm = this.sectionService.vendorFormGroup.get("module");
    const labForm = this.sectionService.vendorFormGroup.get("laboratory");

    if (
      moduleForm.get("Module_submission_code") &&
      moduleForm.get("Module_submission_code").invalid
    ) {
      invalid.push({ name: "Transaction Type" });
    }
    if (labForm.get("laboratory") && labForm.get("laboratory").invalid) {
      invalid.push({ name: "Lab Name" });
    }
    if (
      moduleForm.get("submission-type") &&
      moduleForm.get("submission-type").invalid
    ) {
      invalid.push({ name: "Submission Type" });
    }
    if (moduleForm.get("cstl-tid") && moduleForm.get("cstl-tid").invalid) {
      invalid.push({ name: "TID for CSTL" });
    }
    if (moduleForm.get("csec-tid") && moduleForm.get("csec-tid").invalid) {
      invalid.push({ name: "CCCS TID" });
    }
    if (
      moduleForm.get("itar").value &&
      moduleForm.get("csec-tid").value !== "ITAR"
    ) {
      invalid.push({ name: "CCCS TID" });
    }
    this.validationResults = invalid;
  }

  saveFormAsPdf() {
    const data = this.pdfService.getPdfData();
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );

    pdfMake.createPdf(data).download(filename);
  }

  openModule(form) {
    this.openedModule = form;
    this.securityPolicy = false;
    this.validate = null;
  }

  openSecurityPolicy() {
    this.openedModule = null;
    this.securityPolicy = true;
    this.validate = null;
  }
  openSectionFn(section, link) {
    if (link) {
      this.newOpenSection(section);
    }
  }
}
