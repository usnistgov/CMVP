import { Component, OnInit, OnDestroy, HostListener } from "@angular/core";
import { FormControl, UntypedFormGroup } from "@angular/forms";
import { VendorForms } from "../../assets/vendor-forms";
import { FormService } from "../shared/services/form.service";
import { ConverterService } from "../shared/services/converter.service";
import { saveAs } from "file-saver";
// import * as sections from '../../assets/sections';
import { DatePipe } from "@angular/common";
import { SectionService } from "../shared/services/section.service";
import { Router, NavigationStart, ActivatedRoute } from "@angular/router";
import { MatDialog } from "@angular/material/dialog";
import { ValidationService } from "../shared/services/validation.service";

@Component({
  selector: "app-section",
  templateUrl: "./section.component.html",
  styleUrls: ["./section.component.scss"],
})
export class SectionComponent implements OnInit {
  openedSection;
  sectionFormGroup: UntypedFormGroup;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public sectionService: SectionService,
    public formService: FormService,
    private converterService: ConverterService,
    public dialog: MatDialog,
    public datepipe: DatePipe,
    private validationService: ValidationService,
  ) { }

  ngOnInit() {
    if(!this.validationService.selectedValidation){
      this.router.navigate(["/validations"]);
      return;
    }
    this.route.paramMap.subscribe((params) => {
      const sectionId = params.get("id");
      this.openedSection = this.sectionService.getSectionByNumber(sectionId);
      if (this.openedSection) {
        // if (!this.sectionService.sections[sectionId]) {
        //   let group = {};

        //   this.openedSection.dtrs.forEach(row => {
        //     let dtr = {
        //       "assessment": new FormControl(''),
        //       "test-status": new FormControl('Open'),
        //       "reval-assessment": new FormControl(''),
        //     }
        //     group[row.dtrId] = new FormGroup(dtr);
        //   });
        //   this.sectionService.sections[sectionId] = new FormGroup(group);
        // }
        this.sectionFormGroup = this.sectionService.sections[sectionId];
      }
    });
  }

  closeSection() {
    this.router.navigate(["/home"]);
  }
}
