import { NgModule } from '@angular/core';

import { SectionRoutingModule } from './section-routing.module';
import { SectionComponent } from './section.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [SectionComponent],
  imports: [
    SectionRoutingModule,
    SharedModule
  ]
})
export class SectionModule { }
