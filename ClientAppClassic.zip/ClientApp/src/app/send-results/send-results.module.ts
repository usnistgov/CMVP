import { NgModule } from '@angular/core';

import { SendResultsRoutingModule } from './send-results-routing.module';
import { SendResultsComponent } from './send-results.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [SendResultsComponent],
  imports: [
    SendResultsRoutingModule,
    SharedModule
  ]
})
export class SendResultsModule { }
