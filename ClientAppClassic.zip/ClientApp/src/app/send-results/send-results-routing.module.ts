import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SendResultsComponent } from './send-results.component';


const routes: Routes = [{
  path: '',
  component: SendResultsComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SendResultsRoutingModule { }
