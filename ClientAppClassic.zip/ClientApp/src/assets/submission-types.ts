export const SubmissionTypes = [
  {
    label: "Full Submission",
    value: "FS",
  },

  // {
  //   label: "Vendor update",
  //   value: "VU",
  // },
  // {
  //   label: "OE & Alg update",
  //   value: "OE",
  // },
  // {
  //   label: "Quick update",
  //   value: "QU",
  // },
  // {
  //   label: "Update",
  //   value: "UP",
  // },
  // {
  //   label: "OEM Update",
  //   value: "UPOEM",
  // },
];
