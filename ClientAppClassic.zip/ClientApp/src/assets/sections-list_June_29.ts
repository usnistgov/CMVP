export const sectionsList = [
  {
    secId: "1",
    comments: {},
    dtrs: [
      {
        dtrId: "AS01.01",
        level: "1",
        requirement:
          "This clause specifies the security requirements that shall be satisfied by the cryptographic module&#39;s compliance to {ISO/IEC 19790:2012}. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS01.02",
        level: "1",
        requirement:
          "A cryptographic module shall be tested against the requirements of each area addressed in this clause. <br> NOTE The tests can be performed in one or more of the following manners. <br> <ol type=1>   <li> Tester performs tests at the tester&#39;s facility. <br>   </li>   <li> Tester performs tests at the vendor&#39;s facility. <br>   </li>   <li> Tester supervises vendor performing tests at the vendor&#39;s facility. <br> </ol>  <br> <br>- Tester develops the required test plan and required tests. <br> <br>- Tester directly observes the tests being performed. <br> An assertion fails if any of its subsequent tests fails. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS01.03",
        level: "1",
        requirement:
          "The cryptographic module shall be independently rated in each area. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS01.04",
        level: "1",
        requirement:
          "All documentation, including copies of the user and installation manuals, design specifications, life-cycle documentation shall be provided for a cryptographic module that is to undergo an independent verification or evaluation scheme. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "2",
    dtrs: [
      {
        dtrId: "AS02.01",
        level: "1",
        requirement:
          "A cryptographic module shall be a set of hardware, software, firmware, or some combination thereof, that at a minimum, implements a defined cryptographic service employing an approved cryptographic algorithm, security function or process and contained within a defined cryptographic boundary. <br> NOTE: This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.02",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.2 shall be provided. <br> NOTE: This assertion is tested as part of ASA.01. <br> 6.2.2 Types of cryptographic modules <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.03",
        level: "1",
        requirement:
          "A cryptographic module shall be defined as one of the following module types: <br> <br>- Hardware module is a module whose cryptographic boundary is specified at a hardware perimeter. Firmware and/or software, which may also include an operating system, may be included within this hardware cryptographic boundary. <br> <br>- Software module is a module whose cryptographic boundary delimits the software exclusive component(s) (may be one or multiple software components) that execute(s) in a modifiable operational environment. The computing platform and operating system of the operational environment which the software executes in are external to the defined software module boundary. <br> <br>- Firmware module is a module whose cryptographic boundary delimits the firmware exclusive component(s) that execute(s) in a limited or non-modifiable operational environment. The computing platform and operating system of the operational environment which the <br> </ol>firmware executes in are external to the defined firmware module boundary but explicitly bound to the firmware module. <br> <br>- Hybrid Software module is a module whose cryptographic boundary delimits the composite of a software component and a disjoint hardware component (i.e. the software component is not contained within the hardware module boundary). The computing platform and operating system of the operational environment which the software executes in are external to the defined hybrid software module boundary. <br> <br>- Hybrid Firmware module is a module whose cryptographic boundary delimits the composite of a firmware component and a disjoint hardware component (i.e. the firmware component is not contained within the hardware module boundary). The computing platform and operating system of the operational environment which the firmware executes in are external to the defined hybrid firmware module boundary but explicitly bound to the hybrid firmware module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.03.01",
        level: "1",
        requirement:
          "<br> The vendor shall provide a description of the cryptographic module describing the type of cryptographic module. It will explain the rationale of the module type selection. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.03.02",
        level: "1",
        requirement:
          "<br> The vendor shall provide a specification of the cryptographic module identifying all hardware, software, and/or firmware components of the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.03.01",
        level: "1",
        requirement:
          "<br> The tester shall verify that the vendor provided documentation identifies one of the module types listed in <a href='#AS02.03'>AS02.03</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.03.02",
        level: "1",
        requirement:
          "<br> The tester shall verify from the vendor provided specification documentation, by identifying all hardware, software, and/or firmware components (<a href='#AS02.15'>AS02.15</a> to <a href='#AS02.18'>AS02.18</a>), that the cryptographic module is consistent with the type of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.04",
        level: "1",
        requirement:
          "For hardware and firmware modules, the applicable physical security and non-invasive security requirements found in (ISO/IEC 19790:2012) 7.7 and 7.8 shall apply. <br> </ol>NOTE: This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.05",
        level: "1",
        requirement:
          "For software modules executing in a modifiable environment, the physical security requirements found in (ISO/IEC 19790:2012) 7.7 are optional and the applicable non-invasive security requirements in (ISO/IEC 19790:2012) 7.8 shall apply. <br> </ol>NOTE	This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.06",
        level: "1",
        requirement:
          "For hybrid modules, all applicable requirements of {ISO/IEC 19790:2012} 7.5, 7.6, 7.7 and 7.8 shall apply. <br> NOTE	This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.07",
        level: "1",
        requirement:
          "The cryptographic boundary shall consist of an explicitly defined perimeter (i.e. set of hardware, software or firmware components) that establishes the boundary of all components of the cryptographic module. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.07.01",
        level: "1",
        requirement:
          "<br> The vendor documentation shall specify all components within the cryptographic boundary. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.07.01",
        level: "1",
        requirement:
          "<br> The tester shall verify by inspection and from the vendor documentation that all the components specified in <a href='#AS02.15'>AS02.15</a> to <a href='#AS02.18'>AS02.18</a> are within the cryptographic boundary. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.07.02",
        level: "1",
        requirement:
          "<br> The tester shall verify by inspection and from the vendor documentation that there are no unidentified components which are not specified in <a href='#AS02.15'>AS02.15</a> to <a href='#AS02.18'>AS02.18</a> within the cryptographic boundary. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.08",
        level: "1",
        requirement:
          "The requirements of {ISO/IEC 19790:2012} shall apply to all algorithms, security functions, processes, and components within the module&#39;s cryptographic boundary. <br> NOTE	This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.09",
        level: "1",
        requirement:
          "The cryptographic boundary shall, at a minimum, encompass all security relevant algorithms, security functions, processes, and components of a cryptographic module (i.e. security relevant within the scope of this document). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.09.01",
        level: "1",
        requirement:
          "The vendor shall provide a list of all the security relevant algorithms, security functions, processes, and components within the cryptographic boundary. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.09.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided documentation clearly identifies and lists all the security relevant algorithms, security functions, processes, and components of the module within the cryptographic boundary. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.10",
        level: "1",
        requirement:
          "Non-security relevant algorithms, security functions, processes or components which are used in an approved mode of operation shall be implemented in a manner to not interfere or compromise the approved operation of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.10.01",
        level: "1",
        requirement:
          "The vendor provided documentation shall list the non-security relevant functions used in an approved mode of operation and justify that they are not interfering with the approved mode of operation of the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.10.01",
        level: "1",
        requirement:
          "The tester shall verify through documentation review and inspection of the module that the non-security relevant functions are not interfering or compromising the approved mode of operation of <br> the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.10.02",
        level: "1",
        requirement:
          "The tester shall verify the correctness of any rationale for not interfering nor compromising provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.11",
        level: "1",
        requirement:
          "The defined name of a cryptographic module shall be representative of the composition of the components within the cryptographic boundary and not representative of a larger composition or product. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.11.01",
        level: "1",
        requirement:
          "The vendor shall provide the defined name of the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.11.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided module name is consistent with the composition of the components within the cryptographic boundary. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.11.02",
        level: "1",
        requirement:
          "The tester shall verify that the module name does not represent a composition of components or functions that are not consistent with the composition of the components within the cryptographic boundary. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.12",
        level: "1",
        requirement:
          "The cryptographic module shall have, at minimum, specific versioning information representing the distinct individual hardware, software, and/or firmware components. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.12.01",
        level: "1",
        requirement:
          "The vendor shall provide the versioning information of the modules distinct individual hardware, software, and/or firmware components. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.12.01",
        level: "1",
        requirement:
          "The tester shall verify the versioning information represents the modules distinct individual hardware, software, and/or firmware components. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.13",
        level: "1",
        requirement:
          "The excluded hardware, software or firmware components shall be implemented in a manner to not interfere or compromise the approved secure operation of the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.13.01",
        level: "1",
        requirement:
          "The vendor shall describe the excluded components of the module and justify that these components will not interfere with the approved secure operation of the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.13.02",
        level: "1",
        requirement:
          "The vendor documentation shall provide the rationale for excluding each of the components. The rationale shall describe how each excluded component, when working properly or <br> when it malfunctions, cannot interfere with the approved secure operation of the module. Rationale that may be acceptable, if adequately supported by documentation, includes the following. <br> <ol type=1>   <li> The component is not connected with security relevant components of the module that would allow inappropriate transfer of SSPs, plaintext data, or other information that could interfere with the approved secure operation of the module. <br>   </li>   <li> All information processed by the component is strictly for internal use of the module, and does not in any way impact the correctness of control, status or data outputs. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.13.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor provided documentation that the excluded components of the cryptographic boundary will not interfere with the approved secure operation of the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.13.02",
        level: "1",
        requirement:
          "The tester shall verify the correctness of any rationale for exclusion provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.13.03",
        level: "1",
        requirement:
          "The tester shall manipulate (e.g. to cause the component to operate not as designed) the excluded components in a manner to cause incorrect operation of the excluded component. The tester shall verify that the incorrect operation of the excluded component shall not interfere with the approved secure operation of the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.14",
        level: "1",
        requirement:
          "The excluded hardware, software or firmware shall be specified {ISO/IEC 19790:2012} (Annex A). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.14.01",
        level: "1",
        requirement:
          "All components that are to be excluded from the security requirements shall be explicitly listed in the vendor documentation. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.14.01",
        level: "1",
        requirement:
          "The tester shall verify whether the vendor indicates that any components of the module are to be excluded from the requirements of ISO/IEC 19790:2012. <br> 6.2.3.2 Definitions of cryptographic boundary <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.15",
        level: "1",
        requirement:
          "The cryptographic boundary of a hardware cryptographic module shall delimit and identify: <br> <br>- the set of hardware components which may include: <br> <br>- physical structures, including circuit boards, substrates or other mounting surfaces that provide the interconnecting physical wiring between components; <br> <br>- active electrical components such as semi-integrated, custom-integrated or common-integrated circuits, processors, memory, power supplies, converters, etc.; <br> <br>- physical structures, such as enclosures, potting or encapsulation materials, connectors, and interfaces; <br> <br>- firmware, which may include an operating system; <br> <br>- other components types not listed above. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.15.01",
        level: "1",
        requirement:
          "All hardware components of the cryptographic module shall be identified in the vendor documentation. Components to be listed shall include all of the following: <br> <ol type=1>   <li> physical structures, including circuit boards, substrates or other mounting surfaces that provide the interconnecting physical wiring between components: <br>   </li>     <ol type=a>       <li> circuit boards, substrates and mounting surfaces; <br>       </li>     </ol>   <li> active electrical components such as semi-integrated, custom-integrated or common-integrated circuits, processors, memory, power supplies, converters, etc.: <br>   </li>     <ol type=a>       <li> processors, including microprocessors, digital signal processors, custom processors, microcontrollers, or any other types of processors (identify manufacturer and type); <br>       </li>       <li> read-only memory (ROM) integrated circuits for program executable code and data (this may include mask-programmed ROM, programmable ROM (PROM) such as ultraviolet, erasable PROM (EPROM), electrically erasable PROM (EEPROM), or Flash-memory); <br>       </li>       <li> random-access memory (RAM) or other integrated circuits for temporary data storage; <br>       </li>       <li> semi-custom, application-specific integrated circuits, such as gate arrays, programmable logic arrays, field programmable gate arrays, or other programmable logic devices; <br>       </li>       <li> fully custom, application-specific integrated circuits, including any custom cryptographic integrated circuits; <br>       </li>       <li> power supply components, including power supply, power converters (e.g. AC-to-DC or DC-to-DC modules, transformers), input power connectors, and output power connectors; <br>       </li>       <li> other active electronic circuit elements (passive circuit elements such as pull up/pull down resistors or bypass capacitors do not need to be included if they do not provide security relevant function as part of the cryptographic module); <br>       </li>     </ol>   <li> physical structures, such as enclosures, potting or encapsulation materials, connectors, and interfaces: <br>   </li>     <ol type=a>       <li> physical structures and enclosures, including any removable access doors or covers; <br>       </li>       <li> potting or encapsulation materials; <br>       </li>       <li> boundary connectors; <br>       </li>       <li> connectors between major independent sub assemblies within the module; <br>       </li>     </ol>   <li> firmware, which may include an operating system: <br>   </li>     <ol type=a>       <li> executable code: <br>       </li>         <ol type=i>           <li> non-modifiable <br>           </li>           <li> modifiable <br>           </li>         </ol>     </ol>   <li>	other components types not listed above: <br>   </li>     <ol type=a>       <li> cooling or heating arrangements, such as conduction plates, cooling airflow, heat exchanger, cooling fins, fans, heaters, or other arrangements for removing or adding heat. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.15.02",
        level: "1",
        requirement:
          "The vendor documentation shall indicate the internal layout and assembly methods (e.g. fasteners and fittings) of the module, including drawings that are at least approximately to scale. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.15.03",
        level: "1",
        requirement:
          "The vendor documentation shall describe the primary physical parameters of the module, including descriptions of the enclosure, access points, circuit boards, location of power supply, interconnection wiring runs, cooling arrangements, and any other significant parameters. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.15.04",
        level: "1",
        requirement:
          "The vendor documentation shall include a block diagram which represents the module�s boundary and relationship of the hardware components. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.15.05",
        level: "1",
        requirement:
          "For each processor in the module, the vendor shall identify, by major services, the software or firmware that are executed by the processor, and the memory devices that contain the executable code and data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.15.06",
        level: "1",
        requirement:
          "For each processor, the vendor shall identify any hardware with which the processor interfaces. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.01",
        level: "1",
        requirement:
          "The tester shall identify all hardware components of the cryptographic module. Components to be listed shall include all of the following: <br> <ol type=1>   <li> physical structures, including circuit boards, substrates or other mounting surfaces that provide the interconnecting physical wiring between components: <br>   </li>     <ol type=a>       <li>	circuit boards, substrates and mounting surfaces; <br>       </li>     </ol>   <li> active electrical components such as semi-integrated, custom-integrated or common-integrated circuits, processors, memory, power supplies, converters, etc.: <br>   </li>     <ol type=a>       <li> processors, including microprocessors, digital signal processors, custom processors, microcontrollers, or any other types of processors (identify manufacturer and type); <br>       </li>       <li> read-only memory (ROM) integrated circuits for program executable code and data (this may include mask-programmed ROM, programmable ROM (PROM) such as ultraviolet, erasable PROM (EPROM), electrically erasable PROM (EEPROM), or Flash-memory; <br>       </li>       <li> random-access memory (RAM) or other integrated circuits for temporary data storage; <br>       </li>       <li> semi-custom, application-specific integrated circuits, such as gate arrays, programmable logic arrays, field programmable gate arrays, or other programmable logic devices; <br>       </li>       <li> fully custom, application-specific, integrated circuits, including any custom cryptographic integrated circuits; <br>       </li>       <li> power supply components, including power supply, power converters (e.g. AC-to-DC or DC-to-DC modules, transformers), input power connectors, and output power connectors; <br>       </li>       <li> other active electronic circuit elements (passive circuit elements such as pull up/pull down resistors or bypass capacitors do not need to be included if they do not provide security relevant function as part of the cryptographic module); <br>       </li>     </ol>   <li> physical structures, such as enclosures, potting or encapsulation materials, connectors, and interfaces: <br>   </li>     <ol type=a>       <li> physical structures and enclosures, including any removable access doors or covers; <br>       </li>       <li> potting or encapsulation materials; <br>       </li>       <li> boundary connectors; <br>       </li>       <li> connectors between major independent sub assemblies within the module; <br>       </li>     </ol>   <li> firmware, which may include an operating system: <br>   </li>     <ol type=a>       <li> executable code: <br>       </li>         <ol type=i>           <li> non-modifiable <br>           </li>           <li> modifiable <br>           </li>         </ol>     </ol>   <li>	other components types not listed above: <br>   </li>     <ol type=a>       <li> cooling or heating arrangements, such as conduction plates, cooling airflow, heat exchanger, cooling fins, fans, heaters, or other arrangements for removing or adding heat. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.02",
        level: "1",
        requirement:
          "The tester shall verify that the components list is consistent with information provided for other assertions of 6.2.3, as defined below. <br> <ol type=1>   <li> The specification of the cryptographic boundary under assertion <a href='#AS02.07'>AS02.07</a>. Verify that all components inside the cryptographic boundary are included in the components list and vice versa. Also verify that any components outside the cryptographic boundary are not listed as components of the cryptographic module. <br>   </li>   <li> The specification of the block diagram under assertion ASA.01. Verify that any individual components identified in the block diagram (e.g. processors, application specific integrated circuits) are also listed in the components list. <br> </ol>  </li>   <li> Any components that are to be excluded from the requirements of ISO/IEC 19790:2012 under the provisions of assertions <a href='#AS02.13'>AS02.13</a> and <a href='#AS02.14'>AS02.14</a>. Verify that components to be so excluded are still listed in the components list. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ],
        files: {
          title: "Files for TE02.15.02",
          position: 11
        }
      },
      {
        dtrId: "TE02.15.03",
        level: "1",
        requirement:
          "The tester shall verify that the cryptographic boundary is physically contiguous, such that there are no gaps that could allow uncontrolled input, output, or other access into the cryptographic module. (Physical protection and tamper protection are covered separately in requirements under ISO/IEC 19790:2012, 7.7.) The module design has to also ensure that there are no uncontrolled interfaces into or out of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.04",
        level: "1",
        requirement:
          "The tester shall verify that the cryptographic boundary encompasses all components that are identified in the block diagram under assertion ASA.01 as inputting, outputting, or processing SSPs, plaintext data, or other information. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.05",
        level: "1",
        requirement:
          "As a partial exception to the above requirements, the vendor is allowed to exclude certain components from the requirements of ISO/IEC 19790:2012 after satisfying the requirements under assertions <a href='#AS02.13'>AS02.13</a> and <a href='#AS02.14'>AS02.14</a> in 6.2.3.1. The tester shall verify that any interfaces or physical connections between such excluded components and the rest of the module do not allow the following: <br> <ol type=1>   <li> uncontrolled release of CSPs, plaintext data, or other information that if misused could lead to a compromise; <br>   </li>   <li> uncontrolled modifications of SSPs or other information that could lead to a compromise. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.06",
        level: "1",
        requirement:
          "The tester shall verify that the vendor�s documentation shows the internal layout of the module, including the placement and approximate dimensions of major identifiable components of the module. This has to include drawings that are at least approximately to scale. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.07",
        level: "1",
        requirement:
          "The tester shall verify that the vendor�s documentation indicates the major physical assemblies of the module and how they are assembled or inserted into the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.08",
        level: "1",
        requirement:
          "The tester shall verify that the vendor�s documentation describes the primary physical parameters of the module. This description has to include at least the following: <br> <ol type=1>   <li> enclosure shape and approximate dimensions, including any access doors or covers; <br>   </li>   <li> circuit board(s) approximate dimensions, layout, and interconnections; <br> </ol>  </li>   <li> location of power supply, power converters, and power inputs and outputs; <br>   </li>   <li> interconnection wiring runs: routing and terminals; <br>   </li>   <li> cooling or heating arrangements, such as conduction plates, cooling airflow, heat exchanger, cooling fins, fans, heaters, or other arrangements for removing heat from or adding heat to the module; <br> </ol>  <br> <ol type=1>   <li>	other component types not listed above. <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.09",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided block diagram represents the module�s boundary and relationship of the hardware components. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ],
        files: {
          title: "Files for TE02.15.09",
          position: 10
        }
      },
      {
        dtrId: "TE02.15.10",
        level: "1",
        requirement:
          "The tester shall verify the documentation provided under assertion <a href='#AS02.02'>AS02.02</a>, with a focus on the block diagram depicting all of the major hardware components of a cryptographic module and component interconnections, including any microprocessors, input/output buffers, plaintext/ciphertext buffers, control buffers, key storage, working memory, and program memory. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.11",
        level: "1",
        requirement:
          "The tester shall verify that the block diagram indicates all significant interconnections and data flow among major components of the module, and between the module and outside equipment. In particular, each line on the block diagram indicating an interconnection must be labeled with the type of information it transmits. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.12",
        level: "1",
        requirement:
          "The tester shall verify that the block diagram indicates the cryptographic boundary for the cryptographic module, as required under this assertion. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.13",
        level: "1",
        requirement:
          "The tester shall verify that, for each processor, the vendor has identified the software or firmware code modules executed by that processor, the services performed by that processor and associated code, and the memory devices containing the executable code and data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.15.14",
        level: "1",
        requirement:
          "The tester shall verify that, for each processor, the vendor has identified any hardware with which the processor interfaces. This must include, as applicable, any hardware components that provide input, control, or status data to the processor and associated software/firmware, and any hardware components that receive output, control, or status data from the processor and associated software/firmware. Such hardware components may be within the cryptographic module or may be user equipment outside the module such as input/output devices. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.16",
        level: "1",
        requirement:
          "The cryptographic boundary of a software cryptographic module shall delimit and identify <br> <br>- the set of executable file or files that constitute the cryptographic module, and <br> <br>- the instantiation of the cryptographic module saved in memory and executed by one or more processors. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.16.01",
        level: "1",
        requirement:
          "All software components of the cryptographic module shall be identified in the vendor documentation. Components to be listed shall include all of the following: <br> <ol type=1>   <li> the set of executable file or files that constitute the cryptographic module; <br>   </li>   <li> other security relevant component types not listed above. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.16.02",
        level: "1",
        requirement:
          "The vendor documentation shall indicate the internal software architecture, including how the software components interact. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.16.03",
        level: "1",
        requirement:
          "The vendor documentation shall indicate the software environment (e.g. operating system, run-time library, etc.) on which the module executes. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.16.01",
        level: "1",
        requirement:
          "The tester shall verify that the documentation includes a components list that includes all software components of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.16.02",
        level: "1",
        requirement:
          "The tester shall verify that the components list includes all occurrences of the following types of components, excluding only component types that are not used in the module: <br> <ol type=1>   <li> the set of executable file or files that constitute the cryptographic module; <br>   </li>   <li> other component types not listed above. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.16.03",
        level: "1",
        requirement:
          "The tester shall verify that the components list is consistent with information provided for other assertions of 6.2.3, as defined below. <br> <ol type=1>   <li> The specification of the cryptographic boundary under assertion <a href='#AS02.07'>AS02.07</a>. Verify that all components inside the cryptographic boundary are included in the components list and vice versa. Also verify that any components outside the cryptographic boundary are not listed as components of the cryptographic module. <br>   </li>   <li> The specification of the software under assertion ASA.01. Verify that the list of software components is the same as in the specifications under assertion <a href='#AS02.07'>AS02.07</a>. <br>   </li>   <li> The specification of the block diagram under assertion ASA.01. Verify that any individual components identified in the block diagram are also listed in the components list. <br>   </li>   <li> Any components that are to be excluded from the requirements of ISO/IEC 19790:2012 under the provisions of assertions <a href='#AS02.13'>AS02.13</a> and <a href='#AS02.14'>AS02.14</a>. Verify that components to be so excluded are still listed in the components list. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.16.04",
        level: "1",
        requirement:
          "As a partial exception to the above requirements, the vendor is allowed to exclude certain components from the requirements of ISO/IEC 19790:2012 after satisfying the requirements under assertions <a href='#AS02.13'>AS02.13</a> and <a href='#AS02.14'>AS02.14</a> in 6.2.3.1. The tester shall verify that any interfaces or physical connections between such excluded components and the rest of the module do not allow the following: <br> <ol type=1>   <li> uncontrolled release of CSPs, plaintext data, or other information that if misused could lead to a compromise; <br>   </li>   <li> uncontrolled modifications of SSPs or other information that could lead to a compromise. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.16.05",
        level: "1",
        requirement:
          "The tester shall verify that the vendor�s documentation indicates the major software components of the module and how they are linked together forming the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.17",
        level: "1",
        requirement:
          "The cryptographic boundary of a firmware cryptographic module shall delimit and identify <br> <br>- the set of executable file or files that constitute the cryptographic module, and <br> <br>- the instantiation of the cryptographic module saved in memory and executed by one or more processors. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.17.01",
        level: "1",
        requirement:
          "All firmware components of the cryptographic module shall be identified in the vendor documentation. Components to be listed shall include all of the following: <br> <ol type=1>   <li> the set of executable file or files that constitute the cryptographic module; <br>   </li>   <li> other security relevant component types not listed above. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.17.02",
        level: "1",
        requirement:
          "The vendor documentation shall indicate the internal firmware architecture, including how the firmware components interact. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.17.03",
        level: "1",
        requirement:
          "The vendor documentation shall indicate the firmware environment (e.g. operating system, run-time library, etc.) on which the module executes. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.17.04",
        level: "1",
        requirement:
          "For each processor in the computing platform of the operational environment bound to the firmware module, the vendor shall identify, by major services, the firmware that is executed by the processor, and the memory devices that contain the executable code and data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.17.05",
        level: "1",
        requirement:
          "For each processor in the computing platform of the operational environment bound to the firmware module, the vendor shall identify any hardware with which the processor interfaces. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.01",
        level: "1",
        requirement:
          "The tester shall verify that the documentation includes a components list that includes all firmware components of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.02",
        level: "1",
        requirement:
          "The tester shall verify that the components list includes all occurrences of the following types of components, excluding only component types that are not used in the module: <br> <ol type=1>   <li> the set of executable file or files that constitute the cryptographic module; <br>   </li>   <li> other component types not listed above. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.03",
        level: "1",
        requirement:
          "The tester shall verify that the components list is consistent with information provided for other assertions of 6.2.3, as defined below. <br> <ol type=1>   <li> The specification of the cryptographic boundary under assertion <a href='#AS02.07'>AS02.07</a>. Verify that all components inside the cryptographic boundary are included in the components list and vice versa. Also verify that any components outside the cryptographic boundary are not listed as components of the cryptographic module. <br>   </li>   <li> The specification of the firmware under assertion ASA.01. Verify that the list of firmware components is the same as in the specifications under assertion <a href='#AS02.07'>AS02.07</a>. <br>   </li>   <li> The specification of the block diagram under assertion ASA.01. Verify that any individual components identified in the block diagram are also listed in the components list. <br>   </li>   <li> Any components that are to be excluded from the requirements of ISO/IEC 19790:2012 under the provisions of assertions <a href='#AS02.13'>AS02.13</a> and <a href='#AS02.14'>AS02.14</a>. Verify that components to be so excluded are still listed in the components list. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.04",
        level: "1",
        requirement:
          "As a partial exception to the above requirements, the vendor is allowed to exclude certain components from the requirements of ISO/IEC 19790:2012 after satisfying the requirements under assertions <a href='#AS02.13'>AS02.13</a> and <a href='#AS02.14'>AS02.14</a> in 6.2.3.1. The tester shall verify that any interfaces or physical connections between such excluded components and the rest of the module do not allow the following: <br> <ol type=1>   <li> uncontrolled release of CSPs, plaintext data, or other information that if misused could lead to a compromise; <br>   </li>   <li> uncontrolled modifications of SSPs or other information that could lead to a compromise. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.05",
        level: "1",
        requirement:
          "The tester shall verify that the vendor�s documentation indicates the major firmware components of the module and how they are linked together forming the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.06",
        level: "1",
        requirement:
          "The tester shall verify the documentation provided under assertion <a href='#AS02.02'>AS02.02</a>, with a focus on the block diagram depicting all of the major hardware components of a cryptographic module and component interconnections, including any microprocessors, input/output buffers, plaintext/ciphertext buffers, control buffers, key storage, working memory, and program memory. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.07",
        level: "1",
        requirement:
          "The tester shall verify that the block diagram indicates all significant interconnections and data flows among major components of the module, and between the module and outside equipment. In particular, each line on the block diagram indicating an interconnection must be labeled with the type of information it transmits. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.08",
        level: "1",
        requirement:
          "The tester shall verify that the block diagram indicates the cryptographic boundary for the cryptographic module, as required under this assertion. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.09",
        level: "1",
        requirement:
          "The tester shall verify that, for each processor in the computing platform of the operational environment bound to the firmware module, the vendor has identified the firmware code modules executed by that processor, the services performed by that processor and associated code, and the memory devices containing the executable code and data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.17.10",
        level: "1",
        requirement:
          "The tester shall verify that, for each processor in the computing platform of the operational environment bound to the firmware module, the vendor has identified any hardware with which the processor interfaces. This must include, as applicable, any hardware components that provide input, control, or status data to the processor and associated firmware, and any hardware components that receive output, control, or status data from the processor and associated firmware. Such hardware components may be within the cryptographic module or may be user equipment outside the module such as input/output devices. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.18",
        level: "1",
        requirement:
          "The cryptographic boundary of a hybrid cryptographic module shall: <br> <br>- be the composite of the module&#39;s hardware component boundary and the disjoint software or firmware component(s) boundary; and <br> </ol><br>- include the collection of all ports and interfaces from each component. <br> NOTE	In addition to the disjoint software or firmware component(s), the hardware component can also include embedded software or firmware. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.18.01",
        level: "1",
        requirement:
          "<a href='#VE02.18.01'>VE02.18.01</a>: The cryptographic module shall be identified in the vendor documentation as either a Hybrid Software Module or a Hybrid Firmware Module. <br> <ol type=1>   <li> For Hybrid Software Module components, the vendor documentation shall provide information required under <a href='#VE02.15.01'>VE02.15.01</a> to <a href='#VE02.15.06'>VE02.15.06</a> and <a href='#VE02.16.01'>VE02.16.01</a> to <a href='#VE02.16.03'>VE02.16.03</a>. <br>   </li>   <li> For Hybrid Firmware Module components, the vendor documentation shall provide information required under <a href='#VE02.15.01'>VE02.15.01</a> to <a href='#VE02.15.06'>VE02.15.06</a> and <a href='#VE02.17.01'>VE02.17.01</a> to <a href='#VE02.17.05'>VE02.17.05</a>. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.18.01",
        level: "1",
        requirement:
          "The tester shall verify that the documentation identifies the module as either a Hybrid Software Module or a Hybrid Firmware Module. <br> <ol type=1>   <li> For Hybrid Software Module components, the tester shall follow procedures required under <a href='#TE02.15.01'>TE02.15.01</a> to <a href='#TE02.15.14'>TE02.15.14</a> and <a href='#TE02.16.01'>TE02.16.01</a> to <a href='#TE02.16.05'>TE02.16.05</a>. <br>   </li>   <li> For Hybrid Firmware Module components, the tester shall follow procedures required under <a href='#TE02.15.01'>TE02.15.01</a> to <a href='#TE02.15.14'>TE02.15.14</a> and <a href='#TE02.17.01'>TE02.17.01</a> to <a href='#TE02.17.10'>TE02.17.10</a>. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.19",
        level: "1",
        requirement:
          "The operator shall be able to operate the module in an approved mode of operation. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.19.01",
        level: "1",
        requirement:
          "The vendor provided non-proprietary security policy shall provide a description of the approved mode of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.19.02",
        level: "1",
        requirement:
          "The vendor provided non-proprietary security policy shall provide instructions for invoking the approved mode of operation. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.19.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided non-proprietary security policy contains a description of the approved mode of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.19.02",
        level: "1",
        requirement:
          "The tester shall invoke the approved mode of operation using the vendor provided instructions found in the non-proprietary security policy. The tester shall verify, by inspection and from the vendor documentation, that the cryptographic module is the approved mode of operation as a result of documented instructions. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.20",
        level: "1",
        requirement:
          "An approved mode of operation shall be defined as the set of services which include at least one service that utilizes an approved cryptographic algorithm, security function or process and those services or processes specified in (ISO/IEC 19790:2012) 7.4.3. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.20.01",
        level: "1",
        requirement:
          "The vendor shall provide a validation certificate for each approved security function. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.20.02",
        level: "1",
        requirement:
          "The vendor shall provide a list of all non-approved security functions. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.20.01",
        level: "1",
        IGs: [
          "2.3.A", "2.4.B", "C.A", "C.B", "C.C", "C.D", "C.F", "C.G", "C.H", "C.I", "C.J", "D.H", "D.K", "D.O"
        ],
        Anchors: [
          "h.3dy6vkm", "h.44sinio", "h.2nusc19", "h.1302m92", "h.3mzq4wv", "h.2250f4o", "h.1gf8i83", "h.3ep43zb", "h.184mhaj", "h.279ka65", "h.meukdy", "h.rjefff", "h.14ykbeg-1"
        ],
        requirement:
          "The tester shall verify that the vendor has provided a validation certificate for each approved security function issued by a validation authority. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.20.02",
        level: "1",
        IGs: ["C.D", "D.H"],
        Anchors: ["h.2250f4o", "h.rjefff"],
        requirement:
          "The tester shall verify that the vendor has provided the list of non-approved security functions. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.21",
        level: "1",
        requirement:
          "Non-approved cryptographic algorithms, security functions, and processes or other services not specified in (ISO/IEC 19790:2012) 7.4.3 shall not be utilized by the operator in an approved mode of operation unless the non-approved cryptographic algorithm or security function is part of an approved process and is not security relevant to the approved processes operation (e.g. a non-approved cryptographic algorithm or non-approved generated key may be used to obfuscate data or CSPs but the result is considered unprotected plaintext and provides no security relevant functionality until protected with an approved cryptographic algorithm). <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.21.01",
        level: "1",
        requirement:
          "The vendor provided documentation shall identify all of non-approved cryptographic algorithms, security functions or processes utilized for each service in each approved mode of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.21.02",
        level: "1",
        requirement:
          "The vendor documentation shall provide a rationale for why utilized non-approved cryptographic algorithms, security functions or processes are considered non-security relevant to the approved processes operation. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.20.03",
        level: "1",
        requirement:
          "The vendor shall provide a list of all vendor affirmed security methods.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.20.04",
        level: "1",
        requirement:
          "The vendor provided non-proprietary security policy shall include a list of all vendor affirmed security methods. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.21.01",
        level: "1",
        IGs: ["2.4.A"],
        Anchors: ["h.lnxbz9"],
        requirement:
          "The tester shall verify by inspection that the vendor provided documentation identifies all of non-approved cryptographic algorithms, security functions or processes utilized for each service in each approved mode of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.21.02",
        level: "1",
        IGs: ["2.4.A"],
        Anchors: ["h.lnxbz9"],
        requirement:
          "The tester shall verify the correctness of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.20.03",
        level: "1",
        requirement:
          "The tester shall verify that the vendor has provided the list of vendor affirmed security methods as described above. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.20.04",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided documentation specifies how the implemented vendor affirmed security methods conform to the relevant standards. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.22",
        level: "1",
        requirement:
          "CSPs shall be exclusive between approved and non-approved services and modes of operation (e.g. not shared or accessed). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.22.01",
        level: "1",
        requirement:
          "The vendor shall provide a list of all CSPs within the module and identify their usage between approved and non-approved services and mode of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.22.02",
        level: "1",
        requirement:
          "The vendor shall provide a description of how each CSP becomes exclusive between approved and non-approved services and modes of operation. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.22.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided documentation contains a description of the usage of each CSP in an approved or non-approved mode of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.22.02",
        level: "1",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the CSPs are exclusive between approved and non-approved services and modes of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.23",
        level: "1",
        requirement:
          "The module&#39;s security policy shall define the complete set of services that are provided for each defined mode of operation (both approved and non-approved). <br> NOTE	This assertion is tested under ASB.01. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.24",
        level: "1",
        requirement:
          "All services shall provide an indicator when the service utilizes an approved cryptographic algorithm, security function or process in an approved manner and those services or processes specified in (ISO/IEC 19790:2012) 7.4.3. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.24.01",
        level: "1",
        requirement:
          "The vendor provided documentation shall specify the indicator for each service. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.24.01",
        level: "1",
        IGs: ["2.4.C"],
        Anchors: ["h.2jxsxqh"],
        requirement:
          "The tester shall verify that the vendor provided documentation contains a description of indicator when the service utilizes an approved cryptographic algorithm, security function or process in an approved manner. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.24.02",
        level: "1",
        IGs: ["2.4.C"],
        Anchors: ["h.2jxsxqh"],
        requirement:
          "The tester shall execute all services and verify that the indicator provides an unambiguous indication of whether the service utilizes an approved cryptographic algorithm, security function or process in an approved manner or not. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.25",
        level: "1",
        requirement:
          "For a cryptographic module to operate in degraded operation, the following (ISO/IEC 19790:2012 <a href='#AS02.26'>AS02.26</a> to <a href='#AS02.30'>AS02.30</a>) shall apply. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.26",
        level: "1",
        requirement:
          "The degraded operation shall be entered only after exiting an error state. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.26.01",
        level: "1",
        requirement:
          "If the cryptographic module allows a degraded operation, the vendor shall provide a description of all degraded operation after exiting each error state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.26.02",
        level: "1",
        requirement:
          "The vendor shall provide specification of degraded operation. For each degraded operation, the specification shall include: <br> <ol type=1>   <li> conditions of entry into and exit from the degraded operation; <br>   </li>   <li> operational algorithms, security functions, services, or processes; <br>   </li>   <li> non-operational algorithms, security functions, services, or processes; <br>   </li>   <li> isolated mechanisms, functions, or components in the degraded operation; <br>   </li>   <li> techniques to isolate mechanisms, functions, or components; <br>   </li>   <li> status information provided in the degraded operation; <br>   </li>   <li> status indicator if attempts are made to use a non-operational algorithm, security function, or process. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.26.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided documentation clearly identifies the degraded operation and its conditions of entry and exit. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.26.02",
        level: "1",
        requirement:
          "The tester shall use the vendor documentation to check that the degraded operation can only be accessed after exiting in error state. The tester shall check that the error status indicator (see <a href='#AS03.11'>AS03.11</a>) is correctly positioned. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.26.03",
        level: "1",
        requirement:
          "The tester shall exercise the cryptographic module, causing it to operate in each degraded operation. For each degraded operation, the tester shall attempt to perform a service to verify that all conditional algorithm self-tests are performed prior to the first operational use of any cryptographic algorithm. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.26.04",
        level: "1",
        requirement:
          "The tester shall first exercise the cryptographic module, causing it to operate in each degraded operation. The tester shall next perform pre-operational self-tests to verify that the cryptographic module remains in degraded operation until such time the cryptographic module passes without failure all pre-operational self-tests successfully. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.26.05",
        level: "1",
        requirement:
          "The tester shall first exercise the cryptographic module, causing it to operate in each degraded operation. The tester shall next perform pre-operational self-tests, causing an error condition in pre-operational self-tests to occur. The tester shall verify that the cryptographic module does not remain in degraded operation but enters an error state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.27",
        level: "1",
        requirement:
          "The module shall provide status information when re-configured and the degraded operation entered. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS02.26'>AS02.26</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.28",
        level: "1",
        requirement:
          "The mechanism or function that failed shall be isolated. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.28.01",
        level: "1",
        requirement:
          "The vendor documentation requirement is specified under <a href='#VE02.26.02'>VE02.26.02</a>. The vendor design shall ensure that any failure from the failed mechanisms, functions, and components cannot interfere or compromise the approved operation of the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.28.01",
        level: "1",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that failed mechanisms, functions, and components are isolated before entering degraded operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.28.02",
        level: "1",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that failed mechanisms, functions, and components cannot interfere or compromise the approved operation of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.29",
        level: "1",
        requirement:
          "All conditional algorithm self-tests shall be performed prior to the first operational use of the cryptographic algorithm after entering degraded operation. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS02.26'>AS02.26</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.30",
        level: "1",
        requirement:
          "Services shall provide an indicator if attempts are made to use a non-operational algorithm, security function, or process. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE02.30.01",
        level: "1",
        requirement:
          "The vendor documentation requirement is specified under <a href='#VE02.26.02'>VE02.26.02</a>. The vendor design shall ensure that service output includes an indicator if attempts are made to use a non-operational algorithm, security function, or process. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.30.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation that services provide documented <br> indicators if attempts are made to use a non-operational algorithm, security function, or process. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE02.30.02",
        level: "1",
        requirement:
          "The tester shall exercise the cryptographic module and verify that the documented indicator is provided if attempts are made to use a non-operational algorithm, security function, or process. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.31",
        level: "1",
        requirement:
          "The cryptographic module shall remain in degraded operation until such time the cryptographic module passes without failure all pre-operational self-tests successfully. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS02.26'>AS02.26</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS02.32",
        level: "1",
        requirement:
          "If the cryptographic module fails the pre-operational self-tests, the module shall not enter a degraded operation. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS02.26'>AS02.26</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "3",
    dtrs: [
      {
        dtrId: "AS03.01",
        level: "1",
        requirement:
          "A cryptographic module shall restrict all logical information flow to only those physical access points and logical interfaces that are identified as entry and exit points to and from the cryptographic boundary of the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.01.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify each of the physical ports and logical interfaces of the cryptographic module, including the following: <br> <ol type=1>   <li> physical ports and their pin assignments; <br>   </li>   <li> physical covers, doors or openings; <br>   </li>   <li> logical interfaces (e.g. APIs and all other data/control/status signals) and the signal names and functions; <br>   </li>   <li> manual controls (e.g. buttons or switches) for applicable physical control inputs; <br>   </li>   <li> physical status indicators (e.g. lights or displays) for applicable physical status outputs; <br> </ol>  </li>   <li> mapping of the logical interfaces to the physical ports, manual controls, and physical status indicators of the cryptographic module; <br>   </li>   <li> physical, logical, and electrical characteristics, as applicable, of the above ports and interfaces. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.01.02",
        level: "1",
        requirement:
          "The vendor documentation shall specify the information flows and physical access points of the cryptographic module by highlighting or annotating copies of the block diagrams, design specifications, and/or source code and schematics provided in  6.2 and  6.11. The vendor shall also provide any other documentation necessary to clearly specify the relationship of the information flows and physical access points to the physical ports and logical interfaces. The vendor shall establish the above information in relation with the information provided under assertions <a href='#AS02.07'>AS02.07</a> and <a href='#AS02.15'>AS02.15</a> to <a href='#AS02.18'>AS02.18</a> without inconsistencies in the description of components and physical layout for the input/output ports. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.01.03",
        level: "1",
        requirement:
          "For each physical or logical input to the cryptographic module, or physical and logical output from the module, the vendor documentation shall specify the logical interface to which the physical input or output belongs, and the physical entry/exit port. The specifications provided shall be consistent with the specifications of the cryptographic module components provided under 6.2 and 6.11, and the specifications of the logical interfaces provided in assertions <a href='#AS03.04'>AS03.04</a> to <a href='#AS03.11'>AS03.11</a> of 6.3.3. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.01.01",
        level: "1",
        requirement:
          "The tester shall verify that vendor documentation specifies each of the physical ports and logical interfaces of the cryptographic module. The required specifications shall include: <br> <ol type=1>   <li> all physical input and output ports, including their pin assignments, physical locations within the module, a summary of the logical signals that flow through each port, and the timing sequence of signal flows if two or more signals share the same physical pin; <br>   </li>   <li> all physical covers, doors, or openings, including their physical location within the cryptographic module, and the components or functions that can be accessed and/or modified via each cover/door/ opening; <br>   </li>   <li> all logical input and output interfaces (e.g. APIs and all other data/control/status signals), including a listing or annotated block diagram of all the logical data and control inputs and data and status outputs of the cryptographic module, and a listing and description of the signal names and functions; <br>   </li>   <li> all manual controls used to physically enter control signals, such as switches or buttons, including their physical location within the cryptographic module, and a listing and description of the control signals that can be entered manually; <br>   </li>   <li> all physical status indicators, including their physical location within the module and a listing and description of the status indication signals that are output physically; <br>   </li>   <li> a mapping of the logical input and output interfaces to the physical input and output ports, manual controls, and physical status indicators of the cryptographic module; <br>   </li>   <li> physical, logical, and electrical characteristics, as applicable, of the above physical ports and interfaces, including summaries of pin designations, logical signals carried on each port, voltage levels and their logical significance (e.g. what a low or high voltage signifies in terms of a logic 0, 1, or other meaning) and the timing of signals. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.01.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies all information flows and physical access points of the cryptographic module, by examining the block diagrams, design specifications, and/or source code and schematics provided in 6.2 and 6.11, and any other documentation provided by the vendor. The documentation shall specify the relationship of the information flows and physical access points to the physical ports and logical interfaces of the cryptographic module. The tester shall compare the above information with the information provided under assertions <a href='#AS02.07'>AS02.07</a> and <a href='#AS02.15'>AS02.15</a> to <a href='#AS02.18'>AS02.18</a> and verify that there are no inconsistencies in the description of components and physical layout for the input/output ports. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.01.03",
        level: "1",
        requirement:
          "The tester shall verify that for each physical or logical input to the cryptographic module, or physical and logical output from the module, the vendor documentation specifies the logical interface to which the physical input or output belongs, and the physical entry/exit port. The specifications provided shall be consistent with the specifications of the cryptographic module components provided under 6.2  and 6.11, and the specifications of the logical interfaces provided in assertions <a href='#AS03.04'>AS03.04</a> to <a href='#AS03.11'>AS03.11</a> of 6.3.3. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.01.04",
        level: "1",
        requirement:
          "The tester shall verify, by inspection of the cryptographic module, that all the above specifications provided by the vendor documentation are consistent with the actual design of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.02",
        level: "1",
        requirement:
          "The cryptographic module logical interfaces shall be distinct from each other although they may share one physical port (e.g. input data may enter and output data may exit via the same port) or may be distributed over one or more physical ports (e.g. input data may enter via both a serial and a parallel port). <br> </ol>NOTE	An Application Program Interface (API) of a software component of a cryptographic module can be defined as one or more logical interface(s). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.02.01",
        level: "1",
        requirement:
          "The vendor�s design shall separate the cryptographic module interfaces into logically distinct and isolated categories, using the categories listed in assertion <a href='#AS03.04'>AS03.04</a>, and, if applicable, <a href='#AS03.12'>AS03.12</a> and <a href='#AS03.13'>AS03.13</a> in 6.3.3. This information shall be consistent with the specification of the logical interfaces and physical ports provided in <a href='#AS03.01'>AS03.01</a> in 6.3.1. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.02.02",
        level: "1",
        requirement:
          "The vendor documentation shall provide a mapping of each category of logical interface to a physical port of the cryptographic module. A logical interface may be physically distributed across more than one physical port, or two or more logical interfaces may share one physical port as long as the information flows are kept logically separate. If two or more logical interfaces share the same physical port, the vendor documentation shall specify how the information from the different interface categories is kept logically separate. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.02.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the cryptographic module that the module interfaces are logically distinct and isolated for the categories of interfaces specified in assertions <a href='#AS03.04'>AS03.04</a> and, if applicable, <a href='#AS03.12'>AS03.12</a> and <a href='#AS03.13'>AS03.13</a> of 6.3.3. This <br> information shall be consistent with the specification and design of the logical interfaces and physical ports provided in <a href='#AS03.01'>AS03.01</a> in 6.3.1. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.02.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation provides a mapping of each category of logical interface to a physical port of the cryptographic module. A logical interface may be physically distributed across more than one physical port, or two or more logical interfaces may share one physical port. If two or more interfaces share the same physical port, the tester shall verify that the vendor documentation specifies how the information flows for the input, output, control, and status interfaces are kept logically separate. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.03",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.3 shall be provided. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.03.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation as specified in ISO/IEC 19790:2012, A.2.3. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.03.01",
        level: "1",
        requirement:
          "The tester shall verify completeness of the documentation specified in ISO/IEC 19790:2012, A.2.3. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.04",
        level: "1",
        requirement:
          "A cryptographic module shall have the following five interfaces (input and output are indicated from the perspective of the module): <br> <br>- data input interface; <br> <br>- data output interface; <br> <br>- control input interface; <br> <br>- control output interface; <br> <br>- status output interface. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.04.01",
        level: "1",
        requirement:
          "The vendor documentation shall separate the cryptographic module interfaces into logically distinct and isolated categories by the following five distinctly defined logical interfaces within --- cryptographic module (-input� and -output� are indicated from the perspective of the module): <br> <ol type=1>   <li> data input interface (for the input of data as specified in <a href='#AS03.05'>AS03.05</a>); <br>   </li>   <li> data output interface (for the output of data as specified in <a href='#AS03.06'>AS03.06</a> and <a href='#AS03.07'>AS03.07</a>); <br>   </li>   <li> control input interface (for the input of commands as specified in <a href='#AS03.08'>AS03.08</a>); <br>   </li>   <li> control output interface (for the output of commands as specified in <a href='#AS03.09'>AS03.09</a>, and <a href='#AS03.10'>AS03.10</a>); <br>   </li>   <li> status output interface (for the output of status information as specified in <a href='#AS03.11'>AS03.11</a>). Required Test Procedures <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.04.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies that the five logical interfaces as listed in <a href='#VE03.04.01'>VE03.04.01</a> have been designed within the cryptographic module. If so, <br> verification that the logical interfaces within the cryptographic module function as specified shall be performed under assertions <a href='#AS03.05'>AS03.05</a> to <a href='#AS03.11'>AS03.11</a> in 6.3.3. <br> Data input interface  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.05",
        level: "1",
        requirement:
          "All data (except control data entered via the control input interface) that is input to and processed by a cryptographic module (including plaintext data, ciphertext data, SSPs, and status information from another module) shall enter via the - data input� interface. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.05.01",
        level: "1",
        requirement:
          "The cryptographic module shall have a data input interface. All data (except control data entered via the control input interface) that is to be input to and processed by the cryptographic module shall enter via the data input interface, including: <br> <ol type=1>   <li> plaintext data; <br>   </li>   <li> ciphertext or signed data; <br>   </li>   <li> cryptographic keys and other key management data (plaintext or encrypted); <br>   </li>   <li> authentication data (plaintext or encrypted); <br>   </li>   <li> status information from external sources; <br>   </li>   <li> any other input data. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.05.02",
        level: "1",
        requirement:
          "If applicable, the vendor documentation shall specify any external input devices to be used with the cryptographic module for the entry of data into the data input interface, such as smart cards, tokens, keypads, key loaders, and/or biometric devices. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.05.01",
        level: "1",
        requirement:
          "The tester shall verify, by inspection, that the cryptographic module includes a data input interface, and that the data input interface functions as specified. The tester shall verify that all data (except control data entered via the control input interface) that is to be input to and processed by the cryptographic module enters via the data input interface, including: <br> <ol type=1>   <li> plaintext data that is to be encrypted or signed by the cryptographic module; <br>   </li>   <li> ciphertext or signed data that is to be decrypted or verified by the module; <br>   </li>   <li> plaintext or encrypted cryptographic keys and other key management data that are input into and used by the cryptographic module, including initialization data and vectors, split key information, and/or key accounting information. (Other key management requirements are covered in ISO/IEC 19790:2012, 7.9.); <br>   </li>   <li> plaintext or encrypted authentication data that is input into the cryptographic module, including passwords, PINs, and/or biometric information; <br>   </li>   <li> status information from external sources (e.g. another cryptographic module or device); <br>   </li>   <li> any other information that is input into the cryptographic module for processing or storage, except for control information that is covered separately in <a href='#AS03.08'>AS03.08</a>. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.05.02",
        level: "1",
        requirement:
          "The tester shall verify if the vendor documentation specifies any external input devices to be used with the cryptographic module for the entry of data into the data input interface, such as smart cards, tokens, keypads, key loaders, and/or biometric devices. The tester shall enter data into the data input interface using the identified external input device(s), and verify that entry of data using the external input device functions as specified. <br> Data output interface  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.06",
        level: "1",
        requirement:
          "All data (except status data output via the status output interface and control data output via the control output interface) that is output from a cryptographic module (including plaintext data, ciphertext data, and SSPs) shall exit via the - data output� interface. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.06.01",
        level: "1",
        requirement:
          "The cryptographic module shall have a data output interface. All data (except status data output via the status output interface and control data output via the control output interface) that has been processed and is to be output by the cryptographic module shall exit via the data output interface, including: <br> <ol type=1>   <li> plaintext data; <br>   </li>   <li> ciphertext data and digital signatures; <br>   </li>   <li> cryptographic keys and other key management data (plaintext or encrypted); <br>   </li>   <li> any other information that is output from the cryptographic module after processing or storage except for status information that is covered separately in <a href='#AS03.11'>AS03.11</a> and control information that is covered separately in <a href='#AS03.09'>AS03.09</a> and <a href='#AS03.10'>AS03.10</a> in 6.3.3. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.06.02",
        level: "1",
        requirement:
          "If applicable, the vendor documentation shall specify any external output devices to be used with the cryptographic module for the output of data from the data output interface, such as smart cards, tokens, displays, and/or other storage devices. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.06.01",
        level: "1",
        requirement:
          "The tester shall verify, by inspection, that the cryptographic module includes a data output interface, and that the data output interface functions as specified. The tester shall verify that all data (except status data output via the status output interface and control data output via the control output interface) that has been processed and is to be output by the cryptographic module exits via the data output interface, including: <br> <ol type=1>   <li> plaintext data that has been decrypted by the cryptographic module; <br>   </li>   <li> ciphertext data that has been encrypted, and digital signatures that have been generated by the cryptographic module; <br>   </li>   <li> plaintext or encrypted cryptographic keys and other key management data that have been internally generated and output from the module, including initialization data and vectors, split key information, and/or key accounting information (other key management requirements are covered in ISO/IEC 19790:2012, 7.9); <br>   </li>   <li> any other information that is output from the cryptographic module after processing or storage except for status information that is covered separately in <a href='#AS03.11'>AS03.11</a> in 6.3.3 and control information that is covered separately in <a href='#AS03.09'>AS03.09</a> and <a href='#AS03.10'>AS03.10</a> in 6.3.3. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.06.02",
        level: "1",
        requirement:
          "The tester shall verify if vendor documentation specifies any external output devices to be used with the cryptographic module for the output of data from the data output interface, such as smart cards, tokens, displays, and/or other storage devices. The tester shall output data from the data output interface using the identified external output device(s), and verify that output of data using the external output device functions as specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.07",
        level: "1",
        requirement:
          "All data output via the - data output� interface shall be inhibited while performing manual entry, pre-operational self-tests, software/firmware loading and zeroisation; or when the cryptographic module is in an error state. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.07.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the cryptographic module inhibits data output while performing manual entry, pre-operational self-tests, software/firmware loading and zeroisation, or when the cryptographic module is in an error state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.07.02",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the design of the cryptographic module ensures that all data output via the data output interface is inhibited while performing manual entry, pre-operational self-tests, software/firmware loading and zeroisation, or when the cryptographic module is in an error state. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.07.03",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the physical and logical paths used by all major categories of output data exiting the cryptographic module are logically or physically disconnected from the processes performing SSP generation, manual SSP entry, and zeroisation of SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.07.04",
        level: "1",
        requirement:
          "If the physical and logical paths followed by the output data and SSP information are physically shared, the vendor documentation shall specify how the cryptographic module enforces logical separation of the output data and SSP information. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.07.05",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the cryptographic module does not allow the specified SSP processes to pass SSP information to the output data path, and does not allow output data exiting the module to interfere with the SSP processes. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies that all data output via the data output interface is inhibited: <br> <ol type=1>   <li>	whenever the cryptographic module is performing: <br>   </li>     <ol type=a>       <li> manual entry; <br>       </li>       <li> pre-operational self-tests; <br>       </li>       <li> software/firmware loading; <br>       </li>       <li> zeroisation; <br>       </li>     </ol>   <li>	or when the cryptographic module is in an error state. <br> </ol>  <br> <ol type=1>   <li>	The tester shall verify from the vendor documentation that once each of the following services is started, all data output via the data output interface is inhibited, until the service is completed successfully: <br>   </li>     <ol type=a>       <li> manual entry; <br>       </li>       <li> pre-operational self-tests; <br>       </li>       <li> software/firmware loading; <br>       </li>       <li> zeroisation; <br>       </li>     </ol>   <li> The tester shall verify from vendor documentation that once an error condition is detected and the error state is entered, all data output via the data output interface is inhibited, until error recovery occurs. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.02",
        level: "1",
        requirement:
          "The tester shall cause the cryptographic module to enter each of following states: <br> <ol type=1>   <li> a state performing manual SSP entry; <br>   </li>   <li> a self-test state performing pre-operational self-tests; <br>   </li>   <li> a state performing software/firmware loading; <br>   </li>   <li> a state performing zeroisation; <br>   </li>   <li> an error state; <br> </ol>  <br> If it is not possible for the tester to cause an error then the vendor shall provide a rationale to the tester why this test cannot be performed. In such case, the tester shall follow alternative procedures allowed by the validation authority to ensure that all data output via the data output interface is inhibited. <br> EXAMPLE	Examining the applicable source code. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.03",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies that all data output via the data output interface is inhibited whenever the cryptographic module is in a self-test condition. The tester shall verify from the vendor documentation that once self-tests are being performed, all data output via the data output interface is inhibited, until the self-tests are completed. Status information to display the results of the self-tests may be allowed from the status output interface. The tester shall also verify that the self-test conditions specified in response to this assertion are identical to the self-tests specified under <a href='#AS10.14'>AS10.14</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.04",
        level: "1",
        requirement:
          "The tester shall command the module to perform the self-tests and verify that all data output via the data output interface is inhibited. If status information is output from the status output interface to indicate the results of the self-tests, the tester shall verify that no CSPs, plaintext data, or other information are output that, if misused, could lead to a compromise. If it is not possible for the tester to attempt data output during specific self-test state, then the vendor shall provide a rationale to the tester why this test cannot be performed. In such case, the tester shall follow alternative procedures allowed by the validation authority, to ensure that all data output via the data output interface is inhibited. <br> EXAMPLE 1 Examining the applicable source code. <br> EXAMPLE 2 Using a simulator. <br> EXAMPLE 3 Using a debugger. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.05",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies how the cryptographic module ensures that all data output via the data output interface is to be inhibited during error states or self-test conditions. The tester shall also verify, by inspection of the design of the cryptographic module, that the data output interface is, in fact, logically or physically inhibited under these conditions. <br> Control input interface  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.06",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies how the physical and logical paths used by all major categories of output data exiting the cryptographic module are logically or physically disconnected from the processes performing SSP generation, manual SSP entry, and zeroisation of SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.07",
        level: "1",
        requirement:
          "If the physical and logical paths followed by the output data and SSP information are physically shared, the tester shall verify that the vendor documentation specifies how the cryptographic module enforces logical separation of the output data and SSP information. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.07.08",
        level: "1",
        requirement:
          "The tester shall verify that the output data path is logically or physically disconnected from the processes performing SSP generation, manual SSP entry, and zeroisation of SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.08",
        level: "1",
        requirement:
          "All input commands, signals (e.g. clock input), and control data (including function calls and manual controls such as switches, buttons, and keyboards) used to control the operation of a cryptographic module shall enter via the - control input� interface. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.08.01",
        level: "1",
        requirement:
          "The cryptographic module shall have a control input interface. All commands, signals, and control data (except data entered via the data input interface) used to control the operation of the cryptographic module shall enter via the control input interface, including: <br> <ol type=1>   <li> commands input logically via an API (e.g. for the software and firmware components of the cryptographic module); <br>   </li>   <li> signals input logically or physically via one or more physical ports (e.g. for the hardware components of the cryptographic module); <br>   </li>   <li> manual control inputs (e.g. using switches, buttons, or a keyboard); <br>   </li>   <li> any other input control data. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.08.02",
        level: "1",
        requirement:
          "If applicable, the vendor documentation shall specify any external input devices to be used with the cryptographic module for the entry of commands, signals, and control data into the control input interface, such as smart cards, tokens, or keypads. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.08.01",
        level: "1",
        requirement:
          "The tester shall verify, by inspection, that the cryptographic module includes a control input interface, and that the control input interface functions as specified. The tester shall verify that all commands, signals, and control data (except data entered via the data input interface) used to control the operation of the cryptographic module shall enter via the control input interface, including: <br> <ol type=1>   <li> commands input logically via an API, such as function calls to a software library or to a smart card; <br>   </li>   <li> signals input logically or physically via one or more physical ports, such as commands and signals sent through a serial port or a PC Card; <br>   </li>   <li> manual control inputs (e.g. using switches, buttons, or a keyboard); <br>   </li>   <li> any other input control data. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.08.02",
        level: "1",
        requirement:
          "The tester shall verify if the vendor documentation specifies any external input devices to be used with the cryptographic module for the entry of commands, signals, and control data into the control input interface, such as smart cards, tokens, or keypads. The tester shall enter commands via the control input interface using the identified external input device(s), and verify that input of commands using the external input device functions as specified. <br> Control output interface  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.09",
        level: "1",
        requirement:
          "All output commands, signals, and control data (e.g. control commands to another module) used to control or indicate the state of operation of a cryptographic module shall exit via the - control output� interface. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.09.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify all output commands, signals, and control data (e.g. control commands to another module) used to control or indicate the state of operation of a cryptographic module shall exit via the control output interface. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.09.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation shall specify all output commands, signals, and control data (e.g. control commands to another module) used to control or indicate the state of operation of a cryptographic module shall exit via the control output interface. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.09.02",
        level: "1",
        requirement:
          "If the control output interface is specified, the tester shall verify, by inspection, that the control output interface functions as specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.10",
        level: "1",
        requirement:
          "All control output via the - control output� interface shall be inhibited when the cryptographic module is in an error state unless exceptions are specified and documented in the security policy. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.10.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the cryptographic module ensures that all control output via the control output interface is inhibited whenever the module is in an error state (error states are covered in ISO/IEC 19790:2012, 7.11). Status information may be allowed from the status output interface to identify the type of error. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.10.02",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the design of the cryptographic module ensures that all control output via the control output interface is inhibited whenever the module is in a self-test condition (self-tests are covered in ISO/IEC 19790:2012, 7.10). Status information to display the results of the self-tests may be allowed from the status output interface. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.10.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies that all control output via the control output interface is inhibited whenever the cryptographic module is in an error state. The tester shall verify from the vendor documentation that once an error condition is detected and the error state is entered, all control output via the control output interface is inhibited, until error recovery occurs. The tester shall also verify that the error states specified in response to this assertion are identical to the error states specified under <a href='#AS11.08'>AS11.08</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.10.02",
        level: "1",
        requirement:
          "The tester shall cause the cryptographic module to enter each specified error state and verify that all control output via the control output interface is inhibited. If status information is output from the status output interface to identify the type of error, the tester shall verify that the information output is not sensitive. The following actions may be used to cause the cryptographic module to enter an error state - opening a tamper-detecting cover or door, entering incorrectly-formatted commands, keys, or parameters, reducing input voltage, and/or any other error-causing actions. <br> If it is not possible for the tester to cause an error, then the vendor shall provide a rationale to the tester why this test cannot be performed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.10.03",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies that all control output via the control output interface is inhibited whenever the cryptographic module is in a self-test condition. The tester shall verify from the vendor documentation that once self-tests are being performed, all control output via the control output interface is inhibited until the self-tests are completed. The tester shall also verify that the self-test conditions specified in response to this assertion are identical to the self-tests specified under <a href='#AS10.14'>AS10.14</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.10.04",
        level: "1",
        requirement:
          "The tester shall cause the module to perform the self-tests and verify that all control output via the control output interface is inhibited. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.10.05",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies how the cryptographic module ensures that all control output via the control output interface is to be inhibited during error states or self-test conditions. The tester shall also verify, by inspection of the implementation of the cryptographic module, that the control output interface is, in fact, logically or physically inhibited under these conditions. <br> Status output interface  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.11",
        level: "1",
        requirement:
          "All output signals, indicators (e.g. error indicator), and status data [including return codes and physical indicators such as visual (display, indicator lamps), audio (buzzer, tone, ring), and mechanical (vibration)] used to indicate the status of a cryptographic module shall exit via the - status output� interface. <br> NOTE	Status output will be either implicit or explicit. Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.11.01",
        level: "1",
        requirement:
          "The cryptographic module shall have a status output interface. All status information, signals, logical indicators, and physical indicators used to indicate or display the status of the module shall exit via the status output interface, including: <br> <ol type=1>   <li> status information output logically via an API; <br>   </li>   <li> signal outputs logically or physically via one or more physical ports; <br>   </li>   <li> manual status outputs (e.g. using displays, indicator, lamps, buzzer, tone, or ring); <br>   </li>   <li> any other output status information. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.11.02",
        level: "1",
        requirement:
          "If applicable, the vendor documentation shall specify any external output devices to be used with the cryptographic module for the output of status information, signals, logical indicators, <br> and physical indicators via the status output interface, such as smart cards, tokens, displays, and/or other storage devices. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.11.01",
        level: "1",
        requirement:
          "The tester shall verify, by inspection, that the cryptographic module includes a status output interface, and that the status output interface functions as specified. The tester shall verify that all status information, signals, logical indicators, and physical indicators used to indicate or display the status of the module shall exit via the status output interface, including: <br> <ol type=1>   <li> status information output logically via an API, such as return codes from a software library or a smart card; <br>   </li>   <li> signal outputs logically or physically via one or more physical ports, such as status information sent through a serial port or a PC Card connector; <br>   </li>   <li> manual status outputs (e.g. using LEDs, buzzers, or a display); <br>   </li>   <li> any other output status information. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.11.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies any external output devices (if applicable) to be used with the cryptographic module for the output of status information, signals, logical indicators, and physical indicators via the status output interface. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.11.03",
        level: "1",
        requirement:
          "The tester shall verify that the status information output from the status output interface shall not output any information that could result in a compromise of CSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.12",
        level: "1",
        requirement:
          "Except for the software cryptographic modules, all modules shall also have the following interface. <br> NOTE	This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.13",
        level: "1",
        requirement:
          "Power interface: All external electrical power that is input to a cryptographic module shall enter via a power interface. <br> NOTE	A power interface is not required if all power is provided or maintained internal to the module, and that replacement of an internal battery is considered a physical maintenance activity, and is subject to the requirements specified in ISO/IEC 19790:2012, 7.7. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.13.01",
        level: "1",
        requirement:
          "If the cryptographic module requires or provides power to/from other devices external to the boundary (e.g. a power supply or an external battery), the vendor documentation shall specify a power interface and a corresponding physical port. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.13.02",
        level: "1",
        requirement:
          "All power entering or exiting the cryptographic module to/from other devices external to the cryptographic boundary shall pass through the specified power interface. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.13.01",
        level: "1",
        requirement:
          "The tester shall verify if the vendor documentation specifies whether the cryptographic module requires or provides power to/from other devices external to the cryptographic boundary (e.g. a power supply, power cord, power inlet/outlet, or an external battery). The tester shall also verify that the vendor documentation specifies a power interface and a corresponding physical port. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.13.02",
        level: "1",
        requirement:
          "The tester shall verify, by inspection of the cryptographic module that all power entering or exiting the module to/from other devices external to the cryptographic boundary passes through the specified power interface. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.14",
        level: "1",
        requirement:
          "The cryptographic module shall distinguish between data, control information, and power for input, and data, control information, status information, and power for output. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.14.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the cryptographic module distinguishes between data and control for input and data, control and status for output, and how the physical and logical paths followed by the input data and control information entering the module via the applicable input interfaces are logically or physically disconnected from the physical and logical paths followed by the output data, control and status information exiting the module via the applicable output interfaces. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.14.02",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the physical and logical paths used by the input data and control information are logically or physically disconnected from the physical and logical paths used by the output data, control and status information. If the physical and logical paths used by the input data and control information and the output data, control and status information are physically shared, the vendor documentation shall specify how logical separation is enforced by the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.14.03",
        level: "1",
        requirement:
          "The vendor documentation shall show consistency and shall show that the cryptographic module distinguishes between data and control for input and data, control and status for output, and that the physical and logical paths followed by the input data and control information entering the module via the applicable input interfaces are logically or physically disconnected from the physical and logical paths followed by the output data, control and status information exiting the module via the applicable output interfaces. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.14.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies how the cryptographic module distinguishes between data and control for input and data, control and status for output. Input data entered from the data input interface, and control information entered from the control input interface shall be logically or physically distinguished from output data exiting to the output data interface, output control exiting to the output control interface, and status information exiting to the status output interface. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.14.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies how the physical and logical paths used by the input data and control information are logically or physically disconnected from the physical and logical paths used by the output data, control and status information. If the physical and logical paths used by the input data and control information and the output data, control and status information are physically shared, the tester shall verify that the vendor documentation specifies how logical separation is enforced by the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.14.03",
        level: "1",
        requirement:
          "The tester shall verify, by inspection, the consistency of the vendor documentation, and that the cryptographic module distinguishes between data and control for input and data, control and status for output, and that the physical and logical paths followed by the input data and control information entering the module via the applicable input interfaces are logically or physically disconnected from the physical and logical paths followed by the output data, control and status information exiting the module via the applicable output interfaces. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.15",
        level: "1",
        requirement:
          "The cryptographic module specification shall, unambiguously, specify format of input data and control information, including length restrictions for all variable length inputs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.15.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the physical and logical paths used by all major categories of input data entering the cryptographic module via the data input interface and the applicable physical ports. The documentation shall include a specification of the applicable paths (e.g. by highlighted or annotated copies of the schematics, block diagrams, or other information provided under <a href='#AS02.07'>AS02.07</a> and <a href='#AS02.15'>AS02.15</a> to <a href='#AS02.18'>AS02.18</a>). All input data entering the cryptographic module via the data input interface shall only use the specified paths while being processed or stored by each physical or logical sub-section of the module. The input data paths shall be specified in sufficient detail to verify which type of data pass through each applicable physical port. <br> NOTE	The term - all major categories of input data� refer to items addressed in <a href='#AS03.05'>AS03.05</a> for data input and to items addressed in <a href='#AS03.08'>AS03.08</a> for control input. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.15.02",
        level: "1",
        requirement:
          "The vendor documentation shall specify that all input data entering the cryptographic module via the data input interface and applicable physical ports only use the specified paths. The documentation shall show that all logical and physical information flows used by the input data are consistent with the design and operation of the cryptographic module. The vendor documentation shall establish that there are no conflicts between the applicable paths that may lead to the compromise of CSPs, plaintext data, or other information of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.15.03",
        level: "1",
        requirement:
          "The vendor provided documentation shall unambiguously specify format of input data and control information including length restrictions for all variable length inputs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.15.04",
        level: "1",
        requirement:
          "The vendor provided documentation shall identify which component within the cryptographic boundary is validating the format. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.15.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies the physical and logical paths used by all major categories of input data entering the cryptographic module via the data input interface. The tester shall also verify that the paths shall be documented in the specification (e.g. by highlighted or annotated copies of the schematics, block diagrams, or other information provided under <a href='#AS02.07'>AS02.07</a> and <a href='#AS02.15'>AS02.15</a> to <a href='#AS02.18'>AS02.18</a>). The tester shall verify the documentation which type of data pass through each applicable physical port. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.15.02",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the cryptographic module, that all input data entering the module via the data input interface and applicable physical ports only use the specified paths. The tester shall examine all logical and physical information flows and shall verify that the specification of the paths used by the input data is consistent with the design and operation of the cryptographic module. The tester shall verify that there are no conflicts between the applicable paths that may lead to the compromise of CSPs, plaintext data, or other information. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.15.03",
        level: "1",
        requirement:
          "The tester shall verify, by inspection and from the vendor documentation, that the unambiguous specification is provided about the format of input data and control information, including length restrictions for all variable length inputs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.15.04",
        level: "1",
        requirement:
          "The tester shall verify that the identified component within the cryptographic boundary is located on the specified path under <a href='#VE03.15.02'>VE03.15.02</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.15.05",
        level: "1",
        requirement:
          "The tester shall examine the applicable source code(s) to ensure that the identified component is actually validating the documented format. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.15.06",
        level: "1",
        requirement:
          "The tester shall attempt to input data and/or control information which is not compliant with the format, and verify that such service inputs are rejected by the cryptographic module. <br> NOTE	The test platform or configuration can impose a part of format/restrictions. EXAMPLE 1 A device driver to use the cryptographic module is enforcing a part of the format. EXAMPLE 2 A layer in a protocol stack supports fixed length packet only. <br> If it is not possible for the tester to input certain data or control information which is not compliant with the format, then the tester shall require the vendor to provide a rationale why this test cannot be performed. In such case, the tester shall follow alternative procedures allowed by the validation authority to ensure that the cryptographic module is validating the format. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.16",
        level: "3",
        requirement:
          "For the transmission of unprotected plaintext CSPs, key components and authentication data between the cryptographic module and the sender or receivers endpoint the cryptographic module shall implement a trusted channel. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.16.01",
        level: "3",
        requirement:
          "The vendor shall describe the method of transmission of unprotected CSPs and the way they are protected via a trusted channel. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.16.01",
        level: "3",
        IGs: ["3.4.A", "9.5.A"],
        Anchors: ["h.4i7ojhp", "h.19c6y18"],
        requirement:
          "The tester shall verify that the trusted channel is able to protect unprotected CSPs between the cryptographic module boundary and the sender or receiver endpoint. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.17",
        level: "3",
        requirement:
          "The trusted channel shall prevent unauthorized modification, substitution, and disclosure along the communication link. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS03.18'>AS03.18</a> or <a href='#AS03.19'>AS03.19</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.18",
        level: "3",
        requirement:
          "The physical ports used for the trusted channel shall be physically separated from all other ports (or <a href='#AS03.19'>AS03.19</a> shall be satisfied}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.18.01",
        level: "3",
        requirement:
          "The vendor documentation shall specify if the cryptographic module inputs or outputs plaintext CSPs. The physical port(s) used for the input and output of plaintext CSPs shall be physically separated from all other physical ports of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.18.02",
        level: "3",
        requirement:
          "If the cryptographic module inputs or outputs plaintext CSPs, the module shall ensure that only plaintext CSPs enter or exit the module through the applicable physical ports, and that no other data, plaintext or encrypted, enters or exits the module via the applicable physical ports. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.18.01",
        level: "3",
        IGs: ["3.4.A", "9.5.A"],
        Anchors: ["h.4i7ojhp", "h.19c6y18"],
        requirement:
          "The tester shall verify if the vendor documentation specifies whether the cryptographic module inputs or outputs plaintext CSPs. The tester shall verify from the vendor documentation and also by inspection of the physical ports on the cryptographic module that the applicable physical ports used for the input and output of plaintext CSPs are physically separated from all other physical ports of the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.18.02",
        level: "3",
        IGs: ["3.4.A", "9.5.A"],
        Anchors: ["h.4i7ojhp", "h.19c6y18"],
        requirement:
          "If the cryptographic module inputs or outputs plaintext CSPs, the tester shall verify that only plaintext CSPs enter or exit the module through the applicable physical ports, and that no other data, plaintext or encrypted, enters or exits the module via the applicable physical ports. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.19",
        level: "3",
        requirement:
          "The logical interfaces used for the trusted channel shall be logically separated from all other interfaces (or <a href='#AS03.18'>AS03.18</a> shall be satisfied}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.19.01",
        level: "3",
        requirement:
          "The vendor documentation shall describe how the logical interfaces used in the trusted channel to input and output plaintext CSPs are logically separated from all other interfaces. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.19.02",
        level: "3",
        requirement:
          "If the cryptographic module inputs or outputs plaintext CSPs, the module shall ensure that plaintext CSPs enter or exit the module through the applicable logical interface using the trusted channel, and that no other data, plaintext or encrypted, enters or exits the module via the applicable logical interface using the trusted channel. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.19.03",
        level: "3",
        requirement:
          "The vendor documentation shall provide rationale how the trusted channel prevents unauthorized modification, substitution, and disclosure along the communication link. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.19.01",
        level: "3",
        IGs: ["3.4.A", "9.5.A"],
        Anchors: ["h.4i7ojhp", "h.19c6y18"],
        requirement:
          "The tester shall verify from the vendor documentation and also by inspection of the cryptographic module that the applicable logical interfaces used in the trusted channel to input and <br> output of plaintext CSPs are logically separated from all other logical interfaces of the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.19.02",
        level: "3",
        IGs: ["3.4.A", "9.5.A"],
        Anchors: ["h.4i7ojhp", "h.19c6y18"],
        requirement:
          "If the cryptographic module inputs or outputs plaintext CSPs, the tester shall verify that plaintext CSPs enter or exit the module through the applicable logical interface using the trusted channel, and that no other data, plaintext or encrypted, enters or exits the module via the applicable logical interface using the trusted channel. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.19.03",
        level: "3",
        IGs: ["3.4.A", "9.5.A"],
        Anchors: ["h.4i7ojhp", "h.19c6y18"],
        requirement:
          "The tester shall verify the correctness of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.19.04",
        level: "3",
        IGs: ["3.4.A", "9.5.A"],
        Anchors: ["h.4i7ojhp", "h.19c6y18"],
        requirement:
          "The tester shall, by attempting to access the communication link, verify that the trusted channel prevents unauthorized modification, substitution, and disclosure along the communication link. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.20",
        level: "3",
        requirement:
          "Identity-based authentication shall be employed for all services utilizing the trusted channel. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.20.01",
        level: "3",
        requirement:
          "The vendor shall provide description of the authentication mechanism used by the trusted channel. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.20.01",
        level: "3",
        IGs: ["3.4.A, 9.5.A"],
        Anchors: ["h.4i7ojhp, h.19c6y18"],
        requirement:
          "The tester shall verify that an identity-based authentication mechanism is employed for all services utilizing the trusted channel. The tester shall verify that services utilizing the trusted channel are not provided without successfully passing the operator authentication. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.21",
        level: "3",
        requirement:
          "A status indicator shall be provided when the trusted channel is in use. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.21.01",
        level: "3",
        requirement:
          "The vendor shall provide description of the indicator provided when trusted channel is in use. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.21.01",
        level: "3",
        IGs: ["3.4.A, 9.5.A"],
        Anchors: ["h.4i7ojhp, h.19c6y18"],
        requirement:
          "The tester shall verify, by exercising the module, that the status indicator is provided when the trusted channel is in use. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS03.22",
        level: "4",
        requirement:
          "In addition to the requirements of Security Level 3, for Security Level 4 multi-factor identity-based authentication shall be employed for all services utilizing the trusted channel. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE03.22.01",
        level: "4",
        requirement:
          "The vendor shall provide description of the multi-factor identity-based authentication mechanism used by the trusted channel. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE03.22.01",
        level: "4",
        IGs: ["3.4.A, 9.5.A"],
        Anchors: ["h.4i7ojhp, h.19c6y18"],
        requirement:
          "The tester shall verify that a multi-factor identity-based authentication mechanism is employed for all services utilizing the trusted channel. The tester shall verify that services utilizing the trusted channel are not provided without successfully passing the operator authentication. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "4",
    dtrs: [
      {
        dtrId: "AS04.01",
        level: "1",
        requirement:
          "A cryptographic module shall support authorized roles for operators and corresponding services within each role. <br> NOTE	This assertion is tested under <a href='#AS04.11'>AS04.11</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.02",
        level: "1",
        requirement:
          "If a cryptographic module supports concurrent operators, then the module shall internally maintain the separation of the roles assumed by each operator and the corresponding services. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.02.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify whether multiple concurrent operators are allowed. The vendor documentation shall specify the method by which separation of the authorized roles and services performed by each operator is achieved. The vendor documentation shall also describe any restrictions on concurrent operators. <br> EXAMPLE 1 One operator in a maintenance role and another in a user role simultaneously is not allowed. <br> EXAMPLE 2 Multiple concurrent operators up to 16 operators in a user role are supported, but the only one RSA key generation service can be run at a time in the cryptographic module. <br> EXAMPLE 3 When multiple concurrent operators in a Crypto Officer role are logged in, but each Crypto Officer cannot change the authentication data of the other operators in a Crypto Officer role. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.02.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor documentation that the method implemented by the module to enforce separation between the roles and services performed by concurrent operators is described. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.02.02",
        level: "1",
        requirement:
          "The tester shall assume the identity of two independent operators: Operator1 and Operator2. The operators shall assume different roles. The tester shall verify that only the services allocated to the each role can be performed in that role. The tester shall also attempt, for each operator, to access services that are unique to the role assumed by the other operator in order to verify that separation is maintained between the roles and services allowed in concurrent operators. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.02.03",
        level: "1",
        requirement:
          "If the vendor documentation specifies any restrictions on concurrent operators, the tester shall attempt to violate the restrictions by attempting to concurrently assume restricted roles as independent operators and verify that the module enforces the restrictions. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.03",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.4 shall be provided. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.03.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation as described in {ISO/IEC 19790:2012} A.2.4. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.03.01",
        level: "1",
        requirement:
          "The tester shall check vendor documentation against {ISO/IEC 19790:2012} A.2.4 specification. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.04",
        level: "1",
        requirement:
          "A cryptographic module shall, at a minimum, support a Crypto Officer Role. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.05'>AS04.05</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.05",
        level: "1",
        requirement:
          "The Crypto Officer Role shall be assumed to perform cryptographic initialization or management functions and general security services (e.g. module initialization, management of CSPs, PSPs, and audit functions). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.05.01",
        level: "1",
        requirement:
          "In the documentation required, the vendor shall include at least one crypto-officer role. These roles shall be specified by name and allowed services. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.05.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor documentation that at least one crypto-officer role is defined. The tester shall verify that roles are specified by name and allowed services as specified in <a href='#AS04.05'>AS04.05</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.06",
        level: "1",
        requirement:
          "If the cryptographic module supports a User Role, then the User Role shall be assumed to perform general security services, including cryptographic operations and other approved security functions. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.06.01",
        level: "1",
        requirement:
          "If the cryptographic module supports a User Role, the vendor provided documentation shall (1) explicitly state that a User Role is supported, and (2) completely specify the role by name and allowed services. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.06.01",
        level: "1",
        requirement:
          "The tester shall determine from the vendor documentation whether the cryptographic module supports a User Role. If the cryptographic module supports a User Role, the tester shall verify the vendor documentation that at least one user role is defined. The tester shall verify that user role is specified by name and allowed services as specified in <a href='#AS04.06'>AS04.06</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.07",
        level: "1",
        requirement:
          "All unprotected SSPs shall be zeroised when entering or exiting the Maintenance Role. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.07.01",
        level: "1",
        requirement:
          "If the cryptographic module has a maintenance access interface, the vendor provided documentation shall 1) explicitly state a maintenance role is supported, 2) completely specify the role by name, purpose, and allowed services, and 3) specify the maintenance access interface under <a href='#VE07.11.01'>VE07.11.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.07.02",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the module�s unprotected SSPs, as defined in <br> ISO/IEC 19790:2012, 3.110, are actively zeroised when the maintenance role is entered or exited. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.07.01",
        level: "1",
        requirement:
          "The tester shall verify the specifications of the module interfaces whether a maintenance access interface is specified (see <a href='#AS07.11'>AS07.11</a>). If so, the tester shall verify the vendor documentation pertaining to the authorized roles and verify that the maintenance role is specified by name, purpose, and allowed services. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.07.02",
        level: "1",
        requirement:
          "The tester shall verify the specifications of the module interfaces whether a maintenance role is defined and check the zeroisation of all unprotected SSPs as described in the module specification. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.07.03",
        level: "1",
        requirement:
          "While in the maintenance role, the tester shall enter, for all unprotected SSPs, known values which are effective in demonstrating the zeroisation and, upon exit from the maintenance role, shall verify that zeroisation has taken place. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.08",
        level: "1",
        requirement:
          "Services shall refer to all of the services, operations, or functions that can be performed by a module. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.09",
        level: "1",
        requirement:
          "Service inputs shall consist of all data or control inputs to the module that initiate or obtain specific services, operations, or functions. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.10",
        level: "1",
        requirement:
          "Service outputs shall consist of all data outputs, control outputs, and status outputs that result from services, operations, or functions initiated or obtained by service inputs. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.11",
        level: "1",
        requirement:
          "Each service input shall result in a service output. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.11.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the purpose and function of each service. The documentation shall include for each service: service inputs, corresponding service outputs, and the authorized role or roles in which the service can be performed. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.11.01",
        level: "1",
        requirement:
          "The tester shall check the vendor documentation and verify that the purpose and function of each service is described. The tester shall also check that the following information is specified for each service: service inputs, corresponding service outputs, and the authorized role or roles in which the service can be performed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.11.02",
        level: "1",
        requirement:
          "The tester shall perform the following for each service (i.e. security and non-security services, both approved and non-approved services). <br> � Enter each of the specified service inputs and observe that they result in the specified service outputs. <br> � For services that require the operator to assume a role, the role shall be assumed to enter each of the specified service inputs and observe that they result in the specified service outputs. <br> � For services that require the operator to assume a role, assume the role that is not specified for the service and enter each of the specified service inputs and observe that the service is not provided. <br> � For services that require the operator to assume an authenticated role, the role shall be assumed and authenticated to enter each of the specified service inputs and observe that they result in the specified service outputs. <br> � For services that require the operator to assume an authenticated role, the role shall be assumed but the authentication data shall be modified to fail authentication and enter each of the specified service inputs and observe that the service is not provided. <br> �	For services that provide data output over the data output interface, the tester shall verify the result <br> against the expected result. <br> EXAMPLE	If the service provides data output which is a function of the services data input, the tester will <br> verify the data output result as a function of the provided input data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.12",
        level: "1",
        requirement:
          "A cryptographic module shall provide the following services to operators. <br> NOTE	This assertion is not separately tested. <br> Show module&#39;s versioning information  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.13",
        level: "1",
        requirement:
          "The cryptographic module shall output the name or module identifier and the versioning information that can be correlated with a validation record (e.g. hardware, software, and/or firmware versioning information). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.13.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the output of the current name and versioning information of the cryptographic module; <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.13.02",
        level: "1",
        requirement:
          "The vendor provided documentation shall identify the name or module identifier and the versioning information which will be posted as the validation record. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.13.03",
        level: "1",
        requirement:
          "The vendor provided documentation, either non-proprietary security policy or an Administrator guidance, shall specify how to correlate the output of the current name and the versioning information with a validation record. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.13.01",
        level: "1",
        requirement:
          "The tester shall verify that the service outputs (i.e. name or module identifier and versioning information) are consistent with specification and with information provided under assertions <a href='#AS02.11'>AS02.11</a>, <a href='#AS02.12'>AS02.12</a>, and <a href='#AS11.04'>AS11.04</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.13.02",
        level: "1",
        IGs: ["11.A"],
        Anchors: ["h.2w5ecyt"],
        requirement:
          "The tester shall verify that the vendor provided documentation (i.e. non-proprietary security policy or an Administrator guidance) provides sufficient information to unambiguously identify the module version. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.13.03",
        level: "1",
        requirement:
          "The tester shall verify that the output of the current name or module identifier and the versioning information is sufficient for an operator to correlate the module with a validation record, with the help of non-proprietary security policy or an administrator guidance. <br> Show Status  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.14",
        level: "1",
        requirement:
          "The cryptographic module shall output current status. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.14.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the output of the current status of the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.14.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor documentation to verify that the -Show Status� service is allocated to at least one authorized role. The tester shall verify that these services are described as specified in <a href='#AS04.14'>AS04.14</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.14.02",
        level: "1",
        requirement:
          "The tester shall verify that the -Show Status� indicator matches the vendor documentation. <br> Perform self-tests  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.15",
        level: "1",
        requirement:
          "The cryptographic module shall initiate and run the pre-operational self-tests as specified in (ISO/IEC 19790:2012) 7.10.2. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.15.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the initiation and running of user callable self-tests. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.15.01",
        level: "1",
        requirement:
          "The tester shall verify that the module provides for the initiation of the running of preoperational self-tests, as specified in {ISO/IEC 19790:2012} 7.10 this is performed under documentation verification in TEA.01.01. <br> Perform approved security functions   <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.16",
        level: "1",
        requirement:
          "The cryptographic module shall perform at least one approved security function used in an approved mode of operation as specified in (ISO/IEC 19790:2012) 7.2.4. <br> </ol>NOTE	This assertion is not separately tested. <br> Perform zeroisation  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.17",
        level: "1",
        requirement:
          "The cryptographic module shall perform zeroisation of the parameters as specified in (ISO/IEC 19790:2012) 7.9.7. <br> </ol>NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.18",
        level: "1",
        requirement:
          "If the module can output a particular data or status item in a cryptographically protected form, or (as a result of module configuration or operator intervention) can also output the item in a non-protected form, then a bypass capability shall be defined. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.18.01",
        level: "1",
        requirement:
          "If the module implements a bypass capability, the vendor documentation shall describe the bypass service. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.18.01",
        level: "1",
        requirement:
          "The tester shall verify that the module implements a bypass capability as specified in the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.19",
        level: "1",
        requirement:
          "If a cryptographic module implements a bypass capability, then the operator shall assume an authorized role before configuring the bypass capability. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.19.01",
        level: "1",
        requirement:
          "If the module implements a bypass capability, the vendor documentation shall describe how the operator assumes an authorized role before configuring the bypass capability. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.19.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation that the module requires an operator to assume an authorized role before configuring the bypass capability. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.19.02",
        level: "1",
        requirement:
          "The tester shall assume the defined role that is documented to configure the bypass capability and perform the configuration. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.19.03",
        level: "1",
        requirement:
          "The tester shall assume a defined role that is not documented to configure the bypass capability and attempt to perform the bypass configuration. The tester shall verify the attempt fails. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.20",
        level: "1",
        requirement:
          "If a cryptographic module implements a bypass capability, then two independent internal actions shall be required to activate the capability to prevent the inadvertent bypass of plaintext data due to a single error. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.20.01",
        level: "1",
        requirement:
          "If the module implements a bypass capability, the vendor documentation shall describe the bypass service as specified in <a href='#AS04.20'>AS04.20</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.20.02",
        level: "1",
        requirement:
          "The finite state model and other vendor documentation shall indicate, for all transitions into an exclusive or alternating bypass state, two independent internal actions that are required to transition into each bypass state. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.20.01",
        level: "1",
        requirement:
          "The tester shall verify whether the bypass capability is implemented by the module. The tester shall verify the vendor documentation to verify that the bypass capability is allocated to at least one authorized role. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.20.02",
        level: "1",
        requirement:
          "The tester shall verify the finite state model and other vendor documentation whether each transition into an exclusive or alternating bypass state shows two independent internal actions that have to occur in order for the cryptographic module to transition into either exclusive or alternating bypass state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.20.03",
        level: "1",
        requirement:
          "The tester shall attempt to transition to each bypass state from each state that shows such a transition and verify that it takes two internal actions to accomplish each such transition. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.21",
        level: "1",
        requirement:
          "If a cryptographic module implements a bypass capability, then the two independent internal actions shall modify software and/or hardware behaviour that is dedicated to mediate the bypass capability. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.21.01",
        level: "1",
        requirement:
          "If the module implements a bypass capability, the vendor provided documentation shall specify how the two independent internal actions modify software and/or hardware behaviour that is dedicated to mediate the bypass capability. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.21.02",
        level: "1",
        requirement:
          "The vendor provided documentation shall specify how the two independent internal actions protect against the inadvertent bypass of plain text data to a single error. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.21.01",
        level: "1",
        requirement:
          "The tester shall verify that vendor documentation specifies how the two independent internal actions protect against the inadvertent bypass of plain text data due to a single error. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.21.02",
        level: "1",
        requirement:
          "The tester shall verify that the two independent internal actions modify software and/or hardware behaviour that is dedicated to mediate the bypass capability, by inspection and by attempting to transition to each bypass state from each state that shows such a transition. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.22",
        level: "1",
        requirement:
          "If a cryptographic module implements a bypass capability, then the module shall show status to indicate whether the bypass capability <br> <ol type=1>   <li> is not activated, and the module is exclusively providing services with cryptographic processing (e.g. plaintext data is encrypted), <br>   </li>   <li> is activated and the module is exclusively providing services without cryptographic processing (e.g. plaintext data is not encrypted), or <br>   </li>   <li> is alternately activated and deactivated and the module is providing some services with cryptographic processing and some services without cryptographic processing (e.g. for modules with multiple communication channels, plaintext data is or is not encrypted depending on each channel configuration). <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.22.01",
        level: "1",
        requirement:
          "The vendor documentation for the -Show Status� service shall indicate bypass status. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.22.01",
        level: "1",
        requirement:
          "The tester shall review the vendor documentation for the -Show Status� service and verify the bypass service indication. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.22.02",
        level: "1",
        requirement:
          "The tester shall transition to each bypass state and verify that the -Show Status� indicates the applicable bypass status. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.23",
        level: "1",
        requirement:
          "The self-initiated cryptographic output capability shall be configured by the Crypto Officer and this configuration may be preserved over resetting, rebooting, or power cycling of the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.23.01",
        level: "1",
        requirement:
          "The vendor shall provide description of the self-initiated cryptographic output capability. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.23.01",
        level: "1",
        requirement:
          "The tester shall verify that the self-initiated cryptographic output capability is configured by the Crypto Officer. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.24",
        level: "1",
        requirement:
          "If a cryptographic module implements a self-initiated cryptographic output capability, then two independent internal actions shall be required to activate the capability to prevent the inadvertent output due to a single error. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.25'>AS04.25</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.25",
        level: "1",
        requirement:
          "If a cryptographic module implements a self-initiated cryptographic output capability, then the two independent internal actions shall modify software and/or hardware behaviour that is dedicated to mediate the capability (e.g. two different software or hardware flags are set, one of which may be user-initiated). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.25.01",
        level: "1",
        requirement:
          "The vendor shall define a set of two internal actions to be independently done in order to activate the self-initiated cryptographic output capability. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.25.02",
        level: "1",
        requirement:
          "The vendor provided documentation shall specify how the two independent internal actions modify software and/or hardware behaviour that is dedicated to mediate the self-initiated cryptographic output capability. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.25.03",
        level: "1",
        requirement:
          "The vendor provided documentation shall specify how the two independent internal actions protect against the inadvertent output due to a single error. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.25.01",
        level: "1",
        requirement:
          "The tester shall determine whether the cryptographic module implements a self-initiated cryptographic output capability. The tester shall verify that vendor documentation specifies the two independent internal actions performed by the cryptographic module before activating the self-initiated cryptographic output capability. The tester shall also verify that vendor documentation specifies how the two independent internal actions protect against the inadvertent output due to a single error. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.25.02",
        level: "1",
        requirement:
          "The tester shall activate the self-initiated cryptographic output capability and verify that the two independent internal actions function as specified. If any software or firmware components are executed in the process of activation, the tester shall examine the applicable source code to ensure that the software or firmware components support the requirement for two independent internal actions before activating the self-initiated cryptographic output capability. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.25.03",
        level: "1",
        requirement:
          "The tester shall verify that a status indicator is provided to indicate when the self-initiated cryptographic output capability is activated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.26",
        level: "1",
        requirement:
          "If a cryptographic module implements a self-initiated cryptographic output capability, then the module shall show status to indicate whether the self-initiated cryptographic output capability is activated. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.25'>AS04.25</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.27",
        level: "1",
        requirement:
          "If a cryptographic module has the capability of loading software or firmware from an external source, then the following requirements shall apply. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.28'>AS04.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.28",
        level: "1",
        requirement:
          "The loaded software or firmware shall be validated by a validation authority prior to loading to maintain validation. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.28.01",
        level: "1",
        requirement:
          "The vendor shall provide a certificate of validation by a validation authority. This certificate shall unambiguously identity the software or firmware loaded in the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.28.01",
        level: "1",
        requirement:
          "The tester shall check that the software or firmware version is the one who claims to be. This identification shall be consistent with the one verified in ISO/IEC 19790:2012, 7.2.3.1. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.29",
        level: "1",
        requirement:
          "All data output via the data output interface shall be inhibited until the software/firmware loading and load test has completed successfully. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.29.01",
        level: "1",
        requirement:
          "The vendor shall describe the process used to inhibit data output during loading processes and load test. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.29.01",
        level: "1",
        requirement:
          "The tester shall verify that the data output is inhibited during software or firmware loading and load test. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.30",
        level: "1",
        requirement:
          "The Software/Firmware Load Test specified in (ISO/IEC 19790:2012) 7.10.3.4 shall be performed before the loaded code can be executed. <br> </ol>NOTE	This assertion is not separately tested. Tested as part of <a href='#AS10.37'>AS10.37</a> to <a href='#AS10.41'>AS10.41</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.31",
        level: "1",
        requirement:
          "The cryptographic module shall withhold execution of any loaded or modified approved security functions until after the pre-operational self-tests specified in (ISO/IEC 19790:2012) 7.10.2 have been successfully executed. <br> </ol>NOTE	This assertion is not separately tested. Tested as part of <a href='#AS10.37'>AS10.37</a> to <a href='#AS10.41'>AS10.41</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.32",
        level: "1",
        requirement:
          "The modules versioning information shall be modified to represent the addition and/or update of the newly loaded software or firmware ((ISO/IEC 19790:2012) 7.4.3). <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.32.01",
        level: "1",
        requirement:
          "The vendor shall provide the means to read the version of the newly loaded software or firmware. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.32.01",
        level: "1",
        requirement:
          "The tester shall initiate the software/firmware load test. After the pre-operational self-tests have been successfully executed subsequent to software/firmware load test, the tester shall verify that the versioning information is modified to represent the addition and/or update of the newly loaded software or firmware. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.33",
        level: "1",
        requirement:
          "If the loading of new software or firmware is a complete image replacement, this shall constitute an entirely new module which would require validation by a validation authority to maintain validation. <br> Required Vendor Information <br> VE04. 33.01: The vendor provided documentation shall specify whether the module supports a complete image replacement as a result of software/firmware loading and load test. <br> VE04. 33.02: The vendor shall provide a certificate of validation by a validation authority. This certificate shall unambiguously identity the software or firmware loaded in the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.33.01",
        level: "1",
        requirement:
          "The tester shall ensure that the new complete image replacement is validated by a validation authority by inspection of the name and version as indicated in <a href='#AS04.13'>AS04.13</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.34",
        level: "1",
        requirement:
          "The new software or firmware image shall only be executed after the module transitions through a power-on reset. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.34.01",
        level: "1",
        requirement:
          "If a complete image replacement is supported, the vendor provided documentation shall specify how the new image is executed only after the module transitions through a power-on reset. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.34.01",
        level: "1",
        requirement:
          "The tester shall initiate the software/firmware load test. After the software/firmware load test passed, the tester shall verify that the loaded software or firmware cannot be used until after the pre-operational self-tests have been successfully executed through power-on reset. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.35",
        level: "1",
        requirement: "Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.35.01",
        level: "1",
        requirement:
          "If a complete image replacement is supported, the vendor provided documentation shall specify that SSP zeroisation takes place prior to execution of the new image. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.35.02",
        level: "1",
        requirement:
          "If a complete image replacement is supported, the vendor documentation shall specify the following SSPs zeroisation information: <br> <ol type=1>   <li> zeroisation techniques; <br>   </li>   <li> rationale explaining how the zeroisation technique is performed in a time that is not sufficient to compromise SSPs. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.35.01",
        level: "1",
        requirement:
          "The tester shall review the vendor documentation to verify that the information specified in <a href='#VE04.35.01'>VE04.35.01</a> is included. The tester shall determine the accuracy of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.35.02",
        level: "1",
        requirement:
          "The tester shall note which SSPs are present in the module and initiate the power-on reset subsequent to software/firmware load test. Following the completion of the pre-operational self-test, the tester shall attempt to perform cryptographic operations using each of the SSPs that were stored in the module. The tester shall verify that each SSP cannot be accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.36",
        level: "2",
        requirement:
          "If role-based authentication mechanisms are supported by a cryptographic module, the module shall require that one or more roles either be implicitly or explicitly selected by the operator {and shall authenticate the assumption of the selected role (or set of roles)}. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.37'>AS04.37</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.37",
        level: "2",
        requirement:
          "If role-based authentication mechanisms are supported by a cryptographic module, the module {shall require that one or more roles either be implicitly or explicitly selected by the operator and} shall authenticate the assumption of the selected role (or set of roles). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.37.01",
        level: "2",
        requirement:
          "The vendor shall document the type of authentication performed for the module. The vendor shall document the mechanisms used to perform the implicit or explicit selection of a role or set of roles and the authentication of the operator to assume the role(s). <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.37.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation specifies the mechanisms used for the selection of a role or roles and the authentication of the operator to assume a role. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.37.02",
        level: "2",
        IGs: ["4.4.A"],
        Anchors: ["h.2p2csry"],
        requirement:
          "The tester shall assume each role and initiate an error during the authentication procedure. The tester shall verify that the module denies access to each role. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.38",
        level: "2",
        requirement:
          "If a cryptographic module permits an operator to change roles, then the module shall  authenticate the assumption of any role that was not previously authenticated for that operator. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.38.01",
        level: "2",
        requirement:
          "The vendor documentation shall describe the ability of an operator to modify roles and shall state that authentication of an operator to assume a new role is required. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.38.01",
        level: "2",
        requirement:
          "The tester shall verify the vendor documentation to verify that the method by which an operator can modify roles includes the authentication of the operator to assume a new role. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.38.02",
        level: "2",
        IGs: ["4.4.A"],
        Anchors: ["h.2p2csry"],
        requirement:
          "The tester shall perform the following tests. <br> <ol type=1>   <li> Assume a role, attempt to modify to another role that the operator is authorized to assume, and verify that the module allows the operator to request services assigned to the new role. <br>   </li>   <li> Assume a role, attempt to modify to another role that the operator is not authorized to assume, and verify that the module does not allow the operator to request the services assigned only to the new role. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.39",
        level: "3",
        requirement:
          "If identity-based authentication mechanisms are supported by a cryptographic module, the module shall require that the operator be individually and uniquely identified, {shall require that one or more roles either be implicitly or explicitly selected by the operator, and shall authenticate <br> the identity of the operator and the authorization of the operator to assume the selected role or set of roles}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.39.01",
        level: "3",
        requirement:
          "The vendor documentation shall specify the type of authentication implemented within the module. The vendor documentation shall specify <br> <ol type=1>   <li> the mechanism(s) used to perform the identification of the operator, <br> </ol></ol>  <br> <ol type=1>   <li> the mechanism(s) used to perform the authentication of the operator&#39;s identity, NOTE 2 This is associated with <a href='#AS04.41'>AS04.41</a>. <br>   </li>   <li> the mechanism(s) used to perform the implicit or explicit selection of a role or set of roles, NOTE 3 This is associated with <a href='#AS04.40'>AS04.40</a>. <br>   </li>   <li> the mechanism(s) used to perform the verification of the authorization of the operator to assume the role(s), and <br> </ol></ol>  <br> <ol type=1>   <li> the mechanism(s) used to internally maintain the relationship between the identified and authenticated operator and the selected role or set of roles authorized to assume by the operator. <br> </ol></ol>  <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.39.01",
        level: "3",
        requirement:
          "The tester shall verify that the vendor documentation specifies <br> <ol type=1>   <li> how the operator is uniquely identified, <br> </ol>  <br> <ol type=1>   <li> how that identity is authenticated, <br> </ol>  <br> <ol type=1>   <li> how the operator chooses a role, <br> </ol>  <br> <ol type=1>   <li> how the authorization of the operator to assume a role is performed based on the authenticated identity, and <br> </ol>  <br> <ol type=1>   <li> how the relationship is internally maintained between the identified and authenticated operator and the selected role or set of roles authorized to assume by the operator. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.39.02",
        level: "3",
        IGs: ["4.4.A"],
        Anchors: ["h.2p2csry"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the identification and authentication procedure is implemented as specified in the vendor documentation provided under <a href='#VE04.39.01'>VE04.39.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.39.03",
        level: "3",
        IGs: ["4.4.A"],
        Anchors: ["h.2p2csry"],
        requirement:
          "The tester shall initiate an error during the authentication procedure and shall verify that the module does not allow the tester to proceed beyond the authentication procedure. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.39.04",
        level: "3",
        IGs: ["4.4.A"],
        Anchors: ["h.2p2csry"],
        requirement:
          "The tester shall successfully authenticate his/her identity to the module. When required to select one or more roles, the tester shall select roles not compatible with the authenticated identity and shall verify that authorization to assume the roles is denied. <br> NOTE 11 This test procedure is associated with <a href='#AS04.39'>AS04.39</a> and <a href='#AS04.41'>AS04.41</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.40",
        level: "3",
        requirement:
          "{If identity-based authentication mechanisms are supported by a cryptographic module, the module shall require that the operator be individually and uniquely identified}, shall require that one or more roles either be implicitly or explicitly selected by the operator, {and shall authenticate the identity of the operator and the authorization of the operator to assume the selected role or set of roles}. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.41",
        level: "3",
        requirement:
          "{If identity-based authentication mechanisms are supported by a cryptographic module, the module shall require that the operator be individually and uniquely identified, shall require that one or more roles either be implicitly or explicitly selected by the operator}, and shall authenticate the identity of the operator and the authorization of the operator to assume the selected role or set of roles. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.42",
        level: "3",
        requirement:
          "If a cryptographic module permits an operator to change roles, then the module shall verify the authorization of the identified operator to assume any role that was not previously authorized. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.42.01",
        level: "3",
        requirement:
          "The vendor documentation shall specify: <br> <ol type=1>   <li> whether the cryptographic module permits an operator to modify roles; <br>   </li>   <li> how an operator can modify roles after the operator is identified and authenticated; <br>   </li>   <li> how the relationship is internally maintained between the identified and authenticated operator and the selected role or set of roles authorized to assume by the operator [see item<ol><li>of <a href='#VE04.39.01'>VE04.39.01</a>]; <br> </ol>  </li>   <li> how the cryptographic module enforces the verification of authorization of the identified operator to assume a role that was not previously authorized; <br>   </li>   <li> conditions under which the operator&#39;s identity has to be reauthenticated in modifying roles; <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br> f) how the cryptographic module is designed to meet the assertion <a href='#AS11.13'>AS11.13</a>: <br> 1) how the cryptographic module prohibits changing to a Crypto Officer state from any other role other than the Crypto Officer; <br> 2) how the results of previous authentications/authorization is cleared and the cryptographic module requires the operator to be authenticated and authorized to assume a Crypto Office role, when changing from any other role other than the Crypto Officer role. <br> </ol>Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.42.01",
        level: "3",
        requirement:
          "The tester shall determine, by inspection and from the vendor documentation, whether the cryptographic module permits an operator to modify roles. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.42.02",
        level: "3",
        requirement:
          "The tester shall verify in the vendor documentation that the method by which an operator can modify roles without re-authentication of the operator�s identity includes the verification of the authorization of the operator for a role not previously authenticated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.42.03",
        level: "3",
        requirement:
          "The tester shall perform the following tests. <br> <ol type=1>   <li> Assume each role, attempt to modify to another role that the tester is authorized to assume, verify that the tester&#39;s identity does not have to be reauthenticated, and verify that the tester can access the services associated with the new role. The tester shall perform services in the new role that were not associated with the previous role in order to verify that the tester has assumed a different role. <br>   </li>   <li> Assume each role, attempt to modify to another role that the operator is not authorized to assume, and verify that the module denies access to the role based on the identity of the operator. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.42.04",
        level: "3",
        requirement:
          "The tester shall exercise the cryptographic module and verify that the changing to a Crypto Officer role from any other role other than the Crypto Officer role is prohibited as specified in the vendor documentation provided under <a href='#VE04.42.01'>VE04.42.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.43",
        level: "1",
        requirement:
          "When a cryptographic module is reset, rebooted, powered off and subsequently powered on, the module shall require the operator to be authenticated. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.43.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe how the results of previous authentications are cleared when the module is powered off. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.43.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor documentation that the clearing of previous authentications upon power off of the module is described. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.43.02",
        level: "1",
        requirement:
          "The tester shall authenticate to the module and assume one or more roles, power off the module, power on the module, and attempt to perform services in those roles. To meet this assertion, the module shall deny access to the services and require that the tester be reauthenticated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.44",
        level: "1",
        requirement:
          "Authentication data within a cryptographic module shall be protected against unauthorized use, disclosure, modification, and substitution. <br> NOTE	Approved security functions can be used as part of the authentication mechanism.  <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.44.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the protection of all authentication data within the module. Protection shall include the implementation of mechanisms that protect against unauthorized use, disclosure, modification, and substitution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.44.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor documentation that describes the protection of authentication data. The tester shall verify that the documentation describes how the data will be protected against unauthorized use, disclosure, modification, and substitution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.44.02",
        level: "1",
        requirement:
          "The tester shall perform the following tests. <br> <ol type=1>   <li> Attempt to access (by circumventing the documented protection mechanisms) authentication data for which the tester is not authorized to have access. If the module denies access or allows access only to encrypted or otherwise protected forms of data, the requirement is met. <br> </ol>  </li>   <li> Modify authentication data using any method not specified by the vendor documentation and attempt to enter the modified data. The module shall not allow the tester to be authenticated using the modified data. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.45",
        level: "2",
        requirement:
          "If a cryptographic module does not contain the authentication data required to authenticate the operator for the first time the module is accessed, then other authorized methods (e.g. procedural controls or use of factory-set or default authentication data) shall be used to control access to the module and initialize the authentication mechanisms. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.45.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify means to control access to the module before it is initialized. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.45.01",
        level: "2",
        requirement:
          "The tester shall verify the vendor documentation describes the procedure by which the operator is authenticated upon accessing the module for the first time. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.45.02",
        level: "2",
        requirement:
          "If access to the module before initialization is procedurally controlled, the tester shall initiate an error on an uninitialized module and shall verify that the module denies access. The tester shall assume the authorized role and verify that the required authentication complies with the documented procedures. The tester shall attempt to assume other roles before the module has been initialized and verify that the module denies access to the roles. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.45.03",
        level: "2",
        requirement:
          "If default authentication data is used to access to the module and to initialize the authentication mechanism, the tester shall assume the authenticated role, and verify that the default authentication data is replaced upon the first-time authentication. The tester shall also enter the default authentication data after the first-time authentication and verify that the cryptographic module does not allow the tester to be authenticated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.46",
        level: "2",
        requirement:
          "If default authentication data is used to control access to the module, then default authentication data shall be replaced upon first-time authentication ((ISO/IEC 19790:2012) 7.9.7). <br> </ol>NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.45'>AS04.45</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.47",
        level: "2",
        requirement:
          "If the cryptographic module uses security functions to authenticate the operator, then those security functions shall be approved security functions. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.47.01",
        level: "2",
        requirement:
          "The vendor provided documentation shall specify the list of security functions used to authenticate operators. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.47.02",
        level: "2",
        requirement:
          "The vendor shall provide a validation certificate for each approved security functions as specified in <a href='#VE02.20.01'>VE02.20.01</a>. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.47.01",
        level: "2",
        requirement:
          "The tester shall verify that the security functions used to authenticate operators are all approved security functions. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.48",
        level: "2",
        requirement:
          "The module shall implement an approved authentication mechanism as specified in (ISO/IEC 19790:2012) Annex E. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.48.01",
        level: "2",
        requirement:
          "The vendor documentation shall describe the approved authentication mechanism used to authenticate operators. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.48.02",
        level: "2",
        requirement:
          "If the module implements an approved authentication mechanism, the vendor shall provide a validation certificate as specified in <a href='#VE02.20.01'>VE02.20.01</a>. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.48.01",
        level: "2",
        requirement:
          "The tester shall verify that the authentication mechanism used to authenticate operators is an approved one. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.49",
        level: "2",
        requirement:
          "The strength of the approved authentication mechanism shall be specified in the security policy ({ISO/IEC 19790:2012} Annex B). <br> NOTE	This assertion is not separately tested. Tested as part of ASB.01. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.50",
        level: "2",
        requirement:
          "For each attempt to use the approved authentication mechanism, the module shall meet the strength of the authentication objective. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.50.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify each authentication mechanism and the associated false acceptance rate or probability that a random access will succeed. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.50.01",
        level: "2",
        requirement:
          "The tester shall verify the vendor documentation for each authentication mechanism that the associated false acceptance or random access rate is specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.50.02",
        level: "2",
        requirement:
          "The tester shall verify the vendor documentation for each authentication mechanism that the objective is met. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.51",
        level: "2",
        requirement:
          "For multiple attempts to use the approved authentication mechanism during a one-minute period, the module shall meet the strength of the authentication objective. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.51.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify each authentication mechanism and the associated probability of a successful random attempt during a one-minute period. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.51.01",
        level: "2",
        requirement:
          "The tester shall verify the vendor documentation for each authentication mechanism that the associated probability of a successful random is specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.51.02",
        level: "2",
        requirement:
          "The tester shall verify the vendor documentation for each authentication mechanism that the associated probability of a successful random is meeting the objective. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.52",
        level: "2",
        requirement:
          "The approved authentication mechanism shall be met by the module&#39;s implementation and not <br> rely on documented procedural controls or security rules (e.g. password size restrictions). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.52.01",
        level: "2",
        requirement:
          "The vendor shall provide complete description of the authentication mechanisms. <br> Required Test Procedures <br> TE04. 52.01: The tester shall verify by inspection and from the vendor documentation that the approved authentication mechanism is met by the module&#39;s implementation and does not rely on documented procedural controls or security rules. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.53",
        level: "2",
        requirement:
          "If the operating system implements the authentication mechanism, then the authentication mechanism shall meet the requirements of this clause. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.53.01",
        level: "2",
        requirement:
          "The vendor shall provide authentication mechanism specification of the operating system. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.53.01",
        level: "2",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection that the approved authentication mechanism implemented in the operating system meets the applicable requirements. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.54",
        level: "2",
        requirement:
          "Feedback of authentication data to an operator shall be obscured during authentication to anyone other than the operator. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.54.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify the method used to obscure feedback of the authentication data during entry of the authentication data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.54.02",
        level: "2",
        requirement:
          "The vendor documentation shall specify how, if implemented, the vendor allows an operator to confirm authentication data at the time of entry, while obscuring any useful information to all others. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.54.01",
        level: "2",
        requirement:
          "The tester shall verify from the vendor documentation that the authentication data is obscured during data entry. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.54.02",
        level: "2",
        requirement:
          "The tester shall enter authentication data and verify that there is no access of authentication data during data entry, except, as an option, to the operator. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.54.03",
        level: "2",
        requirement:
          "If the vendor allows an operator to confirm authentication data at the time of entry, the tester shall verify that this information is obscured from other entities. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.55",
        level: "2",
        requirement:
          "Feedback provided to an operator during an attempted authentication shall prevent weakening of the authentication mechanism strength beyond the required authentication strength. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.55.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify the feedback mechanism that is used when the operator is entering authentication data. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.55.01",
        level: "2",
        requirement:
          "The tester shall verify from the vendor documentation that the feedback mechanism does not provide information that could be used to guess or determine the authentication data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.55.02",
        level: "2",
        requirement:
          "The tester shall enter authentication data to assume each role to ensure that the feedback mechanism does not provide useful information. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.56",
        level: "1",
        requirement:
          "If a module does not support authentication mechanisms, the module shall require that the operator either implicitly or explicitly select one or more roles. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.56.01",
        level: "1",
        requirement:
          "The vendor shall document the type of authentication performed for the module. The vendor shall document the mechanisms used to perform the implicit or explicit selection of a role or set of roles and the authentication of the operator to assume the role(s). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.56.02",
        level: "1",
        requirement:
          "The vendor provided non-proprietary security policy shall provide a description of the roles, either implicit or explicit, that the operator can assume. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE04.56.03",
        level: "1",
        requirement:
          "The vendor provided non-proprietary security policy shall provide instructions for the operator to assume either the implicit or explicit roles. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.56.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided non-proprietary security policy provides a description of the roles, either implicit or explicit, that the operator can assume and the means to assume each role. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.56.02",
        level: "1",
        requirement:
          "The tester shall invoke the method described in the non-proprietary security policy and verify that each role can either be implicitly or explicitly assumed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.57",
        level: "2",
        requirement:
          "A cryptographic module shall at a minimum employ role-based authentication to control access to the module. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.36'>AS04.36</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.58",
        level: "3",
        requirement:
          "A cryptographic module shall employ identity-based authentication mechanisms to control access to the module. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS04.39'>AS04.39</a> to <a href='#AS04.41'>AS04.41</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS04.59",
        level: "4",
        requirement:
          "A cryptographic module shall employ multi-factor identity-based authentication mechanisms to control access to the module. <br> VE04. 59.01: The vendor shall provide specification of a multi-factor identity-based authentication and provide testing features of the mechanism. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE04.59.01",
        level: "4",
        IGs: ["4.4.A"],
        Anchors: ["h.2p2csry"],
        requirement:
          "The tester shall verify the vendor documentation and assess multi-factor identity-based authentication. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "5",
    dtrs: [
      {
        dtrId: "AS05.01",
        level: "1",
        requirement:
          "The requirements of this clause shall apply to software and firmware components of a cryptographic module. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.02'>AS05.02</a> to <a href='#AS05.23'>AS05.23</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.02",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.5 shall be provided. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.02.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation as specified in ISO/IEC 19790:2012, A.2.5. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.02.01",
        level: "1",
        requirement:
          "The tester shall verify completeness of the documentation specified in ISO/IEC 19790:2012, A.2.5. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.03",
        level: "1",
        requirement:
          "The following requirements shall apply to software and firmware components of a cryptographic module for Security Level 1. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.04",
        level: "1",
        requirement:
          "All software and firmware shall be in a form that satisfies the requirements of {ISO/IEC 19790:2012} without modification prior to installation {ISO/IEC 19790:2012} (7.11.7). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.04.01",
        level: "1",
        requirement:
          "The vendor shall provide software and firmware specification. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.04.01",
        level: "1",
        requirement:
          "The tester shall verify, by inspection of the cryptographic module, that specifications provided by vendor documentation are consistent with the actual design of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.05",
        level: "1",
        requirement:
          "For software and firmware modules and the software or firmware component of a hybrid module (except for the software and firmware components within a disjoint hardware component of a hybrid module): A cryptographic mechanism using an approved integrity technique shall be applied to all software and firmware components within the module&#39;s defined cryptographic boundary in one of the following ways: <br> � by the cryptographic module itself; <br> � by another validated cryptographic module operating in an approved mode of operation. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.05.01",
        level: "1",
        requirement:
          "The vendor provided documentation shall describe the approved integrity technique that is applied to all software and firmware components and the software or firmware component of a hybrid module (except for the software and firmware components within a disjoint hardware component of a hybrid module). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.05.02",
        level: "1",
        requirement:
          "The vendor provided documentation shall specify how the integrity technique is applied to all software and firmware components and the software or firmware component of a hybrid module (except for the software and firmware components within a disjoint hardware component of a hybrid module) using either <br> <ol type=1>   <li> a single encompassing message authentication code or signature, <br> </ol>  <br> <ol type=1>   <li> multiple disjoint codes or signatures. <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.05.03",
        level: "1",
        requirement:
          "The vendor documentation shall describe whether the approved integrity technique is implemented either by the cryptographic module itself or by another validated cryptographic module operating in an approved mode of operation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.05.04",
        level: "1",
        requirement:
          "The vendor provided documentation shall specify the location of the cryptographic key used in the integrity technique. If the approved digital signature is used as the integrity technique, the vendor documentation shall also specify the location of the private signing key which is used to generate reference signature. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.05.05",
        level: "1",
        requirement:
          "The vendor shall provide a validation certificate for the approved integrity technique as specified in <a href='#VE02.20.01'>VE02.20.01</a>. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.05.01",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify by inspection of the cryptographic module that an approved integrity technique is applied to all software and firmware components and the software or firmware component of a hybrid module (except for the software and firmware components within a disjoint hardware component of a hybrid module) within the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.05.02",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify that the vendor has provided a validation certificate for the approved integrity technique implemented as specified in <a href='#VE02.20.01'>VE02.20.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.05.03",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If the module implements a hash or MAC for the software/firmware integrity test, the tester shall verify that the vendor documentation of the software/firmware integrity test fully describes the process by which the hash or MAC is calculated and verified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.05.04",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If the module implements an approved digital signature for the software/firmware integrity test, the tester shall verify that the vendor documentation of the software/firmware integrity test includes the following: <br> <ol type=1>   <li> specification of the approved digital signature algorithm implemented; <br>   </li>   <li> identification of software and firmware that is protected using the approved digital signatures; <br>   </li>   <li> verification that the pre-calculated value of the approved digital signature is included with the software or firmware; <br>   </li>   <li> verification of the approved digital signature; <br>   </li>   <li> failure of the self-test upon failure of the approved digital signature verification. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.05.05",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "Even if the approved integrity technique is provided by another validated module, the tester shall verify that the determination of pass or fail of the software/firmware integrity test is made as specified in <a href='#AS10.01'>AS10.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.05.06",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the implementation of the software/firmware test is consistent with the information provided under <a href='#AS05.05'>AS05.05</a> and <a href='#AS05.08'>AS05.08</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.05.07",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall modify the cryptographic software and firmware components. This test is failed if the integrity mechanisms do not detect the modifications. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.06",
        level: "1",
        requirement:
          "For software and firmware components of a hardware cryptographic module and the software or firmware components within a disjoint hardware component of a hybrid cryptographic module: A cryptographic mechanism using an approved integrity technique or an error detection code (EDC) shall be applied to all software and firmware components within the hardware module&#39;s defined cryptographic boundary or within disjoint hardware components of the hybrid module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.06.01",
        level: "1",
        requirement:
          "The vendor provided documentation shall describe the approved integrity technique or error detection code that is applied to all software and firmware components of a hardware cryptographic module and the software or firmware components within a disjoint hardware component of a hybrid cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.06.02",
        level: "1",
        requirement:
          "The vendor provided documentation shall specify how the approved integrity technique or error detection code is applied to all software and firmware components of a hardware cryptographic module and the software or firmware components within a disjoint hardware component of a hybrid cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.06.03",
        level: "1",
        requirement:
          "If the module implements an error detection code, the vendor shall provide the documentation required under <a href='#VE05.07.01'>VE05.07.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.06.04",
        level: "1",
        requirement:
          "If the cryptographic module implements an approved integrity technique for the integrity test, the vendor provided documentation shall provide information required under <a href='#VE05.05.02'>VE05.05.02</a>, <a href='#VE05.05.04'>VE05.05.04</a>, and <a href='#VE05.05.05'>VE05.05.05</a>. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.06.01",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify by inspection of the cryptographic module that an approved integrity technique or error detection code is applied to all software and firmware components of a hardware cryptographic module and all software or firmware components within a disjoint hardware component of a hybrid cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.06.02",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If the module implements an error detection code, the tester shall follow procedures required under <a href='#TE05.07.01'>TE05.07.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.06.03",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If the module implements a hash or MAC for the software/firmware integrity test, the tester shall follow procedures required under <a href='#TE05.05.03'>TE05.05.03</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.06.04",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If the module implements an approved digital signature for the software/firmware integrity test, the tester shall follow procedures required under <a href='#TE05.05.04'>TE05.05.04</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.06.05",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the implementation of the software/firmware test is consistent with the information provided under <a href='#AS05.06'>AS05.06</a> to <a href='#AS05.08'>AS05.08</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.06.06",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall modify the cryptographic software and firmware components. This test is failed if the integrity mechanisms do not detect the modifications. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.07",
        level: "1",
        requirement:
          "If an EDC is used, the EDC shall be at least 16 bits in length. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.07.01",
        level: "1",
        requirement:
          "The vendor shall provide the specification of the error detection code used within the module. This mechanism shall be an error detection code of at least 16 bits in length. The vendor shall provide: <br> <ol type=1>   <li> description of EDC calculation algorithm; <br>   </li>   <li> calculation of the EDCs when the software and firmware is installed; <br>   </li>   <li> description of verification process: <br>   </li>     <ol type=a>       <li> recalculation of the EDCs when the self-test is initiated; <br>       </li>       <li> comparison of the stored EDC against the recalculated EDC; <br>       </li>       <li> expected outputs for success or failure of test. <br>       </li>     </ol> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.07.01",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify that the error detection code is at least 16 bits in length and verify by inspection that the following information is provided: <br> <ol type=1>   <li> the implementation of the EDC calculation algorithm; <br>   </li>   <li> the verification process: <br>   </li>     <ol type=a>       <li> recalculation of the EDCs when the self-test is initiated; <br>       </li>       <li> comparison of the stored EDC against the recalculated EDC; <br>       </li>       <li> the expected outputs for success or failure of test. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.08",
        level: "1",
        requirement:
          "If the integrity test fails (i.e. the calculated result is not successfully verified or the EDC cannot be verified depending on the module type), the module shall enter the error state. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.08.01",
        level: "1",
        requirement:
          "The vendor shall provide the specification of the integrity test of software/firmware. This <br> mechanism shall be an approved integrity technique or an error detection code depending on the module type (see <a href='#AS05.05'>AS05.05</a> and <a href='#AS05.06'>AS05.06</a>). <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.08.01",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify that if the integrity test fails, the module enters the error state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.08.02",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify that any temporary values generated during the integrity test are zeroised upon completion of the integrity test. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.09",
        level: "1",
        requirement:
          "The approved integrity technique may consist of a single encompassing message authentication code or signature, or multiple disjoint authentication codes or signatures of which failure of any disjoint authentication code or signature shall cause the module to enter the error state. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.05'>AS05.05</a>, <a href='#AS05.06'>AS05.06</a> and <a href='#AS05.08'>AS05.08</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.10",
        level: "1",
        requirement:
          "The temporary value(s) generated during the integrity test of the module&#39;s software or firmware shall be zeroised from the module upon completion of the integrity test. <br> </ol>NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.08'>AS05.08</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.11",
        level: "1",
        requirement:
          "An operator shall be able to perform the integrity test on demand via an HMI, SFMI, HSMI, or HFMI service (ISO/IEC 19790:2012) (7.3.2). <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.11.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the way to perform the integrity test on demand via an HMI, SFMI, HSMI, or HFMI service. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.11.01",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify that the integrity test can be performed via an HMI, SFMI, HSMI, or HFMI service on demand. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.11.02",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify by inspection of the module that the integrity of all software and firmware components within the module is tested during the integrity test callable on demand. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.12",
        level: "1",
        requirement:
          "All data and control inputs, and data, control and status outputs (specified in (ISO/IEC 19790:2012) 7.3.3) of the cryptographic module and services ((ISO/IEC 19790:2012)7.4.3) shall  be directed through a defined HMI, SFMI, HFMI, or HSMI. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.12.01",
        level: "1",
        requirement:
          "The vendor documentation requirement is specified under <a href='#VE05.16.01'>VE05.16.01</a> and 6.3.1, 6.3.3, and 6.4.3. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.12.01",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify that the vendor documentation specifies the following: <br> � total set of commands used to request the services of the cryptographic module, including parameters that enter or leave the module&#39;s cryptographic boundary as part of the requested service. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.12.02",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that all data and control inputs, and data, control and status outputs (specified in ISO/IEC 19790:2012, 7.3.3) of the cryptographic module and services (specified in ISO/IEC 19790:2012, 7.4.3) pass through only the defined HMI, SFMI, HFMI, or HSMI. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.13",
        level: "1",
        requirement:
          "If the software or firmware that is loaded is associated, bound, modifies, or is an executable requisite of the validated module, then the software/firmware load test is applicable and shall  be performed by the validated module with the following exceptions. <br> � The cryptographic module is a software module and the loaded software image is a complete image replacement or overlay of the validated module. <br> � The cryptographic module is a firmware module of physical Security Level 1 and the loaded firmware image is a complete image replacement or overlay of the validated module. <br> � The cryptographic module is a hybrid software module and the loaded software image is a complete image replacement or overlay of the disjoint software components. <br> � The cryptographic module is a hybrid firmware module of physical Security Level 1 and the loaded firmware image is a complete image replacement or overlay of the disjoint firmware components. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.13.01",
        level: "1",
        requirement:
          "The vendor shall provide a specification of software/firmware loading processes, including: <br> <ol type=1>   <li>	the type(s) of software/firmware loading processes: <br> </ol>  </li>     <ol type=a>       <li> adding software and firmware components; <br>       </li>       <li> updating existing software and firmware components; <br>       </li>     </ol>   <li>	the location where newly loaded software and firmware components are stored; <br>   </li>   <li>	existing software/firmware/hardware components to enforce the software/firmware loading; <br>   </li>   <li> existing software/firmware components which will be affected, modified, or replaced as a result of software/firmware loading; <br>   </li>   <li> existing software/firmware components which will be neither affected, modified, nor replaced as a result of software/firmware loading. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.13.02",
        level: "1",
        requirement:
          "The vendor shall provide the specification of the software/firmware load test performed by the validated module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.01",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall determine, by inspection and from the vendor documentation, whether the cryptographic module has a capability of loading software or firmware. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.02",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If the cryptographic module has a capability of loading any software or firmware components, the tester shall determine, by inspection and from the vendor documentation, the type(s) of software/firmware loading whether additional software and firmware components are loaded, or existing software and firmware components are updated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.03",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If additional software and firmware components are loaded, the tester shall verify that the software/firmware load test is performed with the software/firmware loading. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.04",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall determine, by inspection and from the vendor documentation, whether any security relevant components are included in the existing components which will be affected, modified, or replaced as a result of software/firmware loading. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.05",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "If any security relevant components are included in the existing components affected, modified or replaced as a result of software/firmware loading, the tester shall verify that the software/firmware load test is performed with the software/firmware loading. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.06",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify, by inspection and from the vendor documentation, that a Crypto Officer role has to be assumed to perform software/firmware loading. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.07",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the implementation of the software/firmware loading is consistent with the information provided under <a href='#VE05.13.01'>VE05.13.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.13.08",
        level: "1",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify the implementation of the software/firmware load test under <a href='#TE04.28.01'>TE04.28.01</a>, <a href='#TE04.29.01'>TE04.29.01</a>, <a href='#TE04.32.01'>TE04.32.01</a>, <a href='#TE04.34.01'>TE04.34.01</a>, <a href='#TE04.35.01'>TE04.35.01</a>, and <a href='#TE04.35.02'>TE04.35.02</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.14",
        level: "2",
        requirement:
          "The following requirements shall apply to software and firmware components of a cryptographic module for Security Level 2. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.15'>AS05.15</a> to <a href='#AS05.18'>AS05.18</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.15",
        level: "2",
        requirement:
          "The software and firmware components of a cryptographic module shall only include code that is in executable form (e.g. no source code, object code, or just-in-time compiled code). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.15.01",
        level: "2",
        requirement:
          "The vendor shall provide software and firmware description with the executable form used. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.15.01",
        level: "2",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify, by inspection and from the vendor documentation, that the documented executable form does not require further compilation and that there is no dynamically modified code. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.15.02",
        level: "2",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify, by inspection and from the vendor documentation, that the documented executable form is used for each software/firmware components. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.16",
        level: "2",
        requirement:
          "There shall be no services via the HMI, SFMI, HFMI, or HSMI interface to allow the operator to examine the executable code. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.16.01",
        level: "2",
        requirement:
          "The vendor shall provide specification of HMI, SFMI, HFMI, or HSMI services. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.16.01",
        level: "2",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify the vendor documented specification of services. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.16.02",
        level: "2",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify from the vendor documentation that the services do not allow the operator to examine the executable code. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.16.03",
        level: "2",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall test the services to verify that the operator cannot examine the executable code. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.17",
        level: "2",
        requirement:
          "For software and firmware modules and the software or firmware component of a hybrid module for Security Level 2 (except for the software and firmware components within a disjoint hardware component of a hybrid module): An approved digital signature or keyed message authentication code shall be applied to all software and firmware within the module&#39;s defined cryptographic boundary. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.17.01",
        level: "2",
        requirement:
          "The vendor shall provide documentation that identifies the technique used to maintain the integrity of the cryptographic software and firmware components. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.17.01",
        level: "2",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify that the information specified in <a href='#VE05.17.01'>VE05.17.01</a> is included. If this information is not included, then this assertion fails. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.17.02",
        level: "2",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall attempt to corrupt the cryptographic software and firmware components. If the module determines that the integrity is maintained, this test is failed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.18",
        level: "2",
        requirement:
          "If the calculated result is not successfully verified, the test fails and the module shall enter the error state. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.17'>AS05.17</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.19",
        level: "3",
        requirement:
          "In addition to the requirements of Security Levels 1 and 2, the following requirements shall  apply to software and firmware modules and the software or firmware component of a hybrid module for Security Levels 3 and 4 (except for the software and firmware components within a disjoint hardware component of a hybrid module). <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.20'>AS05.20</a> to <a href='#AS05.23'>AS05.23</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.20",
        level: "3",
        requirement:
          "A cryptographic mechanism using an approved digital signature shall be applied to all software and firmware components within the module&#39;s defined cryptographic boundary. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.20.01",
        level: "3",
        requirement:
          "The vendor shall provide documentation of the approved digital signature mechanism. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.20.01",
        level: "3",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify by inspection of the cryptographic module that a cryptographic mechanism using an approved digital signature mechanism is applied to all software and firmware components within the module�s defined cryptographic boundary. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.21",
        level: "3",
        requirement:
          "If the calculated result is not successfully verified, the test fails and the module shall enter the error state. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.17'>AS05.17</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.22",
        level: "3",
        requirement:
          "The digital signature technique may consist of a single encompassing signature or multiple disjoint signatures of which failure of any disjoint signature shall cause the module to enter the error state. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.05'>AS05.05</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS05.23",
        level: "3",
        requirement:
          "The private signing key shall reside outside the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE05.23.01",
        level: "3",
        requirement:
          "The vendor documentation requirement is specified under <a href='#VE05.05.04'>VE05.05.04</a>. The vendor design shall ensure that the private signing key for generating reference signature does not reside within the cryptographic module boundary. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE05.23.01",
        level: "3",
        IGs: ["5.A"],
        Anchors: ["h.23ckvvd"],
        requirement:
          "The tester shall verify, by inspection and from the vendor documentation, that the private signing key does not reside within the cryptographic boundary. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "6",
    dtrs: [
      {
        dtrId: "AS06.01",
        level: "1",
        requirement:
          "If the operational environment is non-modifiable or a limited operational environment, only the operating system requirements in (ISO/IEC 19790:2012) 7.6.2 shall apply. <br> </ol>NOTE	This assertion is not separately tested. It is tested as part of <a href='#AS06.04'>AS06.04</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.02",
        level: "1",
        requirement:
          "If the operational environment is a modifiable operational environment, the operating system requirements in (ISO/IEC 19790:2012) 7.6.3 shall apply. <br> </ol>NOTE	This assertion is not separately tested. It is tested as part of <a href='#AS06.05'>AS06.05</a> to <a href='#AS06.29'>AS06.29</a> as applicable.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.03",
        level: "1",
        requirement:
          "The documentation requirements specified in (ISO/IEC 19790:2012) A.2.6 shall be provided. Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.03.01",
        level: "1",
        requirement:
          "The vendor shall provide the documentation requirements as specified in ISO/IEC 19790:2012, A.2.6. <br> </ol>Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.03.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation as specified in ISO/IEC 19790:2012, A.2.6. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.04",
        level: "1",
        requirement:
          "The requirements in (ISO/IEC 19790:2012) 7.6.3 Security Level 1 shall be applicable if the module is Security Level 1 in (ISO/IEC 19790:2012) 7.7. <br> </ol>NOTE	This assertion is not separately tested. It is tested as part of <a href='#AS06.05'>AS06.05</a> to <a href='#AS06.08'>AS06.08</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.05",
        level: "1",
        requirement:
          "Each instance of a cryptographic module shall have control over its own SSPs. <br> NOTE 1 Each instance of a cryptographic module controls its own SSPs and are not owned or controlled by external processes/operators. <br> NOTE 2 This requirement cannot be enforced by administrative documentation and procedures but by the cryptographic module itself. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.05.01",
        level: "1",
        requirement:
          "The vendor shall provide a description of the operating system mechanism used to ensure that each instance of a cryptographic module has control over its own SSPs while the cryptographic process is in use. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.05.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the operating system that each instance of a cryptographic module has control over its own SSPs while the cryptographic module is in use. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.05.02",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the operating system that the requirement shall be enforced by the cryptographic module itself. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.05.03",
        level: "1",
        requirement:
          "The tester shall perform cryptographic functions as described in the crypto officer and user guidance documentation. While the cryptographic functions are executing, the same or another tester shall attempt to gain unauthorized access to secret and private keys, intermediate key generation values, and other SSPs which are under the control of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.06",
        level: "1",
        requirement:
          "The operational environment shall provide the capability to separate individual application processes from each other in order to prevent uncontrolled access to CSPs and uncontrolled modifications of SSPs regardless if this data is in the process memory or stored on persistent storage within the operational environment. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.06.01",
        level: "1",
        requirement:
          "The vendor shall provide a description of the operational environment mechanism used to provide the capability to separate individual application processes from each other in order to prevent uncontrolled access to CSPs and uncontrolled modifications of SSPs regardless if this data is in the process memory or stored on persistent storage within the operational environment. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.06.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the operational environment mechanism used that it provides the capability to separate individual application processes from each other in order to prevent uncontrolled access to CSPs and uncontrolled modifications of SSPs regardless if this data is in the process memory or stored on persistent storage within the operational environment. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.06.02",
        level: "1",
        requirement:
          "The tester shall perform cryptographic functions as described in the crypto officer and user guidance documentation. While the cryptographic functions are executing, the same or another tester shall attempt to gain access to CSPs and perform modifications of SSPs regardless if this data is in the process memory or stored on persistent storage within the operational environment. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.07",
        level: "1",
        requirement:
          "Restrictions to the configuration of the operational environment shall be documented in the security policy of the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.07.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation which provides a description of any restrictions to the operational environment. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.07.01",
        level: "1",
        requirement:
          "The tester shall verify that any restrictions to the operational environment are documented in the Security Policy. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.08",
        level: "1",
        requirement:
          "Processes that are spawned by the cryptographic module shall be owned by the module and are not owned by external processes/operators. <br> NOTE	This requirement cannot be enforced by administrative documentation and procedures but by the cryptographic module itself. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.08.01",
        level: "1",
        requirement:
          "The vendor shall provide a description of the operating system mechanism used to ensure that processes that are spawned by the cryptographic module are owned by the module and are not owned by external processes/operators. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.08.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the operating system that processes that are spawned by the cryptographic module are owned by the module and are not owned by external processes/operators. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.08.02",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the operating system that the requirement shall be enforced by the cryptographic module itself. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.08.03",
        level: "1",
        requirement:
          "The tester shall perform cryptographic functions as described in the crypto officer and user guidance documentation. While the cryptographic functions are executing, the same or another tester shall attempt to gain ownership of a spawned cryptographic process that is owned by a cryptographic module from either a separate external process or operator. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.09",
        level: "2",
        requirement:
          "For Security Level 2, an operating environment shall meet the following requirements or as allowed by the validation authority. <br> NOTE 1 If the operating environment requirements are not specified by a validation authority, the assertion is tested in <a href='#AS06.10'>AS06.10</a> to <a href='#AS06.29'>AS06.29</a>. <br> NOTE 2 If the operating environment requirements are specified by a validation authority, the assertion is tested as follows. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.09.01",
        level: "2",
        requirement:
          "The vendor shall provide documentation which provides a description of the operating environment. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.09.02",
        level: "2",
        requirement:
          "The vendor shall provide documentation comparing the operating environment with the operating environment allowed by the validation authority. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.09.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation provides a description of the operating system. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.09.02",
        level: "2",
        requirement:
          "The tester shall verify by inspection of the operating system that it matches the vendor provided description of the operating system. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.09.03",
        level: "2",
        requirement:
          "The tester shall verify by inspection of the operating system and the vendor provided description of the operating system that it is allowed by the validation authority. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.10",
        level: "2",
        requirement:
          "All cryptographic software, SSPs, and control and status information shall be under the control of an operating system that implements either role-based access controls or, at the minimum, a discretionary access control with robust mechanism of defining new groups and assigning restrictive permissions, for example, through access control lists (ACLs) and with the capability of assigning each user to more than one group. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.10.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of the operating system control mechanisms which implements either role-based access controls or, at the minimum, a discretionary access control with robust mechanism of defining new groups and assigning restrictive permissions, for example, through access control lists (ACLs) and with the capability of assigning each user to more than one group. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.10.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system implements either role-based access controls or, at the minimum, a discretionary access control with robust mechanism of defining new groups and assigning restrictive permissions, for example, through access control lists (ACLs) and with the capability of assigning each user to more than one group. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.10.02",
        level: "2",
        requirement:
          "The tester shall configure the operating systems role-based access controls or discretionary access controls to give permissions to a specific user or group. The tester, assuming a permitted user or group role, shall attempt to execute, modify, or read SSPs, control or status data which the tester has authorized access. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.10.03",
        level: "2",
        requirement:
          "The tester shall configure the operating systems role-based access controls or discretionary access controls to give permissions to a specific user or group. The tester, assuming a different user or group role, shall attempt to execute, modify, or read SSPs, control or status data which the tester has unauthorized access. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.11",
        level: "2",
        requirement:
          "The operating system shall be configured to protect against unauthorized execution, modification, and reading of SSPs, control and status data. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.11.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of the operating system control mechanisms which can be configured to protect against unauthorized execution, modification, and reading of SSPs, control and status data. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.11.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system can be configured to protect against unauthorized execution, modification, and reading of SSPs, control and status data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.11.02",
        level: "2",
        requirement:
          "The tester shall configure the operating system to protect against unauthorized execution, modification, and reading of SSPs, control and status data. During execution of a cryptographic process, the tester shall attempt to execute, modify or read SSPs, control or status data which the tester has authorized access. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.11.03",
        level: "2",
        requirement:
          "The tester shall configure the operating system to protect against unauthorized execution, modification, and reading of SSPs, control and status data. During execution of a cryptographic process, the tester shall attempt to execute, modify or read SSPs, control or status data which the tester has unauthorized access. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.12",
        level: "2",
        requirement:
          "(To protect plaintext data, cryptographic software, SSPs, and authentication data, the access control mechanisms of the operating system} shall be configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to execute the stored cryptographic software. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.12.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of how the access control mechanisms of the operating system are configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to execute the stored cryptographic software. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.12.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system is configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to execute the stored cryptographic software. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.12.02",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to give exclusive rights to execute the stored cryptographic software. The tester shall verify that they have exclusive rights to execute the stored cryptographic software. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.12.03",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to not give exclusive rights to execute the stored cryptographic software. The tester shall verify that they do not have exclusive rights to execute the stored cryptographic software. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.13",
        level: "2",
        requirement:
          "(To protect plaintext data, cryptographic software, SSPs, and authentication data, the access control mechanisms of the operating system} shall be configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to modify (i.e. write, replace, and delete) the following cryptographic module software stored within the cryptographic boundary: cryptographic programs, cryptographic data (e.g. cryptographic audit data), SSPs, and plaintext data. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.13.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of how the access control mechanisms of the operating system are configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to modify (i.e. write, replace, and delete) the following cryptographic module software stored within the cryptographic boundary: cryptographic programs, cryptographic data (e.g. cryptographic audit data), SSPs, and plaintext data. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.13.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system is configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to modify (i.e. write, replace, and delete) the following cryptographic module software stored within the cryptographic boundary: cryptographic programs, cryptographic data (e.g. cryptographic audit data), SSPs, and plaintext data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.13.02",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to give exclusive rights to execute the stored cryptographic software. The tester shall verify that they have exclusive rights to modify (i.e. write, replace, and delete) the following cryptographic module software stored within the cryptographic boundary: cryptographic programs, cryptographic data (e.g. cryptographic audit data), SSPs, and plaintext data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.13.03",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to not give exclusive rights to modify (i.e. write, replace, and delete) the following cryptographic module software stored within the cryptographic boundary: cryptographic programs, cryptographic data (e.g. cryptographic audit data), SSPs, and plaintext data. The tester shall verify that they do not have exclusive rights to modify (i.e. write, replace, and delete) the following cryptographic module software stored within the cryptographic boundary: cryptographic programs, cryptographic data (e.g. cryptographic audit data), SSPs, and plaintext data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.14",
        level: "2",
        requirement:
          "(To protect plaintext data, cryptographic software, SSPs, and authentication data, the access control mechanisms of the operating system} shall be configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to read cryptographic data (e.g. cryptographic audit data), CSPs, and plaintext data. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.14.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of how the access control mechanisms of the operating system are configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to read cryptographic data (e.g. cryptographic audit data), CSPs, and plaintext data. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.14.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system is configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to read cryptographic data (e.g. cryptographic audit data), CSPs, and plaintext data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.14.02",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to give exclusive rights to read cryptographic data (e.g. cryptographic audit data), CSPs, and plaintext data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.14.03",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to not give exclusive rights to read cryptographic data (e.g. cryptographic audit data), CSPs, and plaintext data. The tester shall verify that they do not have exclusive rights to read cryptographic data (e.g. cryptographic audit data), CSPs, and plaintext data. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.15",
        level: "2",
        requirement:
          "(To protect plaintext data, cryptographic software, SSPs, and authentication data, the access control mechanisms of the operating system} shall be configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to enter SSPs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.15.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of how the access control mechanisms of the operating system are configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to enter SSPs. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.15.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system is configured to define and enforce the set of roles or the groups and their associated restrictive permissions that have exclusive rights to enter SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.15.02",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to give exclusive rights to enter SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.15.03",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to define and enforce the set of roles or the groups and their associated restrictive permissions to not give exclusive rights to enter SSPs. The tester shall verify that they do not have exclusive rights to enter SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.16",
        level: "2",
        requirement:
          "The following specifications shall be consistent with the roles or designated groups&#39; rights and services as defined in the security policy. <br> NOTE	This assertion is not separately tested. It is tested as part of <a href='#AS06.17'>AS06.17</a> to <a href='#AS06.20'>AS06.20</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.17",
        level: "2",
        requirement:
          "When not supporting a maintenance role, the operating system shall prevent all operators and running processes from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.17.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of how the operating system prevents all operators and running processes from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images) when not in maintenance mode. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.17.02",
        level: "2",
        requirement:
          "The specifications of how the operating system prevents all operators and running processes from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images) when not in maintenance mode shall be consistent with the roles or designated groups� rights and services as defined in the Security Policy. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.17.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system is configured to prevent all operators and running processes from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images) when not in maintenance mode. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.17.02",
        level: "2",
        requirement:
          "The tester shall verify that the roles or designated groups� rights and services as defined in the Security Policy are consistent with how the operating system is configured to prevent all operators and running processes from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images) when not in maintenance mode. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.17.03",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to prevent all operators and running processes from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images) when not in maintenance mode. The tester shall assume an operator role and verify that they are prevented from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images) when not in maintenance mode. The tester shall verify that running processes are prevented from modifying running cryptographic processes (i.e. loaded and executing cryptographic program images) when not in maintenance mode. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.18",
        level: "2",
        requirement:
          "The operating system shall prevent processes in user role or user groups from gaining either read or write access to SSPs owned by other processes and to system SSPs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.18.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of how the operating system prevents processes in user roles or user groups from gaining either read or write access to SSPs owned by other processes and to system SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.18.02",
        level: "2",
        requirement:
          "The specifications of how the operating system prevents processes in user roles or user groups from gaining either read or write access to SSPs owned by other processes and to system SSPs shall be consistent with the roles or designated groups� rights and services as defined in the Security Policy. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.18.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system control mechanisms, that the operating system is configured to prevent processes in user roles or user groups from gaining either read or write access to SSPs owned by other processes and to system SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.18.02",
        level: "2",
        requirement:
          "The tester shall verify that the roles or designated groups� rights and services as defined in the Security Policy is consistent with how the operating system is configured to prevent processes in user roles or user groups from gaining either read or write access to SSPs owned by other processes and to system SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.18.03",
        level: "2",
        requirement:
          "The tester shall configure the operating system control mechanisms to prevent processes in user roles or user groups from gaining either read or write access to SSPs owned by other processes and to system SSPs. The tester shall verify that running processes in user roles or user groups are prevented from gaining either read or write access to SSPs owned by other processes and to system SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.19",
        level: "2",
        requirement:
          "The configuration of the operating system that meets the above requirements (<a href='#AS06.16'>AS06.16</a> to <a href='#AS06.18'>AS06.18</a>) shall be specified in the Administrator Guidance. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.19.01",
        level: "2",
        requirement:
          "The vendor shall provide the Administrator Guidance documents which provides a description of how the operating system is configured to meet the requirements in <a href='#AS06.16'>AS06.16</a> to <a href='#AS06.18'>AS06.18</a>. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.19.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor provided Administrator Guidance documents provide a description of how the operating system is configured to meet the requirements in <a href='#AS06.16'>AS06.16</a> to <a href='#AS06.18'>AS06.18</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.20",
        level: "2",
        requirement:
          "The Administrator Guidance shall state that the operating system must be configured as specified (<a href='#AS06.16'>AS06.16</a> to <a href='#AS06.18'>AS06.18</a>) for the module contents to be considered protected. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.20.01",
        level: "2",
        requirement:
          "The vendor shall provide the Administrator Guidance documents which state that the operating system shall be configured as specified <a href='#AS06.16'>AS06.16</a> to <a href='#AS06.18'>AS06.18</a> for the module contents to be considered protected. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.20.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor provided Administrator Guidance documents state that the operating system shall be configured as specified <a href='#AS06.16'>AS06.16</a> to <a href='#AS06.18'>AS06.18</a> for the module contents to be considered protected. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.21",
        level: "2",
        requirement:
          "The identification and authentication mechanism to the operating system shall meet the requirements of {ISO/IEC 19790:2012} 7.4.3 and be specified in the module&#39;s security policy. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS06.24'>AS06.24</a> to <a href='#AS06.28'>AS06.28</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.22",
        level: "2",
        requirement:
          "All cryptographic software, SSPs, control and status information shall be under the control of {an operating system which shall have, at a minimum, the following attributes.} <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS06.24'>AS06.24</a> to <a href='#AS06.28'>AS06.28</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.23",
        level: "2",
        requirement:
          "{All cryptographic software, SSPs, control and status information shall be under the control of} an operating system which shall have, at a minimum, the following attributes. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS06.24'>AS06.24</a> to <a href='#AS06.28'>AS06.28</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.24",
        level: "2",
        requirement:
          "The operating system shall provide an audit mechanism with the date and time of each audited event. <br> NOTE	An assumption of this assertion is that the cryptographic module is using the audit mechanism provided by the operating system to audit the identified events. It is insufficient for the cryptographic module software to use another file as its audit log, no matter how well protected. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.24.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of the audit mechanism provided by the operating system and how each event is marked with the date and time. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.24.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system, that an audit mechanism is provided and that each event is marked with the date and time. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.25",
        level: "2",
        requirement:
          "The cryptographic module shall not include SSPs as part of any audit record. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.25.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of the cryptographic module�s services that provide audit records to the audit mechanism of the operating system. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.25.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of the cryptographic module�s services that provide audit records to the audit mechanism of the operating system, that no SSPs are provided in the audit records. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.25.02",
        level: "2",
        requirement:
          "The tester shall execute the module�s services that provide audit records and examine the operating system audit logs to verify that no SSPs were provided. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.26",
        level: "2",
        requirement:
          "The cryptographic module shall provide the following events to be recorded by the audit mechanism of the operating system: <br> � modifications, accesses, deletions, and additions of cryptographic data and SSPs; � attempts to provide invalid input for Crypto Officer functions; <br> � addition or deletion of an operator to and from a Crypto Officer role (if those roles are managed by the cryptographic module); <br> � the use of a security-relevant Crypto Officer function; <br> � requests to access authentication data associated with the cryptographic module; <br> � the use of an authentication mechanism (e.g. login) associated with the cryptographic module; <br> </ol>� explicit requests to assume a Crypto Officer role. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.26.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of the cryptographic module events that are provided and recorded by the audit mechanism of the operating system. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.26.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of the cryptographic module�s services that provide audit event records to the audit mechanism of the operating system, that the list of events specified in <a href='#AS06.26'>AS06.26</a> {modifications, accesses, deletions, and additions of cryptographic data and SSPs; attempts to provide invalid input for Crypto Officer functions; addition or deletion of an operator to and from a Crypto Officer role (if those roles are managed by the cryptographic module); the use of a security-relevant Crypto Officer function; requests to access authentication data associated with the cryptographic module; the use of an authentication mechanism (e.g. login) associated with the cryptographic module; and explicit requests to assume a Crypto Officer role} are provided by the cryptographic module for event recording. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.26.02",
        level: "2",
        requirement:
          "The tester shall execute the module�s services that provide audit event records and examine the operating system audit logs to verify that the events in <a href='#AS06.26'>AS06.26</a> {modifications, accesses, deletions, and additions of cryptographic data and SSPs; attempts to provide invalid input for Crypto Officer functions; addition or deletion of an operator to and from a Crypto Officer role (if those roles are managed by the cryptographic module); the use of a security-relevant Crypto Officer function; requests to access authentication data associated with the cryptographic module; the use of an authentication mechanism (e.g. login) associated with the cryptographic module; and explicit requests to assume a Crypto Officer role} were recorded. <br> NOTE	The tester DOES NOT have to test the audit mechanism provided by the operating system and identified by the vendor. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.27",
        level: "2",
        requirement:
          "The audit mechanism of the operating system shall be capable of auditing the following operating system related events: <br> � all operator read or write accesses to audit data stored in the audit trail; <br> � access to files used by the cryptographic module to store cryptographic data or SSPs; <br> � addition or deletion of an operator to and from a Crypto Officer role (if those roles are managed by operational environment); <br> � requests to use authentication data management mechanisms; <br> � attempts to use the trusted channel function and whether the request was granted, when trusted channel is supported at this security level; <br> � identification of the initiator and target of a trusted channel, when trusted channel is supported at this security level. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.27.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation which provides a description of the operating system events that are provided and recorded by the audit mechanism of the operating system. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.27.01",
        level: "2",
        IGs: ["3.4.A"],
        Anchors: ["h.4i7ojhp"],
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of the operating system documentation, that the operating system provides the list of events specified in <a href='#AS06.27'>AS06.27</a> {all operator read or write accesses to audit data stored in the audit trail; access to files used by the cryptographic module to store cryptographic data or SSPs; addition or deletion of an operator to and from a Crypto Officer role (if those roles are managed by operational environment); requests to use authentication data management mechanisms; attempts to use the trusted channel function and whether the request was granted, when trusted channel is supported at this security level; and identification of the initiator and target of a trusted channel, when trusted channel is supported at this security level} as audit event records to the audit mechanism of the operating system. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.27.02",
        level: "2",
        IGs: ["3.4.A"],
        Anchors: ["h.4i7ojhp"],
        requirement:
          "The tester shall execute the cryptographic module�s services to verify that the operating system events in <a href='#AS06.27'>AS06.27</a> {all operator read or write accesses to audit data stored in the audit trail; access to files used by the cryptographic module to store cryptographic data or SSPs; addition or deletion of an operator to and from a Crypto Officer role (if those roles are managed by operational environment); requests to use authentication data management mechanisms; attempts to use the trusted channel function and whether the request was granted, when trusted channel is supported at this security level; and identification of the initiator and target of a trusted channel, when trusted channel is supported at this security level} were recorded. <br> NOTE	The tester DOES NOT have to test the audit mechanism provided by the operating system and identified by the vendor. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.28",
        level: "2",
        requirement:
          "The operating system shall be configured to prevent operators other than those with the privileges identified in the Security Policy from modifying cryptographic module software and audit data stored within the operational environment of the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE06.28.01",
        level: "2",
        requirement:
          "The vendor shall provide operating system documentation that specifies how the operating system is configured to prevent operators other than those with the privileges identified in the Security Policy from modifying cryptographic module software and audit data stored within the operational environment of the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.28.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor documentation, and by inspection of operating system configuration controls, that the operating system is configured to prevent operators other than those with the privileges identified in the Security Policy from modifying cryptographic module software and audit data stored within the operational environment of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.28.02",
        level: "2",
        requirement:
          "The tester shall configure the operating system controls to prevent operators other than those with the privileges identified in the Security Policy from modifying cryptographic module <br> software and audit data stored within the operational environment of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.28.03",
        level: "2",
        requirement:
          "The tester shall assume the privileges identified in the Security Policy to allow modification of the cryptographic module software and audit data stored within the operational environment of the cryptographic module and verify that modification can be achieved. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE06.28.04",
        level: "2",
        requirement:
          "The tester shall assume the privileges identified in the Security Policy that do not allow modification of the cryptographic module software and audit data stored within the operational environment of the cryptographic module and verify that modification cannot be achieved. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS06.29",
        level: "2",
        requirement:
          "Only operating systems that are configured to meet the above security requirements {<a href='#AS06.05'>AS06.05</a> to <a href='#AS06.28'>AS06.28</a>} shall be permitted at this security level, whether or not the cryptographic module operates in an approved mode of operation. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS06.05'>AS06.05</a> to <a href='#AS06.28'>AS06.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "7",
    dtrs: [
      {
        dtrId: "AS07.01",
        level: "1",
        requirement:
          "A cryptographic module shall employ physical security mechanisms in order to restrict unauthorized physical access to the contents of the module and to deter unauthorized use or modification of the module (including substitution of the entire module) when installed. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.01.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the applicable physical security mechanisms that are employed by the module. The contents of the module, including all hardware, firmware, software, and data (including plaintext CSPs) shall be protected. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.01.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation describes the applicable physical security mechanisms that are employed by the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.01.02",
        level: "1",
        requirement:
          "The tester shall verify that the physical security mechanisms documented are implemented.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.02",
        level: "1",
        requirement:
          "All hardware, software, firmware, and data components and SSPs within the cryptographic boundary shall be protected. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.03",
        level: "1",
        requirement:
          "The requirements of this clause shall be applicable to hardware and firmware modules, and hardware and firmware components of hybrid modules. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.04",
        level: "1",
        requirement:
          "The requirements of this clause shall be applicable at the defined physical boundary of the module. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.05",
        level: "1",
        requirement:
          "Depending on the physical security mechanisms of a cryptographic module, unauthorized attempts at physical access, use, or modification shall have a high probability of being detected: <br> � subsequent to an attempt by leaving visible signs (i.e. tamper evidence); <br> and/or <br> � during an access attempt <br> {and appropriate immediate actions shall be taken by the cryptographic module to protect CSPs). <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.06",
        level: "1",
        requirement:
          "{In conjunction with <a href='#AS07.05'>AS07.05</a>:) Appropriate immediate actions shall be taken by the <br> cryptographic module to protect CSPs. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.07",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012) A.2.7 shall be provided. <br> </ol>NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.08",
        level: "1",
        requirement:
          "The following requirements shall apply to all physical embodiments. <br> NOTE	Tested as part of <a href='#AS07.09'>AS07.09</a> to <a href='#AS07.33'>AS07.33</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.09",
        level: "1",
        requirement:
          "Documentation shall specify the physical embodiment and the security level for which the physical security mechanisms of a cryptographic module are implemented. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.09.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the physical embodiment of the module: single-chip cryptographic module, multiple-chip embedded cryptographic module, or multiple-chip standalone cryptographic module, as defined in ISO/IEC 19790:2012, 7.7.1. <br> The specified physical embodiment shall be consistent with the module physical design. The vendor documentation shall also state which security level (1 to<ol><li>the module is intended to meet. <br> </ol>Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.09.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor identified that the cryptographic module is either a single-chip module, a multi-chip embedded module, or a multi-chip standalone module as defined in ISO/IEC 19790:2012, 7.7.1. <br> The tester shall perform an independent determination that the physical embodiment satisfies one of the three criteria specified below. The fundamental determining characteristics of the three physical embodiments and some common examples are summarized below. <br> <ol type=1>   <li> Single-chip cryptographic module. Characteristics: A single integrated circuit (IC) chip, used as a standalone device or physically embedded within some other module or enclosure that may not be physically protected. The single-chip will consist of one die that may be covered with a uniform external material such as plastic or ceramic, and external input/output connectors. Examples: <br> </ol>  <br> <ol type=1>   <li> Multiple-chip embedded cryptographic module. Characteristics: Two or more IC chips interconnected and physically embedded within some other product or enclosure that may not be physically protected. <br>   </li>   <li> Multiple-chip standalone cryptographic module. Characteristics: Two or more IC chips interconnected and physically embedded in an enclosure that is entirely physically protected. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.09.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation states which security level the module is intended to meet. The tester shall perform an independent determination of the security level that the module actually meets. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.10",
        level: "1",
        requirement:
          "Whenever zeroisation is performed for physical security purposes, the zeroisation shall occur in a sufficiently small time period so as to prevent the recovery of the sensitive data between the time of detection and the actual zeroisation. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.10.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the response time of the zeroisation after tamper detection. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.10.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation describes the zeroisation response time after the tamper detection. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.10.02",
        level: "1",
        requirement:
          "The tester shall verify that the zeroisation response mechanism is implemented as specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.11",
        level: "1",
        requirement:
          "{If a module includes a maintenance role that requires physical access to the contents of the module or if the module is designed to permit physical access (e.g. by the module vendor or other authorized individual), then} a maintenance access interface shall be defined. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.11.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the maintenance access interface employed by the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.11.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation describes the maintenance access interface. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.11.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation and implementation are consistent.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.12",
        level: "1",
        requirement:
          "{If a module includes a maintenance role that requires physical access to the contents of the module or if the module is designed to permit physical access (e.g. by the module vendor or other authorized individual), then} the maintenance access interface shall include all physical access paths to the contents of the cryptographic module, including any removable covers or doors. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.12.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the maintenance access interface, including any removable covers or doors. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.12.01",
        level: "1",
        requirement:
          "The tester shall verify in the vendor documentation that a maintenance access interface is provided, including any removable covers or doors. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.13",
        level: "1",
        requirement:
          "{If a module includes a maintenance role that requires physical access to the contents of the module or if the module is designed to permit physical access (e.g. by the module vendor or other authorized individual), then} any removable covers or doors included within the maintenance access interface shall be safeguarded using the appropriate physical security mechanisms. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.13.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify a physical protection such that any removable covers or doors included within the maintenance access interface are safeguarded using the appropriate physical security mechanisms. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.13.01",
        level: "1",
        requirement:
          "The tester shall verify that any removable covers or doors included within the maintenance access interface are safeguarded using the appropriate physical security mechanisms. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.14",
        level: "1",
        requirement:
          "The following requirements shall apply to all cryptographic modules for Security Level 1. <br> NOTE	Tested as part of <a href='#AS07.15'>AS07.15</a> to <a href='#AS07.16'>AS07.16</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.15",
        level: "1",
        requirement:
          "The cryptographic module shall consist of production-grade components that include standard passivation techniques (e.g. a conformal coating or a sealing coat applied over the module&#39;s circuitry to protect against environmental or other physical damage). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.15.01",
        level: "1",
        requirement:
          "The module shall consist of standard, production-quality ICs, designed to meet commercial-grade specifications for power, temperature, reliability, shock and vibration, etc. The module shall use standard passivation techniques for the entire chip. The vendor documentation shall describe the IC quality. If an IC is used that is not a standard device, its passivation design shall also be described. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.15.01",
        level: "1",
        requirement:
          "The tester shall verify by inspection, or from the vendor documentation, that the module contains standard integrated circuits with a uniform exterior material and standard connectors. The tester shall verify from the vendor documentation that the chips in the module are commercial grade in regards to power and voltage ranges, temperature, reliability, and shock and vibration. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.15.02",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation that the module has a standard passivation applied to it. The passivation has to be a sealing coat applied over the chip circuitry to protect it against environmental or other physical damage. If standard passivation is not used, then the documentation shall provide information to indicate why it is equivalent to a standard passivation approach. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.16",
        level: "1",
        requirement:
          "When performing physical maintenance, zeroisation shall either be performed procedurally by the operator or automatically by the cryptographic module. <br> NOTE	This assertion is tested as part of <a href='#AS07.10'>AS07.10</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.17",
        level: "2",
        requirement:
          "The following requirement shall apply to all cryptographic modules for Security Level 2. <br> NOTE	Tested as part of <a href='#AS07.18'>AS07.18</a> to <a href='#AS07.20'>AS07.20</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.18",
        level: "2",
        requirement:
          "The cryptographic module shall provide evidence of tampering (e.g. on the cover, enclosure, and seal) when physical access to the module is attempted. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS07.34'>AS07.34</a> and <a href='#AS07.35'>AS07.35</a> for single-chip embodiments, <a href='#AS07.44'>AS07.44</a> and <a href='#AS07.45'>AS07.45</a> for multiple-chip embedded embodiments, and <a href='#AS07.62'>AS07.62</a> and <a href='#AS07.63'>AS07.63</a> for multiple-chip standalone embodiments. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.19",
        level: "2",
        requirement:
          "The tamper-evident material, coating or enclosure shall either be opaque or translucent within the visible spectrum (i.e. light of wavelength range of 400 nm to 750 nm) to prevent the gathering of information about the internal operations of the critical areas of the module. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.19.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify that the tamper evident material, coating, or enclosure shall be opaque or translucent within the visible spectrum. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.19.01",
        level: "2",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the tamper evident material, coating, or enclosure is opaque or translucent within the visible spectrum. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.20",
        level: "2",
        requirement:
          "If the cryptographic module contains ventilation holes or slits, then the module shall be constructed in a manner to prevent the gathering of information of the module&#39;s internal construction or components by direct visual observation using artificial light sources in the visual spectrum of the module&#39;s internal construction or components. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.20.01",
        level: "2",
        requirement:
          "If the module is contained within a cover or enclosure that contains any ventilation holes or slits, then they shall be constructed in a manner that prevents the gathering of information of the module�s internal construction or components by direct visual observation using artificial light sources in the visual spectrum of the module�s internal construction or components. The vendor documentation shall describe the physical design approach that prevents such observation. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.20.01",
        level: "2",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation whether the module has a cover or enclosure with ventilation holes, slits, or other openings, and if so, whether they are constructed to deter the gathering of information of the module�s internal construction or components by direct visual observation using artificial light sources in the visual spectrum of the module�s internal construction or components. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.21",
        level: "3",
        requirement:
          "The following requirements shall apply to all cryptographic modules for Security Level 3. <br> NOTE	Tested as part of <a href='#AS07.22'>AS07.22</a> to <a href='#AS07.28'>AS07.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.22",
        level: "3",
        requirement:
          "If the cryptographic module contains any doors or removable covers or if a maintenance access interface is defined, then the module shall contain tamper response and zeroisation capability. <br> NOTE	This assertion is tested as part of <a href='#AS07.13'>AS07.13</a> for general requirements, <a href='#AS07.38'>AS07.38</a> for single-chip <br> embodiments, <a href='#AS07.50'>AS07.50</a> for multiple-chip embedded embodiments, and <a href='#AS07.62'>AS07.62</a> for multiple-chip standalone embodiments. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.23",
        level: "3",
        requirement:
          "The tamper response and zeroisation capability shall immediately zeroise all unprotected SSPs when a door is opened, a cover is removed, or when the maintenance access interface is accessed. <br> NOTE	This assertion is tested as part of <a href='#AS07.13'>AS07.13</a> for general requirements, <a href='#AS07.38'>AS07.38</a> for single-chip <br> embodiments, <a href='#AS07.50'>AS07.50</a> for multiple-chip embedded embodiments, and <a href='#AS07.62'>AS07.62</a> for multiple-chip standalone embodiments. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.24",
        level: "3",
        requirement:
          "The tamper response and zeroisation capability shall remain operational when unprotected SSPs are contained within the cryptographic module. <br> NOTE	This assertion is tested as part of <a href='#AS07.38'>AS07.38</a> for single-chip embodiments, <a href='#AS07.50'>AS07.50</a> for multiple-chip <br> embedded embodiments, and <a href='#AS07.65'>AS07.65</a> for multiple-chip standalone embodiments. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.25",
        level: "3",
        requirement:
          "If the cryptographic module contains ventilation holes or slits, then the module shall be constructed in a manner that prevents undetected physical probing inside the enclosure (e.g. prevent probing by a single articulated probe). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.25.01",
        level: "3",
        requirement:
          "If the module is contained within a cover or enclosure that contains any ventilation holes or slits, then they shall be constructed in a manner that prevents undetected physical probing inside the enclosure. The vendor documentation shall describe the ventilation physical design approach. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.25.01",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation whether the module has a cover or enclosure with ventilation holes, slits, or other openings, and if so, whether they are constructed to deter undetected probing inside the cover or enclosure. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.26",
        level: "3",
        requirement:
          "Strong or hard conformal or non-conformal enclosures, coatings, or potting materials shall  <br> maintain strength and hardness characteristics over the module&#39;s intended temperature range of operation, storage, and distribution. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.26.01",
        level: "3",
        requirement:
          "The vendor documentation shall describe the strength or hardness of the conformal or non-conformal enclosure, coatings or potting materials, and the rationale that the strength or hardness is appropriate for the module design. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.26.01",
        level: "3",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify from the vendor documentation and inspection of the module that the strength or hardness of the conformal or non-conformal enclosure, coatings, or potting materials is implemented as specified. The tester shall verify the module hardness at the following temperatures: <br> 	-- the lowest temperature of the module&#39;s intended temperature range of operation, storage and distribution; <br> 	-- the highest temperature of the module&#39;s intended temperature range of operation, storage and distribution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.26.02",
        level: "3",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify that the vendor provided security policy specifies the high/low temperature range. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.27",
        level: "3",
        requirement:
          "If tamper evident seals are employed, they shall be uniquely numbered or independently identifiable (e.g. uniquely numbered evidence tape or uniquely identifiable holographic seals). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.27.01",
        level: "3",
        requirement:
          "The vendor shall provide the specification of the tamper evident seal. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.27.01",
        level: "3",
        requirement:
          "The tester shall verify that tamper evident seals are uniquely numbered or independently identifiable as documented. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.28",
        level: "3",
        requirement:
          "The module shall either include EFP features or undergo EFT. <br> NOTE	This assertion is tested as part of <a href='#AS07.73'>AS07.73</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.29",
        level: "4",
        requirement:
          "The following requirement shall apply to all cryptographic modules for Security Level 4. <br> NOTE	Tested as part of <a href='#AS07.30'>AS07.30</a> to <a href='#AS07.33'>AS07.33</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.30",
        level: "4",
        requirement:
          "The cryptographic module shall be protected either by a hard opaque removal-resistant coating or by a tamper detection envelope with tamper response and zeroisation capability. <br> NOTE	This assertion is tested as part of <a href='#AS07.40'>AS07.40</a> for single-chip embodiments, <a href='#AS07.52'>AS07.52</a> for multiple-chip embedded embodiments, and <a href='#AS07.64'>AS07.64</a> for multiple-chip standalone embodiments. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.31",
        level: "4",
        requirement:
          "NOTE	This assertion is tested as part of <a href='#AS07.74'>AS07.74</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.32",
        level: "4",
        requirement:
          "The cryptographic module shall provide protection from fault induction. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.32.01",
        level: "4",
        requirement:
          "The vendor documentation shall specify the protection mechanism from fault induction. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.32.01",
        level: "4",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the module the specified fault induction protection mechanisms. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.33",
        level: "4",
        requirement:
          "The fault induction mitigation techniques and the mitigation metrics employed shall be documented as specified in {ISO/IEC 19790:2012} Annex B. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.33.01",
        level: "4",
        requirement:
          "The vendor documentation shall specify the fault induction mitigation techniques and the mitigation metrics employed by the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.33.01",
        level: "4",
        requirement:
          "The tester shall verify that the fault induction mitigation techniques and the mitigation metrics employed by the module are documented as specified. <br> NOTE 1	In addition to the general security requirements specified in ISO/IEC 19790:2012, 7.7.2, the requirements specified in <a href='#AS07.34'>AS07.34</a> to <a href='#AS07.42'>AS07.42</a> are specific to single-chip cryptographic modules. <br> NOTE 2 There are no additional Security Level 1 requirements for single-chip cryptographic modules. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.34",
        level: "2",
        requirement:
          "The following requirements shall apply to single-chip cryptographic modules for Security Level 2. <br> NOTE	This assertion is tested as part of <a href='#AS07.35'>AS07.35</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.35",
        level: "2",
        requirement:
          "The cryptographic module shall be covered with a tamper-evident coating (e.g. a tamper-evident passivation material or a tamper-evident material covering the passivation) or contained in a tamper-evident enclosure to deter direct observation, probing, or manipulation of the module and to provide evidence of attempts to tamper with or remove the module. <br> </ol>NOTE	This requirement is associated with <a href='#AS07.18'>AS07.18</a>. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.35.01",
        level: "2",
        requirement:
          "The vendor documentation shall identify the tamper-evident coating and its characteristics. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.35.01",
        level: "2",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the module is covered with a tamper-evident coating. The inspection shall verify that the tamper-evident coating completely covers the module and deters direct observation, probing, or manipulation of the single-chip. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.36",
        level: "3",
        requirement:
          "The following requirements shall apply to single-chip cryptographic modules for Security Level 3. <br> NOTE	This requirement is tested in <a href='#AS07.37'>AS07.37</a> or <a href='#AS07.38'>AS07.38</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.37",
        level: "3",
        requirement:
          "{Either} the module shall be covered with a hard opaque tamper-evident coating (e.g. a hard opaque epoxy covering the passivation) {or <a href='#AS07.38'>AS07.38</a> shall be satisfied}. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.37.01",
        level: "3",
        requirement:
          "The vendor documentation shall state clearly that the approach specified in <a href='#AS07.37'>AS07.37</a> is used to meet the requirement. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.37.02",
        level: "3",
        requirement:
          "The vendor documentation shall provide supporting detailed design information, especially the type of coating that is used and its characteristics. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.37.01",
        level: "3",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the module is covered with a hard opaque tamper evident coating. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.37.02",
        level: "3",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify that the vendor documentation does sufficiently provide supporting detailed design information, especially specifying the type of coating that is used and its characteristics. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.37.03",
        level: "3",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify that the coating cannot be easily penetrated to the depth of the underlying circuitry, and that it leaves tamper evidence. The inspection has to verify that the coating completely covers the module, is visibly opaque, and deters direct observation, probing, or manipulation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.38",
        level: "3",
        requirement:
          "(If <a href='#AS07.37'>AS07.37</a> is not satisfied, then} the enclosure shall be implemented {so that attempts at removal or penetration of the enclosure shall have a high probability of causing serious damage to the cryptographic module (i.e. the module will not function)}. <br> NOTE	This assertion is not separately tested. Tested in <a href='#AS07.39'>AS07.39</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.39",
        level: "3",
        requirement:
          "(If <a href='#AS07.37'>AS07.37</a> is not satisfied, then} {the enclosure shall be implemented} so that attempts at removal or penetration of the enclosure shall have a high probability of causing serious damage to the cryptographic module (i.e. the module will not function). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.39.01",
        level: "3",
        requirement:
          "The vendor documentation shall state clearly that the approach specified in <a href='#AS07.38'>AS07.38</a> is used to meet the requirement. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.39.02",
        level: "3",
        requirement:
          "The vendor documentation shall provide supporting detailed design information, especially whether the enclosure contains any doors or removable covers and whether a maintenance access interface is specified. The enclosure shall be designed such that attempts to remove it will have a high probability of causing serious damage to the circuitry within the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.39.03",
        level: "3",
        requirement:
          "The vendor documentation shall provide supporting detailed design information. If the enclosure contains any doors or removable covers, or if a maintenance access interface is specified, then the module shall contain tamper response and zeroisation circuitry. The circuitry shall continuously monitor the covers and doors, and upon the removal of a cover or the opening of a door, shall zeroise all plaintext CSPs. The circuitry shall be operational whenever plaintext CSPs are contained within the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.39.01",
        level: "3",
        requirement:
          "The tester shall verify that the documentation specifies that the enclosure cannot be removed easily and whether the module contains doors or removable covers or has a maintenance access interface. If the enclosure contains any doors or removable covers, or if a maintenance access interface is specified, then the tester shall verify that the documentation specifies that the module contains tamper response and zeroisation circuitry. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.39.02",
        level: "3",
        requirement:
          "If the enclosure has removable covers or doors, or if a maintenance access interface is specified, the tester shall verify from the vendor documentation that the module zeroises all plaintext CSPs when a cover or door is removed or if the maintenance access interface is accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.39.03",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the tamper response and zeroisation circuitry remains operational when plaintext CSPs are contained within the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.39.04",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the enclosure cannot be removed or penetrated without having a high probability of causing serious damage to the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.39.05",
        level: "3",
        requirement:
          "If the enclosure has doors or removable covers, or if a maintenance access interface is specified, the tester shall test that the module zeroises all plaintext CSPs when a cover or door is removed or if the maintenance access interface is accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.39.06",
        level: "3",
        requirement:
          "The tester shall test that the enclosure cannot be removed or penetrated without having a high probability of causing serious damage to the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.40",
        level: "4",
        requirement:
          "The following requirements shall apply to single-chip cryptographic modules for Security Level 4. <br> NOTE	This assertion is tested in <a href='#AS07.41'>AS07.41</a> and <a href='#AS07.42'>AS07.42</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.41",
        level: "4",
        requirement:
          "The cryptographic module shall be covered with a hard, opaque removal-resistant coating with hardness and adhesion characteristics such that attempting to peel or pry the coating from the module will have a high probability of resulting in serious damage to the module (i.e. the module will not function). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.41.01",
        level: "4",
        requirement:
          "The vendor documentation shall clearly identify the kind of coating used and shall provide details of its characteristics, especially hardness and removal resistance. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.41.02",
        level: "4",
        requirement:
          "The vendor documentation shall provide supporting detailed design information for the module when covered with a hard, opaque removal-resistant coating. The hardness and adhesion characteristics of the material shall be such that attempting to peel or pry the material from the module will have a high probability of resulting in serious damage to the module (i.e. the module does not function). The material shall be opaque within the visible spectrum. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.41.01",
        level: "4",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the module is covered with a hard, opaque removal-resistant coating. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.41.02",
        level: "4",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify the removal-resistant properties of the module coating. The tester shall attempt to peel or pry the material from the module and verify that this is not possible with a reasonable application of force that the module ceased to function or that the module circuitry was obviously physically destroyed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.42",
        level: "4",
        requirement:
          "The removal-resistant coating shall have solvency characteristics such that dissolving the coating will have a high probability of dissolving or seriously damaging the module (i.e. the module will not function). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.42.01",
        level: "4",
        requirement:
          "The vendor documentation shall describe the solvency characteristics of the removal-resistant coating. The solvency characteristics of the material shall be such that dissolving the material to remove it will have a high probability of dissolving or seriously damaging the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.42.01",
        level: "4",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify the vendor documentation to determine the solvency properties of the module�s removal-resistant coating. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.42.02",
        level: "4",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall test the solvency properties of the module�s removal-resistant coating. The tester, based on documentation provided in <a href='#VE07.42.01'>VE07.42.01</a>, shall verify what type of solvent would be required to compromise the removal-resistant coating. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.43",
        level: "1",
        requirement:
          "If the cryptographic module is contained within an enclosure or removable cover, a production-grade enclosure or removable cover shall be used. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.43.01",
        level: "1",
        requirement:
          "The module shall be entirely contained within a production-grade enclosure or removable cover. The vendor documentation shall describe the cover or enclosure. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.43.01",
        level: "1",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the module is contained within an enclosure or removable cover that is of production-grade. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.44",
        level: "2",
        requirement:
          "The following requirements {<a href='#AS07.45'>AS07.45</a> to AS 07.46} shall apply to multiple-chip embedded cryptographic modules for Security Level 2 {and the assertions <a href='#AS07.45'>AS07.45</a> to AS 07.46 shall be satisfied in the following groups: (<a href='#AS07.45'>AS07.45</a>) or (<a href='#AS07.46'>AS07.46</a> and <a href='#AS07.47'>AS07.47</a>) or (<a href='#AS07.46'>AS07.46</a> and <a href='#AS07.48'>AS07.48</a>)}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.44.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify that either (<a href='#AS07.45'>AS07.45</a>) or [<a href='#AS07.46'>AS07.46</a> and (<a href='#AS07.47'>AS07.47</a> or <a href='#AS07.48'>AS07.48</a>)] are satisfied. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.44.01",
        level: "2",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that either (<a href='#AS07.45'>AS07.45</a>) or [<a href='#AS07.46'>AS07.46</a> and (<a href='#AS07.47'>AS07.47</a> or <a href='#AS07.48'>AS07.48</a>)] are satisfied. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.45",
        level: "2",
        requirement:
          "The module components shall be covered with a tamper-evident coating or potting material (e.g. etch-resistant coating or bleeding paint) to deter direct observation and to provide evidence of attempts to tamper with or remove module components {or the groups (<a href='#AS07.46'>AS07.46</a> and <a href='#AS07.47'>AS07.47</a>) or (<a href='#AS07.46'>AS07.46</a> and <a href='#AS07.48'>AS07.48</a>) shall be satisfied}. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.45.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify that the module is encapsulated with an opaque, tamper-evident coating such as etch-resistant coating or bleeding paint. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.45.01",
        level: "2",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the module is encapsulated with an opaque, tamper-evident material. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.45.02",
        level: "2",
        IGs: ["7.3.B"],
        Anchors: ["h.2grqrue"],
        requirement:
          "The tester shall verify by testing that the module provides evidence of attempts to tamper with or remove module components. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.46",
        level: "2",
        requirement:
          "{If <a href='#AS07.45'>AS07.45</a> is not satisfied, then the} module shall be entirely contained within a metal or hard plastic production-grade enclosure that may include doors or removable covers {and the groups (<a href='#AS07.47'>AS07.47</a> and <a href='#AS07.48'>AS07.48</a>) or (<a href='#AS07.47'>AS07.47</a> and <a href='#AS07.49'>AS07.49</a>) shall be satisfied}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.46.01",
        level: "2",
        requirement:
          "The module shall be entirely contained within a metal or hard plastic production-grade enclosure that may include removable covers or doors. The vendor documentation shall describe the enclosure and its hardness characteristics. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.46.01",
        level: "2",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the module is contained within an enclosure that meets the following requirements. <br> <ol type=1>   <li> The enclosure has to completely surround the entire module. <br>   </li>   <li> The enclosure material has to be of a composition defined in the vendor documentation. <br>   </li>   <li> The enclosure has to be production-grade. The vendor literature has to either show that an enclosure of the same material has been used commercially or provide data to show that it is equivalent to a commercial product. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.47",
        level: "2",
        requirement:
          "(If <a href='#AS07.45'>AS07.45</a> is not satisfied, then if} the enclosure includes any doors or removable covers, then the doors or covers shall be locked with pick-resistant mechanical locks employing physical or logical keys (or <a href='#AS07.48'>AS07.48</a> shall be satisfied}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.47.01",
        level: "2",
        requirement:
          "The doors or covers included by the enclosure shall be locked with pick-resistant mechanical locks that employ physical or logical keys. The vendor documentation shall describe the locks and the employed physical or logical keys. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.47.01",
        level: "2",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the doors or covers are locked with a pick-resistant lock that requires a physical key or a logical key. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.47.02",
        level: "2",
        requirement:
          "The tester shall attempt to open the locked cover or door without use of the key and verify that the cover or door will not open without signs of damage. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.48",
        level: "2",
        requirement:
          "(If <a href='#AS07.45'>AS07.45</a> is not satisfied and the enclosure includes any doors or removable covers without matching <a href='#AS07.47'>AS07.47</a>, then they (i.e. the doors or removable covers)} shall be protected with tamper-evident seals (e.g. evidence tape or holographic seals) {and the group (<a href='#AS07.47'>AS07.47</a> and <a href='#AS07.49'>AS07.49</a>) shall be satisfied}. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.48.01",
        level: "2",
        requirement:
          "The vendor documentation shall describe the tamper-evident seals. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.48.01",
        level: "2",
        IGs: ["7.3.A"],
        Anchors: ["h.41mghml"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the cover or door is protected with a tamper-evident seal such as evidence tape or a holographic seal. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.48.02",
        level: "2",
        IGs: ["7.3.A"],
        Anchors: ["h.41mghml"],
        requirement:
          "The tester shall verify that the cover or door cannot be opened without breaking or removing the seal and that the seal cannot be removed and later replaced. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.49",
        level: "3",
        requirement:
          "The following requirements shall apply to multiple-chip embedded cryptographic modules for Security Level 3. <br> NOTE	This assertion is tested in <a href='#AS07.50'>AS07.50</a> or <a href='#AS07.51'>AS07.51</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.50",
        level: "3",
        requirement:
          "{Either} the multiple-chip embodiment of the circuitry within the cryptographic module shall  be covered with a hard coating or potting material (e.g. a hard epoxy material) {or <a href='#AS07.51'>AS07.51</a> shall be <br> </ol>satisfied} such that attempts at removal or penetration of the enclosure will have a high probability of causing serious damage to the module (i.e. the module will not function). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.50.01",
        level: "3",
        requirement:
          "The vendor documentation shall provide design documentation for the hard coating or potting material. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.50.02",
        level: "3",
        requirement:
          "The vendor documentation shall provide documentation regarding the opacity characteristics of the hard coating or potting material. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.50.01",
        level: "3",
        requirement:
          "The tester shall verify that the vendor documentation specifies the hard coating or potting material. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.50.02",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation the opacity characteristics of the hard coating or potting material. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.50.03",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the hard coating or potting material cannot be removed or penetrated without having a high probability of causing serious damage to the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.51",
        level: "3",
        requirement:
          "{If <a href='#AS07.50'>AS07.50</a> does not apply,} the module shall be contained within a strong enclosure such that attempts at removal or penetration of the enclosure will have a high probability of causing serious damage to the module (i.e. the module will not function). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.51.01",
        level: "3",
        requirement:
          "The vendor documentation shall provide supporting design documentation for the strong enclosure. The module shall be entirely contained within a strong enclosure. The enclosure shall be designed such that attempts to remove it will have a high probability of causing serious damage to the circuitry within the module (i.e. the module does not function). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.51.02",
        level: "3",
        requirement:
          "If the enclosure contains any doors or removable covers, then the module shall contain tamper response and zeroisation circuitry and the vendor shall provide supporting design documentation for the tamper response and zeroisation circuitry. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.01",
        level: "3",
        requirement:
          "The tester shall verify that the vendor documentation specifies whether the enclosure contains any doors or removable covers and whether a maintenance access interface is specified, then the module shall contain tamper response and zeroisation circuitry. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.02",
        level: "3",
        requirement:
          "If the enclosure contains any doors or removable covers, or if a maintenance access interface is specified, then the tester shall verify that the vendor documentation specifies that the module zeroises all plaintext CSPs when a door or cover is removed or if the maintenance access interface is accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.03",
        level: "3",
        requirement:
          "The tester shall verify that the vendor documentation specifies which requirement option in <a href='#VE07.51.01'>VE07.51.01</a> and <a href='#VE07.51.02'>VE07.51.02</a> is implemented and provides design documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.04",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the tamper response and zeroisation circuitry remains operational when plaintext CSPs are contained within the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.05",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the enclosure cannot be removed or penetrated without having a high probability of causing serious damage to the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.06",
        level: "3",
        requirement:
          "The tester shall verify the strength of the enclosure by attempting to access the underlying circuitry and verifying that the enclosure is not easily breached. The tester shall verify by inspection and from the vendor documentation that the enclosure cannot be removed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.07",
        level: "3",
        requirement:
          "If the strong enclosure has doors or removable covers, or if a maintenance access interface is specified, the tester shall verify from the vendor documentation that the module zeroises all plaintext CSPs when a cover or door is removed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.08",
        level: "3",
        requirement:
          "If the enclosure has doors or removable covers, or if a maintenance access interface is specified, the tester shall test that the module zeroises all plaintext CSPs when a cover or door is removed or if the maintenance access interface is accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.51.09",
        level: "3",
        requirement:
          "The tester shall test that the enclosure cannot be removed or penetrated without having a high probability of causing serious damage to the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.52",
        level: "4",
        requirement:
          "The following requirements shall apply to multiple-chip embedded cryptographic modules for Security Level 4. <br> NOTE	This assertion is tested in <a href='#AS07.53'>AS07.53</a> to <a href='#AS07.59'>AS07.59</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.53",
        level: "4",
        requirement:
          "The module components shall be within a strong or hard conformal or non-conformal enclosure. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.53.01",
        level: "4",
        requirement:
          "The module shall be contained within a tamper detection envelope that will detect tampering attacks against the potting material or enclosure. The vendor documentation shall describe the tamper detection envelope design. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.53.01",
        level: "4",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection that the module contains a tamper detection envelope that surrounds the module components. This barrier shall be designed such that any breach by means such as drilling, milling, grinding, or dissolving to access the module components can be detected by monitoring components in the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.54",
        level: "4",
        requirement:
          "The enclosure shall be encapsulated by a tamper detection envelope (e.g. a flexible mylar printed circuit with a serpentine geometric pattern of conductors or a wire-wound package or a non-flexible, brittle circuit or a strong enclosure) {that shall detect tampering by means such as cutting, drilling, milling, grinding, burning, melting, or dissolving of the potting material or enclosure to an extent sufficient for accessing SSPs}. <br> </ol>NOTE	This assertion is not separately tested. Tested in <a href='#AS07.55'>AS07.55</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.55",
        level: "4",
        requirement:
          "{The enclosure shall be encapsulated by a tamper detection envelope (e.g. a flexible mylar printed circuit with a serpentine geometric pattern of conductors or a wire-wound package or a non-flexible, brittle circuit or a strong enclosure)} that shall detect tampering by means such as cutting, drilling, milling, grinding, burning, melting, or dissolving of the potting material or enclosure to an extent sufficient for accessing SSPs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.55.01",
        level: "4",
        requirement:
          "The module shall be contained within a tamper detection envelope that will detect tampering attacks against the potting material or enclosure. The vendor documentation shall describe the tamper detection envelope design. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.55.01",
        level: "4",
        requirement:
          "The tester shall verify from vendor documentation and by inspection that the module contains a tamper detection envelope that surrounds the module components. This barrier shall be <br> designed such that any breach by means such as drilling, milling, grinding, or dissolving to access the module components can be detected by monitoring components in the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.56",
        level: "4",
        requirement:
          "The module shall contain tamper response and zeroisation circuitry {that shall continuously monitor the tamper detection envelope and, upon the detection of tampering, shall immediately zeroise all unprotected SSPs). <br> NOTE	This assertion is not separately tested. Tested in <a href='#AS07.57'>AS07.57</a> and <a href='#AS07.58'>AS07.58</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.57",
        level: "4",
        requirement:
          "{The module shall contain tamper response and zeroisation circuitry) that shall continuously monitor the tamper detection envelope {and, upon the detection of tampering, shall immediately zeroise all unprotected SSPs). <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.57.01",
        level: "4",
        requirement:
          "The module shall contain tamper response and zeroisation circuitry that continuously monitors the tamper detection envelope for tampering, and upon the detection of tampering, shall zeroise all plaintext SSPs. The circuitry shall be operational whenever plaintext SSPs are contained within the module. The vendor documentation shall describe the tamper response and zeroisation design. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.57.01",
        level: "4",
        requirement:
          "The tester shall verify from the vendor documentation that the module contains tamper response and zeroisation circuitry that continuously monitors the tamper detection envelope; detects any breach by means such as drilling, milling, grinding, or dissolving any portion of the envelope; and then zeroises all plaintext SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.58",
        level: "4",
        requirement:
          "{The module shall contain tamper response and zeroisation circuitry that shall continuously monitor the tamper detection envelope ) and upon the detection of tampering, shall immediately zeroise all unprotected SSPs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.58.01",
        level: "4",
        requirement:
          "The module shall contain tamper response and zeroisation circuitry that continuously monitors the tamper detection envelope for tampering, and upon the detection of tampering, shall zeroise all plaintext SSPs. The vendor documentation shall describe the tamper response and zeroisation design. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.58.01",
        level: "4",
        requirement:
          "The tester shall breach the tamper detection envelope barrier and then verify that the module zeroises all plaintext SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.59",
        level: "4",
        requirement:
          "The tamper response circuitry shall remain operational when unprotected SSPs are contained within the cryptographic module. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.60",
        level: "1",
        requirement:
          "The cryptographic module shall be entirely contained within a metal or hard plastic production-grade enclosure that may include doors or removable covers. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.60.01",
        level: "1",
        requirement:
          "The module shall be entirely contained within a metal or hard plastic production-grade enclosure that may include removable covers or doors. The vendor documentation shall describe the enclosure and its hardness characteristics. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.60.01",
        level: "1",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the module is contained within an enclosure that meets the following requirements. <br> <ol type=1>   <li> The enclosure has to completely surround the entire module. <br>   </li>   <li> The enclosure material has to be of a composition defined in the vendor documentation. <br>   </li>   <li> The enclosure has to be production-grade. The vendor literature has to either show that an enclosure of the same material has been used commercially or provide data to show that it is equivalent to a commercial product. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.61",
        level: "2",
        requirement:
          "The following requirements shall apply to multiple-chip standalone cryptographic modules for Security Level 2. <br> NOTE	This assertion is tested in <a href='#AS07.62'>AS07.62</a> or <a href='#AS07.63'>AS07.63</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.62",
        level: "2",
        requirement:
          "If the enclosure of the cryptographic module includes any doors or removable covers, then the doors or covers shall be locked with pick-resistant mechanical locks employing physical or logical keys (or <a href='#AS07.63'>AS07.63</a> shall apply}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.62.01",
        level: "2",
        requirement:
          "If the enclosure includes any removable covers or doors, then either they shall be locked with pick-resistant mechanical locks that employ physical or logical keys. The vendor documentation shall describe pick-resistant mechanical locks that employ physical or logical keys. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.62.01",
        level: "2",
        requirement:
          "The tester shall verify whether the enclosure contains any removable covers or doors. The tester shall verify that each cover or door is locked with a pick-resistant lock that requires a physical key or a logical key. The tester shall attempt to open the locked cover or door without use of the key and verify that the cover or door will not open without signs of damage. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.63",
        level: "2",
        requirement:
          "(If <a href='#AS07.62'>AS07.62</a> is not satisfied, then the doors or covers} shall be protected with tamper-evident seals (e.g. evidence tape or holographic seals). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.63.01",
        level: "2",
        requirement:
          "If the enclosure is protected via tamper-evident seals such as evidence tape or holographic seals, the vendor documentation shall describe the tamper-evident seals. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.63.01",
        level: "2",
        requirement:
          "The cover or door is protected with a seal such as evidence tape or a holographic seal. The tester shall verify that the cover or door cannot be opened without breaking or removing the seal and that the seal cannot be removed and later replaced. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.64",
        level: "3",
        requirement:
          "The following requirements shall apply to multiple-chip standalone cryptographic modules for Security Level 3. <br> NOTE	This assertion is tested in <a href='#AS07.65'>AS07.65</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.65",
        level: "3",
        requirement:
          "The module shall be contained within a strong enclosure, such that attempts at removal or penetration of the enclosure will have a high probability of causing serious damage to the module (i.e. the module will not function). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.65.01",
        level: "3",
        requirement:
          "The vendor documentation shall provide supporting design documentation for the strong enclosure. The module shall be entirely contained within a strong enclosure. The enclosure shall be designed such that attempts to remove it will have a high probability of causing serious damage to the circuitry within the module (i.e. the module does not function). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.65.02",
        level: "3",
        requirement:
          "If the enclosure contains any doors or removable covers, then the module shall contain tamper response and zeroisation circuitry and the vendor documentation shall provide supporting design documentation for the tamper response and zeroisation circuitry. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.01",
        level: "3",
        requirement:
          "The tester shall verify that the vendor documentation specifies whether the enclosure contains any doors or removable covers and whether a maintenance access interface is specified, then the module shall contain tamper response and zeroisation circuitry. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.02",
        level: "3",
        requirement:
          "If the enclosure contains any doors or removable covers, or if a maintenance access interface is specified, then the tester shall verify that the vendor documentation specifies that the module zeroises all plaintext CSPs when a door or cover is removed or if the maintenance access interface is accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.03",
        level: "3",
        requirement:
          "The tester shall verify that the vendor documentation specifies which requirement option in <a href='#VE07.65.01'>VE07.65.01</a> and <a href='#VE07.65.02'>VE07.65.02</a> is implemented and provides design documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.04",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the tamper response and zeroisation circuitry remains operational when plaintext CSPs are contained within the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.05",
        level: "3",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the enclosure cannot be removed or penetrated without having a high probability of causing serious damage to the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.06",
        level: "3",
        requirement:
          "The tester shall verify the strength of the enclosure by attempting to access the underlying circuitry and verifying that the enclosure is not easily breached. The tester shall verify by inspection and from the vendor documentation that the enclosure cannot be removed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.07",
        level: "3",
        requirement:
          "If the strong enclosure has doors or removable covers, or if a maintenance access interface is specified, the tester shall verify from the vendor documentation that the module zeroises all plaintext CSPs when a cover or door is removed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.08",
        level: "3",
        requirement:
          "If the enclosure has doors or removable covers, or if a maintenance access interface is specified, the tester shall test that the module zeroises all plaintext CSPs when a cover or door is removed or if the maintenance access interface is accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.65.09",
        level: "3",
        requirement:
          "The tester shall test that the enclosure cannot be removed or penetrated without having a high probability of causing serious damage to the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.66",
        level: "4",
        requirement:
          "The following requirements shall apply to multiple-chip standalone cryptographic modules for Security Level 4. <br> NOTE	This assertion is tested in <a href='#AS07.67'>AS07.67</a> to <a href='#AS07.72'>AS07.72</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.67",
        level: "4",
        requirement:
          "The enclosure of the cryptographic module shall contain a tamper detection envelope that use tamper detection mechanisms such as cover switches (e.g. micro-switches, magnetic Hall effect switches, permanent magnetic actuators, etc.), motion detectors (e.g. ultrasonic, infrared, or microwave), or other tamper detection mechanisms as described in {ISO/IEC 19790:2012} 7.7.3.2 Security Level 4. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.67.01",
        level: "4",
        requirement:
          "The enclosure or potting material shall be encapsulated by a tamper detection envelope by the use of tamper detection mechanisms. The vendor documentation shall describe the tamper detection envelope design. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.67.01",
        level: "4",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection that the module enclosure or potting material contains tamper detection mechanisms, which shall form a tamper detection envelope that protects the module components. The mechanisms shall be designed such that any breach of the enclosure or potting material to access the module components can be detected. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.68",
        level: "4",
        requirement:
          "The tamper detection mechanisms shall respond to attacks such as cutting, drilling, milling, grinding, burning, melting, or dissolving to an extent sufficient for accessing SSPs. <br> NOTE	This assertion is tested as part of <a href='#AS07.71'>AS07.71</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.69",
        level: "4",
        requirement:
          "The cryptographic module shall contain tamper response and zeroisation capability {that shall continuously monitor the tamper detection envelope and, upon the detection of tampering, shall immediately zeroise all unprotected SSPs}. <br> NOTE	This assertion is tested as part of <a href='#AS07.71'>AS07.71</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.70",
        level: "4",
        requirement:
          "{The cryptographic module shall contain tamper response and zeroisation capability} that shall  continuously monitor the tamper detection envelope {and, upon the detection of tampering, shall immediately zeroise all unprotected SSPs}. <br> NOTE	This assertion is tested as part of <a href='#AS07.71'>AS07.71</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.71",
        level: "4",
        requirement:
          "{The cryptographic module shall contain tamper response and zeroisation capability that shall continuously monitor the tamper detection envelope} and, upon the detection of tampering, shall immediately zeroise all unprotected SSPs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.71.01",
        level: "4",
        requirement:
          "The module shall contain tamper response and zeroisation circuitry that continuously monitors the tamper detection envelope for tampering, and upon the detection of tampering, shall zeroise all plaintext SSPs. The circuitry shall be operational whenever plaintext SSPs are contained within the module. The vendor documentation shall describe the tamper response and zeroisation design. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.71.01",
        level: "4",
        requirement:
          "The tester shall verify from the vendor documentation that the module contains tamper response and zeroisation circuitry that continuously monitors the tamper detection envelope; detects any breach by means such as drilling, milling, grinding, or dissolving any portion of the envelope; and then zeroises all plaintext SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.71.02",
        level: "4",
        requirement:
          "The tester shall breach the tamper detection envelope barrier and then verify that the module zeroises all plaintext SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.72",
        level: "4",
        requirement:
          "The tamper response and zeroisation capability shall remain operational when unprotected SSPs are contained within the cryptographic module. <br> NOTE	This assertion is tested as part of <a href='#AS07.71'>AS07.71</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.73",
        level: "3",
        requirement:
          "A module shall either employ environmental failure protection (EFP) features (<a href='#AS07.75'>AS07.75</a> to <a href='#AS07.77'>AS07.77</a>) or undergo environmental failure testing (EFT) (<a href='#AS07.78'>AS07.78</a> to <a href='#AS07.86'>AS07.86</a>). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.73.01",
        level: "3",
        requirement:
          "The vendor shall use either of the following: <br> <ol type=1>   <li> EFP features; <br>   </li>   <li> EFT <br> </ol>  <br> <ol type=1>   <li> low temperature; <br>   </li>   <li> high temperature; <br>   </li>   <li> large negative voltage; <br>   </li>   <li> large positive voltage. <br> </ol>  <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.73.01",
        level: "3",
        requirement:
          "The tester shall verify that the documentation states EFP/EFT selection for each condition and how the specified approach is used. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.74",
        level: "4",
        requirement:
          "A module shall employ environmental failure protection (EFP) features. <br> NOTE	This assertion is tested in <a href='#AS07.75'>AS07.75</a> to <a href='#AS07.77'>AS07.77</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.75",
        level: "3",
        requirement:
          "Environmental failure protection (EFP) features shall protect a cryptographic module against unusual environmental conditions (accidental or induced) when outside of the module&#39;s normal operating range that can compromise the security of the module. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS07.77'>AS07.77</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.76",
        level: "3",
        requirement:
          "The cryptographic module shall monitor and correctly respond when operating temperature and voltage are outside of the specified normal operating ranges. <br> NOTE	This assertion is tested as part of <a href='#AS07.77'>AS07.77</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.77",
        level: "3",
        requirement:
          "If the temperature or voltage falls outside of the cryptographic module&#39;s normal operating range, the protection capability shall either <br> � shutdown the module to prevent further operation, <br> or <br> � immediately zeroise all unprotected SSPs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.77.01",
        level: "3",
        requirement:
          "If EFP is chosen for a particular condition, the module shall monitor and correctly respond to fluctuations in the operating temperature or voltage outside of the module�s normal operating range for that condition. The protection features shall continuously measure these environmental conditions. If a condition is determined to be outside of the module�s normal operating range, the protection circuitry shall either <br> <ol type=1>   <li> shut down the module, or <br>   </li>   <li> zeroise all unprotected SSPs <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.77.02",
        level: "3",
        requirement:
          "The security policy shall address whether the employed EFP feature forces module shutdown or zeroises all unprotected SSPs and shall specify the temperature range met. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.77.01",
        level: "3",
        requirement:
          "The tester shall configure the environmental condition (ambient temperature and voltage) close to the appropriate extreme of the normal operating range specified for the module and verify that the module continues to perform within normal operating parameters. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.77.02",
        level: "3",
        requirement:
          "The tester shall extend the temperature and voltage outside of the specified normal range and verify that the module either shuts down to prevent further operations or zeroises all plaintext SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.77.03",
        level: "3",
        requirement:
          "If the module is designed to zeroise all plaintext SSPs, and the module was still operational after returning to the normal environmental range, the tester shall perform services that require SSPs and verify that the module does not perform these services. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.77.04",
        level: "3",
        requirement:
          "The tester shall verify that the security policy specifies the normal operating temperature and voltage range, and whether the module shuts down or zeroises all unprotected SSPs if the operating temperature or voltage falls outside the normal operating range of the module <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.78",
        level: "3",
        requirement:
          "Environmental failure testing (EFT) shall involve a combination of analysis, simulation, and testing of a cryptographic module to provide reasonable assurance that the environmental <br> conditions (accidental or induced) when outside the module&#39;s normal operating ranges for temperature and voltage will not compromise the security of the module. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.79",
        level: "3",
        requirement:
          "EFT shall demonstrate that, if the operating temperature or voltage falls outside the normal operating range of the module resulting in a failure, {at no time shall the security of the cryptographic module be compromised}. <br> NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.80",
        level: "3",
        requirement:
          "{EFT shall demonstrate that, if the operating temperature or voltage falls outside the normal operating range of the module resulting in a failure,} at no time shall the security of the cryptographic module be compromised. <br> NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.81",
        level: "3",
        requirement:
          "The temperature range to be tested shall be from a temperature within the normal operating temperature range to the lowest (i.e. coldest) temperature that either (1) shutdown the module to prevent further operation or (2) immediately zeroise all unprotected SSPs; and from a temperature within the normal operating temperature range to the highest (i.e. hottest) temperature that either (1) shuts down or goes into an error state or (2) zeroises all unprotected SSPs. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.81.01",
        level: "3",
        requirement:
          "If EFT is chosen for a particular condition, the module shall be tested within the temperature range specified in <a href='#AS07.82'>AS07.82</a> and voltage ranges specified in <a href='#AS07.85'>AS07.85</a> and <a href='#AS07.86'>AS07.86</a>. The module shall either <br> <ol type=1>   <li> continue to operate normally, or <br>   </li>   <li> shut down, or <br>   </li>   <li> zeroise all unprotected SSPs. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE07.81.02",
        level: "3",
        requirement:
          "The security policy shall address whether the employed EFT feature forces module shutdown or zeroises all unprotected SSPs and shall specify the temperature range met. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.81.01",
        level: "3",
        requirement:
          "The tester shall configure the environmental condition (ambient temperature and voltage) as specified in <a href='#AS07.82'>AS07.82</a>, <a href='#AS07.85'>AS07.85</a>, and <a href='#AS07.86'>AS07.86</a>, and verify that the module either continues to operate normally, or shuts down to prevent further operations, or zeroises all plaintext SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.81.02",
        level: "3",
        requirement:
          "If the module is designed to zeroise all plaintext SSPs, and the module was still operational after returning to the normal environmental range, the tester shall perform services that require SSPs and verify that the module does not perform these services. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE07.81.03",
        level: "3",
        requirement:
          "The tester shall verify that the non-proprietary security policy specifies the normal operating temperature and voltage range, and whether the module forces shut down or zeroises all unprotected SSPs if the operating temperature or voltage falls outside the normal operating range of the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.82",
        level: "3",
        requirement:
          "The temperature range to be tested shall be from -100� to +200� Celsius (-150� to +400� Fahrenheit); {however, the test shall be interrupted as soon as either (1) the module is shutdown to prevent further operation, (2) all unprotected SSPs are immediately zeroised or (3) the module enters a failure state}. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.83",
        level: "3",
        requirement:
          "{The temperature range to be tested shall be from -100� to +200� Celsius (-150� to +400� Fahrenheit);} however, the test shall be interrupted as soon as either (1) the module is shutdown to prevent further operation, (2) all unprotected SSPs are immediately zeroised or (3) the module enters a failure state. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.84",
        level: "3",
        requirement:
          "Temperature shall be monitored internally at the sensitive components and critical devices and not just at the physical boundary of the module. <br> NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.85",
        level: "3",
        requirement:
          "The voltage range tested shall be gradually decreasing from a voltage within the normal operating voltage range to a lower voltage that either (1) shuts down the module to prevent further operation or (2) immediately zeroises all unprotected SSPs; {and shall be gradually increasing from a voltage within the normal operating voltage range to a higher voltage that either (1) shuts down the module to prevent further operation or (2) immediately zeroises all unprotected SSPs}. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS07.86",
        level: "3",
        requirement:
          "{The voltage range tested shall be gradually decreasing from a voltage within the normal operating voltage range to a lower voltage that either (1) shuts down the module to prevent further operation or (2) immediately zeroises all unprotected SSPs;} and shall be gradually increasing from a voltage within the normal operating voltage range to a higher voltage that either (1) shuts down the module to prevent further operation or (2) immediately zeroises all unprotected SSPs. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS07.81'>AS07.81</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "8",
    dtrs: [
      {
        dtrId: "AS08.01",
        level: "1",
        requirement:
          "Non-invasive attack mitigation techniques implemented by the cryptographic module to protect the module&#39;s SSPs that are not referenced in {ISO/IEC 19790:2012} Annex F shall meet the requirements in {ISO/IEC 19790:2012} 7.12. <br> NOTE	This assertion is not separately tested. It is tested as part of <a href='#AS12.01'>AS12.01</a> to <a href='#AS12.04'>AS12.04</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS08.02",
        level: "1",
        requirement:
          "Non-invasive attack mitigation techniques implemented by the cryptographic module to protect the module&#39;s SSPs that are referenced in {ISO/IEC 19790:2012} Annex F shall meet the following requirements. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS08.03",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.8 shall be provided. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE08.03.01",
        level: "1",
        requirement:
          "The vendor shall provide the documentation requirements as specified in ISO/IEC 19790:2012, A.2.8. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE08.03.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation as specified in ISO/IEC 19790:2012, A.2.8. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS08.04",
        level: "1",
        requirement:
          "Documentation shall specify all of the mitigation techniques employed to protect the module&#39;s CSPs from the non-invasive attacks referenced in (ISO/IEC 19790:2012) Annex F. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE08.04.01",
        level: "1",
        requirement:
          "The vendor shall provide supporting documentation which specifies all of the mitigation techniques employed to protect the module�s CSPs from the non-invasive attacks specified in [ISO/IEC 19790:2012] Annex F. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE08.04.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides supporting documentation which specifies all of the mitigation techniques employed to protect the module�s CSPs from the non-invasive attacks specified in [ISO/IEC 19790:2012] Annex F. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS08.05",
        level: "1",
        requirement:
          "Documentation shall include evidence of the effectiveness of each of the attack mitigation techniques. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE08.05.01",
        level: "1",
        requirement:
          "The vendor shall specify in the documentation the effectiveness of the mitigation techniques. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE08.05.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that specifies the effectiveness of the mitigation techniques. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS08.06",
        level: "3",
        requirement:
          "The cryptographic module shall be tested to meet the approved non-invasive attack mitigation test metrics for Security Level 3 as specified in (ISO/IEC 19790:2012) Annex F. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE08.06.01",
        level: "3",
        requirement:
          "The vendor shall provide documentation that the module meets the approved non-invasive attack mitigation test metrics for Security Level 3. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE08.06.01",
        level: "3",
        requirement:
          "The tester shall verify that the vendor provides documentation that the module meets the approved non-invasive attack mitigation test metrics for Security Level 3. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS08.07",
        level: "4",
        requirement:
          "The cryptographic module shall be tested to meet the approved non-invasive attack mitigation test metrics for Security Level 4 as specified in (ISO/IEC 19790:2012) Annex F. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE08.07.01",
        level: "4",
        requirement:
          "The vendor shall provide documentation that the module meets the approved non-invasive attack mitigation test metrics for Security Level 4. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE08.07.01",
        level: "4",
        requirement:
          "The tester shall verify that the vendor provides documentation that the module meets the approved non-invasive attack mitigation test metrics for Security Level 4. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "9",
    dtrs: [
      {
        dtrId: "AS09.01",
        level: "1",
        requirement:
          "CSPs shall be protected within the module from unauthorized access, use, disclosure, modification, and substitution. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.01.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the protection of all CSPs internal to the module. Protection shall include the implementation of mechanisms that protect against unauthorized access, use, disclosure, modification, and substitution. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.01.01",
        level: "1",
        IGs: ["D.L, D.M, D.N"],
        Anchors: ["h.243i4a2, h.j8sehv, h.338fx5o"],
        requirement:
          "The tester shall check the vendor documentation that describes the protection of CSPs. The tester shall verify that the documentation describes how these CSPs are protected from unauthorized access, use, disclosure, modification, and substitution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.01.02",
        level: "1",
        IGs: ["D.L, D.M, D.N"],
        Anchors: ["h.243i4a2, h.j8sehv, h.338fx5o"],
        requirement:
          "The tester shall attempt to access (by circumventing the documented protection mechanisms) CSPs for which the tester is not authorized to access. To meet this assertion, the module is required to deny access. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.01.03",
        level: "1",
        IGs: ["D.L"],
        Anchors: ["h.243i4a2"],
        requirement:
          "The tester shall attempt to modify CSPs using any method not specified by the vendor documentation. <br> NOTE	CSPs encrypted using a non-approved algorithm or proprietary algorithm or method are considered in plaintext form within the scope of this document. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.02",
        level: "1",
        requirement:
          "PSPs shall be protected within the module against unauthorized modification and substitution. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.02.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the protection of all PSPs against unauthorized modification and substitution. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.02.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation describe how the PSPs are protected from unauthorized modification and substitution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.02.02",
        level: "1",
        requirement:
          "The tester shall attempt to modify all PSPs using any method not specified by the vendor documentation and shall attempt to enter them into the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.03",
        level: "1",
        requirement:
          "A module shall associate an SSP which is generated, entered into or output from the module with the entity (i.e. person, group, role, or process) to which the SSP is assigned. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.03.01",
        level: "1",
        requirement:
          "The documented SSP procedures shall describe the mechanisms or procedures used to ensure that each SSP is associated with the correct entity. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.03.01",
        level: "1",
        requirement:
          "The tester shall verify the documented SSP entry/output procedures that the procedures address how an entered or output SSP is associated with the correct entity. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.03.02",
        level: "1",
        requirement:
          "For each SSP that can be entered, the tester shall first enter the SSP while assuming the correct entity. The tester shall then verify that entry is not possible when assuming an incorrect entity. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.03.03",
        level: "1",
        requirement:
          "For each SSP that can be output, the tester shall first output the SSP while assuming the correct entity. The tester shall then verify that output is not possible when assuming an incorrect entity. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.04",
        level: "1",
        requirement:
          "Hash values of passwords, RBG state information, and intermediate key generation values shall  be considered as CSPs. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.04.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that hash values of passwords, RBG state information, and intermediate key generation values are defined as CSPs. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.04.01",
        level: "1",
        IGs: ["D.L"],
        Anchors: ["h.243i4a2"],
        requirement:
          "The tester shall verify that the vendor provides documentation that hash values of passwords, RBG state information, and intermediate key generation values are defined as CSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.04.02",
        level: "1",
        IGs: ["D.L"],
        Anchors: ["h.243i4a2"],
        requirement:
          "The tester shall verify that the vendor provided Security Policy defines any hash values of passwords, RBG state information, and intermediate key generation values as CSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.05",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.9 shall be provided. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.05.01",
        level: "1",
        requirement:
          "The vendor shall provide the documentation requirements as specified in ISO/IEC 19790:2012, A.2.9. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.05.01",
        level: "1",
        IGs: ["D.L"],
        Anchors: ["h.243i4a2"],
        requirement:
          "The tester shall verify that the vendor provides documentation as specified in ISO/IEC 19790:2012, A.2.9. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.06",
        level: "1",
        requirement:
          "If an approved security function, SSP generation, or SSP establishment method requires random values, then an approved RBG shall be used to provide these values. <br> NOTE	Approved RBGs are listed in ISO/IEC 19790:2012, Annex C. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.06.01",
        level: "1",
        requirement:
          "The vendor shall provide the list of all RBGs used in approved security functions, SSP generation, or SSP establishment methods within the cryptographic module and their precise usage. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.06.02",
        level: "1",
        requirement:
          "The vendor shall provide documentation that any random values used by approved security functions, SSP generation, or SSP establishment method are provided from an approved RBG. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.06.01",
        level: "1",
        IGs: ["D.I"],
        Anchors: ["h.1qoc8b1"],
        requirement:
          "The tester shall verify that all RBGs used by approved security functions, SSP generation, or SSP establishment methods are documented and their usage defined. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.06.02",
        level: "1",
        IGs: ["D.I"],
        Anchors: ["h.1qoc8b1"],
        requirement:
          "The tester shall verify from the vendor provided documentation that the implemented RBGs used by approved security functions, SSP generation, or SSP establishment methods are compliant with the approved RBGs listed in ISO/IEC 19790:2012, Annex C. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.06.03",
        level: "1",
        IGs: ["D.I"],
        Anchors: ["h.1qoc8b1"],
        requirement:
          "The tester shall verify from the vendor provided documentation that any random values used by approved security functions, SSP generation, or SSP establishment method are provided from an approved RBG. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.07",
        level: "1",
        requirement:
          "If entropy is collected from outside the cryptographic boundary of the module, the data stream generated using this entropy input shall be considered a CSP. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.07.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that the input datastream generated from entropy collected from outside the cryptographic module�s boundary is defined as a CSP. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.07.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that the input datastream generated from entropy collected from outside the cryptographic module�s boundary is defined as a CSP. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.08",
        level: "1",
        requirement:
          "Compromising the security of the SSP generation method which uses the output of an approved RBG (e.g. guessing the seed value to initialize the deterministic RBG) shall require at least as many operations as determining the value of the generated SSP. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.08.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that provides rationale stating how compromising the security of the SSP generation method (e.g. guessing the seed value to initialize the deterministic RBG) shall require at least as many operations as determining the value of the generated SSP. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.08.01",
        level: "1",
        IGs: ["9.3.A, D.K, D.L, D.O"],
        Anchors: ["h.1v1yuxt, h.14ykbeg-1, h.243i4a2"],
        requirement:
          "The tester shall verify that the vendor provided documentation that provides rationale stating how compromising the security of the SSP generation method (e.g. guessing the seed value to initialize the deterministic RBG) shall require at least as many operations as determining the value of the generated SSP. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.08.02",
        level: "1",
        IGs: ["9.3.A, D.K, D.L, D.O"],
        Anchors: ["h.1v1yuxt, h.14ykbeg-1, h.243i4a2"],
        requirement:
          "The tester shall verify the accuracy of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.09",
        level: "1",
        requirement:
          "SSPs generated by the module from either the output of an approved RBG or derived from an SSP entered into the module and used by an approved security function or SSP establishment method shall be generated using an approved SSP generation method listed in {ISO/IEC 19790:2012} Annex D. <br> NOTE	Approved sensitive security parameter generation methods are listed in ISO/IEC 19790:2012, Annex D. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.09.01",
        level: "1",
        requirement:
          "The vendor shall provide the list of all SSPs generated by the module from either the output of an approved RBG or derived from an SSP entered into the module and used by an approved security function or SSP establishment methods used in the cryptographic module and their precise usage. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.09.02",
        level: "1",
        requirement:
          "The vendor shall provide documentation that SSPs generated by the module from either the output of an approved RBG or derived from an SSP entered into the module and used by an approved security function or SSP establishment method are generated using an approved SSP generation method. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.09.01",
        level: "1",
        IGs: ["D.A, D.J, D.K, D.O"],
        Anchors: ["h.1ljsd9k, h.4anzqyu, h.14ykbeg-1"],
        requirement:
          "The tester shall verify that all SSPs generated by the module from either the output of an approved RBG or derived from an SSP entered into the module and used by an approved security function or SSP establishment methods are documented and their usage defined. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.09.02",
        level: "1",
        IGs: ["D.A, D.J, D.K, D.O"],
        Anchors: ["h.1ljsd9k, h.4anzqyu, h.14ykbeg-1"],
        requirement:
          "The tester shall verify from the vendor provided documentation that the implemented SSPs generated by the module from either the output of an approved RBG or derived from an SSP entered into the module and used by an approved security function or SSP establishment methods are compliant with the approved SSP generation methods listed in ISO/IEC 19790:2012, Annex D. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.10",
        level: "1",
        requirement:
          "Automated SSP establishment shall use an approved method listed in (ISO/IEC 19790:2012) Annex D. <br> </ol>NOTE	Approved sensitive security parameter establishment methods are listed in ISO/IEC 19790:2012, Annex D. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.10.01",
        level: "1",
        requirement:
          "The vendor shall provide the list of all automated SSP establishment methods used in the cryptographic module and their precise usage. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.10.01",
        level: "1",
        IGs: ["9.5.A, D.B, D.D, D.E, D.F, D.G"],
        Anchors: [
          "h.19c6y18, h.14ykbeg, h.3jtnz0s, h.1d96cc0, h.3x8tuzt, h.2ce457m"
        ],
        requirement:
          "The tester shall verify that all automated SSP establishment methods are documented and their usage defined. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.10.02",
        level: "1",
        IGs: ["D.B. D.D, D.E, D.F, D.G"],
        Anchors: ["h.1d96cc0, h.3x8tuzt, h.2ce457m"],
        requirement:
          "The tester shall verify from the vendor provided documentation that the implemented automated SSP establishment methods are compliant with the approved automated SSP establishment methods listed in ISO/IEC 19790:2012, Annex D. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.11",
        level: "1",
        requirement:
          "NOTE	This assertion is tested as part of <a href='#AS09.12'>AS09.12</a> to <a href='#AS09.24'>AS09.24</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.12",
        level: "1",
        requirement:
          "If SSPs are manually entered into or output from a module, the entry or output shall be through the defined HMI, SFMI, HFMI or HSMI ((ISO/IEC 19790:2012) 7.3.2) interfaces. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS03.04'>AS03.04</a> to <a href='#AS03.15'>AS03.15</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.13",
        level: "1",
        requirement:
          "All cryptographically protected SSPs, entered into or output from the module shall be encrypted using an approved security function. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.13.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify all cryptographically protected SSPs which are entered into or output from the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.13.02",
        level: "1",
        requirement:
          "The vendor documentation shall state the encryption method used to cryptographically protect the SSPs which are entered into or output from the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.13.01",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall verify that the vendor has provided documentation specifying all the cryptographically protected SSPs which are entered into and output from the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.13.02",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall verify that the vendor has provided documentation specifies the encryption method used to cryptographically protect the SSPs which are entered into or output from the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.13.03",
        level: "1",
        requirement:
          "The tester shall verify that the encryption method used to cryptographically protect the SSPs which are entered into or output from the cryptographic module is performed using an approved security function. <br> NOTE	For directly entered SSPs, the entered values can be temporarily displayed to allow visual verification and to improve accuracy. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.14",
        level: "1",
        requirement:
          "If encrypted SSPs are directly entered into the module, then the plaintext values of the SSPs shall  not be displayed. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.14.01",
        level: "1",
        requirement:
          "The documented SSP entry mechanisms for encrypted SSPs shall preclude the display of their plaintext values. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.14.01",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall verify the documented SSP entry mechanisms for encrypted SSPs preclude the display of their plaintext values during the encrypted SSP entry process. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.14.02",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall enter all encrypted SSPs and shall monitor the output interfaces of the module to verify that any resulting plaintext SSP values are not displayed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.15",
        level: "1",
        requirement:
          "Directly entered (plaintext or encrypted) SSPs shall be verified during entry into a module for accuracy using the conditional manual entry test specified in (ISO/IEC 19790:2012) 7.10.3.5. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS10.42'>AS10.42</a> to <a href='#AS10.46'>AS10.46</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.16",
        level: "1",
        requirement:
          "To prevent the inadvertent output of sensitive information, two independent internal actions shall be required in order to output any plaintext CSP. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.16.01",
        level: "1",
        requirement:
          "If the module outputs any plaintext CSPs, the vendor documentation shall describe the output services. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.16.02",
        level: "1",
        requirement:
          "The finite state model and other vendor documentation shall indicate, for the output of plaintext CSPs, that two independent internal actions that are required. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.16.01",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall verify from the vendor documentation or finite state model that the module allows the output of plaintext CSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.16.02",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall verify from the finite state model and other vendor documentation that the output of plaintext CSPs requires two independent internal actions in order for the cryptographic module to output the plaintext CSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.16.03",
        level: "1",
        requirement:
          "The tester shall attempt to output plaintext CSPs without the module performing two independent internal actions. The module shall fail if the module allows the output of plaintext CSPs without two independent internal actions. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.17",
        level: "1",
        requirement:
          "These two independent internal actions shall be dedicated to mediating the output of the CSPs. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS09.16'>AS09.16</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.18",
        level: "1",
        requirement:
          "For electronic entry or output via a wireless connection, CSPs, key components, and authentication data shall be encrypted. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.18.01",
        level: "1",
        requirement:
          "If the module inputs or outputs CSPs, key components, and authentication data via wireless interfaces, the vendor documentation shall describe the wireless services. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.18.02",
        level: "1",
        requirement:
          "If the module inputs or outputs CSPs, key components, and authentication data via wireless interfaces, the vendor documentation shall describe the encryption methods employed to encrypt the CSPs, key components, and authentication data. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.18.01",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall verify whether the module inputs or outputs CSPs, key components, and authentication data via wireless interfaces. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.18.02",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "The tester shall verify that the encryption methods employed to encrypt the CSPs, key components, and authentication data are approved encryption methods. <br> NOTE	For Security Levels 1 and 2, plaintext CSPs, key components, and authentication data can be entered and output via physical port(s) and logical interface(s) shared with other physical ports and logical interfaces of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.19",
        level: "1",
        requirement:
          "</ol>For software modules or the software components of a hybrid software module, CSPs, key components, and authentication data may be entered into or output in either encrypted or plaintext form provided that the CSPs, key components, and authentication data shall be maintained within the operational environment and meet the requirements of {ISO/IEC 19790:2012} 7.6.3. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.19.01",
        level: "1",
        requirement:
          "For software modules or the software components of a hybrid software module the vendor shall provide documentation that CSPs, key components, and authentication data may be entered into or output in either encrypted or plaintext form provided that the CSPs, key components, and authentication data are maintained within the operational environment and meet the requirements in ISO/IEC 19790:2012, 7.6.3 {<a href='#AS06.05'>AS06.05</a> to <a href='#AS06.29'>AS06.29</a> as applicable}. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.19.01",
        level: "1",
        IGs: ["9.5.A"],
        Anchors: ["h.19c6y18"],
        requirement:
          "For software modules or the software components of a hybrid software module the tester shall verify that the vendor provides documentation that CSPs, key components, and authentication data may be entered into or output in either encrypted or plaintext form provided that the CSPs, key components, and authentication data are maintained within the operational environment and meet the requirements of ISO/IEC 19790:2012, 7.6.3 {<a href='#AS06.05'>AS06.05</a> to <a href='#AS06.29'>AS06.29</a> as applicable}. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.20",
        level: "3",
        requirement:
          "CSPs, key components, and authentication data shall be entered into or output from the module either encrypted or by a trusted channel. <br> NOTE	This assertion is tested as part of <a href='#AS09.13'>AS09.13</a> or <a href='#AS03.16'>AS03.16</a> to <a href='#AS03.22'>AS03.22</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.21",
        level: "3",
        requirement:
          "CSPs which are plaintext secret and private cryptographic keys shall be entered into or output from the module using split knowledge procedures using a trusted channel. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.21.01",
        level: "3",
        requirement:
          "The vendor shall supply documentation specifying the split knowledge procedures employed by the cryptographic module using a trusted channel for the input or output of plaintext secret and private cryptographic keys. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.21.01",
        level: "3",
        IGs: ["3.4.A, "],
        Anchors: ["h.4i7ojhp"],
        requirement:
          "The tester shall verify that the documentation specifying the split knowledge procedures employed by the cryptographic module using a trusted channel for the input or output of plaintext secret and private cryptographic keys matches the implementation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.21.02",
        level: "3",
        IGs: ["3.4.A,"],
        Anchors: [""],
        requirement:
          "The tester shall verify the split knowledge procedure splits the key into multiple key components, with each key component individually sharing no knowledge of the original key. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.21.03",
        level: "3",
        IGs: ["3.4.A,"],
        Anchors: [""],
        requirement:
          "The tester shall verify that a subset of the split knowledge components or all components are required to be entered or output for each key. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.21.04",
        level: "3",
        IGs: ["3.4.A,"],
        Anchors: [""],
        requirement:
          "The tester shall verify the trusted channel under <a href='#AS03.16'>AS03.16</a> to <a href='#AS03.21'>AS03.21</a> for Level 3 and <a href='#AS03.22'>AS03.22</a> for Level 4. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.22",
        level: "3",
        requirement:
          "If the module employs split knowledge procedures, the module shall employ separate identity-based operator authentication for entering or outputting each key component, {and at least two key components shall be required to reconstruct the original cryptographic key}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.22.01",
        level: "3",
        requirement:
          "The vendor documentation shall specify that identity-based authentication is employed for each separate key component. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.22.01",
        level: "3",
        requirement:
          "The tester shall verify that identity-based authentication is employed for each separate key component. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.23",
        level: "3",
        requirement:
          "{If the module employs split knowledge procedures, the module shall employ separate identity-based operator authentication for entering or outputting each key component,} and at least two key components shall be required to reconstruct the original cryptographic key. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.23.01",
        level: "3",
        requirement:
          "The vendor documentation shall specify the number of components that are required to construct the original CSP. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.23.02",
        level: "3",
        requirement:
          "If knowledge of the number of key components is required to reconstruct the original key, the vendor provided documentation shall include rationale stating how knowledge of any one less than the number of key components provides no information about the original key other than the length. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.23.01",
        level: "3",
        requirement:
          "The tester shall verify in the vendor documentation that the split knowledge procedure requires at least two components to construct the original CSP. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.23.02",
        level: "3",
        requirement:
          "The tester shall verify the vendor documentation provides a rationale that no information is gained without knowing all the necessary split keys. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.23.03",
        level: "3",
        requirement: "Intentionally left blank (SP800 140-3) <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.23.04",
        level: "3",
        requirement:
          "The tester shall verify the accuracy of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.24",
        level: "4",
        requirement:
          "The module shall employ multi-factor separate identity-based operator authentication for entering or outputting each key component. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.24.01",
        level: "4",
        requirement:
          "The vendor documentation shall specify that multi-factor identity-based authentication is employed for each separate key component. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.24.01",
        level: "4",
        requirement:
          "The tester shall verify that multi-factor identity-based authentication is employed for each separate key component. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.24.02",
        level: "4",
        requirement:
          "The tester shall verify the multi-factor authentication method under <a href='#AS04.59'>AS04.59</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.25",
        level: "1",
        requirement:
          "A module shall associate every SSP stored within the module with the entity (e.g. operator, role, or process) to which the SSP is assigned. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.25.01",
        level: "1",
        requirement:
          "The vendor documentation on key storage shall describe the mechanisms or procedures used to ensure that each key is associated with the correct entity. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.25.01",
        level: "1",
        IGs: ["D.L"],
        Anchors: ["h.243i4a2"],
        requirement:
          "The tester shall verify the documentation on key storage that the procedures address how a stored key is associated with the correct entity. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.25.02",
        level: "1",
        IGs: ["D.L"],
        Anchors: ["h.243i4a2"],
        requirement:
          "The tester shall modify the association of key and entity. The tester shall then attempt to perform cryptographic functions as one of the entities and shall verify that these functions fail. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.26",
        level: "1",
        requirement:
          "Access to plaintext CSPs by unauthorized operators shall be prohibited. <br> NOTE	This assertion is tested under <a href='#AS09.01'>AS09.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.27",
        level: "1",
        requirement:
          "Modification of PSPs by unauthorized operators shall be prohibited. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.27.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that modification of PSPs by unauthorized operators shall be prohibited. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.27.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that modification of PSPs by unauthorized operators shall be prohibited. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.27.02",
        level: "1",
        requirement:
          "The tester shall assume an unauthorized role and attempt to modify PSPs stored within the module and verify that this attempt fails. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.28",
        level: "1",
        requirement:
          "A module shall provide methods to zeroise all unprotected SSPs and key components within the module. <br> NOTE 2 Temporarily stored SSPs and other stored values owned by the module should be zeroised when they are no longer needed for future use. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.28.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the following zeroisation information for SSPs: <br> <ol type=1>   <li> Zeroisation techniques <br>   </li>   <li> Restrictions when unprotected SSPs can be zeroised <br>   </li>   <li> Unprotected SSPs that are zeroised <br>   </li>   <li> Unprotected SSPs that are not zeroised and rationale <br>   </li>   <li> Rationale explaining how the zeroisation technique is performed in a time that is not sufficient to compromise unprotected SSPs <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.28.02",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the zeroisation method(s) are employed such that unprotected SSPs within the module cannot be obtained by an attacker. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.28.03",
        level: "1",
        requirement:
          "If SSPs are zeroised procedurally while under the control of the operator (i.e., present to observe the method has completed successfully or controlled via a remote management session), vendor documentation and the module security policy must specify how the methods shall be performed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.28.01",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "The tester shall verify the vendor documentation includes the information specified in <a href='#VE09.30.01'>VE09.30.01</a>. The tester shall verify the accuracy of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.28.02",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "The tester shall verify which SSPs are present in the module and initiate the zeroise command. Following the completion of the zeroise command, the tester shall attempt to perform cryptographic operations using each of the unprotected SSPs that were stored in the module. The tester shall verify that each unprotected SSP cannot be accessed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.28.03",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "The tester shall initiate zeroisation and verify the SSP destruction method is performed in a time that is not sufficient to compromise unprotected SSPs. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.28.04",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "The tester shall verify that all unprotected SSPs that are not zeroised by the zeroise command are either 1) encrypted using an approved algorithm, or 2) physically or logically protected within an embedded validated cryptographic module (validated as conforming to ISO/IEC 19790). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.28.05",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "If procedural zeroisation methods are used, the tester shall verify that the vendor provided documentation, including the security policy, specifies that the procedure must be performed under the control of the operator. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.28.06",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "If the procedural zeroisation method is not under the direct control of the operator, the tester shall verify the accuracy of any rationale provided by the vendor as to why unprotected SSPs within the module cannot be obtained by an attacker. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.29",
        level: "1",
        requirement:
          "A zeroised SSP shall not be retrievable or reusable. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.29.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify how a zeroised SSP cannot be retrievable or reusable. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.29.01",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "The tester shall verify that the vendor provides documentation specifies how a zeroised SSP cannot be retrievable or reusable. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.29.02",
        level: "1",
        IGs: ["9.7.A"],
        Anchors: ["h.111kx3o"],
        requirement:
          "The tester shall verify the accuracy of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br> NOTE 1 Zeroisation of protected PSPs, encrypted CSPs, or CSPs otherwise physically or logically protected within an additional embedded validated module (meeting the requirements of this document) is not required. <br> </ol>NOTE 2 SSPs need not meet these zeroisation requirements if they are used exclusively to reveal plaintext data to processes that are authentication proxies (e.g. a CSP that is a module initialization key). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.30",
        level: "2",
        requirement:
          "The cryptographic module shall perform the zeroisation of unprotected SSPs (e.g. overwriting with all zeros or all ones or with random data). <br> NOTE 1 This assertion is tested in <a href='#AS09.28'>AS09.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.31",
        level: "2",
        requirement:
          "Zeroisation shall exclude the overwriting of an unprotected SSP with another unprotected SSP. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.31.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify that the zeroisation excludes the overwriting of an unprotected SSP with another unprotected SSP. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.31.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor provided documentation specifies that the zeroisation excludes the overwriting of an unprotected SSP with another unprotected SSP. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.32",
        level: "2",
        requirement:
          "Temporary SSPs shall be zeroised when they are no longer needed. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.32.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify that temporary SSPs are zeroised when they are no longer needed. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.32.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor provides documentation specifies that temporary SSPs are zeroised when they are no longer needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.33",
        level: "2",
        requirement:
          "The module shall provide an output status indication when the zeroisation is complete. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.33.01",
        level: "2",
        requirement:
          "The vendor documentation shall specify that the module provides an output status indication when the zeroisation is complete {<a href='#AS03.11'>AS03.11</a>}. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.33.01",
        level: "2",
        IGs: ["9.7.B"],
        Anchors: ["h.206ipza"],
        requirement:
          "The tester shall verify that the vendor provides documentation that specifies that the module provides an output status indication when the zeroisation is complete. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.33.02",
        level: "2",
        IGs: ["9.7.B"],
        Anchors: ["h.206ipza"],
        requirement:
          "The tester shall perform zeroisation and verify the status output indicator. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.34",
        level: "4",
        requirement:
          "The following requirements (ISO/IEC 19790:2012 <a href='#AS09.35'>AS09.35</a> to <a href='#AS09.37'>AS09.37</a>} shall be met. <br> NOTE	This assertion is tested under <a href='#AS09.35'>AS09.35</a> to <a href='#AS09.37'>AS09.37</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.35",
        level: "4",
        requirement:
          "Zeroisation shall be immediate and non-interruptible {and shall occur in a sufficiently small time period so as to prevent the recovery of the sensitive data between the time zeroisation is initiated and the actual zeroisation completed and (<a href='#AS09.37'>AS09.37</a> shall be met}}. <br> NOTE	This assertion is tested in <a href='#AS09.36'>AS09.36</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.36",
        level: "4",
        requirement:
          "(Zeroisation shall be immediate and non-interruptible} and shall occur in a sufficiently small time period so as to prevent the recovery of the sensitive data between the time zeroisation is initiated and the actual zeroisation completed and (<a href='#AS09.37'>AS09.37</a> shall be met}. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.36.01",
        level: "4",
        requirement:
          "The vendor shall provide documentation that the module zeroisation is immediate and non-interruptible and occurs in a sufficiently small time period so as to prevent the recovery of the sensitive data between the time zeroisation is initiated and the actual zeroisation completed. <br> Required Test Procedures <br> TE09. 36.01: The tester shall verify that the vendor provides documentation that the module zeroisation is immediate and non-interruptible and occurs in a sufficiently small time period so as to prevent the recovery of the sensitive data between the time zeroisation is initiated and the actual zeroisation completed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.36.02",
        level: "4",
        requirement:
          "The tester shall perform the module zeroisation. The test shall attempt to interrupt the zeroisation process to prevent its completion in whole or part. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS09.37",
        level: "4",
        requirement:
          "All SSPs shall be zeroised whether plaintext or cryptographically protected, such that the module is returned to the factory state. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE09.37.01",
        level: "4",
        requirement:
          "The vendor shall provide documentation that all SSPs are zeroised whether plaintext or cryptographically protected, such that the module is returned to the factory state. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.37.01",
        level: "4",
        requirement:
          "The tester shall verify that the vendor provides documentation that all SSPs are zeroised whether plaintext or cryptographically protected, such that the module is returned to the factory state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE09.37.02",
        level: "4",
        requirement:
          "The tester shall perform the module zeroisation. The tester shall verify that the module has returned to the factory state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "10",
    dtrs: [
      {
        dtrId: "AS10.01",
        level: "1",
        requirement:
          "All self-tests shall be performed, {and determination of pass or fail shall be made by the module, without external controls, externally provided input test vectors, expected output results, or operator intervention or whether the module will operate in an approved or non-approved mode}. <br> NOTE This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.02",
        level: "1",
        requirement:
          "{All self-tests shall be performed,} and determination of pass or fail shall be made by the module, without external controls, externally provided input test vectors, expected output results, or operator intervention or whether the module will operate in an approved or non-approved mode. <br> NOTE The intention of this assertion is that the determination of pass or fail will be made by the module, without external controls, primarily for pre-operational self-tests and (conditional) cryptographic algorithm self-test. It is known that a software/firmware load test into a validated module involves the software or firmware that is loaded from an external source, and that a manual entry test involves SSPs or key components manually entered by a human operator; however, the essence is the same. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.03",
        level: "1",
        requirement:
          "</ol>The pre-operational self-tests shall be performed and passed successfully prior to the module providing any data output via the data output interface. <br> NOTE	This assertion is tested as part of <a href='#AS10.15'>AS10.15</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.04",
        level: "1",
        requirement:
          "Conditional self-tests shall be performed when an applicable security function or process is invoked (i.e. security functions for which self-tests are required). <br> NOTE	This assertion is tested as part of <a href='#AS10.25'>AS10.25</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.05",
        level: "1",
        requirement:
          "All self-tests identified in underlying algorithmic standards ({ISO/IEC 19790:2012} Annex C to Annex E) shall be implemented as applicable within the cryptographic module. <br> NOTE	This assertion is tested as part of <a href='#AS10.06'>AS10.06</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.06",
        level: "1",
        requirement:
          "All self-tests identified in addition or in lieu of those specified in the underlying algorithmic standards ({ISO/IEC 19790:2012} Annex C to Annex E) shall be implemented as specified in {ISO/IEC 19790:2012} Annex C to Annex E for each approved security function, SSP establishment method and authentication mechanism. <br> NOTE	This assertion is tested as part of <a href='#AS10.01'>AS10.01</a> to <a href='#AS10.04'>AS10.04</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.07",
        level: "1",
        requirement:
          "If a cryptographic module fails a self-test, the module shall enter an error state {and shall output an error indicator as specified in {ISO/IEC 19790:2012) 7.3.3). <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.07.01",
        level: "1",
        requirement:
          "For each error condition, the vendor documentation shall provide the condition name, description of the condition, the events that can produce the condition, and the actions necessary to clear the condition and resume normal operation. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.07.01",
        level: "1",
        requirement:
          "The tester shall verify the list of self-tests to include the following: <br> <ol type=1>   <li> pre-operational self-tests: <br>   </li>     <ol type=a>       <li> pre-operational software/firmware integrity test; <br>       </li>       <li> pre-operational bypass test; <br>       </li>       <li> pre-operational critical functions test; <br>       </li>     </ol>   <li> conditional self-tests: <br>   </li>     <ol type=a>       <li> conditional cryptographic algorithm test; <br>       </li>       <li> conditional pair-wise consistency test; <br>       </li>       <li> conditional software/firmware load test; <br>       </li>       <li> conditional manual entry test; <br>       </li>       <li> conditional bypass test; <br>       </li>       <li> conditional critical functions test. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.07.02",
        level: "1",
        requirement:
          "The tester shall check that the information provided above is specified for each error condition. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.07.03",
        level: "1",
        requirement:
          "The tester shall cause each error condition to occur and shall attempt to clear the error condition. The tester shall verify that actions necessary to clear the error condition are consistent with the vendor documentation. If the tester cannot cause each error condition to occur, the tester shall verify the code listing and or design documentation whether the actions necessary to clear each error condition are consistent with the descriptions in the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.07.04",
        level: "1",
        requirement:
          "The tester shall verify that all self-tests are performed regardless if the cryptographic module operates in an approved mode or non-approved mode. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.07.05",
        level: "1",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that determination of pass or fail of each self-test is made by the module, without external controls, externally provided input test vectors, expected output results, or operator intervention. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.08",
        level: "1",
        requirement:
          "(If a cryptographic module fails a self-test, the module shall enter an error state} and shall output an error indicator as specified in (ISO/IEC 19790:2012} 7.3.3. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.08.01",
        level: "1",
        requirement:
          "The vendor shall document all error states associated with each self-test and shall indicate for each error state the expected error indicator. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.08.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor documentation, check that it lists every error state that the module enters upon failure of a self-test, and indicates the error indicator associated with each error state. The tester shall compare the list of error states to those defined in the finite state model (see <a href='#AS11.10'>AS11.10</a>) to verify that they agree. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.08.02",
        level: "1",
        requirement:
          "By inspecting the vendor documentation that specifies how each self-test handles errors, the tester shall verify that: <br> <ol type=1>   <li> the module enters an error state upon failing a self-test; <br>   </li>   <li> the error state is consistent with the documentation and the finite state model; <br>   </li>   <li> the module outputs an error indicator; <br>   </li>   <li> the error indicator is consistent with the documented error indicator. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.08.03",
        level: "1",
        requirement:
          "The tester shall run each self-test and cause the module to enter every error state. The tester shall compare the observed error indicator with the indicator specified in the vendor documentation. If they are not the same, this test is failed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.09",
        level: "1",
        requirement:
          "The cryptographic module shall not perform any cryptographic operations or output control and data via the control and data output interface while in an error state. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.09.01",
        level: "1",
        requirement:
          "The vendor documentation requirements are specified under <a href='#VE03.07.01'>VE03.07.01</a>, <a href='#VE03.07.02'>VE03.07.02</a>, <a href='#VE03.10.01'>VE03.10.01</a>, and <a href='#VE03.10.02'>VE03.10.02</a>. The vendor design also shall ensure that cryptographic operations cannot be performed while the module is in the error state. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.09.01",
        level: "1",
        requirement:
          "The tester shall verify that the inhibition of control and data output was performed under <a href='#TE03.07.01'>TE03.07.01</a>, <a href='#TE03.07.02'>TE03.07.02</a>, <a href='#TE03.10.01'>TE03.10.01</a>, <a href='#TE03.10.02'>TE03.10.02</a>, and <a href='#TE03.10.05'>TE03.10.05</a>. The results of the verification shall indicate that: <br> <ol type=1>   <li> the vendor documentation shows that all control and data output via the control and data output interface is inhibited whenever the module is in an error state; <br>   </li>   <li> the module inhibits all control and data output when the module is in an error state. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.09.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies that cryptographic functions are inhibited while the module is in an error state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.09.03",
        level: "1",
        requirement:
          "The tester shall cause the module to enter the error state and verify that any cryptographic operations that the tester attempts to initiate are prevented. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.10",
        level: "1",
        requirement:
          "The cryptographic module shall not utilize any functionality that relies upon a function or algorithm that failed a self-test until the relevant self-test has been repeated and successfully passed. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.10.01",
        level: "1",
        requirement:
          "The vendor shall provide design documentation that the cryptographic module cannot utilize any functionality that relies upon a function or algorithm that failed a self-test until the relevant self-test has been repeated and successfully passed. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.10.01",
        level: "1",
        requirement:
          "The tester shall cause an error in a function or algorithm that failed a self-test and initiate a functionality that utilize the function or algorithm and verify that the module cannot utilize this functionality. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.10.02",
        level: "1",
        requirement:
          "The tester shall run each self-test and cause the module to enter every error state or a degraded operation. The tester shall exercise the cryptographic module, and verify that the functionality cannot be utilized until the relevant self-test has been repeated and successfully passed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.11",
        level: "1",
        requirement:
          "If a module does not output an error status upon failure of a module self-test, the operator of the module shall be able to determine if the module has entered an error state implicitly through an unambiguous procedure documented in the security policy ({ISO/IEC 19790:2012} Annex B). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.11.01",
        level: "1",
        requirement:
          "If the module does not output an error status upon failure of the module self-test, the vendor provided non-proprietary security policy shall describe unambiguously the procedure to determine if the cryptographic module has entered an error state. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.11.01",
        level: "1",
        requirement:
          "The tester shall run each self-test and cause the module to enter every error state. The tester shall verify that the module has entered the error state implicitly through the procedure documented in the non-proprietary security policy. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.12",
        level: "3",
        requirement:
          "The module shall maintain an error log that is accessible by an authorized operator of the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.12.01",
        level: "3",
        requirement:
          "The vendor documentation shall specify the error logging functionality of the module including types of recorded information in the error log (e.g. which self-test has failed, when the error occurred). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.12.02",
        level: "3",
        requirement:
          "The vendor documentation shall describe the mechanism to maintain the integrity of the error log. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.12.01",
        level: "3",
        requirement:
          "The tester shall verify from the vendor documentation that an unauthorized operator cannot access to the error log. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.12.02",
        level: "3",
        requirement:
          "The tester shall verify from the vendor documentation that the error logging functionality provides information, at a minimum, of the most recent error event. <br> NOTE	This TE is to cover assertion <a href='#AS10.13'>AS10.13</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.12.03",
        level: "3",
        requirement:
          "The tester shall cause the cryptographic module to enter an error state and verify that the module generates the error log, at a minimum, for the most recent error event. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.12.04",
        level: "3",
        requirement:
          "The tester shall access the error log without assuming any authenticated role supported by the cryptographic module. If the error log can be accessed, this assertion fails. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.12.05",
        level: "3",
        requirement:
          "The tester shall exercise the cryptographic module and verify that the error log is protected against unauthorized modification and substitution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.13",
        level: "3",
        requirement:
          "The error log shall provide information, at a minimum, of the most recent error event (i.e. which self-test failed). <br> NOTE	This assertion is tested as part of <a href='#AS10.12'>AS10.12</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.14",
        level: "1",
        requirement:
          "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.10 shall be provided. <br> NOTE	This assertion is tested as part of ASA.01. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.15",
        level: "1",
        requirement:
          "The pre-operational tests shall be performed and passed successfully by a cryptographic module between the time a cryptographic module is powered on or instantiated (after being powered off, reset, rebooted, cold-start, power interruption, etc.) and before the module transitions to the operational state. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.15.01",
        level: "1",
        requirement:
          "The vendor documentation shall provide the information for each of the pre-operational self-tests. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.15.02",
        level: "1",
        requirement:
          "The vendor shall provide the sequence of pre-operational self-tests between the time the module is powered on or instantiated and before the module transitions to the operational state. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.15.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies each pre-operational self-test. The tester shall verify that the pre-operational self-tests are performed as specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.15.02",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify each preoperational test is performed and passed successfully between the time a cryptographic module is powered on or instantiated and before the module transitions to the operational state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.16",
        level: "1",
        requirement:
          "A cryptographic module shall perform the following pre-operational tests, as applicable: <br> � pre-operational software/firmware integrity test; <br> � pre-operational bypass test; <br> � pre-operational critical functions test. <br> NOTE	This assertion is tested as part of <a href='#AS10.17'>AS10.17</a> to <a href='#AS10.24'>AS10.24</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.17",
        level: "1",
        requirement:
          "All software and firmware components within the cryptographic boundary shall be verified using an approved integrity technique or EDC satisfying the requirements defined in (ISO/IEC 19790:2012) 7.5. <br> </ol>NOTE	This assertion is not separately tested. Tested as part of <a href='#AS05.05'>AS05.05</a> to <a href='#AS05.23'>AS05.23</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.18",
        level: "1",
        requirement:
          "If the verification fails, the pre-operational software/firmware integrity test shall fail. <br> NOTE	This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.19",
        level: "1",
        requirement:
          "If a hardware module does not contain either software or firmware, the module shall, at a minimum, implement one cryptographic algorithm self-test as specified in (ISO/IEC 19790:2012) 7.10.3.2 as a pre-operational self-test. <br> </ol>NOTE	This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.20",
        level: "1",
        requirement:
          "A cryptographic algorithm that is used to perform the approved integrity technique for the preoperational software/firmware test shall first pass the cryptographic algorithm self-test specified in (ISO/IEC 19790:2012) 7.10.3.2. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.20.01",
        level: "1",
        requirement:
          "The vendor documentation requirement is specified under <a href='#VE10.15.02'>VE10.15.02</a>. Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.20.01",
        level: "1",
        requirement:
          "By checking the codes and/or design documentation, the tester shall verify that the cryptographic algorithm test used to perform the approved integrity technique is passed before the preoperational software/firmware integrity test starts. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.21",
        level: "1",
        requirement:
          "If a cryptographic module implements a bypass capability, then the module shall ensure the correct operation of the logic governing activation of the bypass capability by exercising that logic. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.21.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify how the cryptographic module ensures the correct operation of the logic governing activation of the bypass capability. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.21.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation and by inspection of the module that the logic governing activation of the bypass capability is implemented as specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.21.02",
        level: "1",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that the preoperational bypass test is implemented which exercises the logic governing activation of the bypass capability. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.21.03",
        level: "1",
        requirement:
          "The tester shall cause each error condition of the pre-operational bypass test to occur and shall verify that the inhibition of output was performed under <a href='#TE03.07.01'>TE03.07.01</a> to <a href='#TE03.07.05'>TE03.07.05</a> and <a href='#TE03.10.01'>TE03.10.01</a> to <a href='#TE03.10.05'>TE03.10.05</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.21.04",
        level: "1",
        requirement:
          "The tester shall run the pre-operational bypass test and shall verify that any functionality relies on the logic governing activation of the bypass capability cannot be utilized under <a href='#TE10.10.01'>TE10.10.01</a> and <a href='#TE10.10.02'>TE10.10.02</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.22",
        level: "1",
        requirement:
          "The module shall also verify the data path by <br> � setting the bypass switch to provide cryptographic processing and verify that data transferred through the bypass mechanism is cryptographically processed, and <br> � setting the bypass switch to not provide cryptographic processing and verify that data transferred through the bypass mechanism is not cryptographically processed. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.22.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify how to set the bypass switch to provide cryptographic processing. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.22.02",
        level: "1",
        requirement:
          "The vendor documentation shall describe how the bypass mechanism is designed to enforce the data transfer of cryptographically processed data through the data path by setting the bypass switch to provide cryptographic processing. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.22.03",
        level: "1",
        requirement:
          "The vendor documentation shall specify how to set the bypass switch to not provide cryptographic processing. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.22.04",
        level: "1",
        requirement:
          "The vendor documentation shall describe how the bypass mechanism is designed to enforce the data transfer of not cryptographically processed data through the data path by setting the bypass switch to not provide cryptographic processing. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.22.01",
        level: "1",
        requirement:
          "The tester shall verify by inspection that the module does not provide bypass capability by setting the bypass switch to provide cryptographic processing. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.22.02",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the implementation of bypass mechanism is consistent with the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.22.03",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the module performs the pre-operational bypass test which verifies that the data transferred through the data path is cryptographically processed by setting the bypass switch to provide cryptographic processing. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.22.04",
        level: "1",
        requirement:
          "The tester shall verify by inspection that the module provides bypass capability by setting the bypass switch to provide cryptographic processing by setting the bypass switch not to provide cryptographic processing. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.22.05",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the module performs the pre-operational bypass test which verifies that the data transferred through the data path is not cryptographically processed by setting the bypass switch to not provide cryptographic processing. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.23",
        level: "1",
        requirement:
          "There may be other security functions critical to the secure operation of a cryptographic module that shall be tested as a pre-operational test. <br> NOTE	This assertion is tested as part of <a href='#AS10.24'>AS10.24</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.24",
        level: "1",
        requirement:
          "Documentation shall specify the pre-operational critical functions that are tested. <br> NOTE	Critical functions are defined as those functions that, upon failure, could lead to the disclosure of CSPs. Examples of critical functions include but not limited to random bit generation, operation of the cryptographic algorithm, and cryptographic bypass. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.24.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation of all critical functions. For each critical function, the vendor shall indicate: <br> <ol type=1>   <li> the purpose of the critical function; <br>   </li>   <li> which critical functions are tested by which pre-operational self-tests; <br>   </li>   <li> which critical functions are tested by which conditional self-tests. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.24.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor provided documentation of the critical functions and the self-tests that are designed to test them. This documentation shall include the following: <br> <ol type=1>   <li> identification and description of all critical functions; <br>   </li>   <li> identification of at least one self-test for every critical function. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.24.02",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the module performs the specified self-tests for each critical function. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.25",
        level: "1",
        requirement:
          "Conditional self-tests shall be performed by a cryptographic module when the conditions specified for the following tests occur: Cryptographic Algorithm Self-Test, Pair-Wise Consistency Test, Software/Firmware Load Test, Manual Entry Test, Conditional Bypass Test and Conditional Critical Functions Test. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.25.01",
        level: "1",
        requirement:
          "The vendor documentation shall provide the information on the conditional self-tests. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.25.01",
        level: "1",
        IGs: ["10.3.A, 10.3.B"],
        Anchors: ["h.2zbgiuw, h.xvir7l"],
        requirement:
          "The tester shall verify that the vendor documentation specifies conditional self-tests. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.25.02",
        level: "1",
        IGs: ["10.3.A, 10.3.B"],
        Anchors: ["h.2zbgiuw, h.xvir7l"],
        requirement:
          "The tester shall verify that the conditional self-tests are performed as specified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.26",
        level: "1",
        requirement:
          "A cryptographic algorithm test shall be conducted for all cryptographic functions (e.g. security functions, SSP establishment methods and authentication) of each approved cryptographic algorithm implemented in the cryptographic module as specified in {ISO/IEC 19790:2012} Annex C to Annex E. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS10.27'>AS10.27</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.27",
        level: "1",
        requirement:
          "The conditional test shall be performed prior to the first operational use of the cryptographic algorithm. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.27.01",
        level: "1",
        requirement:
          "The vendor documentation shall provide the specification of the conditional cryptographic algorithm self-tests. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.27.02",
        level: "1",
        requirement:
          "The vendor shall provide documentation that provides rationale stating how each conditional cryptographic algorithm self-test is performed prior to the first operational use of the cryptographic algorithm. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.27.03",
        level: "1",
        requirement:
          "The vendor shall specify whether a known answer test, a comparison test, and/or fault-detection test is used to test the module�s cryptographic algorithm. If a comparison test and/or a fault-detection test are used, the vendor shall document this fact. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.27.01",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "The tester shall verify by inspection of the module or from the vendor documentation that the module conducts conditional cryptographic algorithm self-test prior to the first operational use of each cryptographic algorithm. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.28",
        level: "1",
        requirement:
          "If the calculated output does not equal the known answer, the cryptographic algorithm known-answer self-test shall fail. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.28.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the method used to compare the calculated output with the known answer. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.28.02",
        level: "1",
        requirement:
          "The documentation shall show the transition into an error state and output of an error indicator when the two outputs are not equal. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.28.01",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "The tester shall verify that the documentation is consistent with the implementation of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.28.02",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "This is tested under <a href='#TE10.07.02'>TE10.07.02</a>, <a href='#TE10.08.01'>TE10.08.01</a>, <a href='#TE10.08.02'>TE10.08.02</a>, and <a href='#TE10.08.03'>TE10.08.03</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.29",
        level: "1",
        requirement:
          "An algorithm self-test shall at a minimum use the smallest approved key length, modulus size, DSA prime, or curves as appropriate that is supported by the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.29.01",
        level: "1",
        requirement:
          "The vendor documentation shall provide the specification of each conditional cryptographic algorithm self-test that is implemented by the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.29.01",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that each conditional cryptographic algorithm test implements, at a minimum, the smallest approved key length, modulus size, DSA prime, or curves as appropriate that are supported by the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.30",
        level: "1",
        requirement:
          "If an algorithm specifies multiple modes (e.g. ECB, CBC, etc), at a minimum, one mode shall be selected for the self-test that is supported by the module or as specified by the validation authority. <br> NOTE	This assertion is tested as part of <a href='#AS10.29'>AS10.29</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.31",
        level: "1",
        requirement:
          "Examples of known-answer tests: One-way functions: Input test vector(s) generate output which shall be identical to expected output [e.g. hashing, keyed hashes, message authentication, RBG (fixed entropy vector), SSP agreement]. <br> </ol>NOTE	This assertion is tested as part of <a href='#AS10.28'>AS10.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.32",
        level: "1",
        requirement:
          "Examples of known-answer tests: Reversible functions: Both the forward and reverse function shall be self-tested (e.g. symmetric key encryption and decryption, SSP transport encryption and decryption, digital signature generation and verification) <br> NOTE	This assertion is tested as part of <a href='#AS10.28'>AS10.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.33",
        level: "1",
        requirement:
          "A comparison test compares the output of two or more independent cryptographic algorithm implementations, if the outputs are not equal, the cryptographic algorithm comparison self-test shall fail. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.33.01",
        level: "1",
        requirement:
          "The vendor shall describe the implemented cryptographic algorithm comparison self-test. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.33.02",
        level: "1",
        requirement:
          "Vendor documentation requirement is specified under <a href='#VE10.27.03'>VE10.27.03</a> for the vendor requirement. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.33.01",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "The tester shall verify whether the documentation of the comparison test includes: <br> <ol type=1>   <li> use of two or more independent cryptographic algorithm implementations; <br>   </li>   <li> continual comparison of the outputs of the algorithm implementation; <br>   </li>   <li> transition into an error state and output of an error indicator when the two outputs are not equal. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.33.02",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the module implements the documented steps for performing the comparison test. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.34",
        level: "1",
        requirement:
          "A fault-detection test involves the implementation of fault detection mechanisms integrated within the cryptographic algorithm implementation, if a fault is detected, the cryptographic algorithm fault-detection self-test shall fail. <br> EXAMPLE	The fault-detection test of the RBG will cover an error of the entropy source being correctly handled inside the implementation of the RBG. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.34.01",
        level: "1",
        requirement:
          "The vendor shall specify whether a fault-detection test is used to test the module�s cryptographic algorithm to complement either a known-answer test or a comparison test. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.34.01",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "The tester shall verify the documentation of the fault-detection test includes: <br> <ol type=1>   <li> description of each error condition in the cryptographic algorithm specification/implementation; <br>   </li>   <li> specification of the corresponding (internal) error indicator for each error condition; <br> </ol>  </li>   <li> rationale stating the each error condition is tested in the fault-detection test. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.34.02",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "The tester shall verify that the documentation is consistent with the implementation of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.34.03",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "This is tested under <a href='#TE10.07.02'>TE10.07.02</a>, <a href='#TE10.07.03'>TE10.07.03</a>, <a href='#TE10.09.02'>TE10.09.02</a>, <a href='#TE10.09.03'>TE10.09.03</a>, <a href='#TE10.10.01'>TE10.10.01</a>, and <a href='#TE10.10.02'>TE10.10.02</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.35",
        level: "1",
        requirement:
          "If a cryptographic module generates public or private key pairs, a pair-wise consistency test shall be performed for every generated public and private key pair as specified in {ISO/IEC 19790:2012} Annex C to Annex E for the applicable cryptographic algorithm. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.35.01",
        level: "1",
        requirement:
          "If public or private key pairs are used to perform an approved key transport, or an asymmetric cipher, the vendor documentation shall describe the test for pair-wise consistency. This <br> test consists of applying the public key to a plaintext value or to an encoded message. The resulting ciphertext shall be compared to the original plaintext to verify that they differ. <br> �	If the two values are equal, then the cryptographic module shall enter an error state and output an <br> error indicator via the status interface. <br> � If the two values differ, then the private key shall be applied to the ciphertext. If the result is not equal to the original plaintext then pair-wise consistency test shall fail. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.35.02",
        level: "1",
        requirement:
          "If public or private key pairs are to be used only for the calculation and/or verification of digital signatures, the vendor documentation shall describe the test for pair-wise consistency by calculation and verification of a signature. If the signature cannot be verified, the pair-wise consistency test shall fail. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.35.03",
        level: "1",
        requirement:
          "If public or private key pairs are used to perform a SSP agreement, the vendor documentation shall describe the test for pair-wise consistency. The vendor documentation shall identify the prerequisite algorithms of the SSP agreement. This test shall consists of applying the key pair to see if it passes the test for pair-wise consistency by exercising the prerequisite algorithms implemented. <br> EXAMPLE	The Diffie-Hellman key agreement uses the finite field cryptography primitive common to Digital <br> Signature Algorithm. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.35.01",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "If public or private key pairs are to be used to perform an approved key transport, or an asymmetric cipher, the tester shall verify that the implementation of the pair-wise consistency test, as defined in <a href='#VE10.35.01'>VE10.35.01</a>, is consistent with the vendor documentation by checking the code and/or design documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.35.02",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "If public or private key pairs are used for the calculation and/or verification of digital signatures, then the tester shall verify that the implementation of the pair-wise consistency test as defined in <a href='#VE10.35.02'>VE10.35.02</a> is consistent with the vendor documentation by checking the code and/or design documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.35.03",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "If public or private key pairs are used to perform a SSP agreement, then the tester shall verify that the implementation of the pair-wise consistency test as defined in <a href='#VE10.35.03'>VE10.35.03</a> is consistent with the vendor documentation by checking the code and/or design documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.35.04",
        level: "1",
        IGs: ["10.3.A"],
        Anchors: ["h.2zbgiuw"],
        requirement:
          "If possible, the tester shall modify one of the keys of the key pairs before the pair-wise consistency test is performed. The test is failed if the pair-wise consistency test does not detect the modification. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.36",
        level: "1",
        requirement:
          "If a cryptographic module has the capability of loading software or firmware from an external source, then the following requirements in addition to those in {ISO/IEC 19790:2012} 7.4.3.4 shall be performed. <br> NOTE	This assertion is not tested separately. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.37",
        level: "1",
        requirement:
          "The cryptographic module shall implement an approved authentication technique to verify the validity of the software or firmware that is loaded. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.37.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the approved authentication technique used to protect the integrity of all externally loaded software and firmware components. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.37.02",
        level: "1",
        requirement:
          "If the module implements an approved authentication technique, the vendor shall provide a validation certificate as specified in <a href='#VE02.20.01'>VE02.20.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.37.03",
        level: "1",
        requirement:
          "The vendor shall provide documentation specifying how the reference authentication key is loaded independently in the module prior to the software or firmware loading. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.37.04",
        level: "1",
        requirement:
          "The vendor documentation shall describe the mechanisms to ensure that the loaded software or firmware cannot be used if the software/firmware load test fails. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.01",
        level: "1",
        requirement:
          "The tester shall determine from the vendor supplied documentation which approved authentication technique is used for the software/firmware load test. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.02",
        level: "1",
        requirement:
          "The tester shall verify that if an approved authentication technique is implemented, the vendor has provided a validation certificate as specified in <a href='#VE02.20.01'>VE02.20.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.03",
        level: "1",
        requirement:
          "If the module implements an approved authentication technique for the software/firmware load test, the tester shall verify that the vendor documentation of the software/firmware load test includes: <br> <ol type=1>   <li> specification of the approved authentication technique implemented; <br>   </li>   <li> identification of software and firmware that is protected using the approved authentication technique; <br>   </li>   <li> calculation of the approved authentication technique when the software and firmware is loaded; <br>   </li>   <li> verification of the approved authentication technique when the load test is initiated; <br>   </li>   <li> failure of the self-test upon failure of the approved authentication technique verification. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.04",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the implementation of the software/firmware load test is consistent with <a href='#TE10.37.01'>TE10.37.01</a>, <a href='#TE10.37.02'>TE10.37.02</a>, and <a href='#TE10.37.03'>TE10.37.03</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.05",
        level: "1",
        requirement:
          "The tester shall test the module by modifying the software or firmware to be loaded, or the implemented authentication mechanism and initiating the self-test, and observing the output from the status output interface. If no indicator is output that indicates that the software/firmware load test failed, the assertion fails. If it is not possible for the tester to modify the software or firmware to be loaded, or the implemented authentication mechanism, then the vendor shall provide a rationale to the tester why this test cannot be performed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.06",
        level: "1",
        requirement:
          "The tester shall exercise the cryptographic module, with modifying the software or firmware to be loaded, modifying the reference authentication key, or attempting to bypass the implemented authentication mechanism, and shall initiate the software/firmware load test. After the self-test fails, the tester shall verify that the loaded software or firmware cannot be used and that the module�s versioning information is unchanged. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.07",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the reference authentication key is loaded independently from the software or firmware loading. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.08",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the software/firmware load test fails without loading the reference authentication key prior to the software or firmware loading. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.37.09",
        level: "1",
        requirement:
          "The tester shall exercise the cryptographic module, without loading the reference authentication key in advance, and shall initiate the software/firmware load test. If the software/firmware load test passes, the assertion fails. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.38",
        level: "1",
        requirement:
          "The reference authentication key shall be loaded independently in the module prior to the software or firmware loading. <br> NOTE	This assertion is tested as part of <a href='#AS10.37'>AS10.37</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.39",
        level: "1",
        requirement:
          "The applied approved authentication technique shall be successfully verified {or the software/firmware load test shall fail}. <br> NOTE	This assertion is tested as part of <a href='#AS10.37'>AS10.37</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.40",
        level: "1",
        requirement:
          "{The applied approved authentication technique shall be successfully verified} or the software/firmware load test shall fail. <br> NOTE	This assertion is tested as part of <a href='#AS10.37'>AS10.37</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.41",
        level: "1",
        requirement:
          "Loaded software or firmware shall not be used if the software/firmware load test fails. <br> NOTE	This assertion is tested as part of <a href='#AS10.37'>AS10.37</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.42",
        level: "1",
        requirement:
          "If SSPs or key components are manually entered directly into a cryptographic module or if error on the part of the human operator could result in the incorrect entry of the intended value, then the following manual entry tests shall be performed. <br> NOTE	This assertion is not separately tested. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.43",
        level: "1",
        requirement:
          "The SSP or key components shall have an error detection code (EDC) applied, {or shall be entered using duplicate entries}. <br> NOTE	This assertion is tested as part of <a href='#AS10.46'>AS10.46</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.44",
        level: "1",
        requirement:
          "{The SSP or key components shall have an error detection code (EDC) applied,} or shall be entered using duplicate entries. <br> NOTE	This assertion is tested as part of <a href='#AS10.46'>AS10.46</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.45",
        level: "1",
        requirement:
          "If an EDC is used, the EDC shall be at least 16 bits in length. <br> NOTE	This assertion is tested as part of <a href='#AS10.46'>AS10.46</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.46",
        level: "1",
        requirement:
          "If the EDC cannot be verified, or the duplicate entries do not match, the test shall fail. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.46.01",
        level: "1",
        requirement:
          "The vendor shall document the manual entry test. Depending on whether error detection codes or duplicate entries of SSPs or key components are used, the manual entry test shall include the following: <br> <ol type=1>   <li>	error detection code (EDC): <br>   </li>     <ol type=a>       <li> description of EDC calculation algorithm; <br>       </li>       <li> description of verification process; <br>       </li>       <li> expected outputs for success or failure of test; <br>       </li>     </ol>   <li> duplicate entries: <br>   </li>     <ol type=a>       <li> description of verification process; <br>       </li>       <li> expected outputs for success or failure of test. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.46.02",
        level: "1",
        requirement:
          "If the EDC is associated with the SSP or key components, then the vendor documentation <br> that describes the format of the SSP or key components (see <a href='#AS09.03'>AS09.03</a>) shall include fields for EDC. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.46.01",
        level: "1",
        requirement:
          "The tester shall verify from the vendor documentation which method is used for the manual entry test (error detection codes or duplicate entries). Based on the method used, the tester shall check the vendor documentation, code, and/or design documentation that specifies the implementation of the manual entry test to verify whether the following information is included: <br> <ol type=1>   <li>	error detection codes: <br>   </li>     <ol type=a>       <li> SSP or key component format for all manually-entered SSPs or key components, including fields for EDC (see <a href='#AS09.03'>AS09.03</a>); <br>       </li>       <li> description of EDC algorithm; <br>       </li>       <li> description of EDC verification process; <br>       </li>       <li> all expected outputs for success or failure of the test; <br>       </li>     </ol>   <li>	duplicate entries of SSPs or key components: <br>   </li>     <ol type=a>       <li> duplicate entries for all manually-entered SSPs and key components; <br>       </li>       <li> description of duplicate entry verification process; <br>       </li>       <li> all expected outputs for success or failure of the test. <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.46.02",
        level: "1",
        requirement:
          "For manual entry tests using an EDC, the tester shall verify by inspection and from the vendor documentation that the format of the SSP or key components include fields for EDC and that the EDC is at least 16 bits in length. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.46.03",
        level: "1",
        requirement:
          "For manual entry tests using an EDC, the tester shall perform the following tests. <br> <ol type=1>   <li> The tester shall enter every manually entered SSP and verify that the procedure used to enter each SSP is in accordance with the documented procedure, including the form that the SSP are in when they are entered. <br>   </li>   <li> The tester shall enter each type of manually entered SSP without any errors and shall verify the status output interface. If no indicator is output, or if the indicator does not match the documented indicator for the success of the manual entry test, the test is failed. <br>   </li>   <li> The tester shall attempt to perform cryptographic operations with each entered SSP to verify that it was entered correctly. <br>   </li>   <li> The tester shall modify either the EDC associated with each manually entered SSP or the SSP itself and shall enter them into the module. The tester shall verify the indicator that is output from the status output interface; if no indicator is output, or the indicator does not match the documented indicator for the failure of the manual entry test, the test is failed. <br>   </li>   <li> The tester shall attempt to perform cryptographic operations with each SSP that was not successfully entered. Each operation using each SSP is required to fail, verifying that the SSP was not entered. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.46.04",
        level: "1",
        requirement:
          "For manual entry tests using duplicate entries of SSPs or key components, the tester shall perform the following tests. <br> <ol type=1>   <li> The tester shall enter each type of manually-entered SSP without any errors and shall verify the status output interface. If no indicator is output, or if the indicator does not match the documented indicator for the success of the manual entry test, the test is failed. <br>   </li>   <li> The tester shall attempt to perform cryptographic operations with each entered SSP to verify that it was entered correctly. <br>   </li>   <li> The tester shall modify one of the manually entered SSPs, either the first or second duplicate entry, and shall enter them into the module. The tester shall verify the indicator that is output from the status output interface; if no indicator is output, or the indicator does not match the documented indicator for the failure of the manual entry test, the test is failed. <br>   </li>   <li> The tester shall attempt to perform cryptographic operations with each SSP that was not successfully entered. Each operation using each SSP is required to fail, verifying that the SSP was not entered. <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.47",
        level: "1",
        requirement:
          "If a cryptographic module implements a bypass capability where the services may be provided without cryptographic processing (e.g. transferring plaintext through the module), then the following suite of bypass tests shall be performed to ensure that a single point of failure of module components will not result in the unintentional output of plaintext. <br> NOTE	This assertion is tested as part of <a href='#AS10.48'>AS10.48</a> to <a href='#AS10.51'>AS10.51</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.48",
        level: "1",
        requirement:
          "A cryptographic module shall test for the correct operation of the services providing cryptographic processing when a switch takes place between an exclusive bypass service and an exclusive cryptographic service. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.48.01",
        level: "1",
        requirement:
          "If the cryptographic module implements a bypass service, then the vendor shall implement a bypass test to verify the correct operation of the cryptographic service when a switch takes place between an exclusive bypass and an exclusive cryptographic service. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.48.02",
        level: "1",
        requirement:
          "The vendor shall provide a description of the bypass test. The bypass test shall demonstrate that, when switched to an exclusive cryptographic service, the module does not output plaintext information. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.48.01",
        level: "1",
        requirement:
          "The tester shall verify that the module implements a bypass test to verify the correct operation of the cryptographic service when a switch takes place between an exclusive bypass service and an exclusive cryptographic service. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.48.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation is consistent with the bypass test implementation through a review of the source code and/or design documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.48.03",
        level: "1",
        requirement:
          "The tester shall switch the module from the exclusive bypass service to the exclusive cryptographic service and verify that plaintext information is not output. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.49",
        level: "1",
        requirement:
          "If a cryptographic module can automatically alternate between a bypass service and a cryptographic service, providing some services with cryptographic processing and some services without cryptographic processing, then the module shall test for the correct operation of the services providing cryptographic processing when the mechanism governing the switching procedure is modified (e.g. an IP address source/destination table). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.49.01",
        level: "1",
        requirement:
          "If the cryptographic module is designed to automatically alternate between a bypass service and a cryptographic service, then the vendor shall implement a bypass test to verify the correct operation of the cryptographic service when the mechanism governing the switching procedure is modified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.49.02",
        level: "1",
        requirement:
          "The vendor shall provide a description of the test. The bypass test shall guarantee that when the mechanism governing the switching procedure is modified: <br> <ol type=1>   <li> the mechanism is verified not to have been altered since the last modification. If the mechanism has been altered, the cryptographic module shall enter an error state and output an error indicator to the status interface; <br>   </li>   <li> the correct operation of the cryptographic service is verified by demonstrating that the module does not output plaintext information. The bypass test fails if the module outputs plaintext information. <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.49.01",
        level: "1",
        requirement:
          "The tester shall verify that the module implements a bypass test to verify the correct operation of the cryptographic service when the mechanism governing the switching procedure is modified. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.49.02",
        level: "1",
        requirement:
          "The tester shall verify that the description of the test is consistent with the bypass test implementation through the review of the source code and/or design documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.49.03",
        level: "1",
        requirement:
          "The tester shall verify the correct operation of the bypass test by: <br> <ol type=1>   <li> verifying that the mechanism governing the switching procedure checks to ensure that no alteration of the mechanism has taken place since the last modification. The tester will document the method used. If the design allows, the tester shall modify the mechanism to test the method used; <br>   </li>   <li> modifying the mechanism governing the switching procedure in order to verify the correct operation of the mechanism and to verify the correct operation of the cryptographic service by verifying that the plaintext information is not output. <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.50",
        level: "1",
        requirement:
          "If a cryptographic module maintains internal information that governs the bypass capability, then the module shall verify the integrity of the governing information through an approved integrity technique immediately preceding modification of the governing information, {and shall generate a new integrity value using the approved integrity technique immediately following the modification}. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS10.51'>AS10.51</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.51",
        level: "1",
        requirement:
          "{If a cryptographic module maintains internal information that governs the bypass capability, then the module shall verify the integrity of the governing information through an approved integrity technique immediately preceding modification of the governing information,} and shall  generate a new integrity value using the approved integrity technique immediately following the modification. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.51.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the method to modify the internal information that governs the bypass capability. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.51.02",
        level: "1",
        requirement:
          "The vendor shall provide a detailed specification of the internal information that governs the bypass capability, the internal sequence to update the information, and the mechanism to maintain the integrity of the information using an approved integrity technique. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.51.01",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the governing information maintained in the cryptographic module is consistent with the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.51.02",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the internal sequence to update the governing information is consistent with the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.51.03",
        level: "1",
        requirement:
          "By checking the code and/or design documentation, the tester shall verify that the mechanism to maintain the integrity of the governing information is consistent with the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.52",
        level: "1",
        requirement:
          "There may be other security functions critical to the secure operation of a cryptographic module that shall be tested as a conditional self-test. <br> NOTE	This assertion is tested as part of <a href='#AS10.24'>AS10.24</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.53",
        level: "1",
        requirement:
          "A cryptographic module shall permit operators to initiate the pre-operational or conditional self-tests on demand for periodic testing of the module. Acceptable means for the on-demand initiation of periodic self-tests are provided service, resetting, rebooting, or power cycling. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.53.01",
        level: "1",
        requirement:
          "The vendor shall describe the procedure by which an operator can initiate the preoperational self-tests on demand for periodic testing of the module. All of the pre-operational self-tests have to be included. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.53.02",
        level: "1",
        requirement:
          "The vendor shall describe the procedure by which an operator can initiate the conditional self-tests on demand for periodic testing of the module. At a minimum, conditional cryptographic algorithm tests have to be included. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.53.01",
        level: "1",
        requirement:
          "The tester shall inspect the vendor documentation to verify that initiation of preoperational self-tests on demand is specified for all of the pre-operational self-tests. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.53.02",
        level: "1",
        requirement:
          "The tester shall initiate the pre-operational self-tests on demand to verify that the initiation of the pre-operational self-tests on demand is consistent with the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.53.03",
        level: "1",
        requirement:
          "The tester shall initiate the conditional self-tests on demand to verify that the initiation of the conditional self-tests on demand is consistent with the vendor documentation. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.54",
        level: "3",
        requirement:
          "The module shall repeatedly, upon a defined time period automatically, without external input or control, perform the pre-operational or conditional self-tests. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.54.01",
        level: "3",
        requirement:
          "The vendor shall provide documentation that specifies how the pre-operational and conditional self-tests are repeatedly performed upon a defined time, automatically, without external input or control. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE10.54.02",
        level: "3",
        requirement:
          "The vendor documentation shall include the specification on the status indicator used to indicate that the cryptographic module�s operations are interrupted due to the pre-operational or conditional self-tests. <br> VE10. 54.03: The vendor provided non-proprietary security policy shall provide the information on the defined time period and any conditions that result in the interruption of the module&#39;s operation during the time to repeat pre-operational or conditional self-tests. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE10.54.01",
        level: "3",
        requirement:
          "The tester shall verify, by inspection of the cryptographic module, that the pre-operational and conditional self-tests are repeatedly performed as specified in <a href='#VE10.54.01'>VE10.54.01</a>, and <a href='#VE10.54.02'>VE10.54.02</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS10.55",
        level: "3",
        requirement:
          "The time period and any conditions that may result in the interruption of the module&#39;s operations during the time to repeat the pre-operational or conditional self-tests shall be specified in the security policy ((ISO/IEC 19790:2012) Annex B) (e.g. If the module is performing mission critical services that can&#39;t be interrupted and the time period is passed for the initiation of the pre-conditional self-tests, the self-tests may be deferred after the time period is passed again.). <br> </ol>NOTE	This assertion is tested as part of <a href='#AS10.54'>AS10.54</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "11",
    dtrs: [
      {
        dtrId: "AS11.01",
        level: "1",
        requirement:
          "The documentation requirements specified in (ISO/IEC 19790:2012) A.2.11 shall be provided. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.01.01",
        level: "1",
        requirement:
          "The vendor shall provide the documentation requirements as specified in ISO/IEC 19790:2012, A.2.11. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.01.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation as specified in ISO/IEC 19790:2012, A.2.11. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.02",
        level: "1",
        requirement:
          "The following security requirements {ISO/IEC 19790:2012 <a href='#AS11.03'>AS11.03</a> to <a href='#AS11.05'>AS11.05</a>} shall apply to cryptographic modules for Security Levels 1 and 2. <br> NOTE	This assertion is tested as part of <a href='#AS11.03'>AS11.03</a> to <a href='#AS11.05'>AS11.05</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.03",
        level: "1",
        requirement:
          "A configuration management system shall be used for the development of a cryptographic module and module components within the cryptographic boundary and of associated module documentation. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.03.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the configuration management system for the cryptographic module, module components, and associated module documentation. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.03.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor provided documents that a configuration management system has been implemented. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.04",
        level: "1",
        requirement:
          "Each version of each configuration item (e.g. cryptographic module, module hardware parts, module software components, module HDL, user guidance, security policy, etc.) that comprises the module and associated documentation shall be assigned and labelled with a unique identifier. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.04.01",
        level: "1",
        requirement:
          "The vendor cryptographic module documentation shall include a configuration list of all configuration items. The vendor documentation shall describe the method used to uniquely identify the configuration items. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.04.02",
        level: "1",
        requirement:
          "The vendor documentation shall describe the method used to uniquely identify the version of each configuration item being validated. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.04.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor provided configuration list inclusion of configuration items. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.04.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor documentation specifies the method used to uniquely identify all configuration items. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.04.03",
        level: "1",
        requirement:
          "The tester shall verify that vendor documentation describes the method used to uniquely identify each version of a configuration item being validated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.04.04",
        level: "1",
        requirement:
          "The tester shall verify that vendor documentation uniquely identifies the version of each configuration item being validated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.05",
        level: "1",
        requirement:
          "The configuration management system shall track and maintain the changes to the identification and version or revision of each configuration item throughout the life-cycle of the validated cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.05.01",
        level: "1",
        requirement:
          "The vendor documentation shall specify the measures, such that only authorized changes are made to the configuration items. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.05.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor documentation that specifies the measures, such that only authorized changes are made to the configuration items. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.06",
        level: "3",
        requirement:
          "The configuration items shall be managed using an automated configuration management system. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.06.01",
        level: "3",
        requirement:
          "The vendor documentation shall specify how the configuration management system provides an automated means to support the generation of a cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.06.01",
        level: "3",
        requirement:
          "The tester shall verify the vendor documentation that specifies how the configuration management system provides an automated means to support the generation of a cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.07",
        level: "1",
        requirement:
          "Cryptographic modules shall be designed to allow the testing of all provided security related services. <br> NOTE	This assertion is tested in  6.4.3. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.08",
        level: "1",
        requirement:
          "The operation of a cryptographic module shall be specified using a Finite State Model (or equivalent) represented by a state transition diagram and a state transition table and state descriptions. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.08.01",
        level: "1",
        requirement:
          "The vendor shall provide a description of the finite state model. This description shall contain the identification and description of all states of the module and a description of all corresponding state transitions. The descriptions of the state transitions shall include internal module conditions, data inputs and control inputs that cause transitions from one state to another, data outputs and status outputs resulting from transitions from one state to another. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.08.02",
        level: "1",
        requirement:
          "The vendor documentation shall establish a complete description of the following: <br> <ol type=1>   <li> normal operation; <br>   </li>   <li> degraded operation; <br>   </li>   <li> data input interface; <br>   </li>   <li> data output interface; <br>   </li>   <li> control input interface; <br>   </li>   <li> control output interface; <br>   </li>   <li> status output interface; <br>   </li>   <li> trusted channel; <br>   </li>   <li> crypto-officer role; <br>   </li>   <li> user role; <br>   </li>   <li> other roles (if applicable); <br>   </li>   <li> security services; <br>   </li>   <li> SSP entry services (if applicable); <br>   </li>   <li> show status service; <br>   </li>   <li> operator authentication; <br>   </li>   <li> self-tests; <br>   </li>   <li> other authorized services, operations, and functions (if applicable); <br>   </li>   <li> error states; <br>   </li>   <li> bypass service (if applicable); <br>   </li>   <li> maintenance access interface (if applicable); <br>   </li>   <li> maintenance role (if a maintenance access interface is provided); <br>   </li>   <li> SSP generation and establishment services (if applicable); <br>   </li>   <li> SSP output services (if applicable); <br>   </li>   <li> idle states (if applicable); <br>   </li>   <li> uninitialized states (if applicable). <br> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor has provided a description of the finite state model. This description shall contain the identification and description of all states of the module and a description of all corresponding state transitions. The tester shall verify that the descriptions of the state transitions include the internal module conditions, data inputs and control inputs that cause transitions from one state to another, data outputs and status outputs resulting from transitions from one state to another. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.02",
        level: "1",
        requirement:
          "The tester shall verify that the finite state model (e.g. state transition diagram, state transition table and state descriptions) are consistent with the vendor documentation that shall describe the following: <br> <ol type=1>   <li> normal operation; <br>   </li>   <li> degraded operation; <br>   </li>   <li> data input interface; <br>   </li>   <li> data output interface; <br>   </li>   <li> control input interface; <br>   </li>   <li> control output interface; <br>   </li>   <li> status output interface; <br>   </li>   <li> trusted channel; <br>   </li>   <li> crypto officer role; <br>   </li>   <li> user role; <br>   </li>   <li> other roles (if applicable); <br>   </li>   <li> security services; <br>   </li>   <li> SSP entry services (if applicable); <br>   </li>   <li> show status service; <br>   </li>   <li> operator authentication; <br>   </li>   <li> self-tests; <br>   </li>   <li> other authorized services, operations, and functions (if applicable); <br>   </li>   <li> error states; <br>   </li>   <li> bypass service (if applicable); <br>   </li>   <li> maintenance access interface (if applicable); <br>   </li>   <li> maintenance role (if a maintenance access interface is provided); <br>   </li>   <li> SSP generation and establishment services (if applicable); <br>   </li>   <li> SSP output services (if applicable); <br>   </li>   <li> idle states (if applicable); <br>   </li>   <li> uninitialized states (if applicable). <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>  </ol> <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.03",
        level: "1",
        requirement:
          "The tester shall verify that each distinct cryptographic module service, security function use, error state, self-test, or operator authentication is depicted as a separate state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.04",
        level: "1",
        requirement:
          "The tester shall verify that every state that is identified in the state transition diagram is also identified and described in the state description. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.05",
        level: "1",
        requirement:
          "The tester shall verify that every state that is identified and described in the state description is also identified in the state transition diagram(s). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.06",
        level: "1",
        requirement:
          "The tester shall verify that the operation of the module is consistent with the state transition diagram, state transition table, and state descriptions. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.07",
        level: "1",
        requirement:
          "If the module includes a maintenance access interface, the tester shall verify that the finite state model has at least one maintenance state defined. All maintenance states have to be contained in the state transition diagram(s) and described in the state description. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.08",
        level: "1",
        requirement:
          "The tester shall verify the descriptions of the states of the cryptographic module if the descriptions clearly define disjoint states. The tester shall verify that all possible combinations of data and control inputs can be partitioned into disjoint sets. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.09",
        level: "1",
        requirement:
          "The tester shall exercise the cryptographic module, causing it to enter each of its major states. For each state that has a distinct indicator, the tester shall attempt to verify the indicator while the module is in the state. If the expected indicator is not observed, or two or more such indicators are observed at the same time (indicating that the module is in more than one state at one time), this test is failed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.10",
        level: "1",
        requirement:
          "The tester shall verify that there exists a chain of transitions from an initial power on state to each other state in the model that is not an initial power on state. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.11",
        level: "1",
        requirement:
          "The tester shall verify that there exists a chain of transitions from each non-power off state to a power off state of the model. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.08.12",
        level: "1",
        requirement:
          "The tester shall verify that the actions of the finite state model, as the result of all possible data and control inputs, are defined. An example of an acceptable inclusive statement is: <br> <br>- The action of the finite state model as a result of all other combinations of data and control inputs is to place the finite state model into the ERROR-3 state.� <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.09",
        level: "1",
        requirement:
          "The FSM shall be sufficiently detailed to demonstrate that the cryptographic module complies with all of the requirements of {ISO/IEC 19790:2012}. <br> NOTE	This assertion is not separately tested. Tested as part of <a href='#AS11.10'>AS11.10</a> to <a href='#AS11.13'>AS11.13</a>.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.10",
        level: "1",
        requirement:
          "The FSM of a cryptographic module shall include, as a minimum, the following operational and error states. <br> � Power on/off state: a state in which the module is powered off, placed in standby mode (volatile memory maintained), or the operational state preserved in non-volatile memory (e.g. hibernation mode) and in which primary, secondary, or backup power is applied to the module. This state may distinguish between power sources being applied to a cryptographic module. For a software module, power on is the action of spawning an executable image of the cryptographic module. <br> </ol>� General initialization state: a state in which the cryptographic module is undergoing initializing before the module transitions to the approved state. <br> � Crypto Officer State: a state in which the Crypto Officer services are performed (e.g. cryptographic initialization, secure administration, and key management). <br> � CSP entry state: a state for entering the CSPs into the cryptographic module. <br> � User state (if a User role is implemented): a state in which authorized users obtain security services, perform cryptographic operations, or perform other approved functions. <br> � Approved state: a state in which approved security functions are performed. <br> � Self-test state: a state in which the cryptographic module is performing self-tests. <br> � Error state: a state when the cryptographic module has encountered an error condition (e.g. failed a self-test). There may be one or more error conditions that result in a single module error state. Error states may include - hard� errors that indicate an equipment malfunction and that may require maintenance, service or repair of the cryptographic module, or recoverable - soft� errors that may require initialization or resetting of the module. <br> NOTE	This assertion is tested as part of <a href='#AS11.08'>AS11.08</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.11",
        level: "1",
        requirement:
          "Recovery from error states shall be possible, except for those caused by hard errors that require maintenance, service, or repair of the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.11.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the applicable recovery for each error state that does not require maintenance, service, or repair of the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.11.01",
        level: "1",
        requirement:
          "From each error state that does not require maintenance, service, or repair, the tester shall verify that the cryptographic module can be caused to transition to an acceptable operational or initialization state. This effort consists of two parts: first, the tester shall verify that the cryptographic module indicates when it is an error state, and second, that the module operates correctly in this target state. The tester shall report how the requirement was verified (i.e. by code examination or by exercising the module). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.12",
        level: "1",
        requirement:
          "Each distinct cryptographic module service, security function use, error state, self-test, or operator authentication shall be depicted as a separate state. <br> NOTE	This assertion is tested as part of <a href='#AS11.08'>AS11.08</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.13",
        level: "1",
        requirement:
          "Changing to the Crypto Officer state from any other role other than the Crypto Officer shall be prohibited. <br> NOTE: The intention of this assertion is to remove/avoid privilege escalation to a Crypto Officer role. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.13.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that changing to the Crypto Officer state from any other role other than the Crypto Officer is prohibited. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.13.01",
        level: "1",
        requirement:
          "The tester shall verify that a description of the finite state model demonstrates that changing to the Crypto Officer state from any other role other than the Crypto Officer is prohibited. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.13.02",
        level: "1",
        requirement:
          "If the cryptographic module supports any other role other than the Crypto Officer role, the tester shall verify the following: <br> <ol type=1>   <li>	In any chain of transitions from each of any other role states to a power off state or to each state in which the authentication/authorization is cleared to assume the role, <br>   </li>     <ol type=a>       <li> there is no Crypto Officer state, and <br>       </li>       <li> there is no state in which the service assigned only to a Crypto Officer role is performed. <br>       </li>     </ol> </ol>  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.14",
        level: "1",
        requirement:
          "The following requirements shall apply to cryptographic modules for Security Level 1. <br> NOTE	This assertion is tested as part of <a href='#AS11.15'>AS11.15</a> to <a href='#AS11.21'>AS11.21</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.15",
        level: "1",
        requirement:
          "If a cryptographic module contains software or firmware, the source code, language reference, the compilers, compiler versions and compiler options, the linker and linker options, the runtime libraries and runtime library settings, configuration settings, build processes and methods, the build options, environmental variables and all other resources used to compile and link the source code into an executable form shall be tracked using the configuration management system. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.15.01",
        level: "1",
        requirement:
          "For cryptographic modules which contain software or firmware, the vendor shall provide documentation of the source code, language reference, the compilers, compiler versions and compiler options, the linker and linker options, the runtime libraries and runtime library settings, configuration settings, build processes and methods, the build options, environmental variables, and all other resources used to compile and link the source code into an executable form. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.15.02",
        level: "1",
        requirement:
          "For each of the documented items in <a href='#VE11.15.01'>VE11.15.01</a>, the vendor shall provide documentation that these items are tracked using the configuration management system. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.15.01",
        level: "1",
        requirement:
          "For cryptographic modules which contain software or firmware, the tester shall verify that the vendor provides documentation of the source code, language reference, the compilers, compiler versions and compiler options, the linker and linker options, the runtime libraries and runtime library settings, configuration settings, build processes and methods, the build options, environmental variables, and all other resources used to compile and link the source code into an executable form. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.15.02",
        level: "1",
        requirement:
          "For each of the documented items in <a href='#VE11.15.01'>VE11.15.01</a>, the tester shall verify that the vendor provides documentation that these items are tracked using the configuration management system. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.16",
        level: "1",
        requirement:
          "If a cryptographic module contains software or firmware, the source codes shall be annotated with comments that depict the correspondence of the software or firmware to the design of the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.16.01",
        level: "1",
        requirement:
          "The vendor shall supply a list of the names of all the software and firmware components contained in the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.16.02",
        level: "1",
        requirement:
          "The vendor shall supply an annotated source listing of each software and firmware component contained in the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.16.01",
        level: "1",
        requirement:
          "The tester shall use the list supplied by the vendor to verify that a source listing for each software or firmware component is contained in the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.17",
        level: "1",
        requirement:
          "If a cryptographic module contains hardware, documentation shall specify the schematics and/or Hardware Description Language (HDL), as applicable. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.17.01",
        level: "1",
        requirement:
          "The vendor shall supply a list of the hardware components contained in the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.17.01",
        level: "1",
        requirement:
          "The tester shall use the list supplied by the vendor to verify that the documentation includes schematics and/or Hardware Description Language (HDL) listings for the hardware components. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.18",
        level: "1",
        requirement:
          "If a cryptographic module contains hardware, the HDL shall be annotated with comments that depict the correspondence of the hardware to the design of the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.18.01",
        level: "1",
        requirement:
          "The vendor shall supply an annotated HDL listing of each hardware component contained in the cryptographic module <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.18.01",
        level: "1",
        requirement:
          "The tester shall use the list supplied by the vendor to verify that a HDL listing for each hardware component is contained in the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.19",
        level: "1",
        requirement:
          "{For software and firmware cryptographic modules and the software or firmware component of a hybrid module} the result of the integrity and authentication technique mechanisms specified <br> in {ISO/IEC 19790:2012} 7.5 and {ISO/IEC 19790:2012} 7.10 shall be calculated and integrated into the software or firmware module by the vendor during the module development. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.19.01",
        level: "1",
        requirement:
          "For software and firmware cryptographic modules and the software or firmware component of a hybrid module, the vendor shall provide documentation that the result of the integrity and authentication technique mechanisms specified in [ISO/IEC 19790:2012] 7.5 and [ISO/IEC 19790:2012] 7.10 shall be calculated and integrated into the software or firmware module by the vendor during the module development. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.19.01",
        level: "1",
        requirement:
          "For software and firmware cryptographic modules and the software or firmware component of a hybrid module, the tester shall verify that the vendor provides documentation that the result of the integrity and authentication technique mechanisms specified in [ISO/IEC 19790:2012] 7.5 and [ISO/IEC 19790:2012] 7.10 shall be calculated and integrated into the software or firmware module by the vendor during the module development. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.20",
        level: "1",
        requirement:
          "{For software and firmware cryptographic modules and the software or firmware component of a hybrid module} the cryptographic module documentation shall specify the compiler, configuration settings and methods to compile the source code into an executable form. <br> NOTE	This assertion is tested as part of <a href='#AS11.15'>AS11.15</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.21",
        level: "1",
        requirement:
          "{For software and firmware cryptographic modules and the software or firmware component of a hybrid module} the cryptographic module shall be developed using production-grade development tools (e.g. compilers). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.21.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that the cryptographic module shall be developed using production-grade development tools (e.g. compilers). <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.21.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that the module meets the cryptographic module shall be developed using production-grade development tools (e.g. compilers). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.22",
        level: "2",
        requirement:
          "The following requirements {ISO/IEC 19790:2012 <a href='#AS11.23'>AS11.23</a> to <a href='#AS11.26'>AS11.26</a>} shall apply to cryptographic modules for Security Levels 2 and 3. <br> NOTE	This assertion is tested as part of <a href='#AS11.23'>AS11.23</a> to <a href='#AS11.26'>AS11.26</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.23",
        level: "2",
        requirement:
          "All software or firmware shall be implemented using a high-level, non-proprietary language {or rationale shall be provided for the use of a low-level language (e.g. assembly language or microcode) if essential to the performance of the module or when a high-level language is not available}. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.23.01",
        level: "2",
        requirement:
          "The vendor shall provide documentation that all software or firmware within a cryptographic module is implemented using a high-level, non-proprietary language. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.23.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor provides documentation that all software or firmware within a cryptographic module is implemented using a high-level, non-proprietary language. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.24",
        level: "2",
        requirement:
          "{All software or firmware shall be implemented using a high-level, non-proprietary language} or rationale shall be provided for the use of a low-level language (e.g. assembly language or microcode) if essential to the performance of the module or when a high-level language is not available. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.24.01",
        level: "2",
        requirement:
          "The vendor shall identify each of the software and firmware components that is not written in a high-level language and provide a rationale or justification for why the component are written in a low-level language. The rationale shall cite either the unavailability of a high-level language or the need for enhanced performance for the software or firmware. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.24.01",
        level: "2",
        requirement:
          "The tester shall examine the source code for each of the software and/or firmware components to verify which ones are written in a low-level language. The tester shall verify that there are no software and/or firmware components written in a low-level language that were not identified by the vendor in <a href='#VE11.24.01'>VE11.24.01</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.25",
        level: "2",
        requirement:
          "Custom integrated circuits within a cryptographic module shall be implemented using a high-level Hardware Description Language (HDL) (e.g. VHDL or Verilog). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.25.01",
        level: "2",
        requirement:
          "The vendor shall supply documentation on the hardware components that are implemented using a high-level specification language. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.25.01",
        level: "2",
        requirement:
          "The tester shall verify the vendor documentation that the information specified in <a href='#VE11.25.01'>VE11.25.01</a> is included. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.26",
        level: "2",
        requirement:
          "All software or firmware shall be designed and implemented in a manner that avoids the use of code, parameters or symbols not necessary for the module&#39;s functionality and execution. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.26.01",
        level: "2",
        requirement:
          "For all software or firmware the vendor shall supply documentation that the software or firmware is designed and implemented in a manner that avoids the use of code, parameters, or symbols not necessary for the module�s functionality and execution. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.26.01",
        level: "2",
        requirement:
          "For all software or firmware the tester shall verify that the vendor provides documentation that the software or firmware is designed and implemented in a manner that avoids the use of code, parameters or symbols not necessary for the module�s functionality and execution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.27",
        level: "4",
        requirement:
          "The following requirement shall apply to cryptographic modules for Security Level 4. <br> NOTE	This assertion is tested as part of <a href='#AS11.28'>AS11.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.28",
        level: "4",
        requirement:
          "For each cryptographic module hardware and software component, the documentation shall be annotated with comments that specify (1) the pre-conditions required upon entry into the module component, function, or procedure in order to execute correctly and (2) the post-conditions expected to be true when the execution of the module component, function, or procedure is complete. <br> </ol>NOTE	The pre-conditions and post-conditions can be specified using any notation that is sufficiently detailed <br> to completely and unambiguously explain the behaviour of the cryptographic module component, function, or procedure. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.28.01",
        level: "4",
        requirement:
          "The source code listings for all hardware, software, and firmware components, shall include as comments, pre- and post-conditions as required in <a href='#AS11.28'>AS11.28</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.28.02",
        level: "4",
        requirement:
          "The vendor provided documentation shall provide a rationale or justification for why each pre-condition is satisfied, together with allowable use cases for the cryptographic module. <br> NOTE	Use cases will include providing services to concurrent operators with various roles and detecting <br> physical tampering. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.28.03",
        level: "4",
        requirement:
          "If there are any pre-conditions which are not solely satisfied by the design of the cryptographic module, the vendor provided documentation shall also address the fact and identify which entities are responsible for each pre-condition. The entities might be additional validated module embedded inside the cryptographic module, or hardware components assembled in the module. If the entities outside the cryptographic boundary are responsible for a pre-condition, the administrator guidance shall provide the pre-condition as rule imposed on the use of cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.28.04",
        level: "4",
        requirement:
          "The vendor provided documentation shall provide a rationale or justification for why each post-condition is satisfied. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.28.01",
        level: "4",
        requirement:
          "The tester shall verify the source code listings that the information specified in <a href='#VE11.28.01'>VE11.28.01</a> is included. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.28.02",
        level: "4",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that each precondition is actually satisfied, while taking into account the allowable use cases. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br> NOTE	This inspection will be performed by examining the consistency with other post-conditions already <br> verified and/or by inspecting source code. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.28.03",
        level: "4",
        requirement:
          "The tester shall verify by inspection and from the vendor documentation that each post-condition is actually satisfied, while taking into other pre- and post-conditions verified. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.28.04",
        level: "4",
        requirement:
          "If additional validated module is embedded inside the cryptographic module, the tester shall verify that rules imposed on the use of additional validated module are actually satisfied. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.29",
        level: "1",
        requirement:
          "Documentation shall specify the functional testing performed on the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.29.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that specifies the functional testing performed on the cryptographic module, providing assurance that the cryptographic module behaves in accordance with the module security policy and functional specifications. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.29.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that specifies the functional testing performed on the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.29.02",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided documentation provides assurance that the cryptographic module behaves in accordance with the module security policy and functional specifications. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.30",
        level: "1",
        requirement:
          "For software or firmware cryptographic modules and the software or firmware component of a hybrid module, the vendor shall use current automated security diagnostic tools (e.g. detect buffer overflow). <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.30.01",
        level: "1",
        requirement:
          "For software or firmware cryptographic modules and the software or firmware component of a hybrid module, the vendor shall provide documentation that current automated security diagnostic tools (e.g. detect buffer overflow, etc.) were used. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.30.01",
        level: "1",
        requirement:
          "For software or firmware cryptographic modules and the software or firmware component of a hybrid module, the tester shall verify that the vendor provides documentation that current automated security diagnostic tools (e.g. detect buffer overflow, etc.) were used. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.31",
        level: "3",
        requirement:
          "Documentation shall specify the procedures for and the results of low-level testing performed on the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.31.01",
        level: "3",
        requirement:
          "The vendor shall provide documentation that specifies the procedures for and the results of low-level testing performed on the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.31.01",
        level: "3",
        requirement:
          "The tester shall verify that the vendor provides documentation that specifies the procedures for and the results of low-level testing performed on the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.32",
        level: "1",
        requirement:
          "Documentation shall specify the procedures for secure installation, initialization, and startup of the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.32.01",
        level: "1",
        requirement:
          "The vendor documentation shall describe the steps necessary for the secure installation, initialization, and start-up of the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.32.01",
        level: "1",
        requirement:
          "The tester shall verify the vendor provided documentation that it includes installation, initialization, and start-up procedures that result in a secure configuration. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.32.02",
        level: "1",
        requirement:
          "The tester shall perform the procedures for the secure installation, initialization, and startup of the cryptographic module and verify their correctness. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.33",
        level: "2",
        requirement:
          "Documentation shall specify the procedures required for maintaining security while distributing, installation and the initialization of versions of a cryptographic module to authorized operators. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.33.01",
        level: "2",
        requirement:
          "The delivery documentation shall describe the procedures necessary to maintain security when distributing the cryptographic module to authorized operators. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.33.01",
        level: "2",
        requirement:
          "The tester shall verify the vendor provided documentation that procedures required for maintaining security while distributing and delivering versions of the cryptographic module to authorized operators are correct. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.34",
        level: "2",
        requirement:
          "The procedures shall specify how to detect tamper during the delivery, installation, and initialization of the module to the authorized operators. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.34.01",
        level: "2",
        requirement:
          "The vendor shall provide documentation that specifies the procedures how to detect tamper during the delivery, installation, and initialization of the module to the authorized operators. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.34.01",
        level: "2",
        requirement:
          "The tester shall verify that the vendor provides documentation that specifies the procedures how to detect tamper during the delivery, installation, and initialization of the module to the authorized operators. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.35",
        level: "4",
        requirement:
          "The procedures shall require the authorized operator to be authenticated by the module using the operator specific authentication data provided by the vendor. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.35.01",
        level: "4",
        requirement:
          "The vendor shall provide documentation for the procedures required by the authorized operator to be authenticated by the module using authentication data provided by the vendor. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.35.01",
        level: "4",
        requirement:
          "The tester shall verify that the vendor provides documentation for the procedures required by the authorized operator to be authenticated by the module using authentication data provided by the vendor. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.36",
        level: "1",
        requirement:
          "Documentation shall specify the procedures for secure sanitization of the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.36.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that specifies the procedures for secure sanitization of the cryptographic module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.36.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that specifies the procedures for secure sanitization of the cryptographic module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.37",
        level: "3",
        requirement:
          "Documentation shall specify the procedures required for the secure destruction of the module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.37.01",
        level: "3",
        requirement:
          "The vendor shall provide documentation that specifies the procedures required for the secure destruction of the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.37.01",
        level: "3",
        requirement:
          "The tester shall verify that the vendor provides documentation that specifies the procedures required for the secure destruction of the module. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.38",
        level: "1",
        requirement:
          "Administrator guidance shall specify: <br> � the administrative functions, security events, security parameters (and parameter values, as appropriate), physical ports, and logical interfaces of the cryptographic module available to the Crypto Officer and/or other administrative roles; <br> � procedures required to keep operator authentication data and mechanisms functionally independent; <br> � procedures on how to administer the cryptographic module in an approved mode of operation; and <br> � assumptions regarding User behavior that are relevant to the secure operation of the cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.38.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that includes the information list in <a href='#AS11.38'>AS11.38</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.38.02",
        level: "1",
        requirement:
          "The non-proprietary guidance shall be available to the appropriate administrators of the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.38.03",
        level: "1",
        requirement:
          "The vendor shall list any CVEs associated with the module, and either <br> 	-- provide assurance that they are not security relevant; <br> 	-- or, for any CVE&#39;s that are considered security relevant, the vendor shall describe how they have been mitigated. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.38.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that includes the information list in <a href='#AS11.38'>AS11.38</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.38.02",
        level: "1",
        requirement: "Intentionally left blank (SP800 140-3) <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.38.03",
        level: "1",
        IGs: ["11.A"],
        Anchors: ["h.2w5ecyt"],
        requirement:
          "The tester shall verify that any CVEs associated with the module: <br> 	-- are not security relevant, or, <br> 	-- if they are security relevant, mitigations provided by the vendor are appropriate. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS11.39",
        level: "1",
        requirement:
          "Non-administrator guidance shall specify: <br> � the approved and non-approved security functions, physical ports, and logical interfaces available to the users of a cryptographic module; <br> � all User responsibilities necessary for the approved mode of operation of a cryptographic module. <br> Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.39.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation that includes the information list in <a href='#AS11.39'>AS11.39</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE11.39.02",
        level: "1",
        requirement:
          "The non-proprietary guidance shall be available to the appropriate non-administrators of the module. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE11.39.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation that includes the information list in <a href='#AS11.39'>AS11.39</a>. <br> NOTE 1 The existence and proper functioning of the security mechanisms will be validated when requirements and associated tests are developed. <br> NOTE 2 The non-proprietary security policy includes the information required in {ISO/IEC 19790:2012} B.2.12.  <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "12",
    dtrs: [
      {
        dtrId: "AS12.01",
        level: "1",
        requirement:
          "The documentation requirements specified in (ISO/IEC 19790:2012) A.2.12 shall be provided.  <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE12.01.01",
        level: "1",
        requirement:
          "The vendor shall provide the documentation requirements as specified in ISO/IEC 19790:2012, A.2.12. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE12.01.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation as specified in ISO/IEC 19790:2012, A.2.12. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS12.02",
        level: "1",
        requirement:
          "If a cryptographic module is designed to mitigate one or more specific attack(s) not defined elsewhere in (ISO/IEC 19790:2012), then the module&#39;s supporting documents shall enumerate the attack(s) the module is designed to mitigate. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE12.02.01",
        level: "1",
        requirement:
          "The vendor shall provide supporting documentation which enumerates the attack(s) the module is designed to mitigate. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE12.02.01",
        level: "1",
        IGs: ["12.A"],
        Anchors: ["h.pkwqa1"],
        requirement:
          "The tester shall verify that the vendor provides supporting documentation which enumerates the attack(s) the module is designed to mitigate. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS12.03",
        level: "4",
        requirement:
          "The following requirement shall apply to cryptographic modules for Security Level 4. <br> NOTE	This assertion is tested as part of <a href='#AS12.04'>AS12.04</a>. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "AS12.04",
        level: "4",
        requirement:
          "If the mitigation of specific attacks not defined elsewhere in (ISO/IEC 19790:2012) is claimed, documentation shall specify the methods used to mitigate the attacks and the methods to test the effectiveness of mitigation techniques. <br> </ol>Required Vendor Information <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE12.04.01",
        level: "4",
        requirement:
          "<br> The vendor shall specify in the documentation the methods used to mitigate the attack(s). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE12.04.02",
        level: "4",
        requirement:
          "<br> The vendor shall specify in the documentation the test methods used to test the effectiveness of the mitigation techniques. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VE12.04.03",
        level: "4",
        requirement:
          "<br> The vendor shall specify in the documentation the effectiveness of the mitigation techniques. <br> Required Test Procedures <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE12.04.01",
        level: "4",
        requirement:
          "<br> The tester shall verify that the vendor provides documentation that specifies the methods used to mitigate the attack(s). <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE12.04.02",
        level: "4",
        requirement:
          "<br> The tester shall verify that the vendor provides documentation that specifies the test methods used to test the effectiveness of the mitigation techniques. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TE12.04.03",
        level: "4",
        requirement:
          "<br> The tester shall verify that the vendor provides documentation that specifies the effectiveness of the mitigation techniques. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "0",
    dtrs: [
      {
        dtrId: "ASA.01",
        level: "1",
        requirement:
          "This annex {ISO/IEC 19790:2012 Annex A} specifies the minimum documentation which shall be required for a cryptographic module that is to undergo an independent verification scheme {and the documentation shall meet those requirements}. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VEA.01.01",
        level: "1",
        requirement:
          "The vendor shall provide documentation for a cryptographic module that fulfils but is not limited to the minimum documentation requirements as specified in ISO/IEC 19790:2012, A.2.1 to A.2.12. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TEA.01.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides documentation for a cryptographic module that fulfils but is not limited to the minimum documentation requirements as specified in ISO/IEC 19790:2012, A.2.1 to A.2.12. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  }, // end of section
  {
    secId: "0",
    dtrs: [
      {
        dtrId: "ASB.01",
        level: "1",
        requirement:
          "The following list summarizes requirements that shall be provided in the non-proprietary Security Policy. <br> NOTE ISO/IEC 19790:2012, Annex B specifies the minimum requirements of a cryptographic module security policy. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VEB.01.01",
        level: "1",
        requirement:
          "The vendor shall provide a non-proprietary cryptographic module security policy that fulfils but is not limited to the minimum security policy requirements as specified in ISO/IEC 19790:2012, B.2.1 to B.2.12. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TEB.01.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides a non-proprietary cryptographic module security policy that fulfils but is not limited to the minimum security policy requirements as specified in ISO/IEC 19790:2012, B.2.1 to B.2.12. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ],
        tables: [
          {
            type: "select",
            conditions: [
              {
                details: {
                  controlName: "module-type",
                  label: "Type",
                  options: [
                    {
                      label: "Software",
                      value: "Software"
                    },
                    {
                      label: "Hardware",
                      value: "Hardware"
                    },
                    {
                      label: "Firmware",
                      value: "Firmware"
                    },
                    {
                      label: "Software-hybrid",
                      value: "Software-hybrid"
                    },
                    {
                      label: "Firmware-hybrid",
                      value: "Firmware-hybrid"
                    }
                  ]
                },
                default: true,
                mapsToPath: ""
              }
            ],
            title: "Module Type",
            position: 2,
            linkedTo: "module"
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "CAVP Cert", controlName: "CAVPCert" },
                    {
                      label: "Algorithm and Standard",
                      controlName: "algorithmAndStandard"
                    },
                    { label: "Mode/Method", controlName: "modeMethod" },
                    {
                      label: "Description/Key Size/Key Strength",
                      controlName: "descriptionKeySizeKeyStrength"
                    },
                    { label: "Use/Function", controlName: "useFunction" },
                    { label: "ValidationId", controlName: "ValidationId", hidden: true }
                  ],
                  controlName: "approvedAlgorithms"
                },
                default: false
              }
            ],
            title: "Table 5: Approved Algorithms",
            position: 6
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Algorithm", controlName: "algorithm" },
                    { label: "Caveat", controlName: "caveat" },
                    { label: "Use/Function", controlName: "useFunction" }
                  ],
                  controlName: "nonApprovedAlgorithms"
                },
                default: false
              }
            ],
            title:
              "Table 6: Non-Approved Algorithms Allowed in the Approved Mode of Operation",
            position: 7
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Algorithm", controlName: "algorithm" },
                    { label: "Caveat", controlName: "caveat" },
                    { label: "Use/Function", controlName: "useFunction" }
                  ],
                  controlName: "nonApprovedAllowedNoSecurityClaimed"
                },
                default: false
              }
            ],
            title:
              "Table 7: Non-Approved Allowed in the Approved Mode of Operation with No Security Claimed",
            position: 8
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Algorithm/Function", controlName: "algorithm" },
                    { label: "Use/Function", controlName: "useFunction" }
                  ],
                  controlName: "nonApprovedAllowedNoSecurityClaimedNotAllowed"
                },
                default: false
              }
            ],
            title:
              "Table 8: Non-Approved Algorithms Not Allowed In the approved Mode of Operation",
            position: 9
          },
          
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Physical port", controlName: "algorithm" },
                    {
                      label: "Logical interface",
                      controlName: "logicalInterface"
                    },
                    {
                      label: "Data that passes over port/interface",
                      controlName: "data"
                    }
                  ],
                  controlName: "portsAndInterfaces"
                },
                default: false
              }
            ],
            title: "Table 9: Ports and Interfaces",
            position: 12
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Roles", controlName: "roles" },
                    { label: "Service", controlName: "service" },
                    { label: "Input", controlName: "input" },
                    { label: "Output", controlName: "output" }
                  ],
                  controlName: "rolesServicesInputOutput"
                },
                default: false
              }
            ],
            title: "Table 10: Roles, Services, Input, and Output",
            position: 13
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Role", controlName: "role" },
                    {
                      label: "Authentication Method",
                      controlName: "authenticationMethod"
                    },
                    {
                      label: "Authentication Strength",
                      controlName: "authenticationStrength"
                    }
                  ],
                  controlName: "rolesAuthentication"
                },
                default: false
              }
            ],
            title: "Table 11: Roles and Authentication",
            position: 14
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Service", controlName: "service" },
                    { label: "Description", controlName: "description" },
                    {
                      label: "Approved Security functions",
                      controlName: "approvedSecurityFunctions"
                    },
                    { label: "Keys/SSPs", controlName: "keysSSPs" },
                    { label: "Roles", controlName: "roles" },
                    {
                      label: "Access rights to Keys/SSPs",
                      controlName: "accessRights"
                    },
                    { label: "Indicator", controlName: "indicator" }
                  ],
                  controlName: "approvedServices"
                },
                default: false
              }
            ],
            title: "Table 12: Approved Services",
            position: 15
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Service", controlName: "service" },
                    { label: "Description", controlName: "description" },
                    {
                      label: "Algorithms Accessed",
                      controlName: "algorithmsAccessed"
                    },
                    { label: "Role", controlName: "role" },
                    { label: "Indicator", controlName: "indicator" }
                  ],
                  controlName: "nonApprovedServices"
                },
                default: false
              }
            ],
            title: "Table 13: Non-Approved Services",
            position: 16
          },
          {
            type: "table",
            conditions: [
              {
                details: {
                  th: ["Section", "FIPS 140-3 Section Title", "Security Level"],
                  trs: [
                    //first row
                    [
                      {
                        label: "1"
                      },
                      {
                        label: "General"
                      },
                      {
                        type: "input",
                        controlName: "section1-level",
                      }
                    ],
                    //second row
                    [
                      {
                        label: "2"
                      },
                      {
                        label: "Cryptographic module specification"
                      },
                      {
                        type: "input",
                        controlName: "section2-level"
                      }
                    ],
                    [
                      {
                        label: "3"
                      },
                      {
                        label: "Cryptographic module interfaces"
                      },
                      {
                        type: "input",
                        controlName: "section3-level"
                      }
                    ],
                    [
                      {
                        label: "4"
                      },
                      {
                        label: "Roles, services, and authentication"
                      },
                      {
                        type: "input",
                        controlName: "section4-level"
                      }
                    ],
                    [
                      {
                        label: "5"
                      },
                      {
                        label: "Software/Firmware security"
                      },
                      {
                        type: "input",
                        controlName: "section5-level"
                      }
                    ],
                    [
                      {
                        label: "6"
                      },
                      {
                        label: "Operational environment"
                      },
                      {
                        type: "input",
                        controlName: "section6-level"
                      }
                    ],
                    [
                      {
                        label: "7"
                      },
                      {
                        label: "Physical security"
                      },
                      {
                        type: "input",
                        controlName: "section7-level"
                      }
                    ],
                    [
                      {
                        label: "8"
                      },
                      {
                        label: "Non-invasive security"
                      },
                      {
                        type: "input",
                        controlName: "section8-level"
                      }
                    ],
                    [
                      {
                        label: "9"
                      },
                      {
                        label: "Sensitive security parameter management"
                      },
                      {
                        type: "input",
                        controlName: "section9-level"
                      }
                    ],
                    [
                      {
                        label: "10"
                      },
                      {
                        label: "Self-tests"
                      },
                      {
                        type: "input",
                        controlName: "section10-level"
                      }
                    ],
                    [
                      {
                        label: "11"
                      },
                      {
                        label: "Life-cycle assurance"
                      },
                      {
                        type: "input",
                        controlName: "section11-level"
                      }
                    ],
                    [
                      {
                        label: "12"
                      },
                      {
                        label: "Mitigation of other attacks"
                      },
                      {
                        type: "input",
                        controlName: "section12-level"
                      }
                    ]
                  ]
                },
                default: true
              }
            ],
            linkedTo: "module",
            title: "Table 1: Security Levels",
            position: 1
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    {
                      label: "Operating System",
                      controlName: "operatingSystem"
                    },
                    {
                      label: "Hardware Platform",
                      controlName: "hardwarePlatform"
                    },
                    { label: "Processor", controlName: "processor" },
                    {
                      label: "PAA/Acceleration",
                      controlName: "paaAcceleration"
                    }
                  ],
                  controlName: "SFHTestedOperationalEnvironments"
                },
                default: false,
                condition: {
                  path: ["module", "module-type"],
                  values: [
                    "Software",
                    "Firmware",
                    "Software-hybrid",
                    "Firmware-hybrid"
                  ]
                }
              }
            ],
            title:
              "Table 2: Software, Firmware, Hybrid Tested Operational Environments",
            position: 3
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    {
                      label: "Operating System",
                      controlName: "operatingSystem"
                    },
                    {
                      label: "Hardware Platform",
                      controlName: "hardwarePlatform"
                    }
                  ],
                  controlName: "SFHAffirmedOperationalEnvironment"
                },
                default: false
              }
            ],
            title:
              "Table 3: Software, Hardware, Hybrid Vendor Affirmed Operational Environment",
            position: 4
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Model", controlName: "model" },
                    {
                      label: "Hardware [Part Number and Version]",
                      controlName: "hardware"
                    },
                    {
                      label: "Firmware Version",
                      controlName: "firmwareVersion"
                    },
                    {
                      label: "Distinguishing Features",
                      controlName: "distinguishingFeatures"
                    }
                  ],
                  controlName: "hardwareTestedConfiguration"
                },
                default: false,
                condition: {
                  path: ["module", "module-type"],
                  values: ["Hardware"]
                }
              }
            ],
            title: "Table 4: Hardware Tested Configuration",
            position: 5
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    {
                      label: "Physical security Mechanism",
                      controlName: "physicalSecurityMechanism"
                    },
                    {
                      label: "Recommended Frequency of Inspection/Test",
                      controlName: "recommendedFrequency"
                    },
                    {
                      label: "Inspection/Test Guidance Details",
                      controlName: "inspectionGuidanceDetails"
                    }
                  ],
                  controlName: "physicalSecurityInspectionGuidelines"
                },
                default: false
              }
            ],
            title: "Table 14: Physical Security Inspection Guidelines",
            position: 17
          },
          {
            type: "table",
            conditions: [
              {
                details: {
                  th: [
                    "",
                    "Hardness tested temperature measurement",
                  ],
                  trs: [
                    //first row
                    [
                      {
                        label: "Low Temperature"
                      },
                      {
                        type: "input",
                        controlName: "lowHardnessTemperatureMeasurement"
                      },
                  
                    ],
                    //second row
                    [
                      {
                        label: "High Temperature"
                      },
                      {
                        type: "input",
                        controlName: "highHardnessTemperatureMeasurement"
                      },
                  
                    ],
                 ]
                },
                default: true
              }
            ],

            title: "Table 16: Hardness testing temperature ranges",
            position: 19
          },
          {
            type: "table",
            conditions: [
              {
                details: {
                  th: [
                    "",
                    "Temperature or Voltage Measurement",
                    "EFP/EFT?",
                    "Specify if this condition results in a shutdown or zeroization"
                  ],
                  trs: [
                    //first row
                    [
                      {
                        label: "Low Temperature"
                      },
                      {
                        type: "input",
                        controlName: "lowTempMeasurement"
                      },
                      {
                        type: "input",
                        controlName: "lowTempEFP"
                      },
                      {
                        type: "input",
                        controlName: "lowTempResults"
                      }
                    ],
                    //second row
                    [
                      {
                        label: "High Temperature"
                      },
                      {
                        type: "input",
                        controlName: "highTempMeasurement"
                      },
                      {
                        type: "input",
                        controlName: "highTempEFP"
                      },
                      {
                        type: "input",
                        controlName: "highTempResults"
                      }
                    ],
                    [
                      {
                        label: "Low Voltage"
                      },
                      {
                        type: "input",
                        controlName: "lowVoltMeasurement"
                      },
                      {
                        type: "input",
                        controlName: "lowVoltEFP"
                      },
                      {
                        type: "input",
                        controlName: "lowVoltResults"
                      }
                    ],
                    [
                      {
                        label: "High Voltage"
                      },
                      {
                        type: "input",
                        controlName: "highVoltMeasurement"
                      },
                      {
                        type: "input",
                        controlName: "highVoltEFP"
                      },
                      {
                        type: "input",
                        controlName: "highVoltResults"
                      }
                    ]
                  ]
                },
                default: true
              }
            ],

            title: "Table 15: EFP/EFT",
            position: 18
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Key/SSP/Name/Type", controlName: "KeySSPNameType" },
                    {
                      label: "Strength",
                      controlName: "strength"
                    },
                    { label: "Security Function Cert Number", controlName: "securityFunctionCertNumber" },
                    {
                      label: "Generation",
                      controlName: "generation"
                    },
                    { label: "Import/Export", controlName: "importExport" },
                    { label: "Establishment", controlName: "establishment" },
                    { label: "Storage", controlName: "storage" },
                    { label: "Zeroization", controlName: "zeroization" },
                    { label: "Use & related keys", controlName: "relatedKeys" },

                  ],
                  controlName: "ssps"
                },
                default: false
              }
            ],
            title: "Table 17: SSPs",
            position: 20
          },
          {
            type: "dynamicTable",
            conditions: [
              {
                details: {
                  th: [
                    { label: "Entropy Sources", controlName: "entropySources" },
                    {
                      label: "Minimum number of bits of entropy",
                      controlName: "minimumNumberOfBits ofEntropy"
                    },
                    { label: "Details", controlName: "details" },
 
                  ],
                  controlName: "nonDeterministicRandomNumberGenerationSpecification"
                },
                default: false
              }
            ],
            title: "Table 18: Non-Deterministic Random Number Generation Specification",
            position: 21
          }
        ]
     
      },
      {
        dtrId: "ASB.02",
        level: "1",
        requirement:
          "The format of the security policy shall be presented in the order indicated in this Appendix <br> {ISO/IEC 19790:2012 Annex B} or as specified by a validation authority. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VEB.02.01",
        level: "1",
        requirement:
          "The vendor shall provide a non-proprietary cryptographic module security policy that is presented in the order specified in ISO/IEC 19790:2012, B.2.1 to B.2.12 or as specified by a validation authority. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TEB.02.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provides a non-proprietary cryptographic module security policy that is presented in the order specified in ISO/IEC 19790:2012, B.2.1 to B.2.12 or as specified by a validation authority. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "ASB.03",
        level: "1",
        requirement:
          "The security policy shall not be marked as proprietary or copyrighted without a statement allowing copying or distribution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VEB.03.01",
        level: "1",
        requirement:
          "The vendor shall provide a security policy that is not marked as proprietary or copyrighted. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "VEB.03.02",
        level: "1",
        requirement:
          "If the vendor provided security policy is marked copyrighted then it shall include a statement allowing copying or distribution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TEB.03.01",
        level: "1",
        requirement:
          "The tester shall verify that the vendor provided security policy is not marked as proprietary or copyrighted. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      },
      {
        dtrId: "TEB.03.02",
        level: "1",
        requirement:
          "If the vendor provided security policy is marked copyrighted then the tester shall verify that it includes a statement allowing copying or distribution. <br>",
        testResult: "",
        assessment: "",
        testName: "",
        testDate: "",
        testStatus: "",
        reviewName: "",
        reviewDate: "",
        reviewContent: "",
        references: [
          {
            link: "",
            label: ""
          }
        ]
      } // end of dtrs
    ]
  } // end of section
];
