export const LabNames = [
  { label: "CYGNACOM SOLUTIONS INC", value: "CYGNACOM SOLUTIONS INC" },
  { label: "COACT INC CAFE LAB", value: "COACT INC CAFE LAB" },
  { label: "EWA CANADA", value: "EWA CANADA" },
  {
    label: "UL VERIFICATION SERVICES INC",
    value: "UL VERIFICATION SERVICES INC",
  },
  {
    label: "TÜV INFORMATIONSTECHNIK GMBH",
    value: "TÜV INFORMATIONSTECHNIK GMBH",
  },
  {
    label: "ATSEC INFORMATION SECURITY CORP",
    value: "ATSEC INFORMATION SECURITY CORP",
  },
  { label: "LEIDOS CSTL", value: "LEIDOS CSTL" },
  { label: "ÆGISOLVE", value: "ÆGISOLVE" },
  { label: "ECSEC LABORATORY INC", value: "ECSEC LABORATORY INC" },
  {
    label: "DEKRA Testing and Certification S.A.U",
    value: "DEKRA Testing and Certification S.A.U",
  },
  { label: "IT SECURITY CENTER", value: "IT SECURITY CENTER" },
  { label: "BOOZ ALLEN HAMILTON", value: "BOOZ ALLEN HAMILTON" },
  {
    label: "ADVANCED DATA SECURITY LLC",
    value: "ADVANCED DATA SECURITY LLC",
  },
  { label: "PENUMBRA SECURITY", value: "PENUMBRA SECURITY" },
  {
    label: "GOSSAMER SECURITY SOLUTIONS INC",
    value: "GOSSAMER SECURITY SOLUTIONS INC",
  },
  { label: "ACUMEN SECURITY, LLC", value: "ACUMEN SECURITY, LLC" },
  {
    label: "ASIA PACIFIC IT LABORATORY, TÜV NORD",
    value: "ASIA PACIFIC IT LABORATORY, TÜV NORD",
  },
  {
    label: "SERMA TECHNOLOGIES ITSEF",
    value: "SERMA TECHNOLOGIES ITSEF",
  },
  {
    label: "Lightship Security, Inc.",
    value: "Lightship Security, Inc.",
  },
  { label: "CyberSecurity Malaysia", value: "CyberSecurity Malaysia" },
];
