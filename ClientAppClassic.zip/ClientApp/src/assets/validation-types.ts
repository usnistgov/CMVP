export const ValidationTypes = [
    {
      label: "New Validation",
      value: "new",
    },
    {
      label: "Revalidation",
      value: "reval",
    },
  
  ];
  