export const RevalidationTypes = [

    {
      label: "Vendor Update (VUP)",
      value: "VUP",
    },
    // {
    //   label: "Vendor Approved Operating Environment (VAOE)",
    //   value: "VAOE"
    // },
    // {
    //   label: "Rebrand (RBND)",
    //   value: "RBND"
    // }
  ];
  