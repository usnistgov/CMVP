export const TransactionTypes = [
  {
    label: "Full Submission",
    value: "FS",
  },
  // {
  //   label: "IUTA",
  //   value: "IUTA",
  // },
  // {
  //   label: "IUTB",
  //   value: "IUTB",
  // },
  // {
  //   label: "IUTC",
  //   value: "IUTC",
  // },
  // {
  //   label: "IUTR",
  //   value: "IUTR",
  // },
  // {
  //   label: "IUTM",
  //   value: "IUTM",
  // },

  {
    label: "sCMn – CMVP comments or returned CSTL addressed comments",
    value: "sCMn",
  },

  {
    label: "DRPT – CSTL request to DROP report",
    value: "DRPT",
  },

  {
    label: "STAT – Query report status",
    value: "STAT",
  },
  {
    label: "OTHR – Other",
    value: "OTHR",
  },
  {
    label: "Draft Certificate Approve",
    value: "FCLC_OK",
  },
  {
    label: "Draft Certificate Reject",
    value: "FCLC",
  },

  /*
  {
    "label": "Physical Change",
    "value": "4"
  },
  {
    "label": "Minor Change",
    "value": "3"
  },
  {
    "label": "Security Issue",
    "value": "3A"
  },
  {
    "label": "Maintenence Update",
    "value": "3B"
  },
  {
    "label": "Susnet Change",
    "value": "2"
  },
  {
    "label": "Update SP",
    "value": "1"
  },
  {
    "label": "OEM",
    "value": "1A"
  },
  {
    "label": "Lab Change",
    "value": "1B"
  },
  */
];
