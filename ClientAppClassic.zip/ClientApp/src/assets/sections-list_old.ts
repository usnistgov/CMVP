export const sectionsList = [
    {
        "secId": "1",
        "comments": {
        },
        "dtrs": [
            {
                "dtrId": "AS.01.01",
                "level": "1",
                "requirement": "This clause specifies the security requirements that shall be satisfied by the cryptographic module�s compliance to {ISO/IEC 19790:2012}.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.01.02",
                "level": "1",
                "requirement": "A cryptographic module shall be tested against the requirements of each area addressed in this clause.  NOTE The tests can be performed in one or more of the following manners.  a) Tester performs tests at the tester�s facility.  b) Tester performs tests at the vendor�s facility.  c) Tester supervises vendor performing tests at the vendor�s facility.  - Rationale is included that explains why tester could not perform the tests.  - Tester develops the required test plan and required tests.  - Tester directly observes the tests being performed.  An assertion fails if any of its subsequent tests fails.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.01.03",
                "level": "1",
                "requirement": "This clause specifies the security requirements that shall be satisfied by the cryptographic module�s compliance to {ISO/IEC 19790:2012}.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.01.04",
                "level": "1",
                "requirement": "All documentation, including copies of the user and installation manuals, design specifications, life-cycle documentation shall be provided for a cryptographic module that is to undergo an independent verification or evaluation scheme.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            }
        ]
    },
    {
        "secId": "2",
        "dtrs": [
            {
                "dtrId": "AS.02.01",
                "level": "1",
                "requirement": "A cryptographic module shall be a set of hardware, software, firmware, or some combination thereof, that at a minimum, implements a defined cryptographic service employing an approved cryptographic algorithm, security function or process and contained within a defined cryptographic boundary. NOTE: This assertion is not separately tested.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.02",
                "level": "1",
                "requirement": "The documentation requirements specified in {ISO/IEC 19790:2012} A.2.2 shall be provided.  NOTE: This assertion is tested as part of ASA.01.  6.2.2 Types of cryptographic modules ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.03",
                "level": "1",
                "requirement": "A cryptographic module shall be defined as one of the following module types: - Hardware module is a module whose cryptographic boundary is specified at a hardware perimeter. Firmware and/or software, which may also include an operating system, may be included within this hardware cryptographic boundary.  - Software module is a module whose cryptographic boundary delimits the software exclusive component(s) (may be one or multiple software components) that execute(s) in a modifiable operational environment. The computing platform and operating system of the operational environment which the software executes in are external to the defined software module boundary.  - Firmware module is a module whose cryptographic boundary delimits the firmware exclusive component(s) that execute(s) in a limited or non-modifiable operational environment. The computing platform and operating system of the operational environment which the firmware executes in are external to the defined firmware module boundary but explicitly bound to the firmware module.  - Hybrid Software module is a module whose cryptographic boundary delimits the composite of a software component and a disjoint hardware component (i.e. the software component is not contained within the hardware module boundary). The computing platform and operating system of the operational environment which the software executes in are external to the defined hybrid software module boundary.  - Hybrid Firmware module is a module whose cryptographic boundary delimits the composite of a firmware component and a disjoint hardware component (i.e. the firmware component is not contained within the hardware module boundary). The computing platform and operating system of the operational environment which the firmware executes in are external to the defined hybrid firmware module boundary but explicitly bound to the hybrid firmware module.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.03.01",
                "level": "1",
                "requirement": "The vendor shall provide a description of the cryptographic module describing the type of cryptographic module. It will explain the rationale of the module type selection.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.03.02",
                "level": "1",
                "requirement": "The vendor shall provide a specification of the cryptographic module identifying all hardware, software, and/or firmware components of the cryptographic module.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.03.01",
                "level": "1",
                "requirement": "The tester shall verify that the vendor provided documentation identifies one of the module types listed in AS02.03.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.03.02",
                "level": "1",
                "requirement": "The tester shall verify from the vendor provided specification documentation, by identifying all hardware, software, and/or firmware components (AS02.15 to AS02.18), that the cryptographic module is consistent with the type of the cryptographic module.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.03.02",
                "level": "1",
                "requirement": "The tester shall verify from the vendor provided specification documentation, by identifying all hardware, software, and/or firmware components (AS02.15 to AS02.18), that the cryptographic module is consistent with the type of the cryptographic module.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.04",
                "level": "1",
                "requirement": "For hardware and firmware modules, the applicable physical security and non-invasive security requirements found in (ISO/IEC 19790:2012) 7.7 and 7.8 shall apply.  NOTE: This assertion is not tested separately.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.05",
                "level": "1",
                "requirement": "For software modules executing in a modifiable environment, the physical security requirements found in (ISO/IEC 19790:2012) 7.7 are optional and the applicable non-invasive security requirements in (ISO/IEC 19790:2012) 7.8 shall apply.  NOTE\tThis assertion is not tested separately.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.07",
                "level": "1",
                "requirement": "The cryptographic boundary shall consist of an explicitly defined perimeter (i.e. set of hardware, software or firmware components) that establishes the boundary of all components of the cryptographic module.  Required Vendor Information VE02.07.01: The vendor documentation shall specify all components within the cryptographic boundary.  Required Test Procedures",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": ""
            },
            {
                "dtrId": "VE.02.07.01",
                "level": "1",
                "requirement": "The vendor documentation shall specify all components within the cryptographic boundary.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.07.01",
                "level": "1",
                "requirement": "The tester shall verify by inspection and from the vendor documentation that all the components specified in AS02.15 to AS02.18 are within the cryptographic boundary. ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.07.02",
                "level": "1",
                "requirement": "The tester shall verify by inspection and from the vendor documentation that there are no unidentified components which are not specified in AS02.15 to AS02.18 within the cryptographic boundary.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.08",
                "level": "1",
                "requirement": "The requirements of {ISO/IEC 19790:2012} shall apply to all algorithms, security functions, processes, and components within the module�s cryptographic boundary.  NOTE\tThis assertion is not tested separately.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.09",
                "level": "1",
                "requirement": "The cryptographic boundary shall, at a minimum, encompass all security relevant algorithms, security functions, processes, and components of a cryptographic module (i.e. security relevant within the scope of this document).  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.09.01",
                "level": "1",
                "requirement": "The tester shall verify that the vendor provided documentation clearly identifies and lists all the security relevant algorithms, security functions, processes, and components of the module within the cryptographic boundary.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.10",
                "level": "1",
                "requirement": "Non-security relevant algorithms, security functions, processes or components which are used in an approved mode of operation shall be implemented in a manner to not interfere or compromise the approved operation of the cryptographic module.  VE02.10.01: The vendor provided documentation shall list the non-security relevant functions used in an approved mode of operation and justify that they are not interfering with the approved mode of operation of the module.  Required Test Procedures",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.10.01",
                "level": "1",
                "requirement": "The vendor provided documentation shall list the non-security relevant functions used in an approved mode of operation and justify that they are not interfering with the approved mode of operation of the module.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.10.01",
                "level": "1",
                "requirement": "The tester shall verify through documentation review and inspection of the module that the non-security relevant functions are not interfering or compromising the approved mode of operation of the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.10.02",
                "level": "1",
                "requirement": "The tester shall verify the correctness of any rationale for not interfering nor compromising provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.11",
                "level": "1",
                "requirement": "The defined name of a cryptographic module shall be representative of the composition of the components within the cryptographic boundary and not representative of a larger composition or product.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.11.01",
                "level": "1",
                "requirement": "The vendor shall provide the defined name of the module.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.11.01",
                "level": "1",
                "requirement": "The tester shall verify that the vendor provided module name is consistent with the composition of the components within the cryptographic boundary.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.11.02",
                "level": "1",
                "requirement": "The tester shall verify that the module name does not represent a composition of components or functions that are not consistent with the composition of the components within the cryptographic boundary.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.12",
                "level": "1",
                "requirement": "The cryptographic module shall have, at minimum, specific versioning information representing the distinct individual hardware, software, and/or firmware components.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": ""
            },
            {
                "dtrId": "VE.02.12.01",
                "level": "1",
                "requirement": "The vendor shall provide the versioning information of the modules distinct individual hardware, software, and/or firmware components.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.12.01",
                "level": "1",
                "requirement": "The tester shall verify the versioning information represents the modules distinct individual hardware, software, and/or firmware components.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.13",
                "level": "1",
                "requirement": "The excluded hardware, software or firmware components shall be implemented in a manner to not interfere or compromise the approved secure operation of the cryptographic module.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.13.01",
                "level": "1",
                "requirement": "The vendor shall describe the excluded components of the module and justify that these components will not interfere with the approved secure operation of the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.13.02",
                "level": "1",
                "requirement": "The vendor documentation shall provide the rationale for excluding each of the components. The rationale shall describe how each excluded component, when working properly or when it malfunctions, cannot interfere with the approved secure operation of the module. Rationale that may be acceptable, if adequately supported by documentation, includes the following.  a) The component is not connected with security relevant components of the module that would allow inappropriate transfer of SSPs, plaintext data, or other information that could interfere with the approved secure operation of the module.  b) All information processed by the component is strictly for internal use of the module, and does not in any way impact the correctness of control, status or data outputs.  Required Test Procedures",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.13.01",
                "level": "1",
                "requirement": "The tester shall verify from the vendor provided documentation that the excluded components of the cryptographic boundary will not interfere with the approved secure operation of the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.13.02",
                "level": "1",
                "requirement": "The tester shall verify the correctness of any rationale for exclusion provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.13.03",
                "level": "1",
                "requirement": "The tester shall manipulate (e.g. to cause the component to operate not as designed) the excluded components in a manner to cause incorrect operation of the excluded component. The tester shall verify that the incorrect operation of the excluded component shall not interfere with the approved secure operation of the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.14",
                "level": "1",
                "requirement": "The excluded hardware, software or firmware shall be specified {ISO/IEC 19790:2012} (Annex A).  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "label": "",
                        "link": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.14.01",
                "level": "1",
                "requirement": "All components that are to be excluded from the security requirements shall be explicitly listed in the vendor documentation.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.14.01",
                "level": "1",
                "requirement": "The tester shall verify whether the vendor indicates that any components of the module are to be excluded from the requirements of ISO/IEC 19790:2012.  6.2.3.2 Definitions of cryptographic boundary ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.15",
                "level": "1",
                "requirement": "The cryptographic boundary of a hardware cryptographic module shall delimit and identify: � the set of hardware components which may include: � physical structures, including circuit boards, substrates or other mounting surfaces that provide the interconnecting physical wiring between components; � active electrical components such as semi-integrated, custom-integrated or common-integrated circuits, processors, memory, power supplies, converters, etc.; � physical structures, such as enclosures, potting or encapsulation materials, connectors, and interfaces; � firmware, which may include an operating system; � other components types not listed above.  Required Vendor Information",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.15.01",
                "level": "1",
                "requirement": "All hardware components of the cryptographic module shall be identified in the vendor documentation. Components to be listed shall include all of the following: a) physical structures, including circuit boards, substrates or other mounting surfaces that provide the interconnecting physical wiring between components: 1) circuit boards, substrates and mounting surfaces; b) active electrical components such as semi-integrated, custom-integrated or common-integrated circuits, processors, memory, power supplies, converters, etc.: 1) processors, including microprocessors, digital signal processors, custom processors, microcontrollers, or any other types of processors (identify manufacturer and type); 2) read-only memory (ROM) integrated circuits for program executable code and data (this may include mask-programmed ROM, programmable ROM (PROM) such as ultraviolet, erasable PROM (EPROM), electrically erasable PROM (EEPROM), or Flash-memory); 3) random-access memory (RAM) or other integrated circuits for temporary data storage; 4) semi-custom, application-specific integrated circuits, such as gate arrays, programmable logic arrays, field programmable gate arrays, or other programmable logic devices; 5) fully custom, application-specific integrated circuits, including any custom cryptographic integrated circuits; 6) power supply components, including power supply, power converters (e.g. AC-to-DC or DC-to-DC modules, transformers), input power connectors, and output power connectors; 7) other active electronic circuit elements (passive circuit elements such as pull up/pull down resistors or bypass capacitors do not need to be included if they do not provide security relevant function as part of the cryptographic module); c) physical structures, such as enclosures, potting or encapsulation materials, connectors, and interfaces: 1) physical structures and enclosures, including any removable access doors or covers; 2) potting or encapsulation materials; 3) boundary connectors; 4) connectors between major independent sub assemblies within the module; d) firmware, which may include an operating system: 1) executable code: i) non-modifiable ii) modifiable e)\tother components types not listed above: 1) cooling or heating arrangements, such as conduction plates, cooling airflow, heat exchanger, cooling fins, fans, heaters, or other arrangements for removing or adding heat.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.15.02",
                "level": "1",
                "requirement": "The vendor documentation shall indicate the internal layout and assembly methods (e.g. fasteners and fittings) of the module, including drawings that are at least approximately to scale.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.15.03",
                "level": "1",
                "requirement": "The vendor documentation shall describe the primary physical parameters of the module, including descriptions of the enclosure, access points, circuit boards, location of power supply, interconnection wiring runs, cooling arrangements, and any other significant parameters.  VE02.15.04: The vendor documentation shall include a block diagram which represents the module�s boundary and relationship of the hardware components.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.15.04",
                "level": "1",
                "requirement": "The vendor documentation shall include a block diagram which represents the module�s boundary and relationship of the hardware components.  Required Test Procedures",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.01",
                "level": "1",
                "requirement": "The tester shall identify all hardware components of the cryptographic module. Components to be listed shall include all of the following: a) physical structures, including circuit boards, substrates or other mounting surfaces that provide the interconnecting physical wiring between components: 1)\tcircuit boards, substrates and mounting surfaces; b) active electrical components such as semi-integrated, custom-integrated or common-integrated circuits, processors, memory, power supplies, converters, etc.: 1) processors, including microprocessors, digital signal processors, custom processors, microcontrollers, or any other types of processors (identify manufacturer and type); 2) read-only memory (ROM) integrated circuits for program executable code and data (this may include mask-programmed ROM, programmable ROM (PROM) such as ultraviolet, erasable PROM (EPROM), electrically erasable PROM (EEPROM), or Flash-memory; 3) random-access memory (RAM) or other integrated circuits for temporary data storage; 4) semi-custom, application-specific integrated circuits, such as gate arrays, programmable logic arrays, field programmable gate arrays, or other programmable logic devices; 5) fully custom, application-specific, integrated circuits, including any custom cryptographic integrated circuits; 6) power supply components, including power supply, power converters (e.g. AC-to-DC or DC-to-DC modules, transformers), input power connectors, and output power connectors; 7) other active electronic circuit elements (passive circuit elements such as pull up/pull down resistors or bypass capacitors do not need to be included if they do not provide security relevant function as part of the cryptographic module); c) physical structures, such as enclosures, potting or encapsulation materials, connectors, and interfaces: 1) physical structures and enclosures, including any removable access doors or covers; 2) potting or encapsulation materials; 3) boundary connectors; 4) connectors between major independent sub assemblies within the module; d) firmware, which may include an operating system: 1) executable code: i) non-modifiable ii) modifiable e)\tother components types not listed above: 1) cooling or heating arrangements, such as conduction plates, cooling airflow, heat exchanger, cooling fins, fans, heaters, or other arrangements for removing or adding heat.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.02",
                "level": "1",
                "requirement": "\"The tester shall verify that the components list is consistent with information provided for other assertions of 6.2.3, as defined below.  a) The specification of the cryptographic boundary under assertion AS02.07. Verify that all components inside the cryptographic boundary are included in the components list and vice versa. Also verify that any components outside the cryptographic boundary are not listed as components of the cryptographic module.  b) The specification of the block diagram under assertion ASA.01. Verify that any individual components identified in the block diagram (e.g. processors, application specific integrated circuits) are also listed in the components list.  c) Any components that are to be excluded from the requirements of ISO/IEC 19790:2012 under the provisions of assertions AS02.13 and AS02.14. Verify that components to be so excluded are still listed in the components list.",
                "\",": null,
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.03",
                "level": "1",
                "requirement": "The tester shall verify that the cryptographic boundary is physically contiguous, such that there are no gaps that could allow uncontrolled input, output, or other access into the cryptographic module. (Physical protection and tamper protection are covered separately in requirements under ISO/IEC 19790:2012, 7.7.) The module design has to also ensure that there are no uncontrolled interfaces into or out of the cryptographic module.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.04",
                "level": "1",
                "requirement": "The tester shall verify that the cryptographic boundary encompasses all components that are identified in the block diagram under assertion ASA.01 as inputting, outputting, or processing SSPs, plaintext data, or other information.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.05",
                "level": "1",
                "requirement": "As a partial exception to the above requirements, the vendor is allowed to exclude certain components from the requirements of ISO/IEC 19790:2012 after satisfying the requirements under assertions AS02.13 and AS02.14 in 6.2.3.1. The tester shall verify that any interfaces or physical connections between such excluded components and the rest of the module do not allow the following: a) uncontrolled release of CSPs, plaintext data, or other information that if misused could lead to a compromise; b) uncontrolled modifications of SSPs or other information that could lead to a compromise.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.06",
                "level": "1",
                "requirement": "The tester shall verify that the vendor�s documentation shows the internal layout of the module, including the placement and approximate dimensions of major identifiable components of the module. This has to include drawings that are at least approximately to scale.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "assessment": "",
                "dtrId": "TE.02.15.07",
                "level": "1",
                "requirement": "The tester shall verify that the vendor�s documentation indicates the major physical assemblies of the module and how they are assembled or inserted into the module.",
                "reviewContent": "",
                "reviewDate": "",
                "reviewName": "",
                "testDate": "",
                "testName": "",
                "testResult": "",
                "testStatus": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.08",
                "level": "1",
                "requirement": "The tester shall verify that the vendor�s documentation indicates the major physical assemblies of the module and how they are assembled or inserted into the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.08",
                "level": "1",
                "requirement": "The tester shall verify that the vendor�s documentation indicates the major physical assemblies of the module and how they are assembled or inserted into the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.15.09",
                "level": "1",
                "requirement": "The tester shall verify that the vendor�s documentation indicates the major physical assemblies of the module and how they are assembled or inserted into the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.16",
                "level": "1",
                "requirement": "The cryptographic boundary of a software cryptographic module shall delimit and identify - the set of executable file or files that constitute the cryptographic module, and - the instantiation of the cryptographic module saved in memory and executed by one or more processors.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.16.01",
                "level": "1",
                "requirement": " All software components of the cryptographic module shall be identified in the vendor documentation. Components to be listed shall include all of the following: a) the set of executable file or files that constitute the cryptographic module; b) other security relevant component types not listed above. ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.16.02",
                "level": "1",
                "requirement": "The vendor documentation shall indicate the internal software architecture, including how the software components interact.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.16.03",
                "level": "1",
                "requirement": "The vendor documentation shall indicate the software environment (e.g. operating system, run-time library, etc.) on which the module executes.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.16.01",
                "level": "1",
                "requirement": "The tester shall verify that the documentation includes a components list that includes all software components of the cryptographic module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.16.02",
                "level": "1",
                "requirement": "The tester shall verify that the components list includes all occurrences of the following types of components, excluding only component types that are not used in the module: a) the set of executable file or files that constitute the cryptographic module; b) other component types not listed above.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.16.03",
                "level": "1",
                "requirement": "The tester shall verify that the components list is consistent with information provided for other assertions of 6.2.3, as defined below.  a) The specification of the cryptographic boundary under assertion AS02.07. Verify that all components inside the cryptographic boundary are included in the components list and vice versa. Also verify that any components outside the cryptographic boundary are not listed as components of the cryptographic module.  b) The specification of the software under assertion ASA.01. Verify that the list of software components is the same as in the specifications under assertion AS02.07.  c) The specification of the block diagram under assertion ASA.01. Verify that any individual components identified in the block diagram are also listed in the components list.  d) Any components that are to be excluded from the requirements of ISO/IEC 19790:2012 under the provisions of assertions AS02.13 and AS02.14. Verify that components to be so excluded are still listed in the components list.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.16.04",
                "level": "1",
                "requirement": " As a partial exception to the above requirements, the vendor is allowed to exclude certain components from the requirements of ISO/IEC 19790:2012 after satisfying the requirements under assertions AS02.13 and AS02.14 in 6.2.3.1. The tester shall verify that any interfaces or physical connections between such excluded components and the rest of the module do not allow the following: a) uncontrolled release of CSPs, plaintext data, or other information that if misused could lead to a compromise; b) uncontrolled modifications of SSPs or other information that could lead to a compromise.  TE02.16.05: The tester shall verify that the vendor�s documentation indicates the major software components of the module and how they are linked together forming the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.17",
                "level": "1",
                "requirement": " As a partial exception to the above requirements, the vendor is allowed to exclude certain components from the requirements of ISO/IEC 19790:2012 after satisfying the requirements under assertions AS02.13 and AS02.14 in 6.2.3.1. The tester shall verify that any interfaces or physical connections between such excluded components and the rest of the module do not allow the following: a) uncontrolled release of CSPs, plaintext data, or other information that if misused could lead to a compromise; b) uncontrolled modifications of SSPs or other information that could lead to a compromise.  TE02.16.05: The tester shall verify that the vendor�s documentation indicates the major software components of the module and how they are linked together forming the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.01",
                "level": "1",
                "requirement": "All firmware components of the cryptographic module shall be identified in the vendor documentation. Components to be listed shall include all of the following: a) the set of executable file or files that constitute the cryptographic module; b) other security relevant component types not listed above.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.02",
                "level": "1",
                "requirement": "The vendor documentation shall indicate the internal firmware architecture, including how the firmware components interact.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.03",
                "level": "1",
                "requirement": "The vendor documentation shall indicate the firmware environment (e.g. operating system, run-time library, etc.) on which the module executes.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.01",
                "level": "1",
                "requirement": "The tester shall verify that the documentation includes a components list that includes all firmware components of the cryptographic module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.02",
                "level": "1",
                "requirement": "The tester shall verify that the components list includes all occurrences of the following types of components, excluding only component types that are not used in the module: a) the set of executable file or files that constitute the cryptographic module; b) other component types not listed above.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.03",
                "level": "1",
                "requirement": "The tester shall verify that the components list is consistent with information provided for other assertions of 6.2.3, as defined below.  a) The specification of the cryptographic boundary under assertion AS02.07. Verify that all components inside the cryptographic boundary are included in the components list and vice versa. Also verify that any components outside the cryptographic boundary are not listed as components of the cryptographic module.  b) The specification of the firmware under assertion ASA.01. Verify that the list of firmware components is the same as in the specifications under assertion AS02.07.  c) The specification of the block diagram under assertion ASA.01. Verify that any individual components identified in the block diagram are also listed in the components list.  d) Any components that are to be excluded from the requirements of ISO/IEC 19790:2012 under the provisions of assertions AS02.13 and AS02.14. Verify that components to be so excluded are still listed in the components list.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.04",
                "level": "1",
                "requirement": "As a partial exception to the above requirements, the vendor is allowed to exclude certain components from the requirements of ISO/IEC 19790:2012 after satisfying the requirements under assertions AS02.13 and AS02.14 in 6.2.3.1. The tester shall verify that any interfaces or physical connections between such excluded components and the rest of the module do not allow the following: a) uncontrolled release of CSPs, plaintext data, or other information that if misused could lead to a compromise; b) uncontrolled modifications of SSPs or other information that could lead to a compromise.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.17.05",
                "level": "1",
                "requirement": "The tester shall verify that the vendor�s documentation indicates the major firmware components of the module and how they are linked together forming the module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.18",
                "level": "1",
                "requirement": "The cryptographic boundary of a hybrid cryptographic module shall: � be the composite of the module�s hardware component boundary and the disjoint software or firmware component(s) boundary; and � include the collection of all ports and interfaces from each component.  NOTE	In addition to the disjoint software or firmware component(s), the hardware component can also include embedded software or firmware.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.18.01",
                "level": "1",
                "requirement": "TThe cryptographic module shall be identified in the vendor documentation as either a Hybrid Software Module or a Hybrid Firmware Module.  a) For Hybrid Software Module components, the vendor documentation shall provide information required under VE02.15.01 to VE02.15.04 and VE02.16.01 to VE02.16.03.  b) For Hybrid Firmware Module components, the vendor documentation shall provide information required under VE02.15.01 to VE02.15.04 and VE02.17.01 to VE02.17.03.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.19",
                "level": "1",
                "requirement": "The operator shall be able to operate the module in an approved mode of operation.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.19.01",
                "level": "1",
                "requirement": "The vendor provided non-proprietary security policy shall provide a description of the approved mode of operation.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.19.02",
                "level": "1",
                "requirement": " The vendor provided non-proprietary security policy shall provide instructions for invoking the approved mode of operation.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.19.01",
                "level": "1",
                "requirement": " The tester shall verify that the vendor provided non-proprietary security policy contains a description of the approved mode of operation.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.19.02",
                "level": "1",
                "requirement": "The tester shall invoke the approved mode of operation using the vendor provided instructions found in the non-proprietary security policy. The tester shall verify, by inspection and from the vendor documentation, that the cryptographic module is the approved mode of operation as a result of documented instructions.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.20",
                "level": "1",
                "requirement": "An approved mode of operation shall be defined as the set of services which include at least one service that utilizes an approved cryptographic algorithm, security function or process and those services or processes specified in (ISO/IEC 19790:2012) 7.4.3.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.20.01",
                "level": "1",
                "requirement": "The vendor shall provide a validation certificate for each approved security function.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.20.02",
                "level": "1",
                "requirement": "The vendor shall provide a list of all non-approved security functions.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.20.01",
                "level": "1",
                "requirement": "The tester shall verify that the vendor has provided a validation certificate for each approved security function issued by a validation authority.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.20.02",
                "level": "1",
                "requirement": "The tester shall verify that the vendor has provided the list of non-approved security functions.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.21",
                "level": "1",
                "requirement": "on-approved cryptographic algorithms, security functions, and processes or other services not specified in (ISO/IEC 19790:2012) 7.4.3 shall not be utilized by the operator in an approved mode of operation unless the non-approved cryptographic algorithm or security function is part of an approved process and is not security relevant to the approved processes operation (e.g. a non-approved cryptographic algorithm or non-approved generated key may be used to obfuscate data or CSPs but the result is considered unprotected plaintext and provides no security relevant functionality until protected with an approved cryptographic algorithm).  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.21.01",
                "level": "1",
                "requirement": "The vendor provided documentation shall identify all of non-approved cryptographic algorithms, security functions or processes utilized for each service in each approved mode of operation.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.21.02",
                "level": "1",
                "requirement": "The vendor documentation shall provide a rationale for why utilized non-approved cryptographic algorithms, security functions or processes are considered non-security relevant to the approved processes operation.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.21.01",
                "level": "1",
                "requirement": "The tester shall verify by inspection that the vendor provided documentation identifies all of non-approved cryptographic algorithms, security functions or processes utilized for each service in each approved mode of operation.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.21.02",
                "level": "1",
                "requirement": "The tester shall verify the correctness of any rationale provided by the vendor. The burden of proof is on the vendor; if there is any uncertainty or ambiguity, the tester shall require the vendor to produce additional information as needed.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.22",
                "level": "1",
                "requirement": "CSPs shall be exclusive between approved and non-approved services and modes of operation (e.g. not shared or accessed).  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.22.01",
                "level": "1",
                "requirement": "The vendor shall provide a list of all CSPs within the module and identify their usage between approved and non-approved services and mode of operation.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.22.02",
                "level": "1",
                "requirement": "The vendor shall provide a description of how each CSP becomes exclusive between approved and non-approved services and modes of operation.  Required Test Procedures",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.22.01",
                "level": "1",
                "requirement": "The tester shall verify that the vendor provided documentation contains a description of the usage of each CSP in an approved or non-approved mode of operation.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.22.02",
                "level": "1",
                "requirement": "The tester shall verify by inspection and from the vendor documentation that the CSPs are exclusive between approved and non-approved services and modes of operation.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.23",
                "level": "1",
                "requirement": "The module�s security policy shall define the complete set of services that are provided for each defined mode of operation (both approved and non-approved).  NOTE	This assertion is tested under ASB.01.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.24",
                "level": "1",
                "requirement": "All services shall provide an indicator when the service utilizes an approved cryptographic algorithm, security function or process in an approved manner and those services or processes specified in (ISO/IEC 19790:2012) 7.4.3.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.24.01",
                "level": "1",
                "requirement": "The vendor provided documentation shall specify the indicator for each service.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.24.01",
                "level": "1",
                "requirement": "The tester shall verify that the vendor provided documentation contains a description of indicator when the service utilizes an approved cryptographic algorithm, security function or process in an approved manner.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.24.02",
                "level": "1",
                "requirement": "The tester shall execute all services and verify that the indicator provides an unambiguous indication of whether the service utilizes an approved cryptographic algorithm, security function or process in an approved manner or not.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.25",
                "level": "1",
                "requirement": "For a cryptographic module to operate in degraded operation, the following (ISO/IEC 19790:2012 AS02.26 to AS02.30) shall apply.  NOTE	This assertion is not separately tested.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.26",
                "level": "1",
                "requirement": "The degraded operation shall be entered only after exiting an error state.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.26.01",
                "level": "1",
                "requirement": "The vendor shall provide specification of degraded operation. For each degraded operation, the specification shall include: a) conditions of entry into and exit from the degraded operation; b) operational algorithms, security functions, services, or processes; c) non-operational algorithms, security functions, services, or processes; d) isolated mechanisms, functions, or components in the degraded operation; e) techniques to isolate mechanisms, functions, or components; f) status information provided in the degraded operation; g) status indicator if attempts are made to use a non-operational algorithm, security function, or process.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.26.01",
                "level": "1",
                "requirement": "The tester shall verify that the vendor provided documentation clearly identifies the degraded operation and its conditions of entry and exit.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.26.02",
                "level": "1",
                "requirement": "The tester shall use the vendor documentation to check that the degraded operation can only be accessed after exiting in error state. The tester shall check that the error status indicator (see AS03.11) is correctly positioned.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.26.03",
                "level": "1",
                "requirement": "The tester shall exercise the cryptographic module, causing it to operate in each degraded operation. For each degraded operation, the tester shall attempt to perform a service to verify that all conditional algorithm self-tests are performed prior to the first operational use of any cryptographic algorithm.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.26.04",
                "level": "1",
                "requirement": " The tester shall first exercise the cryptographic module, causing it to operate in each degraded operation. The tester shall next perform pre-operational self-tests to verify that the cryptographic module remains in degraded operation until such time the cryptographic module passes without failure all pre-operational self-tests successfully.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.26.05",
                "level": "1",
                "requirement": "The tester shall first exercise the cryptographic module, causing it to operate in each degraded operation. The tester shall next perform pre-operational self-tests, causing an error condition in pre-operational self-tests to occur. The tester shall verify that the cryptographic module does not remain in degraded operation but enters an error state.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.27",
                "level": "1",
                "requirement": "The module shall provide status information when re-configured and the degraded operation entered.  NOTE	This assertion is not separately tested. Tested as part of AS02.26.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.28",
                "level": "1",
                "requirement": "The mechanism or function that failed shall be isolated.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.28.01",
                "level": "1",
                "requirement": "The vendor documentation requirement is specified under VE02.26.02. The vendor design shall ensure that any failure from the failed mechanisms, functions, and components cannot interfere or compromise the approved operation of the cryptographic module.  Required Test Procedures ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.28.01",
                "level": "1",
                "requirement": "The tester shall verify by inspection and from the vendor documentation that failed mechanisms, functions, and components are isolated before entering degraded operation.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.28.02",
                "level": "1",
                "requirement": "The tester shall verify by inspection and from the vendor documentation that failed mechanisms, functions, and components cannot interfere or compromise the approved operation of the cryptographic module.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.29",
                "level": "1",
                "requirement": "All conditional algorithm self-tests shall be performed prior to the first operational use of the cryptographic algorithm after entering degraded operation.  NOTE	This assertion is not separately tested. Tested as part of AS02.26.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.30",
                "level": "1",
                "requirement": "Services shall provide an indicator if attempts are made to use a non-operational algorithm, security function, or process.  Required Vendor Information ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "VE.02.30.01",
                "level": "1",
                "requirement": "The vendor documentation requirement is specified under VE02.26.02. The vendor design shall ensure that service output includes an indicator if attempts are made to use a non-operational algorithm, security function, or process.  Required Test Procedures",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.30.01",
                "level": "1",
                "requirement": "The tester shall verify from the vendor documentation that services provide documented indicators if attempts are made to use a non-operational algorithm, security function, or process.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "TE.02.30.02",
                "level": "1",
                "requirement": "The tester shall exercise the cryptographic module and verify that the documented indicator is provided if attempts are made to use a non-operational algorithm, security function, or process.  ",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.31",
                "level": "1",
                "requirement": "The cryptographic module shall remain in degraded operation until such time the cryptographic module passes without failure all pre-operational self-tests successfully.  NOTE	This assertion is not separately tested. Tested as part of AS02.26.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            },
            {
                "dtrId": "AS.02.32",
                "level": "1",
                "requirement": "If the cryptographic module fails the pre-operational self-tests, the module shall not enter a degraded operation.  NOTE	This assertion is not separately tested. Tested as part of AS02.26.",
                "testResult": "",
                "assessment": "",
                "testName": "",
                "testDate": "",
                "testStatus": "",
                "reviewName": "",
                "reviewDate": "",
                "reviewContent": "",
                "references": [
                    {
                        "link": "",
                        "label": ""
                    }
                ]
            }
        ]
    }

] 
