export const ScenarioTypes = [
    {
        label: "Vendor Update",
        value: "VUP",
    },
    {
        label: "Vendor Affirmed OE",
        value: "VAOE",
    },
    {
        label: "Non-Security Relevant changes",
        value: "NSRL",
    },
    {
        label: "Algorithm update",
        value: "ALG",
    },
    {
        label: "OE update",
        value: "OEUP",
    },
    {
        label: "Rebrand",
        value: "RBND",
    },
    {
        label: "Port single chip	(OE update for single chip)",
        value: "PTSC",
    },
    {
        label: "Update",
        value: "UPDT",
    },
    {
        label: "Interim Validation update 2yr -> 5yr after … 2yr",
        value: "140B",
    },
    {
        label: "Common vulnerability disclosure",
        value: "CVE",
    },
    {
        label: "Algorithm transition",
        value: "TRNS",
    },
    {
        label: "Physical enclosure",
        value: "PHYS",
    },
    {
        label: "Full Submission",
        value: "PHYS",
    },
]