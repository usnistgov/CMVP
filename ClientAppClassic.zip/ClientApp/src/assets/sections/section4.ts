export const Section4 = [
    {
        "title": "AS.04.01",
        "description": "The operation of the cryptographic module shall be specified using a finite state (or equivalent) represented by a state transition diagram and/or a state transition table. (The state transition diagram and/or state transition table includes all operational and error states of the cryptographic module, the corresponding transitions from one state to another, the input events that cause transitions from one state to another, and the output events resulting from transitions from one state to another.) Note: This assertion is tested as part of AS04.05.",
        "formInputs": [
            {
                "controlName": "AS.04.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.04.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.04.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.04.02",
        "description": "The cryptographic module shall include the following operational and error states: <ul> <li> Power on/off states.  States for primary, secondary, or backup power.  These states may distinguish between power sources being applied to the cryptographic module.  <li> Crypto officer states.  States in which the crypto officer services are performed (e.g., cryptographic initialization and key management).  <li> Key/CSP entry states.  States for entering cryptographic keys and CSPs into the cryptographic module.  <li> User states.  States in which authorized users obtain security services, perform cryptographic operations, or perform other Approved or non-Approved functions.  <li> Self-test states.  States in which the cryptographic module is performing self-tests.  <li> Error states.  States when the cryptographic module has encountered an error (e.g., failed a self-test or attempted to encrypt when missing operational keys or CSPs).  Error states may include \"hard\" errors that indicate an equipment malfunction and that may require maintenance, service or repair of the cryptographic module, or recoverable \"soft\" errors that may require initialization or resetting of the module.  </ul> Note: This assertion is tested as part of AS04.05.",
        "formInputs": [
            {
                "controlName": "AS.04.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.04.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.04.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.04.03",
        "description": "Recovery from error states shall be possible except for those caused by hard errors that require maintenance, service, or repair of the cryptographic module.",
        "formInputs": [
            {
                "controlName": "AS.04.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.04.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.04.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.03.01",
        "description": "From each error state that does not require maintenance, service, or repair, the tester shall verify that the cryptographic module can be caused to transition to an acceptable operational or initialization state.  This effort consists of two parts: first, the tester shall verify that the cryptographic module indicates when it is an error state, and second, that the module operates correctly in this target state.  The tester shall report how the requirement was verified (i.e., by code examination or by exercising the module).",
        "formInputs": [
            {
                "controlName": "TE.04.03.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.03.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.03.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.04.04",
        "description": "If the cryptographic module contains a maintenance role, then a maintenance state shall be included.  Note: This assertion is tested as part of AS04.05.",
        "formInputs": [
            {
                "controlName": "AS.04.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.04.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.04.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.04.05",
        "description": "Documentation shall include a representation of the finite state (or equivalent) using a state transition diagram and/or state transition table that shall specify: <ul> <li> all operational and error states of the cryptographic module, <li> the corresponding transitions from one state to another, <li> the input events, including data inputs and control inputs, that cause transitions from one state to another, and <li> the output events, including internal module conditions, data outputs, and status outputs resulting from transitions from one state to another.  </ul>",
        "formInputs": [
            {
                "controlName": "AS.04.05_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.04.05_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.04.05_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.01",
        "description": "The tester shall verify that the vendor has provided a description of the finite state model.  This description shall contain the identification and description of all states of the module, and a description of all corresponding state transitions.  The tester shall verify that the descriptions of the state transitions include the internal module conditions, data inputs and control inputs that cause transitions from one state to another, data outputs and status outputs resulting from transitions from one state to another.",
        "formInputs": [
            {
                "controlName": "TE.04.05.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.02",
        "description": "The tester shall verify that the finite state diagrams and the descriptions are consistent with the vendor documentation that describes the following: <ol> <li> Data input interface <li> Data output interface <li> Control input interface <li> Status output interface <li> Crypto officer role <li> User role <li> Other roles (if applicable) <li> Key entry services (if applicable) <li> Show status service <li> Self-tests <li> Other authorized services, operations, and functions (if applicable) <li> Error states <li> Bypass service (if applicable) <li> Maintenance interface (if applicable) <li> Maintenance role (if a maintenance interface is provided) <li> Key generation services (if applicable) <li> Key output services (if applicable) <li> Idle states (if applicable) <li> Uninitialized states (if applicable) </ol>",
        "formInputs": [
            {
                "controlName": "TE.04.05.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.03",
        "description": "The tester shall verify that every state that is identified in the finite state diagram(s) is also identified and described in the description.",
        "formInputs": [
            {
                "controlName": "TE.04.05.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.04",
        "description": "The tester shall verify that every state that is identified and described in the description is also identified in the finite state diagram(s).",
        "formInputs": [
            {
                "controlName": "TE.04.05.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.05",
        "description": "The tester shall verify that the operation of the module is consistent with the finite state diagrams and descriptions.",
        "formInputs": [
            {
                "controlName": "TE.04.05.05_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.05_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.05_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.06",
        "description": "If the module includes a maintenance interface, then the tester shall verify that the finite state model has at least one maintenance state define.  All maintenance states must be contained in the finite state diagram(s) and described in the description of the finite state model.",
        "formInputs": [
            {
                "controlName": "TE.04.05.06_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.06_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.06_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.07",
        "description": "The tester shall review the descriptions of the states of the cryptographic module to determine if the descriptions clearly define disjoint states.  The tester shall verify that all possible combinations of data and control inputs can be partitioned into disjoint sets.",
        "formInputs": [
            {
                "controlName": "TE.04.05.07_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.07_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.07_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.08",
        "description": "The tester shall exercise the cryptographic module, causing it to enter each of its major states.  For each state that has a distinct indicator, the tester shall attempt to observe the indicator while the module is in the state.  If the expected indicator is not observed, or two or more such indicators are observed at the same time (indicating that the module is in more than one state at one time), this test fails.",
        "formInputs": [
            {
                "controlName": "TE.04.05.08_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.08_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.08_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.09",
        "description": "The tester shall verify that there exists a chain of transitions from an initial power on state to each other state in the model that is not an initial power on state.",
        "formInputs": [
            {
                "controlName": "TE.04.05.09_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.09_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.09_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.10",
        "description": "The tester shall verify that there exists a chain of transitions from each non-power off state to a power off state of the model.",
        "formInputs": [
            {
                "controlName": "TE.04.05.10_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.10_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.10_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.04.05.11",
        "description": "The tester shall verify that the actions of the finite state model, as the result of all possible data and control inputs, are defined.  An example of an acceptable inclusive statement is: \"The action of the finite state model as a result of all other combinations of data and control inputs is to place the finite state model into the ERROR-3 state.\"",
        "formInputs": [
            {
                "controlName": "TE.04.05.11_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.04.05.11_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.04.05.11_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    }
]