export const Section9 = [
    {
        "title": "AS.09.01",
        "description": "The cryptographic module shall perform power-up self-tests and conditional self-tests to ensure that the module is functioning properly.  Note: This assertion is tested as part of AS09.07.",
        "formInputs": [
            {
                "controlName": "AS.09.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.02",
        "description": "Power-up self-tests shall be performed when the cryptographic module is powered up.  Note: This assertion is tested as part of AS09.07.",
        "formInputs": [
            {
                "controlName": "AS.09.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.03",
        "description": "Conditional self-tests shall be performed when an applicable security function or operation is invoked (i.e., security functions for which self-tests are required).  Note: This assertion is tested as part of AS09.07.",
        "formInputs": [
            {
                "controlName": "AS.09.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.04",
        "description": "If the cryptographic module fails a self-test, the module shall enter an error state and output an error indicator via the status output interface.",
        "formInputs": [
            {
                "controlName": "AS.09.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.04.01",
        "description": "The tester shall inspect the vendor documentation, check that it lists every error state that the module enters upon failure of a self-test, and indicates the error indicator associated with each error state.  The tester shall compare the list of error states to those defined in the finite state model (see AS04.05) to verify that they agree.",
        "formInputs": [
            {
                "controlName": "TE.09.04.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.04.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.04.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.04.02",
        "description": "By inspecting the vendor documentation that specifies how each self-test handles errors, the tester shall verify that: <ol> <li> The module enters an error state upon failing a self-test.  <li> The error state is consistent with the documentation and the finite state model.  <li> The module outputs an error indicator.  <li> The error indicator is consistent with the documented error indicator.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.04.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.04.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.04.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.04.03",
        "description": "The tester shall run self-tests and cause the module to enter every error state.  The tester shall compare the observed error indicator with the indicator specified in the vendor documentation.  If they are not the same, the assertion fails.",
        "formInputs": [
            {
                "controlName": "TE.09.04.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.04.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.04.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.05",
        "description": "The cryptographic module shall not perform any cryptographic operations while in an error state.",
        "formInputs": [
            {
                "controlName": "AS.09.05_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.05_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.05_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.05.01",
        "description": "Tester verification of the inhibition of output was performed under TE02.06.01 and TE02.06.02.  The results of the verification shall indicate that the module inhibits all data output when the module is in an error state.",
        "formInputs": [
            {
                "controlName": "TE.09.05.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.05.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.05.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.05.02",
        "description": "The tester shall verify that vendor documentation specifies that cryptographic functions are inhibited while the module is in an error state.  Cryptographic functions include the following: <ol> <li>. Encryption <li>. Decryption <li>. Secure message hashing <li>. Digital signature creation and verification <li>. Other operations that require the use of cryptography </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.05.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.05.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.05.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.05.03",
        "description": "The tester shall put the module in the error state and verify that any cryptographic operations that the tester attempts to initiate are prevented.",
        "formInputs": [
            {
                "controlName": "TE.09.05.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.05.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.05.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.06",
        "description": "All data output via the data output interface shall be inhibited when an error state exists.",
        "formInputs": [
            {
                "controlName": "AS.09.06_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.06_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.06_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.06.01",
        "description": "Tester verification of the inhibition of output was performed under TE02.06.01 and TE02.06.02.  The results of the verification shall indicate that the vendor documentation shows that all data output via the data output interface is inhibited whenever the module is in an error state.",
        "formInputs": [
            {
                "controlName": "TE.09.06.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.06.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.06.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.06.02",
        "description": "The tester shall put the module in an error state and verify that all data output via the data output interface is inhibited when an error state exists.",
        "formInputs": [
            {
                "controlName": "TE.09.06.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.06.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.06.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.07",
        "description": "Documentation shall specify: <ul> <li> the self-tests performed by the cryptographic module, including power-up and conditional tests, <li> the error states that the cryptographic module can enter when a self-test fails, and <li> the conditions and actions necessary to exit the error states and resume normal operation of the cryptographic module (i.e., this may include maintenance of the module, or returning the module to the vendor for servicing.) </ul>",
        "formInputs": [
            {
                "controlName": "AS.09.07_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.07_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.07_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.07.01",
        "description": "The tester shall inspect the list of self-tests to verify that it includes the following: <ol> <li> Power-up tests <ul> <li> Cryptographic algorithm test <li> Random number generator test <li> Software/firmware test* Critical functions test <li> Other self-tests that are performed at power-up and on demand </ul> <li> Conditional tests <ul> <li> Pairwise consistency test (if the module generates public and private keys <li> Software/firmware load test <li> Manual key entry test <li> Continuous random number generator test <li> Bypass test <li> Other conditional tests </ul></ol>",
        "formInputs": [
            {
                "controlName": "TE.09.07.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.07.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.07.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.07.02",
        "description": "The tester shall check that the information provided above is specified for each error condition.",
        "formInputs": [
            {
                "controlName": "TE.09.07.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.07.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.07.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.07.03",
        "description": "The tester shall cause each error condition to occur and shall attempt to clear the error condition.  The tester shall verify that actions necessary to clear the error condition are consistent with the vendor documentation.  If the tester cannot cause each error condition to occur, the tester shall review the code listing and or design documentation to determine whether the actions necessary to clear each error condition are consistent with the descriptions in the vendor documentation.",
        "formInputs": [
            {
                "controlName": "TE.09.07.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.07.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.07.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.08",
        "description": "Power-up tests shall be performed by the cryptographic module when the module is powered up (after being powered off, reset, rebooted, etc.).  Note: This assertion is tested as part of AS09.09.",
        "formInputs": [
            {
                "controlName": "AS.09.08_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.08_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.08_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.09",
        "description": "The power-up tests shall be initiated automatically and shall not require operator intervention.",
        "formInputs": [
            {
                "controlName": "AS.09.09_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.09_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.09_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.09.01",
        "description": "The tester shall verify that the vendor documentation includes the information required under VE09.09.01.",
        "formInputs": [
            {
                "controlName": "TE.09.09.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.09.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.09.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.09.02",
        "description": "The tester shall power-up the module and verify that the module performs the power-up self-tests without requiring any operator intervention.",
        "formInputs": [
            {
                "controlName": "TE.09.09.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.09.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.09.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.09.03",
        "description": "Note:  This test requirement has been removed.",
        "formInputs": [
            {
                "controlName": "TE.09.09.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.09.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.09.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.10",
        "description": "When the power-up tests are completed, the results (i.e., indications of success or failure) shall be output via the \"status output\" interface.",
        "formInputs": [
            {
                "controlName": "AS.09.10_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.10_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.10_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.10.01",
        "description": "The tester shall verify that the vendor documentation specifies an indicator that is output from the status output interface upon successful completion of the power-up self-tests.",
        "formInputs": [
            {
                "controlName": "TE.09.10.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.10.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.10.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.10.02",
        "description": "The tester shall power-up the module and shall monitor the status output interface.  The expected indicator from the status output interface should be consistent with the documented indicator.",
        "formInputs": [
            {
                "controlName": "TE.09.10.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.10.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.10.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.11",
        "description": "All data output via the output interface shall be inhibited when the tests are performed.  Note: This assertion is tested as part of AS02.06.",
        "formInputs": [
            {
                "controlName": "AS.09.11_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.11_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.11_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.12",
        "description": "In addition to performing the power-up tests when powered up, the cryptographic module shall permit operators to initiate the tests on demand for periodic testing of the module.",
        "formInputs": [
            {
                "controlName": "AS.09.12_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.12_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.12_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.12.01",
        "description": "The tester shall inspect the vendor documentation to verify that initiation of power-up self-tests on demand is specified for all of the power-up self-tests.",
        "formInputs": [
            {
                "controlName": "TE.09.12.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.12.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.12.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.12.02",
        "description": "The tester shall initiate the power-up on demand self-tests to verify that the initiation of the power-up self-tests on demand is consistent with vendor documentation.",
        "formInputs": [
            {
                "controlName": "TE.09.12.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.12.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.12.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.13",
        "description": "The cryptographic module shall perform the following power-up tests: cryptographic algorithm test, software/firmware integrity test, and critical functions test.",
        "formInputs": [
            {
                "controlName": "AS.09.13_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.13_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.13_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.13.01",
        "description": "Verification of the documented list of power-up self-tests was performed under TE09.07.01.",
        "formInputs": [
            {
                "controlName": "TE.09.13.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.13.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.13.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.13.02",
        "description": "Verification that the module performs the self-tests as documented is done under validation requirements for AS09.16-AS09.28.",
        "formInputs": [
            {
                "controlName": "TE.09.13.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.13.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.13.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.14",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "AS.09.14_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.14_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.14_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.14.01",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.14.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.14.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.14.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.14.02",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.14.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.14.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.14.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.14.03",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.14.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.14.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.14.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.14.04",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.14.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.14.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.14.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.15",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "AS.09.15_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.15_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.15_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.15.01",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.15.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.15.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.15.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.15.02",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.15.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.15.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.15.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.16",
        "description": "A cryptographic algorithm test using a known answer shall be conducted for all cryptographic functions (e.g., encryption, decryption, authentication and random number generation) of each Approved cryptographic algorithm implemented by the cryptographic module.",
        "formInputs": [
            {
                "controlName": "AS.09.16_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.16_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.16_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.16.01",
        "description": "By inspecting the vendor documentation, the tester shall verify that a known answer test is associated with all cryptographic functions  of each Approved cryptographic algorithm implemented by the cryptographic module as indicated in AS01.12.",
        "formInputs": [
            {
                "controlName": "TE.09.16.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.16.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.16.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.16.02",
        "description": "The tester shall verify that the documentation is consistent with the implementation of the cryptographic module.",
        "formInputs": [
            {
                "controlName": "TE.09.16.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.16.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.16.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.17",
        "description": "If the calculated output does not equal the known answer, the known-answer test shall fail.",
        "formInputs": [
            {
                "controlName": "AS.09.17_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.17_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.17_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.17.01",
        "description": "The tester shall verify that the documentation is consistent with the implementation of the cryptographic module.",
        "formInputs": [
            {
                "controlName": "TE.09.17.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.17.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.17.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.17.02",
        "description": "This is tested under TE09.04.01, TE09.04.02, and TE09.04.03.",
        "formInputs": [
            {
                "controlName": "TE.09.17.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.17.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.17.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.18",
        "description": "Cryptographic algorithms whose outputs vary for a given set of inputs (e.g., the Digital Signature Algorithm) shall be tested using a known-answer test or shall be tested using a pair-wise consistency test.",
        "formInputs": [
            {
                "controlName": "AS.09.18_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.18_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.18_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.18.01",
        "description": "The tester shall verify that the documentation is consistent with the implementation of the cryptographic module.",
        "formInputs": [
            {
                "controlName": "TE.09.18.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.18.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.18.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.18.02",
        "description": "By inspecting the vendor documentation, the tester shall verify if either a known-answer test or a pair-wise consistency test is associated with the cryptographic function.",
        "formInputs": [
            {
                "controlName": "TE.09.18.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.18.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.18.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.18.03",
        "description": "Pair-wise consistency is tested in AS09.31 (encryption), AS09.32 (key agreement) and AS09.33 (digital signature creation and verification).",
        "formInputs": [
            {
                "controlName": "TE.09.18.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.18.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.18.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.19",
        "description": "Message digest algorithms shall have an independent known-answer test or the known-answer test shall be included with the associated cryptographic algorithm test (e.g., the Digital Signature Standard).",
        "formInputs": [
            {
                "controlName": "AS.09.19_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.19_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.19_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.19.01",
        "description": "The tester shall verify that the documentation is consistent with the implementation of the cryptographic module.",
        "formInputs": [
            {
                "controlName": "TE.09.19.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.19.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.19.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.19.02",
        "description": "The tester shall determine whether the module implements a message digest algorithm.  If so, the tester shall verify that the vendor documentation specifies whether the message digest algorithm has its own known answer test or whether it is included in the known answer test of another algorithm.",
        "formInputs": [
            {
                "controlName": "TE.09.19.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.19.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.19.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.19.03",
        "description": "By checking the code listing and/or design documentation, the tester shall verify that the module uses either a separate known answer test or the known answer test of an algorithm in order to test a message digest algorithm.",
        "formInputs": [
            {
                "controlName": "TE.09.19.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.19.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.19.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.20",
        "description": "If the cryptographic module includes two independent implementations of the same cryptographic algorithm, then the outputs of two implementations shall be continuously compared.",
        "formInputs": [
            {
                "controlName": "AS.09.20_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.20_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.20_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.20.01",
        "description": "The tester shall determine from the vendor documentation whether a known answer test or a compared answer test is used to test the module's cryptographic algorithm.  If the compared answer test is used, the tester shall determine whether the documentation of the compared answer test includes: <ol> <li> Use of two independent cryptographic algorithm implementations <li> Continual comparison of the outputs of the algorithm implementation <li> Transition into an error state and output of an error indicator when the two outputs are not equal </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.20.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.20.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.20.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.20.02",
        "description": "By checking the code and/or design documentation, the tester shall verify that the module implements the documented steps for performing a compared answer test.",
        "formInputs": [
            {
                "controlName": "TE.09.20.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.20.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.20.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.20.03",
        "description": "Validation of whether the module enters the error state and outputs an error indicator upon failure of the self-test is performed under TE09.04.01, TE09.04.02, and TE09.04.03.  If any of these tests fail, this assertion fails.",
        "formInputs": [
            {
                "controlName": "TE.09.20.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.20.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.20.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.21",
        "description": "If the cryptographic module includes two independent implementations of the same cryptographic algorithm then, if the outputs of two implementations are not equal, the cryptographic algorithm test shall fail.  Note: This assertion is tested as part of AS09.20.",
        "formInputs": [
            {
                "controlName": "AS.09.21_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.21_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.21_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.22",
        "description": "A software/firmware integrity test using an error detection code (EDC) or Approved authentication technique (e.g., an Approved message authentication code or digital signature algorithm) shall be applied to all validated software and firmware components within the cryptographic module when the module is powered up.",
        "formInputs": [
            {
                "controlName": "AS.09.22_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.22_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.22_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.22.01",
        "description": "The tester shall determine from the vendor supplied documentation which technique is used for the software/firmware components integrity test.",
        "formInputs": [
            {
                "controlName": "TE.09.22.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.22.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.22.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.22.02",
        "description": "The tester shall verify that if an Approved authentication technique is implemented, the vendor documentation either include requirements in TE01.12.01 or in the absence of a CMVP algorithm validation certificate issuing process, the vendor organization shall provide a written affirmation of conformance.",
        "formInputs": [
            {
                "controlName": "TE.09.22.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.22.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.22.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.22.03",
        "description": "If the module implements EDCs for software/firmware integrity, the tester shall verify that the vendor documentation of the software/firmware test includes: <ol> <li> Description of EDC algorithm.  <li> Identification of software and firmware that is protected using EDCs.  <li> Calculation of the EDCs when the software and firmware is installed.  <li> Recalculation of the EDCs when the self-test is initiated.  <li> Comparison of the stored EDC against the recalculated EDC.  <li> Failure of the self-test when the two EDCs are not equal.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.22.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.22.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.22.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.22.04",
        "description": "If the module implements a DAC for software/firmware integrity, the tester shall verify that the vendor documentation of the software/firmware test fully describes the process by which the DAC is calculated and verified.",
        "formInputs": [
            {
                "controlName": "TE.09.22.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.22.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.22.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.22.05",
        "description": "If the module implements an Approved digital signature for software/firmware integrity, the tester shall verify that the vendor documentation of the software/firmware test includes the following: <ol> <li> Specify the Approved digital signature algorithm implemented.  <li> Identification of software and firmware that is protected using the Approved digital signatures.  <li> Calculation of the Approved digital signatures when the software and firmware is installed.  <li> Verification of the Approved digital signature when the self-test is initiated.  <li> Failure of the self-test upon failure of the Approved digital signature verification.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.22.05_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.22.05_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.22.05_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.22.06",
        "description": "By checking the code and/or design documentation, the tester shall verify that the implementation of the software/firmware test is consistent with TE09.22.01, TE09.22.02, TE09.22.03, or TE09.22.04.",
        "formInputs": [
            {
                "controlName": "TE.09.22.06_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.22.06_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.22.06_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.22.07",
        "description": "If possible, the tester shall test the module by modifying the stored software, firmware, or the implemented integrity mechanism and initiating the self-tests, and observing the output from the status output interface.  If no indicator is output that indicates that the software/firmware self-test failed, the assertion fails.",
        "formInputs": [
            {
                "controlName": "TE.09.22.07_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.22.07_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.22.07_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.23",
        "description": "If the calculated result does not equal the previously generated result, the software/firmware test shall fail.  Note: This assertion is tested as part of AS09.22.",
        "formInputs": [
            {
                "controlName": "AS.09.23_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.23_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.23_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.24",
        "description": "If an EDC is used, the EDC shall be at least 16 bits in length.",
        "formInputs": [
            {
                "controlName": "AS.09.24_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.24_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.24_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.24.01",
        "description": "The tester shall verify that the implemented EDCs are at least 16 bits in length.",
        "formInputs": [
            {
                "controlName": "TE.09.24.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.24.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.24.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.25",
        "description": "Other security functions critical to the secure operation of the cryptographic module shall be tested when the module is powered up as part of the power-up tests.  Note: This assertion is tested as part of AS09.27.",
        "formInputs": [
            {
                "controlName": "AS.09.25_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.25_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.25_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.26",
        "description": "Other critical security functions performed under specific conditions shall be tested as conditional tests.  Note: This assertion is tested as part of AS09.27.",
        "formInputs": [
            {
                "controlName": "AS.09.26_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.26_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.26_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.27",
        "description": "Documentation shall specify all security functions critical to the secure operation of the cryptographic module and shall identify the applicable power-up tests and conditional tests performed by the module.  Note: Critical functions are defined as those functions that, upon failure, could lead to the disclosure of CSPs. Examples of critical functions include but not limited to random number generation, operation of the cryptographic algorithm, and cryptographic bypass.",
        "formInputs": [
            {
                "controlName": "AS.09.27_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.27_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.27_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.27.01",
        "description": "The tester shall review the vendor provided documentation of the critical functions and the self-tests that are designed to test them.  This documentation shall include the following: <ol> <li> Identification and description of all critical functions <li> Identification of at least one self-test for every critical function </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.27.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.27.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.27.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.27.02",
        "description": "By checking the code and/or design documentation, the tester shall verify that the module performs the specified self-tests for each critical function.",
        "formInputs": [
            {
                "controlName": "TE.09.27.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.27.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.27.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.28",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "AS.09.28_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.28_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.28_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.28.01",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.28.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.28.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.28.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.28.02",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.28.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.28.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.28.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.28.03",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.28.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.28.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.28.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.29",
        "description": "Conditional tests shall be performed by the cryptographic module when the conditions specified for the following tests occur: pair-wise consistency test, software/firmware load test, manual key entry test, continuous random number generator test, and bypass test.Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.09.29_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.29_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.29_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.30",
        "description": "If the cryptographic module generates public or private keys, then the following pair-wise consistency tests for public and private keys shall be performed.  Note: This assertion is tested as part of AS09.31, and  AS09.33.",
        "formInputs": [
            {
                "controlName": "AS.09.30_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.30_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.30_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.31",
        "description": "If the keys are used to perform an approved key transport method, then the public key shall encrypt a plaintext value.  The resulting ciphertext value shall be compared to the original plaintext value.  If the two values are equal, then the test shall fail.  If the two values differ, then the private key shall be used to decrypt the ciphertext and the resulting value shall be compared to the original plaintext value.  If the two values are not equal, the test shall fail.",
        "formInputs": [
            {
                "controlName": "AS.09.31_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.31_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.31_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.31.01",
        "description": "If the keys are used to perform an approved key transport method, the tester shall verify that the implementation of the pairwise consistency check, as defined in AS09.31, is consistent with the vendor documentation by checking the code and/or design documentation.",
        "formInputs": [
            {
                "controlName": "TE.09.31.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.31.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.31.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.32",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "AS.09.32_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.32_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.32_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.32.01",
        "description": "Note:  There are no requirements for this assertion number.",
        "formInputs": [
            {
                "controlName": "TE.09.32.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.32.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.32.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.33",
        "description": "If the keys are used to perform the calculation and verification of digital signatures, then the consistency of the keys shall be tested by the calculation and verification of a digital signature.  If the digital signature cannot be verified, the test shall fail.",
        "formInputs": [
            {
                "controlName": "AS.09.33_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.33_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.33_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.33.01",
        "description": "If the public and private keys are used for the calculation and/or verification of digital signatures, then the tester shall verify that the implementation of the pairwise consistency check as defined in AS09.33 is consistent with the vendor documentation by checking the code and/or design documentation.",
        "formInputs": [
            {
                "controlName": "TE.09.33.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.33.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.33.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.34",
        "description": "If software or firmware components can be externally loaded into the cryptographic module, then the following software/firmware load tests shall be performed.  Note: This assertion is tested as part of AS09.34, AS09.35, and AS09.36.",
        "formInputs": [
            {
                "controlName": "AS.09.34_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.34_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.34_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.35",
        "description": "An Approved authentication technique (e.g., an Approved message authentication code, digital signature algorithm, or HMAC) shall be applied to all validated software and firmware components when the components are externally loaded into the cryptographic module.",
        "formInputs": [
            {
                "controlName": "AS.09.35_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.35_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.35_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.35.01",
        "description": "The tester shall determine from the vendor supplied documentation which Approved authentication technique is used for the software/firmware load test.",
        "formInputs": [
            {
                "controlName": "TE.09.35.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.35.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.35.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.35.02",
        "description": "The tester shall verify that if an Approved authentication technique is implemented, the vendor documentation either include requirements in TE01.12.01 or in the absence of a CMVP algorithm validation certificate issuing process, the vendor organization shall provide a written affirmation of conformance.",
        "formInputs": [
            {
                "controlName": "TE.09.35.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.35.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.35.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.35.03",
        "description": "If the module implements an Approved authentication technique for the software/firmware load test, the tester shall verify that the vendor documentation of the software/firmware load test includes: <ol> <li> Specify the Approved authentication technique implemented.  <li> Identification of software and firmware that is protected using the Approved authentication technique.  <li> Calculation of the Approved authentication technique when the software and firmware is loaded.  <li> Verification of the Approved authentication technique when the load test is initiated.  <li> Failure of the self-test upon failure of the Approved authentication technique verification.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.35.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.35.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.35.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.35.04",
        "description": "By checking the code and/or design documentation, the tester shall verify that the implementation of the software/firmware load test is consistent with TE09.35.01, TE09.35.02 and TE09.35.03.",
        "formInputs": [
            {
                "controlName": "TE.09.35.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.35.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.35.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.35.05",
        "description": "If possible, the tester shall test the module by modifying the software or firmware to be loaded, or the implemented authentication mechanism and initiating the self-tests, and observing the output from the status output interface.  If no indicator is output that indicates that the software/firmware load test failed, the assertion fails.",
        "formInputs": [
            {
                "controlName": "TE.09.35.05_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.35.05_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.35.05_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.36",
        "description": "The calculated result shall be compared with a previously generated result.  If the calculated result does not equal the previously generated result, the software/firmware integrity test shall fail.  Note: This assertion is tested as part of AS09.35.",
        "formInputs": [
            {
                "controlName": "AS.09.36_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.36_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.36_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.37",
        "description": "If cryptographic keys or key components are manually entered into the cryptographic module, then the following manual key entry tests shall be performed.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.09.37_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.37_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.37_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.38",
        "description": "The cryptographic key or key components shall have an EDC applied, or shall be entered using duplicate entries.  Note: This assertion is tested as part of AS09.40.",
        "formInputs": [
            {
                "controlName": "AS.09.38_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.38_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.38_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.39",
        "description": "If an EDC is used, the EDC shall be at least 16 bits in length.  Note: This assertion is tested as part of AS09.40.",
        "formInputs": [
            {
                "controlName": "AS.09.39_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.39_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.39_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.40",
        "description": "If the EDC cannot be verified, or the duplicate entries do not match, the test shall fail.",
        "formInputs": [
            {
                "controlName": "AS.09.40_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.40_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.40_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.40.01",
        "description": "Verification of vendor documentation is performed under TE07.28.01.",
        "formInputs": [
            {
                "controlName": "TE.09.40.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.40.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.40.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.40.02",
        "description": "The tester shall determine from the vendor documentation which method is used for the manual key entry test (error detection codes or duplicate key entries).  Based on the method used, the tester shall check the vendor documentation, code, and/or design documentation that specifies the implementation of the manual key entry test to determine whether the following information is included: <ol> <li> Error detection codes: <ul> <li> Key format for all manually-entered keys, including fields for EDCs (see AS07.03) <li> Description of EDC algorithm* Description of EDC verification process <li> All expected outputs for success or failure of the test </ul> <li> Duplicate key entries: <ul> <li> Duplicate key entries for all manually-entered keys <li> Description of duplicate key, entry verification process <li> All expected outputs for success or failure of the test </ul> </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.40.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.40.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.40.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.40.03",
        "description": "For manual key entry tests using EDCs, the tester shall perform the following tests: <ol> <li> The tester shall enter every manually entered key and verify that the procedure used to enter each key is in accordance with the documented procedure, including the form that the keys are in when they are entered.  <li> The tester shall enter each type of manually-entered key without any errors and shall observe the status output interface.  If no indicator is detected, or if the indicator does not match the documented indicator for the success of the manual key entry test, the test is failed.  <li> The tester shall attempt to perform cryptographic operations with each entered key to verify that it was entered correctly.  <li> The tester shall change either the EDC associated with each manually-entered key or the key itself and shall enter them into the module.  The tester shall observe the indicator that is output from the status output interface; if no output is detected, or the indicator does not match the documented indicator for the failure of the manual key entry test, the test is failed.  <li> The tester shall attempt to perform cryptographic operations with each key that was not successfully entered.  Each operation using each key should fail, verifying that the key was not entered.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.40.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.40.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.40.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.40.04",
        "description": "For manual key entry tests using duplicate key entries, the tester shall perform the following tests: <ol> <li> The tester shall enter each type of manually-entered key without any errors and shall observe the status output interface.  If no indicator is detected, or if the indicator does not match the documented indicator for the success of the manual key entry test, the test is failed.  <li> The tester shall attempt to perform cryptographic operations with each entered key to verify that it was entered correctly.  <li> The tester shall alter the accuracy of one of the manually entered keys, either the first or second duplicate entry, and shall enter them into the module.  The tester shall observe the indicator that is output from the status output interface; if no output is detected, or the indicator does not match the documented indicator for the failure of the manual key entry test, the test is failed.  <li> The tester shall attempt to perform cryptographic operations with each key that was not successfully entered.  Each operation using each key should fail, verifying that the key was not entered.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.40.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.40.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.40.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.41",
        "description": "If a cryptographic module employs Approved or non-Approved RNGs in an Approved mode of operation, the module shall perform the following continuous random number generator test on each RNG that tests for failure to a constant value.  Note: This assertion is tested as part of AS09.42 and AS09.43.",
        "formInputs": [
            {
                "controlName": "AS.09.41_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.41_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.41_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.42",
        "description": "If each call to a RNG produces blocks of n bits (where n > 15), the first n-bit block generated after power-up, initialization, or reset shall not be used, but shall be saved for comparison with the next n-bit block to be generated.  Each subsequent generation of an n-bit block shall be compared with the previously generated block.  The test shall fail if any two compared n-bit blocks are equal.",
        "formInputs": [
            {
                "controlName": "AS.09.42_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.42_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.42_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.40.01",
        "description": "The tester shall determine whether the module implements a random number generator.  If so, the tester shall check the documentation, code and/or design documentation that specifies the continuous random number generator test to verify that it implements the specifics of the test.  If the generator generates blocks of n bits, where n  > 15, then the tester shall verify that the implementation of the test includes: <ol> <li> Storage of first block for comparison against the next block <li> Comparison of each subsequently generated block against the previously generated block <li> Failure of the test if two compared blocks are equal </ol> If the generator consistently generates fewer than 16 bits, then the tester shall verify that the implementation of the test includes the following: <ol> <li> Storage of the first n bits, where n > 15, for comparison against the next n generated bits <li> Comparison of each subsequently generated n bits against the previously generated n bits <li> Failure of the test if two compared n-bit sequences are equal </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.40.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.40.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.40.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.43",
        "description": "If each call to a RNG produces fewer than 16 bits, the first n bits generated after power-up, initialization, or reset (for some n > 15) shall not be used, but shall be saved for comparison with the next n generated bits.  Each subsequent generation of n bits shall be compared with the previously generated n bits.  The test fails if any two compared n-bit sequences are equal.",
        "formInputs": [
            {
                "controlName": "AS.09.43_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.43_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.43_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.43.01",
        "description": "The tester shall determine whether the module implements a random number generator.  If so, the tester shall check the documentation, code and/or design documentation that addresses of the continuous random number generator test to verify that it implements the specifics of the test.  If the generator generates blocks of n bits, where n  > 15, then the tester shall verify that the implementation of the test includes: <ol> <li> Storage of first block for comparison against the next block <li> Comparison of each subsequently generated block against the previously generated block <li> Failure of the test if two compared blocks are equal </ol> If the generator consistently generates fewer than 16 bits, then the tester shall verify that the implementation of the test includes the following: <ol> <li> Storage of the first n bits, where n > 15, for comparison against the next n generated bits <li> Comparison of each subsequently generated n bits against the previously generated n bits <li> Failure of the test if two compared n-bit sequences are equal </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.43.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.43.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.43.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.44",
        "description": "If the cryptographic module implements a bypass capability where the services may be provided without cryptographic processing (e.g., transferring plaintext through the module), then the following bypass tests shall be performed to ensure that a single point of failure of module components will not result in the unintentional output of plaintext.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.09.44_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.44_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.44_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.45",
        "description": "The cryptographic module shall test for the correct operation of the services providing cryptographic processing when a switch takes place between an exclusive bypass service and an exclusive cryptographic service.",
        "formInputs": [
            {
                "controlName": "AS.09.45_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.45_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.45_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.45.01",
        "description": "The tester shall verify that the module implements a bypass test to verify the correct operation of the cryptographic service when a switch takes place between an exclusive bypass service and an exclusive cryptographic service.",
        "formInputs": [
            {
                "controlName": "TE.09.45.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.45.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.45.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.45.02",
        "description": "The tester shall verify that the vendor documentation is consistent with the bypass test implementation through a review of the source code and/or design documentation.",
        "formInputs": [
            {
                "controlName": "TE.09.45.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.45.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.45.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.45.03",
        "description": "The tester shall switch the module from the exclusive bypass service to the exclusive cryptographic service and verify that plaintext information is not output.",
        "formInputs": [
            {
                "controlName": "TE.09.45.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.45.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.45.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.46",
        "description": "If the cryptographic module can automatically alternate between a bypass service and a cryptographic service, providing some services with cryptographic processing and some services without cryptographic processing, then the module shall test for the correct operation of the services providing cryptographic processing when the mechanism governing the switching procedure is modified (e.g., an IP address source/destination table).",
        "formInputs": [
            {
                "controlName": "AS.09.46_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.46_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.46_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.46.01",
        "description": "The tester shall verify that the module implements a bypass test to verify the correct operation of the cryptographic service when the mechanism governing the switching procedure is modified.",
        "formInputs": [
            {
                "controlName": "TE.09.46.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.46.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.46.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.46.02",
        "description": "The tester shall verify that the vendor is consistent with the bypass test implementation through the review of the source code and/or design documentation.",
        "formInputs": [
            {
                "controlName": "TE.09.46.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.46.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.46.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.09.46.03",
        "description": "The tester shall verify the correct operation of the bypass test by: <ol> <li> Verifying that the mechanism governing the switching procedure checks to ensure that no alteration of the mechanism has taken place since the last modification.  The tester will document the method used.  If the design allows, the tester shall alter the mechanism to test the method used.  <li> Modifying the mechanism governing the switching procedure in order to verify the correct operation of the mechanism and to verify the correct operation of the cryptographic service by verifying that the plaintext information is not output.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.09.46.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.09.46.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.09.46.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.47",
        "description": "No single point of failure shall result in the unintentional output of plaintext.  Note: This assertion is tested as part of AS09.45 and AS09.46.",
        "formInputs": [
            {
                "controlName": "AS.09.47_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.47_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.47_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.09.48",
        "description": "Documentation shall specify the mechanism or logic governing the switching procedure.  Note: This assertion is tested as part of AS09.45 and AS09.46.",
        "formInputs": [
            {
                "controlName": "AS.09.48_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.09.48_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.09.48_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    }
]