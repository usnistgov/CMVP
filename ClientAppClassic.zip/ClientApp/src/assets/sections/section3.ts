export const Section3 = [
    {
        "title": "AS.03.01",
        "description": "The cryptographic module shall support authorized roles for operators and corresponding services within each role.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.01",
        "description": "If the cryptographic module supports concurrent operators, then the module shall internally maintain the separation of the roles assumed by each operator and the corresponding services.",
        "formInputs": [
            {
                "controlName": "AS.03.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.02",
        "description": "If the cryptographic module supports concurrent operators, then the module shall internally maintain the separation of the roles assumed by each operator and the corresponding services.\t",
        "formInputs": [
            {
                "controlName": "AS.03.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.02.01",
        "description": "The tester shall review the vendor documentation and verify that the method implemented by the module to enforce separation between the roles and services performed by concurrent operators is described.",
        "formInputs": [
            {
                "controlName": "TE.03.02.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.02.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.02.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.02.02",
        "description": "The tester shall assume the identity of two independent operators: Operator1 and Operator2.  The operators shall assume different roles.  The tester shall verify that only the services allocated to the each role can be performed in that role.  The tester shall also attempt, for each operator, to access services that are unique to the role assumed by the other operator in order to verify that separation is maintained between the roles and services allowed in concurrent operators.",
        "formInputs": [
            {
                "controlName": "TE.03.02.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.02.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.02.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.02.03",
        "description": "If the vendor documentation specifies any restrictions on concurrent operators, the tester shall attempt to violate the restrictions by attempting to concurrently assume restricted roles as independent operators and verify that the module enforces the restrictions by preventing the second operator from assuming the role.",
        "formInputs": [
            {
                "controlName": "TE.03.02.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.02.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.02.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.03",
        "description": "The cryptographic module shall support the following authorized roles for operators: User Role.  The role assumed to perform general security services, including cryptographic operations and other Approved security functions.  Crypto Officer Role: The role assumed to perform a set of cryptographic initialization or management functions (e.g., module initialization, input/output of cryptographic keys and CSPs, and audit functions).",
        "formInputs": [
            {
                "controlName": "AS.03.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.03.01",
        "description": "The tester shall review the vendor documentation and verify that at least one user role and one crypto-officer role are defined.  These roles shall be specified by name and allowed services.  These roles shall be described as specified in AS03.03.  (The assumption of roles is tested by TE03.06.02.)",
        "formInputs": [
            {
                "controlName": "TE.03.03.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.03.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.03.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.04",
        "description": "If the cryptographic module allows operators to perform maintenance services, then the module shall support the following authorized role: * Maintenance Role: The role assumed to perform physical maintenance and/or logical maintenance services (e.g., hardware/software diagnostics).  ",
        "formInputs": [
            {
                "controlName": "AS.03.04_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.04_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.04_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.04.01",
        "description": "The tester shall review the specifications of the module interfaces to determine whether a maintenance interface is specified (see AS05.07).  If so, the tester shall check the vendor documentation pertaining to the authorized roles and verify that the maintenance role is specified by name, purpose, and allowed services.  (The assumption of roles is tested by TE03.06.02.)",
        "formInputs": [
            {
                "controlName": "TE.03.04.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.04.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.04.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.05",
        "description": "All plaintext secret and private keys and unprotected CSPs shall be zeroized when entering or exiting the maintenance role.",
        "formInputs": [
            {
                "controlName": "AS.03.05_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.05_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.05_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.05.01",
        "description": "If vendor documentation states that a maintenance role is implemented in the module, the tester shall verify that the vendor documentation specifies the method by which all plaintext secret and private keys and other unprotected CSPs are zeroized when the maintenance role is entered or exited.",
        "formInputs": [
            {
                "controlName": "TE.03.05.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.05.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.05.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.05.02",
        "description": "The tester shall, while in a non-maintenance role, load nonzero values for all private and secret keys and other unprotected CSPs.  Upon assuming the maintenance role, the tester shall verify that zeroization has taken place.",
        "formInputs": [
            {
                "controlName": "TE.03.05.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.05.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.05.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.05.03",
        "description": "While in the maintenance role, the tester shall load nonzero values for all private and secret keys and other unprotected CSPs and, upon exit from the maintenance role, shall verify that zeroization has taken place.",
        "formInputs": [
            {
                "controlName": "TE.03.05.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.05.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.05.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.06",
        "description": "Documentation shall specify all authorized roles supported by the cryptographic module.",
        "formInputs": [
            {
                "controlName": "AS.03.06_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.06_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.06_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.06.01",
        "description": "The tester shall review the vendor documentation and verify that, for each defined role, the name and available services for this role are specified.  The roles that should be described are as follows:<ol> <li> Crypto-officer role (one or more) <li> User role (required) (one or more) <li> Maintenance role (only if the module includes a maintenance interface) <li> Other roles </ol>",
        "formInputs": [
            {
                "controlName": "TE.03.06.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.06.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.06.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.06.02",
        "description": "The tester shall assume each of the authorized roles described in the vendor documentation and verify that each of them can be assumed.  Verification of the services that are designated for each role will be performed under AS03.14.",
        "formInputs": [
            {
                "controlName": "TE.03.06.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.06.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.06.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.07",
        "description": "Services shall refer to all of the services, operations, or functions that can be performed by the cryptographic module.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.07_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.07_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.07_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.08",
        "description": "Service inputs shall consist of all data or control inputs to the cryptographic module that initiate or obtain specific services, operations, or functions.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.08_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.08_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.08_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.09",
        "description": "Service outputs shall consist of all data and status outputs that result from services, operations, or functions initiated or obtained by service inputs.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.09_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.09_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.09_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.10",
        "description": "Each service input shall result in a service output.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.10_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.10_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.10_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.11",
        "description": "The cryptographic module shall provide the following services to operators: Show Status.  Output the current status of the cryptographic module.  Perform Self-Tests.  Initiate and run the self-tests as specified in Section 4.9.  Perform Approved Security Function.  Perform at least one Approved security function used in an Approved mode of operation, as specified in Section 4.1",
        "formInputs": [
            {
                "controlName": "AS.03.11_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.11_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.11_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.11.01",
        "description": "The tester shall check the vendor documentation to verify that the \"Show Status\" service and the user callable self-test initiation service are each allocated to at least one authorized role.  The tester shall verify that these services are described as specified in AS.03.14.",
        "formInputs": [
            {
                "controlName": "TE.03.11.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.11.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.11.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.11.02",
        "description": "The tester shall verify that the \"Show Status\" indicator matches the vendor documentation.",
        "formInputs": [
            {
                "controlName": "TE.03.11.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.11.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.11.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.11.03",
        "description": "Verification that the module provides for the initiation of the running of power-up self-tests, as specified in Section 4.9, is performed under TE03.14.02.",
        "formInputs": [
            {
                "controlName": "TE.03.11.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.11.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.11.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.12",
        "description": "If a cryptographic module implements a bypass capability, where services are provided without cryptographic processing (e.g., transferring plaintext through the module without encryption), then two independent internal actions shall be required to activate the capability to prevent the inadvertent bypass of plaintext data due to a single error (e.g., two different software or hardware flags are set, one of which may be user-initiated).\t",
        "formInputs": [
            {
                "controlName": "AS.03.12_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.12_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.12_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.12.01",
        "description": "The tester shall determine whether the bypass capability is implemented by the module.  The tester shall check the vendor documentation to verify that the bypass capability is allocated to at least one authorized role.",
        "formInputs": [
            {
                "controlName": "TE.03.12.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.12.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.12.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.12.02",
        "description": "The tester shall review the finite state model and other vendor documentation to determine whether each transition into an exclusive or alternating bypass state shows two independent internal actions that must occur in order for the cryptographic module to transition into either exclusive or alternating bypass state.",
        "formInputs": [
            {
                "controlName": "TE.03.12.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.12.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.12.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.12.03",
        "description": "The tester shall attempt to transition to each bypass state from each state that shows such a transition, and determine that it takes two internal actions to accomplish each such transition.",
        "formInputs": [
            {
                "controlName": "TE.03.12.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.12.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.12.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.13",
        "description": "If the cryptographic module implements a bypass capability, where services are provided without cryptographic processing (e.g., transferring plaintext through the module without encryption), then the module shall show status to indicate whether <ol> <li> the bypass capability is not activated, and the module is exclusively providing services with cryptographic processing (e.g., the plaintext is encrypted), <li> the bypass capability is activated and the module is exclusively providing services without cryptographic processing (e.g., plaintext data is not encrypted), or <li> the bypass capability is alternately activated and deactivated and the module is providing some services with cryptographic processing and some services without cryptographic processing (e.g., for modules with multiple communication channels, plaintext data is or is not encrypted depending on each channel configuration).  </ol>",
        "formInputs": [
            {
                "controlName": "AS.03.13_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.13_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.13_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.13.01",
        "description": "The tester shall review the vendor documentation for the \"Show Status\" service and verify the bypass service indication.",
        "formInputs": [
            {
                "controlName": "TE.03.13.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.13.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.13.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.13.02",
        "description": "The tester shall transition to each bypass state and verify that the \"Show Status\" indicates the applicable bypass status.",
        "formInputs": [
            {
                "controlName": "TE.03.13.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.13.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.13.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.14",
        "description": "Documentation shall specify: <ul> <li> the services, operations, or functions provided by the cryptographic module, both Approved and non-Approved, and <li> for each service provided by the module, the service inputs, corresponding service outputs, and the authorized role(s) in which the service can be performed.  </ul>",
        "formInputs": [
            {
                "controlName": "AS.03.14_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.14_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.14_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.14.01",
        "description": "The tester shall check the vendor documentation and verify that the purpose and function of each service is described.  The tester shall also check that the following information is specified for each service: service inputs, corresponding service outputs, and the authorized role or roles in which the service can be performed.",
        "formInputs": [
            {
                "controlName": "TE.03.14.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.14.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.14.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.14.02",
        "description": "The tester shall perform the following for each role: <ol> <li> Perform each of the specified services for the role to verify that they have been implemented for that role.  <li> Enter each of the specified service inputs and observe that they result in the specified service outputs.  <li> Attempt to perform services that are not specified for the role to verify that they have not been implemented for that role.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.03.14.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.14.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.14.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.15",
        "description": "Documentation shall specify any services provided by the cryptographic module for which the operator is not required to assume an authorized role, and how these services do not modify, disclose, or substitute cryptographic keys and CSPs, or otherwise affect the security of the module.",
        "formInputs": [
            {
                "controlName": "AS.03.15_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.15_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.15_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.15.01",
        "description": "The tester shall check the vendor documentation and verify that the purpose and function of each service is described, and the service inputs and corresponding service outputs are described.",
        "formInputs": [
            {
                "controlName": "TE.03.15.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.15.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.15.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.15.02",
        "description": "The tester shall perform the following tests: <ol> <li> Enter each of the specified service inputs and observe that they result in the specified service outputs.  <li> Attempt to perform services that require a role to verify that they have not been implemented.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.03.15.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.15.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.15.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.16",
        "description": "Depending on the security level, the cryptographic module shall perform at least one of the following mechanisms to control access to the module: role-based authentication or identity-based authentication.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.16_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.16_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.16_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.19",
        "description": "If identity-based authentication mechanisms are supported by the cryptographic module, the module shall require that the operator be individually identified, shall require that one or more roles either be implicitly or explicitly selected by the operator, and shall authenticate the identity of the operator and the authorization of the operator to assume the selected role (or set of roles).",
        "formInputs": [
            {
                "controlName": "AS.03.19_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.19_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.19_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.19.01",
        "description": "The tester shall verify that the vendor documentation specifies how the operator is uniquely identified, how that identity is authenticated, how the operator chooses a role, and how the authorization of the operator to assume a role is performed based on the authenticated identity.",
        "formInputs": [
            {
                "controlName": "TE.03.19.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.19.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.19.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.19.02",
        "description": "The tester shall initiate an error during the authentication procedure and shall observe that the module does not allow the tester to proceed beyond the authentication procedure.",
        "formInputs": [
            {
                "controlName": "TE.03.19.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.19.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.19.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.19.03",
        "description": "The tester shall successfully authenticate his/her identity to the module.  When required to select one or more roles, the tester shall select roles not compatible with the authenticated identity and shall observe that authorization to assume the roles is denied.",
        "formInputs": [
            {
                "controlName": "TE.03.19.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.19.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.19.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.20",
        "description": "If the cryptographic module permits an operator to change roles, then the module shall verify the authorization of the identified operator to assume any role that was not previously authorized.",
        "formInputs": [
            {
                "controlName": "AS.03.20_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.20_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.20_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.20.01",
        "description": "The tester shall review the vendor documentation to verify that the method by which an operator can change roles without re-authentication of the operator's identity includes the verification of the authorization of the operator for a role not previously authenticated.",
        "formInputs": [
            {
                "controlName": "TE.03.20.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.20.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.20.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.20.02",
        "description": "The tester shall perform the following tests:1. Assume each role, attempt to change to another role that the tester is authorized to assume, verify that the tester's identity does not have to be reauthenticated, and verify that the tester can access the services associated with the new role.  The tester shall perform services in the new role that were not associated with the previous role in order to verify that the tester has assumed a different role.2. Assume each role, attempt to change to another role that the operator is not authorized to assume, and verify that the module denies access to the role based on the identity of the operator.",
        "formInputs": [
            {
                "controlName": "TE.03.20.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.20.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.20.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.21",
        "description": "When the cryptographic module is powered off and subsequently powered on, the results of previous authentications shall not be retained and the module shall require the operator to be re-authenticated.",
        "formInputs": [
            {
                "controlName": "AS.03.21_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.21_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.21_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.21.01",
        "description": "The tester shall review the vendor documentation and verify that the clearing of previous authentications upon power off of the module is described.",
        "formInputs": [
            {
                "controlName": "TE.03.21.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.21.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.21.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.21.02",
        "description": "The tester shall authenticate himself/herself to the module and assume one or more roles, power off the module, power on the module, and attempt to perform services in those roles.  The module should deny access to the services and require that the tester be reauthenticated.",
        "formInputs": [
            {
                "controlName": "TE.03.21.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.21.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.21.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.22",
        "description": "Authentication data within the cryptographic module shall be protected against unauthorized disclosure, modification, and substitution.",
        "formInputs": [
            {
                "controlName": "AS.03.22_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.22_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.22_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.22.01",
        "description": "The tester shall review the vendor documentation that describes the protection of authentication data.  The tester shall verify that the documentation describes how the data will be protected against unauthorized disclosure, modification, and substitution.",
        "formInputs": [
            {
                "controlName": "TE.03.22.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.22.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.22.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.22.02",
        "description": "The tester shall perform the following tests: <ol> <li> Attempt to access (by circumventing the documented protection mechanisms) authentication data for which the tester is not authorized to have access.  If the module denies access or allows access only to encrypted or otherwise protected forms of data, the requirement is met.  <li> Modify authentication data using any method not specified by the vendor documentation and attempt to enter the modified data.  The module shall not allow the tester to be authenticated using the modified data.  </ol>",
        "formInputs": [
            {
                "controlName": "TE.03.22.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.22.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.22.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.23",
        "description": "If the cryptographic module does not contain the authentication data required to authenticate the operator for the first time the module is accessed, then other authorized methods (e.g., procedural controls or use of factory-set or default authentication data) shall be used to control access to the module and initialize the authentication mechanisms.",
        "formInputs": [
            {
                "controlName": "AS.03.23_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.23_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.23_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.23.01",
        "description": "The tester shall verify the vendor documentation describes the procedure by which the operator is authenticated upon accessing the module for the first time.",
        "formInputs": [
            {
                "controlName": "TE.03.23.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.23.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.23.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.23.02",
        "description": "If access to the module before initialization is controlled, the tester shall initiate an error on an uninitialized module and shall verify that the module denies access.  The tester shall assume the authorized role and verify that the required authentication complies with the documented procedures.  The tester shall attempt to assume other roles before the module has been initialized and verify that the module denies access to the roles.",
        "formInputs": [
            {
                "controlName": "TE.03.23.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.23.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.23.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.24",
        "description": "The strength of the authentication mechanism shall conform to the following specifications: Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.24_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.24_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.24_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.25",
        "description": "For each attempt to use the authentication mechanism, the probability shall be less than one in 1,000,000 that a random attempt will succeed or a false acceptance will occur (e.g., guessing a password or PIN, false acceptance error rate of a biometric device, or some combination of authentication methods).",
        "formInputs": [
            {
                "controlName": "AS.03.25_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.25_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.25_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.25.01",
        "description": "The tester shall review the vendor documentation and verify for each authentication method that the associated false acceptance or random access rate is less than one in 1,000,000.",
        "formInputs": [
            {
                "controlName": "TE.03.25.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.25.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.25.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.26",
        "description": "For multiple attempts to use the authentication mechanism during a one-minute period, the probability shall be less than one in 100,000 that a random attempt will succeed or a false acceptance will occur.",
        "formInputs": [
            {
                "controlName": "AS.03.26_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.26_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.26_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.26.01",
        "description": "The tester shall review the vendor documentation and verify for each authentication method that the associated probability of a successful random attempt during a one-minute period is less than one in 100,000.",
        "formInputs": [
            {
                "controlName": "TE.03.26.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.26.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.26.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.27",
        "description": "Feedback of authentication data to an operator shall be obscured during authentication (e.g., no visible display of characters when entering a password).",
        "formInputs": [
            {
                "controlName": "AS.03.27_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.27_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.27_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.27.01",
        "description": "The tester shall review the vendor documentation and verify that the authentication data is obscured during data entry.",
        "formInputs": [
            {
                "controlName": "TE.03.27.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.27.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.27.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.27.02",
        "description": "The tester shall enter authentication data and verify that there is no visible display of authentication data during data entry.",
        "formInputs": [
            {
                "controlName": "TE.03.27.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.27.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.27.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.28",
        "description": "Feedback provided to an operator during an attempted authentication shall not weaken the strength of the authentication mechanism.",
        "formInputs": [
            {
                "controlName": "AS.03.28_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.28_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.28_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.28.01",
        "description": "The tester shall review the vendor documentation and verify that the feedback mechanism does not provide information that could be used to guess or determine the authentication data.",
        "formInputs": [
            {
                "controlName": "TE.03.28.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.28.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.28.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.03.28.02",
        "description": "The tester shall enter authentication data to assume each role to ensure that the feedback mechanism does not provide useful information.",
        "formInputs": [
            {
                "controlName": "TE.03.28.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.03.28.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.03.28.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.29",
        "description": "Documentation shall specify: <ul> <li> the authentication mechanisms supported by the cryptographic module, <li> the types of authentication data required by the module to implement the supported authentication mechanisms, <li> the authorized methods used to control access to the module for the first time and initialize the authentication mechanisms, and <li> the strength of the authentication mechanisms supported by the module.  </ul> Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.03.29_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.29_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.29_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.30",
        "description": "The cryptographic module shall employ identity-based authentication mechanisms to control access to the module.  Note: This assertion is tested as part of AS03.19.TE.03.30.01",
        "formInputs": [
            {
                "controlName": "AS.03.30_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.30_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.30_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.03.32",
        "description": "The cryptographic module shall employ identity-based authentication mechanisms to control access to the module.  Note: This assertion is tested as part of AS03.19.",
        "formInputs": [
            {
                "controlName": "AS.03.32_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.03.32_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.03.32_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    }
]