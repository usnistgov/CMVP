export const Section6 = [
    {
        "title": "AS.06.01",
        "description": "If the operational environment is a modifiable operational environment, the operating system requirements in Section 4.6.1 shall apply.  Note: This assertion is not separately tested.",
        "formInputs": [
            {
                "controlName": "AS.06.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.02",
        "description": "Documentation shall specify the operational environment for the cryptographic module, including, if applicable, the operating system employed by the module, and for Security Levels 2, 3, and 4, the Protection Profile and the CC assurance level.",
        "formInputs": [
            {
                "controlName": "AS.06.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.02.01",
        "description": "The tester shall verify that the information specified in VE06.02.01 is included.  If this information is not included, then this assertion fails.",
        "formInputs": [
            {
                "controlName": "TE.06.02.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.02.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.02.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.03",
        "description": "The following requirements shall apply to operating systems for Security Level 1.  Note: This assertion is tested as part of AS.06.04 through AS.06.08.",
        "formInputs": [
            {
                "controlName": "AS.06.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.07 ",
        "description": "All cryptographic software and firmware shall be installed in a form that protects the software and firmware source and executable code from unauthorized disclosure and modification.",
        "formInputs": [
            {
                "controlName": "AS.06.07 _assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.07 _status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.07 _re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.07.01",
        "description": "The tester shall attempt to perform unauthorized accesses and unauthorized modifications to software and firmware source and executable code.",
        "formInputs": [
            {
                "controlName": "TE.06.07.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.07.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.07.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.08 ",
        "description": "A cryptographic mechanism using an Approved integrity technique (e.g., an Approved message authentication code or digital signature algorithm) shall be applied to all cryptographic software and firmware components within the cryptographic module.",
        "formInputs": [
            {
                "controlName": "AS.06.08 _assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.08 _status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.08 _re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.08.01",
        "description": "The tester shall verify that the information specified in VE06.08.01 is included.  If this information is not included, then this assertion fails.",
        "formInputs": [
            {
                "controlName": "TE.06.08.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.08.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.08.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.08.02",
        "description": "The tester shall attempt to corrupt the cryptographic software and firmware components.  If the integrity is maintained, this TE fails.",
        "formInputs": [
            {
                "controlName": "TE.06.08.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.08.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.08.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.11",
        "description": "To protect plaintext data, cryptographic software and firmware, cryptographic keys and CSPs, and authentication data, the discretionary access control mechanisms of the operating system shall be configured to specify the set of roles that can execute stored cryptographic software and firmware.",
        "formInputs": [
            {
                "controlName": "AS.06.11_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.11_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.11_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.11.01",
        "description": "This TE is tested as part of TE06.14.01.",
        "formInputs": [
            {
                "controlName": "TE.06.11.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.11.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.11.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.11.02",
        "description": "The tester shall assume a role with privileges to execute the stored cryptographic software and firmware components.  The tester shall execute the stored cryptographic software and firmware components to verify the correct configuration of the operating system access control mechanisms.",
        "formInputs": [
            {
                "controlName": "TE.06.11.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.11.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.11.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.11.03",
        "description": "The tester shall assume a role that does not have privileges to execute the stored cryptographic software and firmware components.  The tester shall attempt to execute the stored cryptographic software and firmware components to verify the correct configuration of the operating system access control mechanisms. If the tester can execute the stored cryptographic software and firmware components, this assertion fails.",
        "formInputs": [
            {
                "controlName": "TE.06.11.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.11.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.11.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.12",
        "description": "To protect plaintext data, cryptographic software and firmware, cryptographic keys and CSPs, and authentication data, the discretionary access control mechanisms of the operating system shall be configured to specify the set of roles that can modify (i.e., write, replace, and delete) the following cryptographic module software or firmware components stored within the cryptographic boundary: cryptographic programs, cryptographic data (e.g., cryptographic keys and audit data), CSPs, and plaintext data.",
        "formInputs": [
            {
                "controlName": "AS.06.12_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.12_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.12_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.12.01",
        "description": "This TE is tested as part of TE06.14.01.",
        "formInputs": [
            {
                "controlName": "TE.06.12.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.12.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.12.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.12.02",
        "description": "The tester shall assume a role with privileges to modify the following cryptographic module software and firmware components stored within the cryptographic boundary: <ol> <li> Cryptographic programs <li> Cryptographic data (e.g., cryptographic keys, audit data) <li> CSPs <li> Plaintext data </ol> The tester shall modify the cryptographic module software and firmware components stored within the cryptographic boundary.",
        "formInputs": [
            {
                "controlName": "TE.06.12.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.12.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.12.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.12.03",
        "description": "The tester shall assume a role that does not have privileges to modify the stored cryptographic software and firmware components.  The tester shall attempt to modify the stored cryptographic software and firmware components.",
        "formInputs": [
            {
                "controlName": "TE.06.12.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.12.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.12.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.13",
        "description": "To protect plaintext data, cryptographic software and firmware, cryptographic keys and CSPs, and authentication data, the discretionary access control mechanisms of the operating system shall be configured to specify the set of roles that can read the following cryptographic software components stored within the cryptographic boundary: cryptographic data (e.g., cryptographic keys and audit data), CSPs, and plaintext data.",
        "formInputs": [
            {
                "controlName": "AS.06.13_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.13_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.13_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.13.01",
        "description": "This TE is tested as part of TE06.14.01.",
        "formInputs": [
            {
                "controlName": "TE.06.13.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.13.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.13.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.13.02",
        "description": "The tester shall assume a role with privileges to read the following cryptographic module software components stored within the cryptographic boundary: <ol> <li> Cryptographic data (e.g., cryptographic keys and audit data) <li> CSPs <li> Plaintext data </ol> The tester shall read the cryptographic module software components stored within the cryptographic boundary.",
        "formInputs": [
            {
                "controlName": "TE.06.13.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.13.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.13.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.13.03",
        "description": "The tester shall assume a role that does not have privileges to read the stored cryptographic software components.  The tester shall attempt to read the stored cryptographic software components.",
        "formInputs": [
            {
                "controlName": "TE.06.13.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.13.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.13.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.14",
        "description": "To protect plaintext data, cryptographic software and firmware, cryptographic keys and CSPs, and authentication data, the discretionary access control mechanisms of the operating system shall be configured to specify the set of roles that can enter cryptographic keys and CSPs.",
        "formInputs": [
            {
                "controlName": "AS.06.14_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.14_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.14_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.14.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.14.01.",
        "formInputs": [
            {
                "controlName": "TE.06.14.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.14.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.14.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.14.02",
        "description": "The tester shall assume a role with privileges to enter cryptographic keys and CSPs. The tester shall enter cryptographic keys and CSPs.",
        "formInputs": [
            {
                "controlName": "TE.06.14.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.14.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.14.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.14.03",
        "description": "The tester shall assume a role that does not have privileges to enter cryptographic keys and CSPs.  The tester shall attempt to enter cryptographic keys and CSPs.",
        "formInputs": [
            {
                "controlName": "TE.06.14.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.14.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.14.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.15",
        "description": "The operating system shall prevent all operators and executing processes from modifying executing cryptographic processes (i.e., loaded and executing cryptographic program images).  In this case, executing processes refer to all non-operating system processes (i.e., operator-initiated), cryptographic or not.",
        "formInputs": [
            {
                "controlName": "AS.06.15_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.15_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.15_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.15.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.15.01.",
        "formInputs": [
            {
                "controlName": "TE.06.15.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.15.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.15.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.15.02",
        "description": "The tester shall attempt to modify executing cryptographic processes.  This test fails if an operator or executing process can modify an executing cryptographic process.",
        "formInputs": [
            {
                "controlName": "TE.06.15.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.15.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.15.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.16",
        "description": "The operating system shall prevent operators and executing processes from reading cryptographic software stored within the cryptographic boundary.",
        "formInputs": [
            {
                "controlName": "AS.06.16_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.16_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.16_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.16.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.16.01.",
        "formInputs": [
            {
                "controlName": "TE.06.16.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.16.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.16.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.16.02",
        "description": "The tester shall attempt to read cryptographic software stored within the cryptographic boundary. The tester must verify that no operator or executing process can read the cryptographic software stored within the cryptographic boundary.",
        "formInputs": [
            {
                "controlName": "TE.06.16.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.16.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.16.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.17",
        "description": "The operating system shall provide an audit mechanism to record modifications, accesses, deletions, and additions of cryptographic data and CSPs.  Note: An assumption of this assertion is that the cryptographic module must use the audit mechanism provided by the operating system to audit the identified events.  It is not sufficient for the cryptographic module software to use another file as its audit log, no matter how well protected.",
        "formInputs": [
            {
                "controlName": "AS.06.17_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.17_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.17_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.17.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.17.01",
        "formInputs": [
            {
                "controlName": "TE.06.17.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.17.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.17.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.17.02",
        "description": "The tester shall exercise the cryptographic module, with the auditing capability turned on, and perform the actions that generate auditable events.  The tester shall review the system's audit log to determine if all the events were audited.",
        "formInputs": [
            {
                "controlName": "TE.06.17.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.17.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.17.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.18",
        "description": "The following events shall be recorded by the audit mechanism: <ul> <li> attempts to provide invalid input for crypto officer functions, and <li> the addition or deletion of an operator to/from a crypto officer role.  </ul> Note:  This assertion is tested as part of AS.06.17.",
        "formInputs": [
            {
                "controlName": "AS.06.18_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.18_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.18_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.19",
        "description": "The audit mechanism shall be capable of auditing the following events: <ul> <li> operations to process audit data stored in the audit trail, <li> requests to use authentication data management mechanisms, <li> use of a security-relevant crypto officer function, <li> requests to access user authentication data associated with the cryptographic module, <li> use of an authentication mechanism (e.g., login) associated with the cryptographic module, <li> explicit requests to assume a crypto officer role, and <li> the allocation of a function to a crypto officer role.  </ul> Note:  This assertion is tested as part of AS.06.17.",
        "formInputs": [
            {
                "controlName": "AS.06.19_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.19_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.19_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.22",
        "description": "All cryptographic keys and CSPs, authentication data, control inputs, and status outputs shall be communicated via a trusted mechanism (e.g., a dedicated I/O physical port or a trusted path).",
        "formInputs": [
            {
                "controlName": "AS.06.22_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.22_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.22_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.22.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.22.01.",
        "formInputs": [
            {
                "controlName": "TE.06.22.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.22.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.22.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.22.02",
        "description": "The tester shall use the trusted mechanism to communicate all cryptographic keys and CSPs, authentication data, control inputs, and status outputs Note: If the trusted mechanism is a trusted path, and the trusted path was an evaluated feature of the operating system, the tester need not independently test the trusted path.  If the trusted mechanism is not a trusted path, or if a trusted path is not an evaluated feature of the operating system, then the tester must test for correct operation and non-circumventability of the trusted mechanism.",
        "formInputs": [
            {
                "controlName": "TE.06.22.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.22.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.22.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.22.03",
        "description": "The tester shall attempt, for each input and output identified in AS.06.22, to enter or output the information via an untrusted mechanism.",
        "formInputs": [
            {
                "controlName": "TE.06.22.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.22.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.22.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.23",
        "description": "If a trusted path is used, the Target of Evaluation Security Functions (TSF) shall support the trusted path between the TSF and the operator when a positive TSF-to-operator connection is required.",
        "formInputs": [
            {
                "controlName": "AS.06.23_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.23_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.23_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.23.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.23.01.",
        "formInputs": [
            {
                "controlName": "TE.06.23.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.23.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.23.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.24",
        "description": "Communications via this trusted path shall be activated exclusively by an operator or the TSF and shall be logically isolated from other paths.",
        "formInputs": [
            {
                "controlName": "AS.06.24_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.24_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.24_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.24.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.24.01.",
        "formInputs": [
            {
                "controlName": "TE.06.24.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.24.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.24.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.24.02",
        "description": "The tester shall invoke the trusted path.  If the capability exists for the TSF to invoke the trusted path, the tester shall exercise the cryptographic module to cause the TSF to invoke the trusted path.",
        "formInputs": [
            {
                "controlName": "TE.06.24.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.24.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.24.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.24.03",
        "description": "The tester shall attempt to cause the trusted path to be invoked by non-TSF software.",
        "formInputs": [
            {
                "controlName": "TE.06.24.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.24.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.24.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.25",
        "description": "In addition to the audit requirements of Security Level 2, the following events shall be recorded by the audit mechanism: <ul> <li> attempts to use the trusted path function, and <li> identification of the initiator and target of a trusted path.  </ul>",
        "formInputs": [
            {
                "controlName": "AS.06.25_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.25_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.25_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.25.01",
        "description": "The tester shall verify that the vendor has supplied the information required under VE06.25.01",
        "formInputs": [
            {
                "controlName": "TE.06.25.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.25.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.25.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.25.02",
        "description": "The tester shall exercise the cryptographic module, with the auditing capability turned on, and perform the actions that generate the audited events.  The tester shall review the system's audit log to determine if all the events were audited.",
        "formInputs": [
            {
                "controlName": "TE.06.25.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.25.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.25.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.26",
        "description": "In addition to the applicable requirements for Security Levels 1, 2, and 3, the following requirements shall also apply to operating systems for Security Level 4.  Note: This assertion is tested as part of AS.06.27.",
        "formInputs": [
            {
                "controlName": "AS.06.26_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.26_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.26_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.06.27",
        "description": "All cryptographic software, cryptographic keys and CSPs, and control and status information shall be under the control of <ul> <li> an operating system that meets the functional requirements specified in the Protection Profiles listed in Annex B.  The operating system shall be evaluated at the CC evaluation assurance level EAL4, or <li> an equivalent evaluated trusted operating system.  </ul>",
        "formInputs": [
            {
                "controlName": "AS.06.27_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.06.27_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.06.27_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.06.27.01",
        "description": "The tester shall verify that the operating system has received a certificate mutually recognized in accordance with the Arrangement on the Recognition of Common Criteria Certificates in the field of Information Technology Security.",
        "formInputs": [
            {
                "controlName": "TE.06.27.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.06.27.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.06.27.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    }
]