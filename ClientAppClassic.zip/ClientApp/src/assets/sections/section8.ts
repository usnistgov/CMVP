export const Section8 = [
    {
        "title": "AS.08.01",
        "description": "Cryptographic modules shall meet the following requirements for EMI/EMC.  Note: This assertion is not separately tested.\t",
        "formInputs": [
            {
                "controlName": "AS.08.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.08.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.08.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.08.02",
        "description": "Radios are explicitly excluded from these requirements but shall meet all applicable FCC requirements.  Note: The phrase \"these requirements\" refers to the requirements in FIPS PUB 140-2.\t",
        "formInputs": [
            {
                "controlName": "AS.08.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.08.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.08.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.08.02.01",
        "description": "The tester shall verify that the vendor has supplied the name of the FCC Accredited Laboratory required under VE08.02.01.\t",
        "formInputs": [
            {
                "controlName": "TE.08.02.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.08.02.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.08.02.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.08.02.02",
        "description": "The tester shall verify that the vendor has supplied the FCC ID number required under VE08.02.02.\t",
        "formInputs": [
            {
                "controlName": "TE.08.02.02_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.08.02.02_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.08.02.02_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.08.03",
        "description": "Documentation shall include proof of conformance to EMI/EMC requirements.  Note: This assertion is tested as part of AS08.04 and AS08.05.\t",
        "formInputs": [
            {
                "controlName": "AS.08.03_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.08.03_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.08.03_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "AS.08.05",
        "description": "The cryptographic module shall (at a minimum) conform to the EMI/EMC requirements specified by 47 Code of Federal Regulations, Part 15, Subpart B, Unintentional Radiators, Digital Devices, Class B (i.e., for home use).\t",
        "formInputs": [
            {
                "controlName": "AS.08.05_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "AS.08.05_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "AS.08.05_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    },
    {
        "title": "TE.08.05.01",
        "description": "The tester shall verify that the vendor has supplied t\u0000\u0004",
        "formInputs": [
            {
                "controlName": "TE.08.05.01_assessment",
                "label": "Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            },
            {
                "controlName": "TE.08.05.01_status",
                "label": "Test Status",
                "type": "radio",
                "options": [
                    {
                        "label": "Passed",
                        "value": "1"
                    },
                    {
                        "label": "Failed",
                        "value": "2"
                    },
                    {
                        "label": "Open",
                        "value": "0"
                    },
                    {
                        "label": "ReVal Passed",
                        "value": "4"
                    },
                    {
                        "label": "Not Applicable",
                        "value": "3"
                    }
                ],
                "col": 30
            },
            {
                "controlName": "TE.08.05.01_re-assessment",
                "label": "Re-Assessment",
                "type": "textarea",
                "col": 70,
                "rows": 5
            }
        ]
    }
]