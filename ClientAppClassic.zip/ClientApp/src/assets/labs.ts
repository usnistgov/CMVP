export const Labs = [

    
    {
        fullName: "CYGNACOM SOLUTIONS INC",
        labCode: "02"
    },
    {
        fullName: "COACT INC CAFE LAB",
        labCode: "04"
    },
    {
        fullName: "EWA CANADA",
        labCode: "06"
    },
    {
        fullName: "UL VERIFICATION SERVICES INC",
        labCode: "01"
    },
    {
        fullName: "TÜV INFORMATIONSTECHNIK GMBH",
        labCode: "09"
    },
    {
        fullName: "ATSEC INFORMATION SECURITY CORP",
        labCode: "11"
    },
    {
        fullName: "LEIDOS CSTL",
        labCode: "13"
    },
    {
        fullName: "ÆGISOLVE",
        labCode: "15"
    },
    {
        fullName: "ECSEC LABORATORY INC",
        labCode: "17"
    },
    {
        fullName: "DEKRA Testing and Certification S.A.U",
        labCode: "18"
    },
    {
        fullName: "IT SECURITY CENTER",
        labCode: "19"
    },
    {
        fullName: "BOOZ ALLEN HAMILTON",
        labCode: "24"
    },
    {
        fullName: "ADVANCED DATA SECURITY LLC",
        labCode: "25"
    },
    {
        fullName: "PENUMBRA SECURITY",
        labCode: "27"
    },
    {
        fullName: "GOSSAMER SECURITY SOLUTIONS INC",
        labCode: "28"
    },
    {
        fullName: "ACUMEN SECURITY, LLC",
        labCode: "29"
    },
    {
        fullName: "ASIA PACIFIC IT LABORATORY, TÜV NORD",
        labCode: "30"
    },
    {
        fullName: "SERMA TECHNOLOGIES ITSEF",
        labCode: "31"
    },
    {
        fullName: "Lightship Security, Inc.",
        labCode: "32"
    },
    {
        fullName: "CyberSecurity Malaysia",
        labCode: "34"
    },




]