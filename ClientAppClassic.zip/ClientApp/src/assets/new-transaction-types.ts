export const NewTransactionTypes = [
    {
      label: "Full Submission",
      value: "FS",
    },
    {
      label: "Vendor Update",
      value: "VUP",
    },

  
  ];
  