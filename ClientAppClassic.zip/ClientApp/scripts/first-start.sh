export NVM_DIR=$HOME/.nvm;
source $NVM_DIR/nvm.sh;
nvm use 12.14.1
cd ..
npm install
ng serve