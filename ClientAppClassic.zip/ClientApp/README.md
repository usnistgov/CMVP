# Cryptik Angular


## Installation

Install [Node.Js](https://nodejs.org/en/).

Install npm

```bash
sudo npm install npm -g
```

Install Angular cli


```bash
npm install -g @angular/cli
```

## Run

Run the following commands from the project root folder to start the app

```bash
npm install
```

```bash
ng serve
```

Open [http://localhost:4200/](http://localhost:4200/)
