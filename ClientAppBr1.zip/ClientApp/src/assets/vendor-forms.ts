import { LabNames } from "./lab-names";
import { SubmissionTypes } from "./submission-types";
import { TransactionTypes } from "./transaction-types";

export const VendorForms = [
  {
    title: "Laboratory Information",
    group: "laboratory",
    default: true,
    formInputs: [
      {
        controlName: "labName",
        label: "Lab Name",
        info: "The name of the lab should match NVLAP’s documentation",
        required: true,
        type: "select",
        options: LabNames,
        col: 100,
      },
      {
        controlName: "labCode",
        label: "LC",
        type: "text",
        disabled: true,
        col: 50,
      },
      {
        controlName: "labInternalId",
        label: "Lab Internal ID",
        type: "text",
        col: 50,
      },
      // {
      //   controlName: "nvlap-code",
      //   label: "NVLAP Code",
      //   info: "A code assigned by NVLAP",
      //   // "required": true,
      //   hidden: true,
      //   type: "select",
      //   disabled: true,
      //   options: [
      //     {
      //       label: "100414-0",
      //       value: "100414-0",
      //     },
      //     {
      //       label: "100432-0",
      //       value: "100432-0",
      //     },
      //     {
      //       label: "200002-0",
      //       value: "200002-0",
      //     },
      //     {
      //       label: "200416-0",
      //       value: "200416-0",
      //     },
      //     {
      //       label: "200423-0",
      //       value: "200423-0",
      //     },
      //     {
      //       label: "200427-0",
      //       value: "200427-0",
      //     },
      //     {
      //       label: "200556-0",
      //       value: "200556-0",
      //     },
      //     {
      //       label: "200636-0",
      //       value: "200636-0",
      //     },
      //     {
      //       label: "200658-0",
      //       value: "200658-0",
      //     },
      //     {
      //       label: "200697-0",
      //       value: "200697-0",
      //     },
      //     {
      //       label: "200802-0",
      //       value: "200802-0",
      //     },
      //     {
      //       label: "200822-0",
      //       value: "200822-0",
      //     },
      //     {
      //       label: "200835-0",
      //       value: "200835-0",
      //     },
      //     {
      //       label: "200856-0",
      //       value: "200856-0",
      //     },
      //     {
      //       label: "200900-0",
      //       value: "200900-0",
      //     },
      //     {
      //       label: "200901-0",
      //       value: "200901-0",
      //     },
      //     {
      //       label: "200928-0",
      //       value: "200928-0",
      //     },
      //     {
      //       label: "200968-0",
      //       value: "200968-0",
      //     },
      //     {
      //       label: "200983-0",
      //       value: "200983-0",
      //     },
      //     {
      //       label: "200996-0",
      //       value: "200996-0",
      //     },
      //     {
      //       label: "200997-0",
      //       value: "200997-0",
      //     },
      //     {
      //       label: "201029-0",
      //       value: "201029-0",
      //     },
      //     {
      //       label: "201038-0",
      //       value: "201038-0",
      //     },
      //   ],
      //   col: 50,
      // },
      // {
      //   controlName: "addressLine1",
      //   label: "Address line 1",
      //   required: true,
      //   type: "text",
      //   col: 100
      // },
      // {
      //   controlName: "addressLine2",
      //   label: "Address line 2",
      //   type: "text",
      //   col: 100
      // },
      // {
      //   controlName: "addressLine3",
      //   label: "Address line 3",
      //   type: "text",
      //   col: 100
      // },
      // {
      //   controlName: "city",
      //   label: "City",
      //   required: true,
      //   type: "text",
      //   col: 100
      // },
      // {
      //   controlName: "stateProvince",
      //   label: "State / Province",
      //   type: "text",
      //   col: 100
      // },
      // {
      //   controlName: "postalCode",
      //   label: "Postal Code",
      //   required: true,
      //   type: "text",
      //   col: 100
      // },
      // {
      //   controlName: "country",
      //   label: "Country",
      //   required: true,
      //   type: "text",
      //   col: 100
      // },
      {
        controlName: "signature1",
        label: "Signature 1",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "title1",
        label: "Title",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "signature2",
        label: "Signature 2",
        type: "text",
        col: 50,
      },
      {
        controlName: "title2",
        label: "Title",
        type: "text",
        col: 50,
      },
      {
        controlName: "signature3",
        label: "Signature 3",
        type: "text",
        col: 50,
      },
      {
        controlName: "title3",
        label: "Title",
        type: "text",
        col: 50,
      },
      {
        controlName: "tester1Name",
        label: "Tester 1",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "tester1Cvp",
        label: "CVP number",
        required: true,
        type: "text",
        col: 50,
      },

      {
        controlName: "tester2Name",
        label: "Tester 2",
        type: "text",
        col: 50,
      },
      {
        controlName: "tester2Cvp",
        label: "CVP number",
        type: "text",
        col: 50,
      },
      {
        controlName: "reviewer1Name",
        label: "Tech Reviewer 1",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "reviewer2Name",
        label: "Tech Reviewer 2",
        type: "text",
        col: 50,
      },
      // {
      //   controlName: "optional-marking",
      //   label: "Optional Marketing",
      //   type: "text",
      //   col: 100
      // }
    ],
  },
  {
    title: "Vendor Information",
    group: "vendor",
    default: true,
    instructions: [
      "For US and Canada, please use the following format for phone and fax numbers: ###-###-####",
    ],
    formInputs: [
      {
        controlName: "vendorName",
        label: "Name",
        required: true,
        type: "text",
        col: 100,
      },
      {
        controlName: "addressLine1",
        label: "Address 1",
        required: true,
        type: "text",
        col: 100,
      },
      {
        controlName: "addressLine2",
        label: "Address 2",
        type: "text",
        col: 100,
      },
      {
        controlName: "addressLine3",
        label: "Address 3",
        type: "text",
        col: 100,
      },
      {
        controlName: "city",
        label: "City",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "stateProvince",
        label: "State / Province",
        type: "text",
        col: 50,
      },
      {
        controlName: "postalCode",
        label: "Postal Code",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "country",
        label: "Country",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "website",
        label: "Vendor Web Site",
        format: "website",
        required: true,
        validators: ["website"],

        type: "text",
        col: 100,
      },
      {
        controlName: "productLink",
        label: "Product Link",
        type: "text",
        col: 100,
      },
      {
        controlName: "contactName1",
        label: "Contact1 (POC1)",
        required: true,
        type: "text",
        col: 50,
      },
      {
        controlName: "email1",
        label: "Email1",
        required: true,
        validators: ["email"],
        type: "text",
        col: 50,
      },
      {
        controlName: "phone1",
        label: "Phone1",
        required: true,
        validators: ["phone"],
        type: "text",
        col: 50,
      },
      {
        controlName: "fax1",
        label: "Fax1",
        type: "text",
        col: 50,
      },
      {
        controlName: "contactName2",
        label: "Contact2 (POC2)",
        type: "text",
        col: 50,
      },
      {
        controlName: "email2",
        validators: ["email"],

        label: "Email2",
        type: "text",
        col: 50,
      },
      {
        controlName: "phone2",
        validators: ["phone"],
        label: "Phone2",
        type: "text",
        col: 50,
      },
      {
        controlName: "fax2",
        label: "Fax2",
        type: "text",
        col: 50,
      },
    ],
  },
  {
    title: "Module Information",
    group: "module",
    default: true,
    formInputs: [
      {
        controlName: "transmissionCode",
        label: "Transaction Type",
        required: true,
        type: "select",
        options: TransactionTypes,
        col: 100,
      },
      // {
      //   controlName: "transmissionCode",
      //   label: "Submission Type",
      //   required: true,
      //   type: "select",
      //   options: SubmissionTypes,
      //   col: 100,
      // },

      // {
      //   controlName: "update-version-label",
      //   label: "Update version label",
      //   type: "select",
      //   col: 100,
      //   hidden: true,
      //   options: [
      //     {
      //       label: "1",
      //       value: "1",
      //     },
      //     {
      //       label: "2",
      //       value: "2",
      //     },
      //     {
      //       label: "3",
      //       value: "3",
      //     },
      //     {
      //       label: "4",
      //       value: "4",
      //     },
      //     {
      //       label: "5",
      //       value: "5",
      //     },
      //     {
      //       label: "6",
      //       value: "6",
      //     },
      //     {
      //       label: "7",
      //       value: "7",
      //     },
      //     {
      //       label: "8",
      //       value: "8",
      //     },
      //     {
      //       label: "9",
      //       value: "9",
      //     },
      //     {
      //       label: "10",
      //       value: "10",
      //     },
      //   ],
      // },
      {
        controlName: "explanation",
        label: "Explanation",
        type: "text",
        hidden: true,
      },
      {
        controlName: "scenario",
        label: "Submission scenario",
        type: "text",
        hidden: true,
      },
      {
        controlName: "commentsRound",
        label: "Comments round",
        type: "number",
        default: 0,
        hidden: true,
      },

      {
        controlName: "cstlTid",
        info: "TID for CSTL",
        label: "CSTL TID",
        required: true,
        type: "text",
        maxLength: 4,
        minLength: 4,
        col: 50,
      },
      {
        controlName: "csecTid",
        label: "CCCS TID",
        required: true,
        type: "text",
        default: "0000",
        maxLength: 4,
        minLength: 4,
        disabled: true,
        col: 50,
      },

      {
        controlName: "name",
        label: "Module Name(s)",
        info: "The name of the Module",
        required: true,
        type: "text",
        col: 100,
      },

      {
        controlName: "fipsVersion",
        label: "FIPS Version",
        info: "The version of the standard",
        required: true,
        type: "text",
        default: "FIPS 140-3",
        disabled: true,
        col: 100,
        // options: [
        //   // {
        //   //   label: "FIPS 140-2",
        //   //   value: "FIPS 140-2"
        //   // },
        //   {
        //     label: "FIPS 140-3",
        //     value: "FIPS 140-3",
        //   },
        // ],
      },

      // {
      //   controlName: "entropy",
      //   label: "Entropy",
      //   type: "checkbox",
      //   default: false,
      //   hidden: true,
      //   col: 50,
      // },
      // {
      //   controlName: "entropy-technology",
      //   label: "Entropy technology",
      //   type: "select",
      //   hidden: true,
      //   col: 50,
      //   options: [
      //     {
      //       label: "Ring Oscillators",
      //       value: "Ring Oscillators",
      //     },
      //     {
      //       label: "RDSEED/RDRAND",
      //       value: "RDSEED/RDRAND",
      //     },
      //     {
      //       label: "CPU Jitter",
      //       value: "CPU Jitter",
      //     },
      //     {
      //       label: "Linux RNG",
      //       value: "Linux RNG",
      //     },
      //     {
      //       label: "Quantum Source",
      //       value: "Quantum Source",
      //     },
      //     {
      //       label: "Other Hardware Source",
      //       value: "Other Hardware Source",
      //     },
      //     {
      //       label: "Other Software Source",
      //       value: "Other Software Source",
      //     },
      //     {
      //       label: "IG 9.3.A Scenario 2",
      //       value: "IG 9.3.A Scenario 2",
      //     },
      //   ],
      // },
      {
        controlName: "count",
        label: "Module Count",
        required: true,
        type: "number",
        col: 100,
      },

      {
        controlName: "description",
        label: "Module Description",
        required: true,
        type: "textarea",
        col: 100,
        rows: 5,
      },
      {
        controlName: "embodiment",
        label: "Module Embodiment",
        info: "07.09.01 physical security requirements are specified for three defined physical embodiments of a cryptographic module. Single-chip cryptographic modules are physical embodiments in which a single integrated circuit (IC) chip may be used as a standalone device or may be embedded within an enclosure or a product that may not be physically protected. Examples of single-chip cryptographic modules include single IC chips or smart cards with a single IC chip. b) Multiple-chip embedded cryptographic modules are physical embodiments in which two or more IC chips are interconnected and are embedded within an enclosure or a product that may not be physically protected. Examples of multiple-chip embedded cryptographic modules include adapters and expansion boards. Multiple-chip standalone cryptographic modules are physical embodiments in which two or more IC chips are interconnected and the entire enclosure is physically protected. Examples of multiple-chip, standalone cryptographic modules include encrypting routers, secure radios or USB tokens.",

        required: true,
        type: "radio",
        options: [
          {
            label: "Single Chip",
            value: "SingleChip",
          },
          {
            label: "Multi-Chip Embedded",
            value: "MultiChipEmbed",
          },
          {
            label: "Multi-Chip standalone",
            value: "MultiChipStand",
          },
        ],
        col: 50,
      },
      {
        controlName: "type",
        label: "Type",
        required: true,
        type: "select",
        options: [
          {
            label: "Software",
            value: "Software",
          },
          {
            label: "Hardware",
            value: "Hardware",
          },
          {
            label: "Firmware",
            value: "Firmware",
          },
          {
            label: "Software-hybrid",
            value: "Software-hybrid",
          },
          {
            label: "Firmware-hybrid",
            value: "Firmware-hybrid",
          },
        ],
        col: 50,
      },
      {
        controlName: "opEnvType",
        label: "Operational Environment Type",
        required: true,
        type: "select",
        options: [
          {
            label: "Modifiable",
            value: "Modifiable",
          },
          {
            label: "Limited",
            value: "Limited",
          },
          {
            label: "Non-Modifiable",
            value: "Non-Modifiable",
          },
        ],
        col: 100,
      },
      {
        label: "Section Level",
        type: "questionnaire",
        answers: [
          {
            label: "1",
            value: "1",
            color: "yellow",
          },
          {
            label: "2",
            value: "2",
            color: "green",
          },
          {
            label: "3",
            value: "3",
            color: "blue",
          },
          {
            label: "4",
            value: "4",
            color: "orange",
          },
          {
            label: "NA",
            value: "NA",
            color: "purple",
          },
        ],
        questions: [
          {
            controlName: "section1-level",
            label: "1",
            link: "/section1",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
          {
            controlName: "section2-level",
            label: "2",
            link: "/section2",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
          {
            controlName: "section3-level",
            label: "3",
            link: "/section3",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
          {
            controlName: "section4-level",
            label: "4",
            link: "/section4",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
          {
            controlName: "section5-level",
            label: "5",
            link: "/section5",
            possibleAnswers: ["1", "2", "3", "4", "NA"],
            default: "NA",
          },
          {
            controlName: "section6-level",
            label: "6",
            link: "/section6",
            possibleAnswers: ["1", "2", "3", "4", "NA"],
            default: "1",
          },
          {
            controlName: "section7-level",
            label: "7",
            link: "/section7",
            possibleAnswers: ["1", "2", "3", "4", "NA"],
            default: "NA",
          },
          {
            controlName: "section8-level",
            label: "8",
            link: "/section8",
            possibleAnswers: ["1", "2", "3", "4", "NA"],
            default: "NA",
          },
          {
            controlName: "section9-level",
            label: "9",
            link: "/section9",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
          {
            controlName: "section10-level",
            label: "10",
            link: "/section10",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
          {
            controlName: "section11-level",
            label: "11",
            link: "/section11",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
          {
            controlName: "section12-level",
            label: "12",
            link: "/section12",
            possibleAnswers: ["1", "2", "3", "4", "NA"],
            default: "NA",
          },

          {
            controlName: "overall-level",
            label: "Overall",
            possibleAnswers: ["1", "2", "3", "4"],
            default: "1",
          },
        ],
        col: 100,
      },

      {
        type: "checkboxes",
        label: "Administrative Flags",
        col: 100,
        options: [
          {
            controlName: "itar",
            label: "ITAR",
            type: "checkbox",
            info: "Must be filled in if an ITAR submission – affects filename",
          },
          {
            controlName: "addToMipList",
            label: "Add Module to MIP List",
            info: "Module in process list. CMVP variables",
            type: "checkbox",
          },
        ],
      },
      {
        controlName: "certificateCaveat",
        label: "Cert Caveat",
        type: "text",
        col: 100,
      },

      {
        controlName: "pivCertNumber",
        label: "PIV Cert #",
        type: "text",
        col: 50,
      },
      // {
      //   controlName: "validation-cert-number",
      //   info: "1 OEM is the only time this would be here.",
      //   label: "Validation Cert #",
      //   type: "text",
      //   col: 50
      // },

      {
        controlName: "specialInstructions",
        label: "Special Instruction",
        type: "textarea",
        col: 100,
      },
    ],
  },
];
