export const TransactionTypes = [
  {
    label: "Full Submission",
    value: "FS",
  },
  {
    label: "IUT Add",
    value: "IUTA",
  },
  {
    label: "IUT Request for Billing",
    value: "IUTB",
  },
  {
    label: "IUT Cancel Billing",
    value: "IUTC",
  },
  {
    label: "IUT Remove",
    value: "IUTR",
  },
  {
    label: "IUT Modify",
    value: "IUTM",
  },

  {
    label: "sCMn – CMVP comments or returned CSTL addressed comments",
    value: "sCMn",
  },

  {
    label: "Drop Submission",
    value: "DRPT",
  },
  {
    label: "ECR Accept: Extended Cost Recovery",
    value: "ECRA"
  },
  {
    label: "ECR Reject",
    value: "ECRR"
  },

  {
    label: "STAT – Query report status",
    value: "STAT",
  },
  {
    label: "OTHR – Other",
    value: "OTHR",
  },
  {
    label: "Draft Certificate Approve",
    value: "FCLC_OK",
  },
  {
    label: "Draft Certificate Reject",
    value: "FCLC",
  },

];
