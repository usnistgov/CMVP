export const environment = {
  production: true,
  version: "Br1 v2.0.0",
};
