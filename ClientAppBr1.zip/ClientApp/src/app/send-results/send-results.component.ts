import { Component, OnInit } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { VendorForms } from "../../assets/vendor-forms";
import { FormService } from "../shared/services/form.service";
import { saveAs } from "file-saver";
import {
  trigger,
  state,
  style,
  transition,
  animate,
} from "@angular/animations";
import * as sections from "../../assets/sections";
import { MatDialog } from "@angular/material/dialog";
import { ConfirmationDialogComponent } from "../shared/components/confirmation-dialog/confirmation-dialog.component";
import { DatePipe } from "@angular/common";
import { Router } from "@angular/router";
import { ValidationService } from "../shared/services/validation.service";
// import { IFile } from '../encryption/model/file';
// import { IEncryptedFile } from '../encryption/model/encryptedFile';
// import {HttpClientService} from '../encryption/service/http-client.service';
// import {EncrDecrService} from '../encryption/service/encr-decr.service';

@Component({
  selector: "app-send-results",
  animations: [
    trigger("openClose", [
      // ...
      state(
        "open",
        style({
          width: "100%",
          opacity: 1,
          // backgroundColor: 'yellow'
        })
      ),
      state(
        "closed",
        style({
          width: "0%",
          opacity: 0.5,
          padding: "0",
          display: "none",
          // backgroundColor: 'green'
        })
      ),
      transition("open => closed", [animate("1s")]),
      transition("closed => open", [animate("0.5s")]),
      transition("* => closed", [animate("1s")]),
      transition("* => open", [animate("0.5s")]),
      transition("open <=> closed", [animate("0.5s")]),
      transition("* => open", [animate("1s", style({ opacity: "*" }))]),
      transition("* => *", [animate("1s")]),
    ]),
  ],
  templateUrl: "./send-results.component.html",
  styleUrls: ["./send-results.component.scss"],
})
export class SendResultsComponent implements OnInit {
  // selectedFiles = [];
  // files = [];
  // fileListToDisplay : Array<IFile>=[];
  // encrypedFilesList : Array<IEncryptedFile>=[];
  // constructor(private formService: FormService, public dialog: MatDialog, public datepipe: DatePipe, private EncrDecr: EncrDecrService, private api : HttpClientService) { }

  constructor(private validationService: ValidationService, private router: Router) {

  }
  ngOnInit() {
    if(!this.validationService.selectedValidation){
      this.router.navigate(["/validations"]);
    }
  }
}
