import { Component, OnInit } from "@angular/core";
import { SectionService } from "../shared/services/section.service";
import { environment } from "src/environments/environment";
import { UntypedFormArray } from "@angular/forms";

@Component({
  selector: "app-draft-certificate",
  templateUrl: "./draft-certificate.component.html",
  styleUrls: ["./draft-certificate.component.scss"],
})
export class DraftCertificateComponent implements OnInit {
  version = environment.version;
  table0;
  table5;
  table6;
  table7;
  table8;
  table9;
  table10;
  table11;

  levelsTables;
  embodimentsMap = {
    "1": "Single Chip",
    "2": "Multi-Chip Embedded",
    "3": "Multi-Chip standalone",
  };
  constructor(public sectionService: SectionService) {}

  ngOnInit() {
    this.table5 =
      this.sectionService.sections["B"].value["TEB.01.01"].approvedAlgorithms;
    this.table6 =
      this.sectionService.sections["B"].value[
        "TEB.01.01"
      ].vendorAffirmedApprovedAlgorithms;
    this.table7 =
      this.sectionService.sections["B"].value[
        "TEB.01.01"
      ].nonApprovedAlgorithms;
    this.table8 =
      this.sectionService.sections["B"].value[
        "TEB.01.01"
      ].nonApprovedAllowedNoSecurityClaimed;
    this.table9 = this.sectionService.sections["B"].value["TEB.01.01"].sfi;
    this.table10 =
      this.sectionService.sections["B"].value["TEB.01.01"].entropyCertificates;
    this.table11 =
      this.sectionService.sections["B"].value[
        "TEB.01.01"
      ].nonApprovedAllowedNoSecurityClaimedNotAllowed;

    this.levelsTables = this.sectionService.securityPolicyTables["B"][0];
  }
  getRowAsArray(form, arrayName) {
    return form.get(arrayName) as UntypedFormArray;
  }
}
