import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { IutaComponent } from "../shared/components/transactions/iuta/iuta.component";
import { RevalidationComponent } from "./revalidation/revalidation.component";
import { NewValidationComponent } from "./new-validation/new-validation.component";
import { ValidationComponent } from "./validation/validation.component";

const routes: Routes = [
  {
    path: "",
    component: ValidationComponent,
  },
  {
    path: "new-validation",
    component: NewValidationComponent,
  },
  {
    path: "revalidation",
    component: RevalidationComponent,
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ValidationsRoutingModule {}
