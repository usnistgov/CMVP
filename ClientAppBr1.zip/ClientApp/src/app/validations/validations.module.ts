import { NgModule } from "@angular/core";

import { ValidationsRoutingModule } from "./validations-routing.module";
import { SharedModule } from "../shared/shared.module";
import { IutaComponent } from "../shared/components/transactions/iuta/iuta.component";
import { IutbComponent } from "../shared/components/transactions/iutb/iutb.component";
import { IutcComponent } from "../shared/components/transactions/iutc/iutc.component";
import { IutmComponent } from "../shared/components/transactions/iutm/iutm.component";
import { IutrComponent } from "../shared/components/transactions/iutr/iutr.component";
import { DrptComponent } from "../shared/components/transactions/drpt/drpt.component";
import { EcraComponent } from "../shared/components/transactions/ecra/ecra.component";
import { EcrrComponent } from "../shared/components/transactions/ecrr/ecrr.component";
import { VupComponent } from "../shared/components/transactions/vup/vup.component";
import { VaoeComponent } from "../shared/components/transactions/vaoe/vaoe.component";
import { AlgComponent } from "../shared/components/transactions/alg/alg.component";
import { OeupComponent } from "../shared/components/transactions/oeup/oeup.component";
import { NsrlComponent } from "../shared/components/transactions/nsrl/nsrl.component";
import { RevalidationComponent } from "./revalidation/revalidation.component";
import { NewValidationComponent } from "./new-validation/new-validation.component";
import { ValidationComponent } from "./validation/validation.component";
import { RbndComponent } from "../shared/components/transactions/rbnd/rbnd.component";

@NgModule({
  declarations: [
    RevalidationComponent,
    NewValidationComponent,
    ValidationComponent,
    IutaComponent,
    IutbComponent,
    IutcComponent,
    IutmComponent,
    IutrComponent,
    DrptComponent,
    EcraComponent,
    EcrrComponent,
    VupComponent,
    VaoeComponent,
    AlgComponent,
    OeupComponent,
    NsrlComponent,
    RbndComponent

  ],
  imports: [ValidationsRoutingModule, SharedModule],
})
export class ValidationsModule { }
