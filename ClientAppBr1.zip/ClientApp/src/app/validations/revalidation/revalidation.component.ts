import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { TransactionTypes } from "src/assets/transaction-types";
import { filter, pairwise, tap } from 'rxjs/operators';
import { MatSelectChange } from "@angular/material/select";
import { BehaviorSubject } from "rxjs";
import { RevalidationTypes } from "src/assets/revalidation-types";
import { TransactionService } from "src/app/shared/services/transaction.service";
import { ValidationService } from "src/app/shared/services/validation.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-revalidation",
  templateUrl: "./revalidation.component.html",
  styleUrls: ["./revalidation.component.scss"],
})
export class RevalidationComponent implements OnInit {
  revalidationTypes = RevalidationTypes;


  constructor(private _formBuilder: FormBuilder, public transactionService: TransactionService, private validationService: ValidationService, private router: Router) {

  }

  ngOnInit() {
    if(!this.validationService.selectedValidation){
      this.router.navigate(["/validations"]);
    }

  }


}
