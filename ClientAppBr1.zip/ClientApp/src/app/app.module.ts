import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { SharedModule } from "./shared/shared.module";
import { HttpClientModule } from "@angular/common/http";
import { SubmissionGuard } from "./shared/services/guards/submission.guard";
import { ArtifactGuard } from "./shared/services/guards/artifact.guard";
import { ToastrModule } from "ngx-toastr";
import { RouterModule } from "@angular/router";

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    SharedModule,
    ToastrModule.forRoot(),
  ],
  providers: [SubmissionGuard, ArtifactGuard],
  bootstrap: [AppComponent],
})
export class AppModule {}
