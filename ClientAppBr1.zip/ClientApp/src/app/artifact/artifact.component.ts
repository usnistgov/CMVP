import { Component, OnInit } from "@angular/core";

import { FormService } from "../shared/services/form.service";
import { ConverterService } from "../shared/services/converter.service";
import { DatePipe } from "@angular/common";
import { SectionService } from "../shared/services/section.service";
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: "app-artifact",
  templateUrl: "./artifact.component.html",
  styleUrls: ["./artifact.component.scss"],
})
export class ArtifactComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public sectionService: SectionService,
    public formService: FormService,
    private converterService: ConverterService,
    public datepipe: DatePipe
  ) {}

  ngOnInit() {}
}
