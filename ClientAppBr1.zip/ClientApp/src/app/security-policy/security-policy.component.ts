import { Component, OnInit } from '@angular/core';
import { SectionService } from '../shared/services/section.service';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import * as _ from 'underscore';


@Component({
  selector: 'app-security-policy',
  templateUrl: './security-policy.component.html',
  styleUrls: ['./security-policy.component.scss']
})
export class SecurityPolicyComponent implements OnInit {

  tables = [];
  openedSection;
  formGroups = {};
  editingRow;
  editingTable;

  constructor(public sectionService: SectionService) {

  }

  ngOnInit() {
    this.tables = [];
    for (let sectionNb in this.sectionService.securityPolicyTables) {
      if (Object.prototype.hasOwnProperty.call(this.sectionService.securityPolicyTables, sectionNb)) {
        // do stuff
        const section = this.sectionService.securityPolicyTables[sectionNb];
        section.forEach(question => {
          this.tables.push({
            form: this.sectionService.sections[sectionNb].controls[question.question],
            details: question.details,
            question: question.question,
            type: question.type,
            formGroup: question.formGroup,
          })
          this.formGroups[question.question] = question.formGroup
        });
      }
    }

  }

  openSection(section) {

    this.openedSection = this.sectionService.sections[section.key];
    this.tables = [];
    section.value.forEach(question => {
      this.tables.push({
        form: this.sectionService.sections[section.key].controls[question.question],
        details: question.details,
        question: question.question,
        type: question.type,
        formGroup: question.formGroup,
      })
      this.formGroups[question.question] = question.formGroup
    });

  }
  addToFormArray(question, formGroup, ArrayControlName) {
    let formGroupObj = {};
    for (let index in formGroup.value) {
      formGroupObj[index] = new FormControl(formGroup.value[index]);
    }
    const fg = new FormGroup(formGroupObj);
    const table = this.tables.find(x => x.question == question);
    if (table) {
      let array = table.form.get(ArrayControlName) as FormArray;;
      array.push(fg);
    }

    formGroup.reset();
  }
  editFormInArray(index, question) {
    this.editingRow = index;
    this.editingTable = question;
  }
  deleteRow(form, arrayName, index) {
    const array = form.get(arrayName) as FormArray;
    array.removeAt(index);
  }
  saveRow() {
    this.editingRow = null;
    this.editingTable = null;
  }
  getRowAsArray(form, arrayName) {
    return form.get(arrayName) as FormArray
  }

}
