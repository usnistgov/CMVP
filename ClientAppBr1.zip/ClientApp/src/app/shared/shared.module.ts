import { NgModule } from "@angular/core";
import { CommonModule, DatePipe } from "@angular/common";
import { MatNativeDateModule } from "@angular/material/core";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatExpansionModule } from "@angular/material/expansion";
import { MatGridListModule } from "@angular/material/grid-list";

import { MatSidenavModule } from "@angular/material/sidenav";
import { MatToolbarModule } from "@angular/material/toolbar";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { NgxMatSelectSearchModule } from "ngx-mat-select-search";
import { FlexLayoutModule } from "@angular/flex-layout";
import { DynamicFormComponent } from "./components/dynamic-form/dynamic-form.component";
import { ConfirmationDialogComponent } from "./components/confirmation-dialog/confirmation-dialog.component";
import { SectionFormComponent } from "./components/section-form/section-form.component";
import { SharedSecurityPolicyComponent } from "./components/shared-security-policy/shared-security-policy.component";
import { SubmissionDialogComponent } from "./components/submission-dialog/submission-dialog.component";
import { ImageDialogComponent } from "./components/image-dialog/image-dialog.component";
import { ImportDialogComponent } from "./components/import-dialog/import-dialog.component";
import { DisclaimerDialogComponent } from "./components/disclaimer-dialog/disclaimer-dialog.component";
import { SaveDialogComponent } from "./components/save-dialog/save-dialog.component";
import { ExportSecurityDialogComponent } from "./components/export-security-dialog/export-security-dialog.component";
import { ConfirmDialogComponent } from "./components/confirm-dialog/confirm-dialog.component";
import { TypeDialogComponent } from "./components/type-dialog/type-dialog.component";
import { Br1TablesComponent } from "./components/br1-tables/br1-tables.component";
import { Table1Component } from "./components/br1-tables/table1/table1.component";
import { Table2Component } from "./components/br1-tables/table2/table2.component";
import { Table3Component } from "./components/br1-tables/table3/table3.component";
import { Table4Component } from "./components/br1-tables/table4/table4.component";

import { SupplementalInformationComponent } from "./components/supplemental-information/supplemental-information.component";
import { Table5Component } from "./components/br1-tables/table5/table5.component";
import { Table6Component } from "./components/br1-tables/table6/table6.component";
import { Table7Component } from "./components/br1-tables/table7/table7.component";
import { Table8Component } from "./components/br1-tables/table8/table8.component";
import { Table9Component } from "./components/br1-tables/table9/table9.component";
import { Table10Component } from "./components/br1-tables/table10/table10.component";
import { Table12Component } from "./components/br1-tables/table12/table12.component";
import { Table13Component } from "./components/br1-tables/table13/table13.component";
import { Table14Component } from "./components/br1-tables/table14/table14.component";
import { Table15Component } from "./components/br1-tables/table15/table15.component";
import { Table16Component } from "./components/br1-tables/table16/table16.component";
import { Table17Component } from "./components/br1-tables/table17/table17.component";
import { Table18Component } from "./components/br1-tables/table18/table18.component";
import { Table19Component } from "./components/br1-tables/table19/table19.component";
import { Table20Component } from "./components/br1-tables/table20/table20.component";
import { Table21Component } from "./components/br1-tables/table21/table21.component";
import { Table22Component } from "./components/br1-tables/table22/table22.component";
import { Table23Component } from "./components/br1-tables/table23/table23.component";
import { Table24Component } from "./components/br1-tables/table24/table24.component";
import { Table11Component } from "./components/br1-tables/table11/table11.component";
import { Table25Component } from "./components/br1-tables/table25/table25.component";
import { Table26Component } from "./components/br1-tables/table26/table26.component";
import { Table27Component } from "./components/br1-tables/table27/table27.component";
import { CavpBuilderComponent } from "./components/cavp-builder/cavp-builder.component";
import { TableStorageEditorComponent } from "./components/table-storage-editor/table-storage-editor.component";
import { TableAlgoPropEditorComponent } from "./components/table-algo-prop-editor/table-algo-prop-editor.component";
import { MatButtonModule } from "@angular/material/button";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatDialogModule } from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatSelectModule } from "@angular/material/select";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatIconModule } from "@angular/material/icon";
import { MatInputModule } from "@angular/material/input";
import { MatMenuModule } from "@angular/material/menu";
import { MatCardModule } from "@angular/material/card";
import { MatListModule } from "@angular/material/list";
import { MatRadioModule } from "@angular/material/radio";
import { MatStepperModule } from "@angular/material/stepper";

import { CapabilitiesEditorComponent } from "./components/capabilities-editor/capabilities-editor.component";
import { TreeModule } from "primeng/tree";
import { TreeSelectModule } from "primeng/treeselect";
import { TreeTableModule } from "primeng/treetable";
import { ScrollPanelModule } from "primeng/scrollpanel";
import {TableModule} from 'primeng/table';
import { ImportTransactionDialogComponent } from "./components/import-transaction-dialog/import-transaction-dialog.component";
import { DropdownModule } from "primeng/dropdown";

@NgModule({
  declarations: [
    DynamicFormComponent,
    SharedSecurityPolicyComponent,
    Br1TablesComponent,
    Table1Component,
    Table2Component,
    Table3Component,
    Table4Component,
    Table5Component,
    Table6Component,
    Table7Component,
    Table8Component,
    Table9Component,
    Table10Component,
    Table11Component,
    Table12Component,
    Table13Component,
    Table14Component,
    Table15Component,
    Table16Component,
    Table17Component,
    Table18Component,
    Table19Component,
    Table20Component,
    Table21Component,
    Table22Component,
    Table23Component,
    Table24Component,
    Table25Component,
    Table26Component,
    Table27Component,
    CavpBuilderComponent,
    SupplementalInformationComponent,
    ConfirmationDialogComponent,
    SectionFormComponent,
    SubmissionDialogComponent,
    SaveDialogComponent,
    ConfirmDialogComponent,
    ExportSecurityDialogComponent,
    ImageDialogComponent,
    ImportDialogComponent,
    ImportTransactionDialogComponent,
    DisclaimerDialogComponent,
    TableStorageEditorComponent,
    TableAlgoPropEditorComponent,
    TypeDialogComponent,
    CapabilitiesEditorComponent,
  ],
  providers: [DatePipe],
  imports: [
    CommonModule,
    MatExpansionModule,
    MatIconModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatGridListModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatRadioModule,
    MatStepperModule,
    NgxMatSelectSearchModule,
    FlexLayoutModule,
    MatMenuModule,
    MatDialogModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatInputModule,
    TreeModule,
    TreeSelectModule,
    TreeTableModule,
    ScrollPanelModule,
    TableModule,
    DropdownModule
  ],
  exports: [
    CommonModule,
    MatExpansionModule,
    MatIconModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatGridListModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatButtonModule,
    MatRadioModule,
    MatStepperModule,
    NgxMatSelectSearchModule,
    FlexLayoutModule,
    DynamicFormComponent,
    SharedSecurityPolicyComponent,
    Br1TablesComponent,
    Table1Component,
    Table2Component,
    Table3Component,
    Table4Component,
    Table5Component,
    Table6Component,
    Table7Component,
    Table8Component,
    Table9Component,
    Table10Component,
    Table11Component,
    Table12Component,
    Table13Component,
    Table14Component,
    Table15Component,
    Table16Component,
    Table17Component,
    Table18Component,
    Table19Component,
    Table20Component,
    Table21Component,
    Table22Component,
    Table23Component,
    Table24Component,
    Table25Component,
    Table26Component,
    Table27Component,
    CavpBuilderComponent,
    SupplementalInformationComponent,
    SectionFormComponent,
    MatMenuModule,
    MatDialogModule,
    MatCardModule,
    TreeModule,
    TreeSelectModule,
    TreeTableModule,
    TableModule,
    ScrollPanelModule,
    DropdownModule
  ],
})
export class SharedModule {}
