import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SectionService } from "src/app/shared/services/section.service";
import { TransactionTypes } from "src/assets/transaction-types";
import { ToastrService } from "ngx-toastr";
import { ScenarioTypes } from "src/assets/scenario-types";
import { TransactionService } from "src/app/shared/services/transaction.service";
import { FormService } from "src/app/shared/services/form.service";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ImportTransactionDialogComponent } from "../../import-transaction-dialog/import-transaction-dialog.component";

@Component({
  selector: "app-rbnd",
  templateUrl: "./rbnd.component.html",
  styleUrls: ["./rbnd.component.scss"],
})
export class RbndComponent implements OnInit {
  transactionTypes = TransactionTypes;
  scenarioTypes = ScenarioTypes;
  transactionType;

  constructor(private _formBuilder: FormBuilder, public sectionService: SectionService, public transactionService: TransactionService, private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.transactionService.initializeRBNDForm();
  }

  async getCert() {
    this.transactionService.getCert('RBND');
  }

  deleteField(form, fieldName) {
    form.controls[fieldName].setValue(null);
  }
  restoreField(form, fieldName) {
    form.controls[fieldName].setValue('');
  }
  deleteContact(number: string) {
    this.transactionService.form.get('payload').get('vendorInfo').get(`contactName${number}`).setValue(null);
    this.transactionService.form.get('payload').get('vendorInfo').get(`email${number}`).setValue(null);
    this.transactionService.form.get('payload').get('vendorInfo').get(`phone${number}`).setValue(null);
    this.transactionService.form.get('payload').get('vendorInfo').get(`fax${number}`).setValue(null);
    this.transactionService.deletedCollections.push({
      name: `contact${number}`
    });
  }
  restoreContact(number: string) {
    this.transactionService.form.get('payload').get('vendorInfo').get(`contactName${number}`).setValue('');
    this.transactionService.form.get('payload').get('vendorInfo').get(`email${number}`).setValue('');
    this.transactionService.form.get('payload').get('vendorInfo').get(`phone${number}`).setValue('');
    this.transactionService.form.get('payload').get('vendorInfo').get(`fax${number}`).setValue('');
    this.transactionService.deletedCollections = this.transactionService.deletedCollections.filter(d => d.name !== `contact${number}`);
  }
  containsValue(list, field, value: string): boolean {
    return list.some(obj => obj[field] === value);
  }

  openImportTransactionDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    (dialogConfig.width = "900px"),
      this.dialog.open(ImportTransactionDialogComponent, dialogConfig);
  }
}
