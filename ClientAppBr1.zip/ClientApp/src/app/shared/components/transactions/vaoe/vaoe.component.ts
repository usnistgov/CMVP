import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SectionService } from "src/app/shared/services/section.service";
import { TransactionTypes } from "src/assets/transaction-types";
import * as JSZip from "jszip";
import { ToastrService } from "ngx-toastr";
import { saveAs } from "file-saver";
import { ScenarioTypes } from "src/assets/scenario-types";
import { Br1Service } from "src/app/shared/services/br1.service";
import { TransactionService } from "src/app/shared/services/transaction.service";

@Component({
  selector: "app-vaoe",
  templateUrl: "./vaoe.component.html",
  styleUrls: ["./vaoe.component.scss"],
})
export class VaoeComponent implements OnInit {
  transactionTypes = TransactionTypes;
  scenarioTypes = ScenarioTypes


  constructor(private _formBuilder: FormBuilder, public sectionService: SectionService,
    private toastr: ToastrService,
    public br1Service: Br1Service,
    public transactionService: TransactionService
  ) { }

  ngOnInit() {
    this.transactionService.initializeVAOEForm();
  }


  deleteField(form, fieldName) {
    form.controls[fieldName].setValue(null);
  }
  restoreField(form, fieldName) {
    form.controls[fieldName].setValue('');
  }

}
