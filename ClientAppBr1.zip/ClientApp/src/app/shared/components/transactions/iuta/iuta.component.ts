import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SectionService } from "src/app/shared/services/section.service";
import { TransactionTypes } from "src/assets/transaction-types";
import * as JSZip from "jszip";
import { ToastrService } from "ngx-toastr";
import { saveAs } from "file-saver";
import { ScenarioTypes } from "src/assets/scenario-types";

@Component({
  selector: "app-iuta",
  templateUrl: "./iuta.component.html",
  styleUrls: ["./iuta.component.scss"],
})
export class IutaComponent implements OnInit {
  transactionTypes = TransactionTypes;
  scenarioTypes = ScenarioTypes

  form: FormGroup
  labs = [];

  constructor(private _formBuilder: FormBuilder, public sectionService: SectionService,
    private toastr: ToastrService,
  ) { }

  ngOnInit() {
    this.getLabs();

    this.form = this._formBuilder.group({
      schemaVersion: ['1.0.0'],
      transaction: this._formBuilder.group({
        transactionCode: ['IUTA'],
        labCode: ['', Validators.required],
        cstlTid: ['', Validators.required]
      }),
      payload: this._formBuilder.group({
        scenario: [''],
        moduleInfo: this._formBuilder.group({
          name: [''],
          itar: [false],
          addToMipList: [false]
        }),
        vendorInfo: this._formBuilder.group({
          vendorName: []
        })
      })
    });

  }
  async getLabs() {
    let labs = await this.sectionService.getLabs();
    if (labs) {
      this.labs = <any[]>labs;

    }
  }
  createPackage() {
    if (!this.form.valid) {
      return;
    }
    try {
      const self = this;
      const jszip = new JSZip();
      const folder = jszip.folder(
        "transaction"
      );
      this.saveFormAsJson(folder);

      jszip.generateAsync({ type: "blob" }).then(function (content) {
        saveAs(
          content,
          `transaction.zip`
        );
      });
    } catch (error) {
      console.error(error)
      this.toastr.error("Error while creating package.");

    }

  }
  saveFormAsJson(jszip) {
    let data = this.form.value;
    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });
    const filename = ""
    jszip.file(filename + "transaction.json", blob);
  }
}
