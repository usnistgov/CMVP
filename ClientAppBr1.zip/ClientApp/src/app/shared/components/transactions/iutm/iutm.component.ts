import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SectionService } from "src/app/shared/services/section.service";
import { TransactionTypes } from "src/assets/transaction-types";
import * as JSZip from "jszip";
import { ToastrService } from "ngx-toastr";
import { saveAs } from "file-saver";
import { ScenarioTypes } from "src/assets/scenario-types";
import { applyOperation, generate, observe, compare } from "fast-json-patch";

@Component({
  selector: "app-iutm",
  templateUrl: "./iutm.component.html",
  styleUrls: ["./iutm.component.scss"],
})
export class IutmComponent implements OnInit {
  transactionTypes = TransactionTypes;
  form: FormGroup;
  labs = [];
  // initialObject = {
  //   schemaVersion: "1.0.0",
  //   transaction: {
  //     transactionCode: "IUTM",
  //     labCode: "",
  //     cstlTid: "cstl",
  //   },
  //   payload: {
  //     labInfo: { labName: "lab name" },
  //     vendorInfo: { vendorName: "vendor name" },
  //     comment: "comment",
  //   },
  // };
  initialObject;
  constructor(
    private _formBuilder: FormBuilder,
    public sectionService: SectionService,
    private toastr: ToastrService
  ) {
    this.form = this._formBuilder.group({
      schemaVersion: ["1.0.0"],
      transaction: this._formBuilder.group({
        transactionCode: ["IUTM"],
        labCode: ["code", Validators.required],
        cstlTid: ["cstl", Validators.required],
      }),
      payload: this._formBuilder.group({
        labInfo: this._formBuilder.group({
          labName: ["lab name", Validators.required],
        }),
        vendorInfo: this._formBuilder.group({
          vendorName: ["vendor name", Validators.required],
        }),
        comment: ["", Validators.required],
      }),
    });
    this.initialObject = this.form.value;
  }

  ngOnInit() {
    this.getLabs();
  }
  async getLabs() {
    let labs = await this.sectionService.getLabs();
    if (labs) {
      this.labs = <any[]>labs;
    }
  }
  createPackage() {
    let patch = compare(this.initialObject, this.form.value);
    if (!this.form.valid) {
      return;
    }
    try {
      const self = this;
      const jszip = new JSZip();
      const folder = jszip.folder("transaction");
      this.saveFormAsJson(folder);

      jszip.generateAsync({ type: "blob" }).then(function (content) {
        saveAs(content, `transaction.zip`);
      });
    } catch (error) {
      console.error(error);
      this.toastr.error("Error while creating package.");
    }
  }
  deleteField(form, fieldName) {
    form.removeControl(fieldName);
  }
  saveFormAsJson(jszip) {
    let data = this.form.value;
    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });
    const filename = "";
    jszip.file(filename + "transaction.json", blob);
  }
}
