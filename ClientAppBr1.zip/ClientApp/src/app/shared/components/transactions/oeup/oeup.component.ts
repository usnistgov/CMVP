
import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SectionService } from "src/app/shared/services/section.service";
import { TransactionTypes } from "src/assets/transaction-types";
import * as JSZip from "jszip";
import { ToastrService } from "ngx-toastr";
import { saveAs } from "file-saver";
import { ScenarioTypes } from "src/assets/scenario-types";
import { Br1Service } from "src/app/shared/services/br1.service";
import { TransactionService } from "src/app/shared/services/transaction.service";

@Component({
  selector: "app-oeup",
  templateUrl: "./oeup.component.html",
  styleUrls: ["./oeup.component.scss"],
})
export class OeupComponent implements OnInit {
  transactionTypes = TransactionTypes;
  scenarioTypes = ScenarioTypes;
  form: FormGroup;
  labs = [];
  initialFormValues;
  deletedCollections = [];
  revals;
  selectedReval
  cert;
  cavpBuilderReval;
  constructor(private _formBuilder: FormBuilder, public sectionService: SectionService,
    private toastr: ToastrService,
    public br1Service: Br1Service,
    private transactionService: TransactionService
  ) { }

  ngOnInit() {
    this.getRevals("OEUP");
    this.getLabs();
    this.form = this._formBuilder.group({
      schemaVersion: ['1.0.0'],
      transaction: this._formBuilder.group({
        transactionCode: ['OEUP'],
        labInfo: this._formBuilder.group({
          labName: [''],
          labCode: [{ value: '', disabled: true }],
          labInternalId: [''],
          signature1: [''],
          title1: [''],
          signature2: [''],
          title2: [''],
          signature3: [''],
          title3: [''],
          tester1Name: [''],
          tester1Cvp: [''],
          tester2Name: [''],
          tester2Cvp: [''],
          reviewer1Name: [''],
          reviewer2Name: [''],
        }),
      }),
      payload: this._formBuilder.group({
        scenario: ['OEUP'],
        moduleInfo: this._formBuilder.group({
          name: [''],
          description: [''],
          type: [''],
          itar: [false],
          addToMipList: [false],
          specialInstructions: [''],
          certificateCaveat: [''],
          opEnvType: ['']
        }),
      })
    });
    this.initialFormValues = this.form.get('payload').getRawValue();
    this.form
    .get("transaction")
    .get("labInfo")
    .get("labName")
    .valueChanges.subscribe((val) => {
      if (val) {
        const lab = this.labs.find((l) => l.name == val);
        if (lab) {
          let code = lab.code;
          this.form
          .get("transaction")
          .get("labInfo")
          .get("labCode")
            .setValue(code, { emitEvent: false });
        }
      }
    });
  }
  async getCert() {
    let cert = await this.sectionService.getCert(this.selectedReval);
    if (cert) {
      this.cert = <any[]>cert;
      this.transactionService.populateOeupForm(this.form, cert);
      this.initialFormValues = this.form.get('payload').getRawValue();
      this.cavpBuilderReval = this.selectedReval

    }
  }
  async getRevals(transaction) {
    let revals = await this.sectionService.getRevals(transaction);
    if (revals) {
      this.revals = <any[]>revals;

    }
  }
  async getLabs() {
    let labs = await this.sectionService.getLabs();
    if (labs) {
      this.labs = <any[]>labs;

    }
  }
  createPackage() {
    // const changedFields = this.getChangedFields(this.form.getRawValue(), this.initialFormValues);
    if (!this.form.valid) {
      return;
    }
    try {
      const self = this;
      const jszip = new JSZip();
      const folder = jszip.folder(
        "transaction"
      );
      this.saveFormAsJson(folder);

      jszip.generateAsync({ type: "blob" }).then(function (content) {
        saveAs(
          content,
          `transaction.zip`
        );
      });
    } catch (error) {
      console.error(error)
      this.toastr.error("Error while creating package.");

    }

  }
  getChangedFields(currentValues: any, initialValues: any): any {
    const changedFields: any = {};
    Object.keys(currentValues).forEach(key => {
      if (typeof currentValues[key] === 'object' && currentValues[key] !== null && !Array.isArray(currentValues[key])) {
        const diff = this.getChangedFields(currentValues[key], initialValues[key]);
        if (Object.keys(diff).length > 0) {
          changedFields[key] = diff;
        }
      } else if (currentValues[key] !== initialValues[key]) {
        changedFields[key] = currentValues[key];
      }
    });
    return changedFields;
  }
  saveFormAsJson(jszip) {
    let data = this.form.value;
    const payload = this.getChangedFields(this.form.get('payload').getRawValue(), this.initialFormValues);
    data.payload = payload;
    data.payload.deletedCollections = this.deletedCollections;
    data.payload.opEnvSwFwHyVAList = this.br1Service.brTables.opEnvSwFwHyVAList;
    data.payload.cavpCertSet = this.br1Service.cavpCertSet;

    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });
    const filename = ""
    jszip.file(filename + "transaction.json", blob);
  }
  deleteField(form, fieldName) {
    form.controls[fieldName].setValue(null);
  }
  restoreField(form, fieldName) {
    form.controls[fieldName].setValue('');
  }

}
