import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { SectionService } from "src/app/shared/services/section.service";
import { TransactionTypes } from "src/assets/transaction-types";
import * as JSZip from "jszip";
import { ToastrService } from "ngx-toastr";
import { saveAs } from "file-saver";
import { ScenarioTypes } from "src/assets/scenario-types";

@Component({
  selector: "app-iutb",
  templateUrl: "./iutb.component.html",
  styleUrls: ["./iutb.component.scss"],
})
export class IutbComponent implements OnInit {
  transactionTypes = TransactionTypes;
  scenarioTypes = ScenarioTypes
  form: FormGroup
  labs = [];
  questions = [
    {section: 1, level: 1},
    {section: 2, level: 1},
    {section: 3, level: 1},
    {section: 4, level: 1},
    {section: 5, level: 0},
    {section: 6, level: 1},
    {section: 7, level: 0},
    {section: 8, level: 0},
    {section: 9, level: 1},
    {section: 10, level: 1},
    {section: 11, level: 1},
    {section: 12, level: 0},


  ]

  constructor(private _formBuilder: FormBuilder, public sectionService: SectionService,
    private toastr: ToastrService,
  ) { 

    this.form = this._formBuilder.group({
      schemaVersion: ['1.0.0'],
      transaction: this._formBuilder.group({
        transactionCode: ['IUTB'],
        labCode: ['', Validators.required],
        cstlTid: ['', Validators.required]
      }),
      payload: this._formBuilder.group({
        scenario: ['', Validators.required],
        moduleInfo: this._formBuilder.group({
          name: [''],
          itar: [false],
        }),
        vendorInfo: this._formBuilder.group({
          vendorName: []
        }),
        securityLevelInfo:this._formBuilder.group({
          overall: [1],
          secLevels: this._formBuilder.array(this.createSecurityLevels())
        }),
      })
    });
  }

  ngOnInit() {
    this.getLabs();


  }
  private createSecurityLevels(): FormGroup[] {
    return Array.from({ length: 12 }, (v, i) => {
      if(i === 4 || i === 6 || i === 7 || i === 11){
        return this._formBuilder.group({
          section: [i + 1],
          level: [0]
        });
      } else {
        return this._formBuilder.group({
          section: [i + 1],
          level: [1]
        });
      }
   
    });
  }
  async getLabs() {
    let labs = await this.sectionService.getLabs();
    if (labs) {
      this.labs = <any[]>labs;

    }
  }
  createPackage() {
    if (!this.form.valid) {
      return;
    }
    try {
      const self = this;
      const jszip = new JSZip();
      const folder = jszip.folder(
        "transaction"
      );
      this.saveFormAsJson(folder);

      jszip.generateAsync({ type: "blob" }).then(function (content) {
        saveAs(
          content,
          `transaction.zip`
        );
      });
    } catch (error) {
      console.error(error)
      this.toastr.error("Error while creating package.");

    }

  }
  saveFormAsJson(jszip) {
    let data = this.form.value;
    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });
    const filename = ""
    jszip.file(filename + "transaction.json", blob);
  }
}
