import { Component, OnInit, Inject } from "@angular/core";
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";

import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { Br1Service } from "../../services/br1.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table-storage-editor",
  templateUrl: "./table-storage-editor.component.html",
  styleUrls: ["./table-storage-editor.component.scss"],
})
export class TableStorageEditorComponent implements OnInit {
  storageList = [];
  public storageListForm: UntypedFormGroup;
  public storageListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    public dialogRef: MatDialogRef<TableStorageEditorComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private dialog: MatDialog,
    private fb: UntypedFormBuilder,
    public br1Service: Br1Service,
    private toastr: ToastrService,

  ) { }

  ngOnInit() {
    this.storageList = this.data.storageList ? this.data.storageList : [];
    this.storageListForm = this.fb.group({
      areaName: ["", Validators.required],
      format: ["", Validators.required],
      algorithmName: [""],
    });
    this.storageListFormEdit = this.fb.group({
      areaName: ["", Validators.required],
      format: ["", Validators.required],
      algorithmName: [""],
    });
  }
  addArray() {
    // if (this.storageListForm.valid) {
      this.storageList.push(this.storageListForm.value);
      this.storageListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  editTableRow(index) {
    this.editingRow = index;
    this.storageListFormEdit.setValue(this.storageList[index]);
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.storageList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.storageList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  onNoClick(): void {
    this.dialogRef.close({ storageList: this.storageList });
  }
}
