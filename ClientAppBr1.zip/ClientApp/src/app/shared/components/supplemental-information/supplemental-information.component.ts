import { Component, OnInit, Input } from "@angular/core";
import { SectionService } from "../../services/section.service";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { MatDialog } from "@angular/material/dialog";
import { ImageDialogComponent } from "../image-dialog/image-dialog.component";
import { FormService } from "../../services/form.service";
import { ExportSecurityDialogComponent } from "../export-security-dialog/export-security-dialog.component";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { Br1Service } from "../../services/br1.service";

@Component({
  selector: "app-supplemental-information",
  templateUrl: "./supplemental-information.component.html",
  styleUrls: ["./supplemental-information.component.scss"],
})
export class SupplementalInformationComponent implements OnInit {
  sectionsData;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder
  ) {}

  async ngOnInit() {}

  onAnswerChanged(event, suppId) {
    let supp = this.br1Service.supplementalSettingList.find(
      (s) => s.suppId === suppId
    );
    if (supp) {
      supp.setting = event;
    }
  }

  getSectionQuestions(sectionId) {
    let x = this.br1Service.supplementalSections.find(
      (sec) => sec.sectionId === sectionId
    );
    if (x) {
      return x.questions;
    }
  }
}
