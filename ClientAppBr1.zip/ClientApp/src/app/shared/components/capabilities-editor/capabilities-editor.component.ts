import { Component, OnInit, Inject } from "@angular/core";
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";

import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { Br1Service } from "../../services/br1.service";
import { TreeNode } from "primeng/api";
import { Observable, of } from "rxjs";
interface Column {
  field: string;
  header: string;
}
@Component({
  selector: "app-capabilities-editor",
  templateUrl: "./capabilities-editor.component.html",
  styleUrls: ["./capabilities-editor.component.scss"],
})
export class CapabilitiesEditorComponent implements OnInit {
  selectedCapabilities = [];
  capabilitiesTree = [];
  allCapabilitiesCopy = [];
  public storageListForm: UntypedFormGroup;
  public storageListFormEdit: UntypedFormGroup;
  metaKeySelection: boolean = true;

  editingTable;
  editingRow;
  cols!: Column[];
  selectedNodes: TreeNode[] = [];
  constructor(
    public dialogRef: MatDialogRef<CapabilitiesEditorComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private dialog: MatDialog,
    private fb: UntypedFormBuilder,
    public br1Service: Br1Service
  ) {}

  ngOnInit() {
    this.cols = [{ field: "displayText", header: "Name" }];
    this.selectedCapabilities = this.data.selectedCapabilities
      ? this.data.selectedCapabilities
      : [];
    if (this.data.allCapabilities) {
      this.allCapabilitiesCopy = JSON.parse(
        JSON.stringify(this.data.allCapabilities)
      );
    }

    this.capabilitiesTree = this.mapDataToTree(
      this.data.allCapabilities,
      this.data.selectedCapabilities
    );
  }

  mapDataToTree(capabilities, selectedCapabilities) {
    let results = [];
    if (capabilities) {
      capabilities.forEach((capability, index) => {
        if (selectedCapabilities[index]) {
          this.selectedNodes.push({
            data: {
              capabilityId: selectedCapabilities[index].capabilityId,
              displayText: selectedCapabilities[index].displayText,
            },
            children: selectedCapabilities[index].childCapabilities,
          });
        }
        results.push({
          data: {
            capabilityId: capability.capabilityId,
            displayText: capability.displayText,
          },
          children: this.mapDataToTree(
            capability.childCapabilities,
            selectedCapabilities[index]
              ? selectedCapabilities[index].childCapabilities
              : []
          ),
        });
      });
    }

    return results;
  }
  getChildren(node: TreeNode): Observable<TreeNode[]> {
    // Access child nodes using your custom field name
    return of(node.data.childCapabilities);
  }
  onNoClick(): void {
    if (this.selectedNodes) {
      this.selectedNodes.forEach((node) => {
        let capability = this.findCapability(
          this.allCapabilitiesCopy,
          node.data.capabilityId
        );

        if (capability) {
          capability.checked = true;
        }
      });
      let capabilities = this.filterCapabilities(this.allCapabilitiesCopy);
      this.dialogRef.close(capabilities);
      return;
    }

    this.dialogRef.close();
  }
  filterCapabilities(capabilities) {
    const filtered = [];
    for (const capability of capabilities) {
      const hasCheckedChild = capability.childCapabilities?.some(
        (child) => child.checked
      );
      if (capability.checked || hasCheckedChild) {
        const filteredChildren = capability.childCapabilities
          ? this.filterCapabilities(capability.childCapabilities)
          : [];
        filtered.push({
          capabilityId: capability.capabilityId,
          displayText: capability.displayText,
          childCapabilities: filteredChildren,
        });
      } else if (capability.childCapabilities) {
        const filteredChildren = this.filterCapabilities(
          capability.childCapabilities
        );
        if (filteredChildren.length) {
          filtered.push({
            capabilityId: capability.capabilityId,
            displayText: capability.displayText,
            childCapabilities: filteredChildren,
          });
        }
      }
    }

    return filtered;
  }
  findCapability(capabilities, capabilityId) {
    // const capability = this.allCapabilitiesCopy.find(cap => )
    for (const capability of capabilities) {
      if (capability.capabilityId === capabilityId) {
        return capability;
      }
      if (capability.childCapabilities) {
        const childCapability = this.findCapability(
          capability.childCapabilities,
          capabilityId
        );
        if (childCapability) {
          return childCapability;
        }
      }
    }
    return null;
  }
}
