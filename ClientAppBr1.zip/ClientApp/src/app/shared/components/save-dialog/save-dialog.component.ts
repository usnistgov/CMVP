import { Component, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { DatePipe } from "@angular/common";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { reject } from "q";
import { ConverterService } from "../../services/converter.service";
import { PdfService } from "../../services/pdf.service";
import { environment } from "src/environments/environment";
import { Br1Service } from "../../services/br1.service";

@Component({
  selector: "app-save-dialog",
  templateUrl: "./save-dialog.component.html",
  styleUrls: ["./save-dialog.component.scss"],
})
export class SaveDialogComponent implements OnInit {
  files = [];
  selectedFiles = [];
  selectedType = "json";
  all = false
  constructor(
    private converterService: ConverterService,
    public pdfService: PdfService,
    public datepipe: DatePipe,
    public formService: FormService,
    public sectionService: SectionService,
    private dialogRef: MatDialogRef<SaveDialogComponent>,
    public br1Service: Br1Service
  ) { }

  ngOnInit() {
    this.updateGeneratedFiles(this.selectedType);
  }
  updateGeneratedFiles(type) {
    this.files = [
      {
        label: "Module File",
        files: [
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_module.${type}`,
            selected: true,
          },
        ],
      },
      {
        label: "Reports",
        files: [
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section1.${type}`,
            selected: false,
            section: "1",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section2.${type}`,
            selected: false,
            section: "2",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section3.${type}`,
            selected: false,
            section: "3",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section4.${type}`,
            selected: false,
            section: "4",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section5.${type}`,
            selected: false,
            section: "5",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section6.${type}`,
            selected: false,
            section: "6",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section7.${type}`,
            selected: false,
            section: "7",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section8.${type}`,
            selected: false,
            section: "8",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section9.${type}`,
            selected: false,
            section: "9",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section10.${type}`,
            selected: false,
            section: "10",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section11.${type}`,
            selected: false,
            section: "11",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_section12.${type}`,
            selected: false,
            section: "12",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_sectionA.${type}`,
            selected: false,
            section: "A",
          },
          {
            name: `${this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            )}_report_sectionB.${type}`,
            selected: false,
            section: "B",
          },
        ],
      },
    ];
  }

  async downloadPackage() {
    const self = this;
    const jszip = new JSZip();
    const folder = jszip.folder(
      self.formService.getFileName(
        self.sectionService.vendorFormGroup.getRawValue()
      )
    );

    // Report files
    if (this.selectedType === "json") {
      this.saveReportsAsJson(folder);
    }

    // Vendor files
    if (this.files[0].files[0].selected) {
      if (this.selectedType === "json") {
        this.saveFormAsJson(folder);
      }
    }

    jszip.generateAsync({ type: "blob" }).then(function (content) {
      // see FileSaver.js

      saveAs(
        content,
        `${self.formService.getFileName(
          self.sectionService.vendorFormGroup.getRawValue()
        )}.zip`
      );
    });
  }

  saveReportsAsJson(jszip) {
    let selectedSections = this.files[1].files.filter((f) => f.selected);
    selectedSections.forEach((sec) => {
      let data = this.sectionService.sections[sec.section].value;
      if (sec.section === "B") {
        data["TEB.01.01"] = {
          ...data["TEB.01.01"],
          ...this.sectionService.securityPolicyContent,
        };
      }
      const blob = new Blob(
        [JSON.stringify(this.sectionService.sections[sec.section].value)],
        { type: "text/json" }
      );
      const filename = this.formService.getFileName(
        this.sectionService.vendorFormGroup.getRawValue()
      );
      jszip.file(filename + `_report_section${sec.section}.json`, blob);
    });
  }

  saveFormAsJson(jszip) {
    let data = this.formService.prepareDataForSchema();
    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });

    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_module.json", blob);
  }

  async getBlob(pdf) {
    let promise = await new Promise((resolve, reject) => {
      pdf.getBlob((blob) => {
        resolve(blob);
      });
    }).catch((err) => {
      reject(err);
    });

    return promise;
  }

  async save() {
    await this.downloadPackage();
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }

  toggleAll() {
    this.files[1].files = this.files[1].files.map(file => ({
      ...file,
      selected: this.all
    }));
  }
  checkChanged(){
    const checked = this.files[1].files.filter(f => f.selected)
    if(checked.length ===14){
      this.all = true;
    } else {
      this.all = false
    }
  }
}
