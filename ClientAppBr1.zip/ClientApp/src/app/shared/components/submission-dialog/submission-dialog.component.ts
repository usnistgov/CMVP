import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  SimpleChanges,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MatDialogRef } from "@angular/material/dialog";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { DatePipe } from "@angular/common";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { reject } from "q";
import { ConverterService } from "../../services/converter.service";
import { PdfService } from "../../services/pdf.service";
import { environment } from "src/environments/environment";
import { ToastrService } from "ngx-toastr";
import { Br1Service } from "../../services/br1.service";

pdfMake.vfs = pdfFonts.pdfMake.vfs;
@Component({
  selector: "app-submission-dialog",
  templateUrl: "./submission-dialog.component.html",
  styleUrls: ["./submission-dialog.component.scss"],
})
export class SubmissionDialogComponent implements OnInit {
  files = [];
  uploadedFiles = [];
  changeLetterFile;
  signatureFile;
  physicalReportFile;
  revalidationReportFile;
  entropyReportFile;
  commentsFile;
  securityPolicyFile;

  selectedType = "json";
  constructor(
    private converterService: ConverterService,
    public pdfService: PdfService,
    public datepipe: DatePipe,
    public formService: FormService,
    public sectionService: SectionService,
    private dialogRef: MatDialogRef<SubmissionDialogComponent>,
    private toastr: ToastrService,
    public br1Service: Br1Service
  ) {}

  ngOnInit() {
    this.updateGeneratedFiles(this.selectedType);
  }
  updateGeneratedFiles(type) {
    const subLevel =
      this.sectionService.vendorFormGroup.getRawValue().module.transmissionCode;
    if (
      subLevel === "FS" ||
      subLevel === "FCLC_OK" ||
      subLevel === "FCLC" ||
      subLevel === "sCMn"
    ) {
      this.files = [
        {
          label: "Assessment Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.pdf`,
            },
          ],
        },
        {
          label: "Module File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_module.${type}`,
            },
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_section<sectionNumber>.${type} (14 Files)`,
            },
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.txt`,
            },
          ],
        },
        // {
        //   label: "Security Policy",
        //   files: [
        //     {
        //       name: `${this.formService.getFileName(
        //         this.sectionService.vendorFormGroup.getRawValue()
        //       )}_140sp.pdf`
        //     }
        //   ]
        // },
        // {
        //   label: "Draft Certificate",
        //   files: [
        //     {
        //       name: `${this.formService.getFileName(
        //         this.sectionService.vendorFormGroup.getRawValue()
        //       )}_140crt.pdf`,
        //     },
        //   ],
        // },
      ];
    } else if (
      subLevel === "IUTA" ||
      subLevel === "IUTB" ||
      subLevel === "IUTC" ||
      subLevel === "IUTR" ||
      subLevel === "IUTM" ||
      subLevel === "sHLD" ||
      subLevel === "DRPT" ||
      subLevel === "RQFG" ||
      subLevel === "STAT" ||
      subLevel === "OTHR"
    ) {
      this.files = [
        {
          label: "Module File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_module.${type}`,
            },
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_sectionB.${type}`,
            },
          ],
        },
      ];
    } else if (subLevel === "VU" || subLevel === "OE" || subLevel === "QU") {
      this.files = [
        {
          label: "Assessment Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.pdf`,
            },
          ],
        },
        {
          label: "Module File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_module.${type}`,
            },
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_section<sectionNumber>.${type} (14 Files)`,
            },
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.txt`,
            },
          ],
        },
      ];
    } else if (subLevel === "UP" || subLevel === "UPOEM") {
      this.files = [
        {
          label: "Assessment Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.pdf`,
            },
          ],
        },
        {
          label: "Module File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_module.${type}`,
            },
          ],
        },
        {
          label: "Reports",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report_section<sectionNumber>.${type} (14 Files)`,
            },
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_report.txt`,
            },
          ],
        },
        // {
        //   label: "Draft Certificate",
        //   files: [
        //     {
        //       name: `${this.formService.getFileName(
        //         this.sectionService.vendorFormGroup.getRawValue()
        //       )}_140crt.pdf`,
        //     },
        //   ],
        // },
      ];
    } else if (subLevel === "ENT" || subLevel === "EU") {
      this.files = [
        {
          label: "Module File",
          files: [
            {
              name: `${this.formService.getFileName(
                this.sectionService.vendorFormGroup.getRawValue()
              )}_module.${type}`,
            },
          ],
        },
      ];
    }
  }

  addFiles(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.uploadedFiles.push({
          name:
            this.formService.getFileName(
              this.sectionService.vendorFormGroup.getRawValue()
            ) +
            "_" +
            input.files[index].name,
          data: reader.result,
        });
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }

  addChangeLetter(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.changeLetterFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_change_document.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeChangeLetter() {
    this.changeLetterFile = null;
  }

  addSignature(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.signatureFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_signature.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeSignature() {
    this.signatureFile = null;
  }

  addPhysicalReport(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        self.physicalReportFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_physicalreport.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removePhysicalReport() {
    this.physicalReportFile = null;
  }
  addRevalidationReport(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        self.revalidationReportFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_revalidation_report.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeRevalidationReport() {
    this.revalidationReportFile = null;
  }
  addEntropyReport(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        self.entropyReportFile = {
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_entropyReport.pdf`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeEntropyReport() {
    this.entropyReportFile = null;
  }
  addComments(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        const splits = input.files[index].name.split(".");
        const ext = splits[splits.length - 1];
        self.commentsFile = {
          // name: "comments.pdf",
          // name: input.files[index].name,
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_modulecomments.${ext}`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeComments() {
    this.commentsFile = null;
  }
  addSecurityPolicy(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        const splits = input.files[index].name.split(".");
        const ext = splits[splits.length - 1];
        self.securityPolicyFile = {
          // name: input.files[index].name,
          name: `${this.formService.getFileName(
            this.sectionService.vendorFormGroup.getRawValue()
          )}_sptemplate.${ext}`,
          // name: `${this.formService.getFileName(
          //   this.sectionService.vendorFormGroup.getRawValue()
          // )}_security_policy.${ext}`,
          data: reader.result,
        };
      };
      reader.readAsArrayBuffer(input.files[index]);
    }
  }
  removeSecurityPolicy() {
    this.securityPolicyFile = null;
  }

  async downloadPackage() {
    try {
      const self = this;
      const jszip = new JSZip();
      const folder = jszip.folder(
        self.formService.getFileName(
          self.sectionService.vendorFormGroup.getRawValue()
        )
      );
      const subLevel =
        this.sectionService.vendorFormGroup.getRawValue().module
          .transmissionCode;
      if (
        subLevel === "FS" ||
        subLevel === "FCLC_OK" ||
        subLevel === "FCLC" ||
        subLevel === "sCMn"
      ) {
        // Report files
        if (this.selectedType === "json") {
          this.saveReportsAsJson(folder);
        } else if (this.selectedType === "xml") {
          this.saveReportsAsXml(folder);
        }
        this.saveReportsAsTxt(folder);
        // await this.saveDraft(folder);
        await this.saveFormAsPdf(folder);
      } else if (
        subLevel === "IUTA" ||
        subLevel === "IUTB" ||
        subLevel === "IUTC" ||
        subLevel === "IUTR" ||
        subLevel === "IUTM" ||
        subLevel === "sHLD" ||
        subLevel === "DRPT" ||
        subLevel === "RQFG" ||
        subLevel === "STAT" ||
        subLevel === "OTHR"
      ) {
        if (this.selectedType === "json") {
          this.saveSectionBAsJson(folder);
        } else if (this.selectedType === "xml") {
          this.saveSectionBAsXml(folder);
        }
      }

      // Module Files
      if (this.selectedType === "json") {
        this.saveFormAsJson(folder);
      }

      // User files
      this.addImportedFiles(jszip);

      jszip.generateAsync({ type: "blob" }).then(function (content) {
        // see FileSaver.js

        saveAs(
          content,
          `${self.formService.getFileName(
            self.sectionService.vendorFormGroup.getRawValue()
          )}.zip`
        );
      });
    } catch (error) {
      this.toastr.error("Error while creating package.");
    }
  }

  saveReportsAsTxt(jszip) {
    const txt = this.formService.prepareSectionInfoTxt();
    const blob = new Blob([txt], { type: "text/plain" });
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_report.txt", blob);
  }
  async saveDraft(jszip) {
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    const data = this.sectionService.getPdfDraft();

    const pdf = pdfMake.createPdf(data);
    const pdfBlob = await this.getBlob(pdf);

    jszip.file(filename + "_140crt.pdf", pdfBlob);
  }

  saveReportsAsJson(jszip) {
    for (let key in this.sectionService.sections) {
      let data = this.sectionService.sections[key].value;
      if (key === "B") {
        data["TEB.01.01"] = {
          ...data["TEB.01.01"],
          ...this.sectionService.securityPolicyContent,
        };
      }
      const blob = new Blob(
        [JSON.stringify(this.sectionService.sections[key].value)],
        { type: "text/json" }
      );
      const filename = this.formService.getFileName(
        this.sectionService.vendorFormGroup.getRawValue()
      );
      jszip.file(filename + `_report_section${key}.json`, blob);
    }
  }

  saveReportsAsXml(jszip) {
    let res = {};
    for (let key in this.sectionService.sections) {
      const blob = new Blob(
        [
          this.converterService.convertReportsToXml(
            this.sectionService.sections[key].value
          ),
        ],
        { type: "text/xml" }
      );
      const filename = this.formService.getFileName(
        this.sectionService.vendorFormGroup.getRawValue()
      );
      jszip.file(filename + `_report_section${key}.xml`, blob);
    }
  }
  saveFormAsJson(jszip) {
    let data = this.formService.prepareDataForSchema();

    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + "_module.json", blob);
  }

  async saveFormAsPdf(jszip) {
    const data = this.pdfService.getPdfData();
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    const pdf = pdfMake.createPdf(data);
    const pdfBlob = await this.getBlob(pdf);

    jszip.file(filename + "_report.pdf", pdfBlob);
  }

  async getBlob(pdf) {
    let promise = await new Promise((resolve, reject) => {
      pdf.getBlob((blob) => {
        resolve(blob);
      });
    }).catch((err) => {
      reject(err);
    });

    return promise;
  }

  addImportedFiles(jszip) {
    this.uploadedFiles.forEach((f) => {
      jszip.file(f.name, f.data, { binary: true });
    });
    if (this.changeLetterFile) {
      jszip.file(this.changeLetterFile.name, this.changeLetterFile.data, {
        binary: true,
      });
    }
    if (this.signatureFile) {
      jszip.file(this.signatureFile.name, this.signatureFile.data, {
        binary: true,
      });
    }
    if (this.physicalReportFile) {
      jszip.file(this.physicalReportFile.name, this.physicalReportFile.data, {
        binary: true,
      });
    }
    if (this.revalidationReportFile) {
      jszip.file(
        this.revalidationReportFile.name,
        this.revalidationReportFile.data,
        {
          binary: true,
        }
      );
    }
    if (this.entropyReportFile) {
      jszip.file(this.entropyReportFile.name, this.entropyReportFile.data, {
        binary: true,
      });
    }
    if (this.commentsFile) {
      jszip.file(this.commentsFile.name, this.commentsFile.data, {
        binary: true,
      });
    }
    if (this.securityPolicyFile) {
      jszip.file(this.securityPolicyFile.name, this.securityPolicyFile.data, {
        binary: true,
      });
    }
  }

  removeFile(i) {
    this.uploadedFiles.splice(i, 1);
  }
  async save() {
    await this.downloadPackage();
    this.dialogRef.close();
  }

  close() {
    this.dialogRef.close();
  }

  saveSectionBAsJson(jszip) {
    const blob = new Blob(
      [JSON.stringify(this.sectionService.sections["B"].value)],
      { type: "text/json" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + `_report_sectionB.json`, blob);
  }

  saveSectionBAsXml(jszip) {
    let res = {};
    const blob = new Blob(
      [
        this.converterService.convertReportsToXml(
          this.sectionService.sections["B"].value
        ),
      ],
      { type: "text/xml" }
    );
    const filename = this.formService.getFileName(
      this.sectionService.vendorFormGroup.getRawValue()
    );
    jszip.file(filename + `_report_sectionB.xml`, blob);
  }
}
