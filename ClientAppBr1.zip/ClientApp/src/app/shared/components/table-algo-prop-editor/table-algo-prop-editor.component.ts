import { Component, OnInit, Inject } from "@angular/core";
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import {
  MatDialog,
  MatDialogConfig,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";

import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { Br1Service } from "../../services/br1.service";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table-algo-prop-editor",
  templateUrl: "./table-algo-prop-editor.component.html",
  styleUrls: ["./table-algo-prop-editor.component.scss"],
})
export class TableAlgoPropEditorComponent implements OnInit {
  propList = [];
  title;
  public propListForm: UntypedFormGroup;
  public propListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    public dialogRef: MatDialogRef<TableAlgoPropEditorComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private dialog: MatDialog,
    private fb: UntypedFormBuilder,
    public br1Service: Br1Service,
    private toastr: ToastrService,

  ) {}

  ngOnInit() {
    this.propList = this.data.propList ? this.data.propList : [];
    this.title = this.data.title ? this.data.title : "";
    this.propListForm = this.fb.group({
      name: ["", Validators.required],
      value: [""],
      propertyId: [0, Validators.required],
    });
    this.propListFormEdit = this.fb.group({
      name: ["", Validators.required],
      value: [""],
      propertyId: [0, Validators.required],
    });
  }
  addArray() {
    // if (this.propListForm.valid) {
      this.propList.push(this.propListForm.value);
      this.propListForm = this.fb.group({
        name: ["", Validators.required],
        value: [""],
        propertyId: [0, Validators.required],
      });
    // }  else {
    //   this.toastr.error("Invalid form");
    // }
  }
  editTableRow(index) {
    this.editingRow = index;
    this.propListFormEdit.setValue(this.propList[index]);
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.propList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.propList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // }  else {
    //   this.toastr.error("Invalid form");
    // }
  }
  onNoClick(): void {
    this.dialogRef.close({ propList: this.propList });
  }
}
