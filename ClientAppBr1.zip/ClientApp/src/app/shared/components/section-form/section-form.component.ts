import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  AfterViewChecked,
  SimpleChanges,
  AfterViewInit,
} from "@angular/core";
import { FormGroup, UntypedFormArray, Form } from "@angular/forms";
import { saveAs } from "file-saver";
import { FormService } from "../../services/form.service";
import * as _ from "underscore";
import { environment } from "src/environments/environment";
import { SectionService } from "../../services/section.service";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { Router } from "@angular/router";
@Component({
  selector: "app-section-form",
  templateUrl: "./section-form.component.html",
  styleUrls: ["./section-form.component.scss"],
})
export class SectionFormComponent
  implements OnInit, AfterViewInit, AfterViewChecked
{
  @Input() section;
  @Input() form;
  @Input() title;

  @Output()
  changeSection: EventEmitter<any> = new EventEmitter<any>();
  level = 0;
  statusCheck = false;
  statusFilter;
  filteredItems = [];
  jumpTo;
  jumpToQuestion;
  isLoading = false;
  submissionType;
  selectedLevel;

  constructor(
    public formService: FormService,
    public sectionService: SectionService,
    private dialog: MatDialog,
    private router: Router
  ) {}

  ngOnInit() {
    this.assignCopy();
    this.form.valueChanges.subscribe((val) => {
      this.onStatusFilterChange(this.statusFilter);
    });
  }
  updateVersions(id): UntypedFormArray {
    return this.form.get(id).get("update-versions") as UntypedFormArray;
  }
  assignCopy() {
    this.filteredItems = Object.assign([], this.section.dtrs);
  }
  ngAfterViewChecked() {
    if (this.sectionService.hash) {
      const elmnt = document.getElementById(this.sectionService.hash);
      elmnt.scrollIntoView({ behavior: "auto", block: "start" });
      this.sectionService.hash = null;
    }
    if (this.jumpToQuestion) {
      const elmnt = document.getElementById(`${this.jumpToQuestion}`);
      elmnt.scrollIntoView({ behavior: "auto", block: "start" });
      this.jumpToQuestion = null;
    }
  }
  ngAfterViewInit() {
    if (this.section) {
      const anchors = document.getElementsByTagName("a");
      for (let i = 0; i < anchors.length; i++) {
        if (anchors[i].hash) {
          // hash URL
          const hash = anchors[i].hash.replace("#", "");
          anchors[i].setAttribute(
            "style",
            `  color: -webkit-link;cursor: pointer;text-decoration: underline;`
          );
          // anchors[i].setAttribute('href', `/home#${hash}`);

          anchors[i].removeAttribute("href");
          anchors[i].setAttribute("fragment", `${hash}`);
          anchors[i].setAttribute("ng-reflect-fragment", `${hash}`);
          anchors[i].addEventListener("click", (event) => {
            // Do something with 'event'
            const secNumber = this.getSectionNumberFromHash(hash);
            if (secNumber.toString() !== this.section.secId) {
              this.changeSection.emit({
                sectionNumber: secNumber.toString(),
                hash,
              });
            } else {
              const elmnt = document.getElementById(hash);
              elmnt.scrollIntoView({ behavior: "auto", block: "start" });
            }
          });
        }
      }
      // if (this.sectionService.hash) {
      //      (this.sectionService.hash)
      //     const elmnt = document.getElementById(this.sectionService.hash);
      //     elmnt.scrollIntoView({ behavior: "auto", block: "start" });
      //     this.sectionService.hash = null;
      // }
    }
    this.isLoading = false;
  }
  getSectionNumberFromHash(hash) {
    if (hash) {
      return parseInt(hash[2] + hash[3]);
    }
  }

  openIg(anchor) {
    // let newRelativeUrl = this.router.createUrlTree(['/ig']);
    // let baseUrl = window.location.href.replace(this.router.url, '');
    // window.open(baseUrl + newRelativeUrl + `;anchor=${anchor}`  , '_blank');

    let baseUrl = window.location.href.replace(this.router.url, "");
    window.open(
      "https://csrc.nist.gov/CSRC/media/Projects/cryptographic-module-validation-program/documents/fips%20140-3/FIPS%20140-3%20IG.pdf" +
        `#${anchor}`,
      "_blank"
    );
  }

  saveSectionFormAsTxt() {
    const txt = this.formService.prepareSectionInfoTxt();
    const blob = new Blob([txt], { type: "text/plain" });
    saveAs(blob, `section${this.section}`);
  }
  saveSectionFormAsJson() {
    const blob = new Blob([JSON.stringify(this.form.value)], {
      type: "text/json",
    });
    saveAs(blob, "filename.json");
  }

  openSectionFile(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file
        const text = reader.result.toString();
        self.formService.parseSectionInfo(self.form, text);
      };
      reader.readAsText(input.files[index]);
    }
  }

  checkStatus() {
    // get drtids from form that have assessment and status passed. get dtrids of all level 1 from section. do difference, if result is empty then level passed
    this.statusCheck = true;
    const dtrids = _.filter(_.pairs(this.form.value), function (p) {
      return (
        (p[1]["test-status"] === "1" &&
          ((p[1]["assessment"] && p[1]["assessment"] !== "") ||
            !p[1]["assessment"])) ||
        p[1]["test-status"] === "3" ||
        p[1]["test-status"] === "4"
      );
    });
    const passed = _.map(dtrids, function (dtr) {
      return dtr[0];
    });

    const level1 = _.where(this.section.dtrs, { level: "1" }).map(function (
      value: any
    ) {
      return value.dtrId;
    });

    const level1Res = _.difference(level1, passed);
    if (level1Res.length === 0) {
      const level2 = _.where(this.section.dtrs, { level: "2" }).map(function (
        value: any
      ) {
        return value.dtrId;
      });
      if (level2.length > 0) {
        // Check for level 2
      } else {
        this.level = 1;
      }
    } else {
      this.level = 0;
    }
  }

  onStatusFilterChange(newValue) {
    if (!newValue || newValue.length === 0) {
      this.assignCopy();
    } else {
      const dtrs = Object.assign([], this.section.dtrs);
      let filteredList = [];
      dtrs.forEach((dtr) => {
        if (
          this.form.value[dtr.dtrId] &&
          newValue.includes(this.form.value[dtr.dtrId]["test-status"])
        ) {
          filteredList.push(dtr);
        }
      });
      this.filteredItems = filteredList;
    }
  }

  onJumpToChange(newValue) {
    this.assignCopy();
    this.jumpToQuestion = newValue;
  }
  ngOnChanges(changes: SimpleChanges) {
    this.submissionType = this.sectionService.vendorFormGroup
      .get("module")
      .get("transmissionCode").value;
    this.isLoading = true;
    this.statusCheck = false;
    this.getSelectedLevel();

    this.assignCopy();
    const self = this;
    setTimeout(function () {
      self.ngAfterViewInit();
    }, 2000);
    this.form.valueChanges.subscribe((val) => {
      this.onStatusFilterChange(this.statusFilter);
    });
  }
  getSelectedLevel() {
    if (this.sectionService.vendorFormGroup.get("module").value) {
      const module = this.sectionService.vendorFormGroup.get("module").value;
      switch (this.section.secId) {
        case "1":
          this.selectedLevel = module["section1-level"];
          break;
        case "2":
          this.selectedLevel = module["section2-level"];
          break;
        case "3":
          this.selectedLevel = module["section3-level"];
          break;
        case "4":
          this.selectedLevel = module["section4-level"];
          break;
        case "5":
          this.selectedLevel = module["section5-level"];
          break;
        case "6":
          this.selectedLevel = module["section6-level"];
          break;
        case "7":
          this.selectedLevel = module["section7-level"];
          break;
        case "8":
          this.selectedLevel = module["section8-level"];
          break;
        case "9":
          this.selectedLevel = module["section9-level"];
          break;
        case "10":
          this.selectedLevel = module["section10-level"];
          break;
        case "11":
          this.selectedLevel = module["section11-level"];
          break;
        case "12":
          this.selectedLevel = module["section12-level"];
          break;
      }
    }
  }
  getRowAsArray(arrayName, question = null) {
    return this.sectionService.sections[this.section.secId].controls[question]
      .controls[arrayName] as UntypedFormArray;
  }
  test(a) {
    //  (a)
  }

  sortTables(tables) {
    if (tables) {
      return tables.sort((a, b) => a.position - b.position);
    } else {
      return [];
    }
  }

  resetToOpen() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message:
        "Are you sure you want to reset all assessments of the current section to Open?",
      btnLabel: "Reset",
      btnClass: "btn-danger",
    };
    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let form = this.form.value;
        for (const key in form) {
          if (form.hasOwnProperty(key)) {
            this.form.controls[key].controls["test-status"].setValue("0");
          }
        }
      }
    });
  }
}
