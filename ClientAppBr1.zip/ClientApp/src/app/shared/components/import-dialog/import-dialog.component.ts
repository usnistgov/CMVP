import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  SimpleChanges,
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MatDialogRef } from "@angular/material/dialog";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { DatePipe } from "@angular/common";
import * as JSZip from "jszip";
import { saveAs } from "file-saver";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import { reject } from "q";
import { ConverterService } from "../../services/converter.service";
import { PdfService } from "../../services/pdf.service";

pdfMake.vfs = pdfFonts.pdfMake.vfs;
@Component({
  selector: "app-import-dialog",
  templateUrl: "./import-dialog.component.html",
  styleUrls: ["./import-dialog.component.scss"],
})
export class ImportDialogComponent implements OnInit {
  uploadedFiles = {
    vendor: null,
    reports: [],
    sections: {},
  };
  sections = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "14"];
  importError = false;
  constructor(
    public pdfService: PdfService,
    public datepipe: DatePipe,
    public formService: FormService,
    public sectionService: SectionService,
    private dialogRef: MatDialogRef<ImportDialogComponent>
  ) {}

  ngOnInit() {}
  removeVendorFile() {
    this.uploadedFiles.vendor = null;
  }
  addVendorFile(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file

        self.uploadedFiles.vendor = {
          name: input.files[index].name,
          data: reader.result.toString(),
        };
      };
      reader.readAsText(input.files[index]);
    }
  }

  removeReportsFile(i) {
    this.uploadedFiles.reports.splice(i, 1);
  }

  addReportsFile(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        // this 'text' is the content of the file

        self.uploadedFiles.reports.push({
          name: input.files[index].name,
          data: reader.result.toString(),
        });
      };
      reader.readAsText(input.files[index]);
    }
  }

  async save() {
    this.importError = false;
    try {
      if (this.uploadedFiles.vendor) {
        if (this.uploadedFiles.vendor.name.endsWith("xml")) {
          this.formService.parseVendoInfoData(
            this.sectionService.vendorFormGroup,
            this.uploadedFiles.vendor.data,
            "xml"
          );
        } else if (this.uploadedFiles.vendor.name.endsWith("json")) {
          this.formService.parseVendoInfoData(
            this.sectionService.vendorFormGroup,
            this.uploadedFiles.vendor.data,
            "json"
          );
        }
      }
      if (this.uploadedFiles.reports) {
        this.uploadedFiles.reports.forEach((report) => {
          let section = report.name.split("_");
          section = section[section.length - 1];
          if (section) {
            section = section.split(".");
            if (section.length === 2) {
              const sectionNumber = section[0].replace("section", "");
              const type = section[1];

              if (type === "xml") {
                this.formService.parseReportSectionData(
                  this.sectionService.sections[sectionNumber],
                  report.data,
                  "xml"
                );
              } else if (type === "json") {
                this.formService.parseReportSectionData(
                  this.sectionService.sections[sectionNumber],
                  report.data,
                  "json"
                );
              }
            }
          }
        });
        // if (this.uploadedFiles.reports.name.endsWith("txt")) {
        //   this.formService.parseReportsInfoTxt(this.uploadedFiles.reports.data);
        // }
      }
      this.dialogRef.close(this.uploadedFiles);
    } catch (error) {
      console.log(error);
      this.importError = true;
    }
  }

  close() {
    this.dialogRef.close();
  }


  async extractZip(event) {
    let file =event.target.files[0];

    try {
      const zip = new JSZip();
      const zipContent = await zip.loadAsync(file);
      const jsonFiles = zipContent.files;
      Object.keys(jsonFiles).forEach(async filename => {
        if(filename.endsWith(".json")) {
          const fileContent = await jsonFiles[filename].async('string');

          if (filename.endsWith('_module.json')) {
            // const jsonData = JSON.parse(fileContent);
            // console.log('JSON data from', filename, jsonData);
            this.uploadedFiles.vendor = {
              name: filename,
              data: fileContent,
            };
            // You can now use jsonData as needed
          } else {
            this.uploadedFiles.reports.push({
              name: filename,
              data: fileContent,
            })
          }
        }
  
      });
    } catch (error) {
      console.error('Error reading ZIP file:', error);
    }
  }
}
