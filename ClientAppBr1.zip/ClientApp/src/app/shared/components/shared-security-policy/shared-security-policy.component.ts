import { Component, OnInit, Input } from "@angular/core";
import { SectionService } from "../../services/section.service";
import {
  AbstractControl,
  UntypedFormArray,
  UntypedFormBuilder,
  UntypedFormControl,
  UntypedFormGroup,
} from "@angular/forms";
import * as _ from "underscore";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ImageDialogComponent } from "../image-dialog/image-dialog.component";
import { FormService } from "../../services/form.service";
import { ExportSecurityDialogComponent } from "../export-security-dialog/export-security-dialog.component";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";

@Component({
  selector: "app-shared-security-policy",
  templateUrl: "./shared-security-policy.component.html",
  styleUrls: ["./shared-security-policy.component.scss"],
})
export class SharedSecurityPolicyComponent implements OnInit {
  tables = [];
  openedSection;
  formGroups = {};
  editingRow;
  editingTable;

  editingEntropyVendorName;
  editingEntropyCert;
  editingEntropyCertificateId;
  editingEntropyCertOptions = [];
  entropyCertOptions = [];
  entropyVendorName;
  entropyEditingVendorName;
  entropyCert;

  @Input()
  readOnly = null;

  currentDate = new Date();

  CAVPCertOptions = [];
  editingCAVPCertOptions = [];

  CAVPCert;
  editingCAVPCert;

  algorithmAndStandardOptions = [];
  algorithmAndStandard;
  editingAlgorithmAndStandardOptions = [];
  editingAlgorithmAndStandard;

  ValidationOEAlgorithms;
  editingValidationOEAlgorithms;

  modeMethod;
  editingModeMethod;

  vendorName;
  editingVendorName;

  moduleType;

  // Table A
  algorithmAndStandardMapTableA = {};
  algorithmAndStandardOptionsTableA = [];
  editingAlgorithmAndStandardOptionsTableA = [];
  algorithmAndStandardTableA;
  editingAlgorithmAndStandardTableA;

  ValidationOEAlgorithmsTableA;
  editingValidationOEAlgorithmsTableA;

  modeMethodTableA;
  editingModeMethodTableA;

  vendorNameTableA;
  editingVendorNameTableA;

  vendorNamesList = [];

  table9Algo;
  editingTable9Algo;

  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    private fb: UntypedFormBuilder
  ) {}

  scrollTo(fragment) {
    const elmnt = document.getElementById(fragment);
    if (elmnt) {
      elmnt.scrollIntoView({ behavior: "auto", block: "start" });
    }
  }

  ngOnInit() {
    this.tables = [];
    this.moduleType = this.formService.moduleType;
    for (let sectionNb in this.sectionService.securityPolicyTables) {
      if (
        Object.prototype.hasOwnProperty.call(
          this.sectionService.securityPolicyTables,
          sectionNb
        )
      ) {
        const section = this.sectionService.securityPolicyTables[sectionNb];

        section.forEach((question) => {
          if (question.type === "files") {
            this.tables.push({
              form: this.sectionService.sections[sectionNb].controls[
                question.question
              ],
              question: question.question,
              type: question.type,
              title: question.title,
              position: question.position,
            });
          } else {
            this.tables.push({
              form: question.form
                ? question.form
                : this.sectionService.sections[sectionNb].controls[
                    question.question
                  ],
              details: question.details,
              question: question.question,
              type: question.type,
              formGroup: question.formGroup,
              disabled: question.form ? true : false,
              title: question.title,
              position: question.position,
              condition: question.condition,
            });
            if (!this.formGroups[question.question]) {
              this.formGroups[question.question] = {};
            }
            this.formGroups[question.question][question.position] =
              question.formGroup;
          }
        });
      }
    }
    this.tables = this.tables.sort((a, b) => a.position - b.position);

    this.vendorName =
      this.sectionService.vendorFormGroup.getRawValue().vendor["vendorName"];
    this.formService.updateTable9AlgoOptions(
      this.tables[5].form.value.approvedAlgorithms
    );
    this.getCAVPCerts();
  }

  async getCAVPCerts() {
    let certs = await this.sectionService.getCAVPCerts(this.vendorName);

    if (certs) {
      this.CAVPCertOptions = <any[]>certs;
    }
  }
  async getEditingCAVPCerts() {
    let certs = await this.sectionService.getCAVPCerts(this.editingVendorName);
    if (certs) {
      this.editingCAVPCertOptions = <any[]>certs;
    }
  }
  async onCAVPCertChange(event, form: UntypedFormGroup) {
    if (event) {
      form.controls["CAVPCert"].setValue(event.ValidationNumber);
      form.controls["ValidationId"].setValue(event.ValidationId);
      form.controls["algorithmAndStandard"].setValue(null);

      this.algorithmAndStandard = null;
      this.modeMethod = null;
      form.controls["modeMethod"].setValue(null);

      const splits = event.ValidationNumber.split(" ");
      let prefix = "";
      let number = "";
      if (splits.length === 1) {
        prefix = splits[0][0];
        number = splits[0].substring(1);
      }

      if (splits.length === 2) {
        prefix = splits[0];
        number = splits[1];
      }

      if (prefix != "" && number != "") {
        let algos = await this.sectionService.getAlgorithms(prefix, number);
        this.algorithmAndStandardOptions = <any[]>algos;
      }
      if (event.ValidationId) {
        let oe = await this.sectionService.getOeAlgos(event.ValidationId);
        this.ValidationOEAlgorithms = <any>oe;
      }
    }
  }

  onAlgorithmChange(event, form) {
    if (event) {
      form.controls["algorithmAndStandard"].setValue(event);

      const splits = event.split("-");
      this.modeMethod = splits[0];
      form.controls["modeMethod"].setValue(this.modeMethod);

      if (
        this.ValidationOEAlgorithms &&
        this.ValidationOEAlgorithms.ValidationOEAlgorithms
      ) {
        let oe = this.ValidationOEAlgorithms.ValidationOEAlgorithms.find(
          (a) => a.Algorithm === event
        );
        if (oe) {
        }
      }
    }
  }

  onModeMethodChange(event, form) {
    form.controls["modeMethod"].setValue(event);
  }
  onVendorNameChange(event, form) {
    form.controls["vendorName"].setValue(event);
  }

  async onEditingCAVPCertChange(event, form, i) {
    if (event) {
      form.CAVPCert = event.ValidationNumber;
      form.ValidationId = event.ValidationId;
      form.algorithmAndStandard = "";
      form.modeMethod = "";
      this.editingAlgorithmAndStandard = null;
      this.editingModeMethod = null;
      this.editingValidationOEAlgorithms = null;
      const splits = event.split(" ");
      let prefix = "";
      let number = "";
      if (splits.length === 1) {
        prefix = splits[0][0];
        number = splits[0].substring(1);
      }

      if (splits.length === 2) {
        prefix = splits[0];
        number = splits[1];
      }

      if (prefix != "" && number != "") {
        let algos = await this.sectionService.getAlgorithms(prefix, number);
        this.editingAlgorithmAndStandardOptions = <any[]>algos;
      }
      if (event.ValidationId) {
        let oe = await this.sectionService.getOeAlgos(event.ValidationId);
        this.editingValidationOEAlgorithms = <any>oe;
      }
      let array = this.tables[5].form.get(
        "approvedAlgorithms"
      ) as UntypedFormArray;
      array.controls[i].get("CAVPCert").setValue(event);
      array.controls[i].get("algorithmAndStandard").setValue("");
      array.controls[i].get("modeMethod").setValue("");
    }
  }

  onEditingAlgorithmChange(event, form, i) {
    if (event) {
      form.algorithmAndStandard = event;
      let array = this.tables[5].form.get(
        "approvedAlgorithms"
      ) as UntypedFormArray;
      array.controls[i].get("algorithmAndStandard").setValue(event);
      const splits = event.split("-");
      this.editingModeMethod = splits[0];
      form.modeMethod = splits[0];
      array.controls[i].get("modeMethod").setValue(splits[0]);

      if (
        this.editingValidationOEAlgorithms &&
        this.editingValidationOEAlgorithms.ValidationOEAlgorithms
      ) {
        let oe = this.editingValidationOEAlgorithms.ValidationOEAlgorithms.find(
          (a) => a.Algorithm === event
        );
        if (oe) {
        }
      }
    }
  }

  onEditModeMethodChange(event, form, i) {
    let array = this.tables[5].form.get(
      "approvedAlgorithms"
    ) as UntypedFormArray;
    array.controls[i].get("modeMethod").setValue(event);
    form.modeMethod = event;
  }

  onEditVendorNameChange(event, form, i) {
    let array = this.tables[5].form.get(
      "approvedAlgorithms"
    ) as UntypedFormArray;
    array.controls[i].get("vendorName").setValue(event);
    form.vendorName = event;
  }

  async getAlgosByCert(cert) {
    const splits = cert.split(" ");
    let prefix = "";
    let number = "";
    if (splits.length === 1) {
      prefix = splits[0][0];
      number = splits[0].substring(1);
    }

    if (splits.length === 2) {
      prefix = splits[0];
      number = splits[1];
    }

    if (prefix != "" && number != "") {
      let algos = await this.sectionService.getAlgorithms(prefix, number);
      this.editingAlgorithmAndStandardOptions = <any[]>algos;
    }
  }
  compareObjects(o1: any, o2: any): boolean {
    return o1.ValidationNumber === o2.ValidationNumber;
  }

  hasCondition(table) {
    let res = false;
    if (table.condition && table.condition.path.length > 0) {
      let obj = this.sectionService.vendorFormGroup.getRawValue();
      table.condition.path.forEach((p) => {
        obj = obj[p];
      });
      if (obj && table.condition.values.includes(obj)) {
        res = true;
      }
    } else {
      return true;
    }
    return res;
  }

  openSection(section) {
    this.openedSection = this.sectionService.sections[section.key];
    this.tables = [];
    section.value.forEach((question) => {
      this.tables.push({
        form: this.sectionService.sections[section.key].controls[
          question.question
        ],
        details: question.details,
        question: question.question,
        type: question.type,
        formGroup: question.formGroup,
      });
      this.formGroups[question.question] = question.formGroup;
    });
  }
  addToFormArray(
    question,
    formGroup: UntypedFormGroup,
    ArrayControlName,
    position,
    custom?
  ) {
    let formGroupObj = {};
    if (custom === "CAVPCert") {
      if (!this.modeMethod) {
        return;
      }
      const v = this.vendorNamesList.find((x) => x === this.vendorName);
      if (!v) {
        this.vendorNamesList.push(this.vendorName);
        this.algorithmAndStandardMapTableA[this.vendorName] = [];
      }
      const algo = this.algorithmAndStandardMapTableA[this.vendorName].find(
        (x) => x === this.algorithmAndStandard
      );
      if (!algo) {
        this.algorithmAndStandardMapTableA[this.vendorName].push(
          this.algorithmAndStandard
        );
      }
      formGroup.value["modeMethod"] = this.modeMethod;
      formGroup.value["vendorName"] = this.vendorName;

      this.CAVPCert = null;
      this.algorithmAndStandard = null;
      this.modeMethod = null;
      this.ValidationOEAlgorithms = null;
    }
    if (custom === "entropyCert") {
      formGroup.value["vendorName"] = this.entropyVendorName;
      formGroup.value["entropyCert"] = this.entropyCert.ValidationNumber;
      formGroup.value["entropyCertificateId"] = this.entropyCert.ValidationId;
      this.entropyCert = null;
    }
    if (custom === "tableA") {
      this.modeMethodTableA = null;
      this.vendorNameTableA = null;
      this.algorithmAndStandardTableA = null;
    }

    if (custom === "sfi") {
      this.table9Algo = null;
    }

    for (let index in formGroup.value) {
      if (formGroup.get(index) instanceof UntypedFormArray) {
        formGroupObj[index] = this.fb.array(formGroup.value[index]);
      } else {
        formGroupObj[index] = new UntypedFormControl(formGroup.value[index]);
      }
    }
    const fg = new UntypedFormGroup(formGroupObj);

    const table = this.tables.find(
      (x) => x.question === question && x.position === position
    );
    if (table) {
      let array = table.form.get(ArrayControlName) as UntypedFormArray;
      array.push(fg);

      if (custom === "CAVPCert") {
        this.formService.updateTable9AlgoOptions(array.value);
      }
    }

    // formGroup.reset();
    this.resetForm(formGroup);
  }

  resetForm(formGroup: UntypedFormGroup) {
    let control: AbstractControl = null;
    formGroup.reset();
    formGroup.markAsUntouched();
    Object.keys(formGroup.controls).forEach((name) => {
      control = formGroup.controls[name];
      if (control instanceof UntypedFormArray) {
        control.clear();
      }
      control.setErrors(null);
    });
  }

  onTable9AlgoChange(event, form: UntypedFormGroup) {
    if (event) {
      let array = form.controls["algorithms"] as UntypedFormArray;
      array.clear();
      event.forEach((e) => {
        array.push(this.fb.control(e));
      });
    }
  }
  onEditTable9AlgoChange(event, form: UntypedFormGroup, i) {
    if (event) {
      let array = this.tables[23].form.get(
        this.tables[23].details.controlName
      ) as UntypedFormArray;

      let algos = array.controls[i].get("algorithms") as UntypedFormArray;
      algos.clear();
      event.forEach((e) => {
        algos.push(this.fb.control(e));
      });
    }
  }
  editFormInArray(index, question, custom?) {
    this.editingRow = index;
    this.editingTable = question;
    if (custom === "sfi") {
      this.editingTable9Algo =
        this.tables[23].form.value[this.tables[23].details.controlName][index][
          "algorithms"
        ];
    }
    if (custom === "CAVPCert") {
      this.editingVendorName =
        this.tables[5].form.value[this.tables[5].details.controlName][index][
          "vendorName"
        ];
      this.getEditingCAVPCerts();
      this.editingCAVPCert = {
        ValidationNumber:
          this.tables[5].form.value[this.tables[5].details.controlName][index][
            "CAVPCert"
          ],
        ValidationId:
          this.tables[5].form.value[this.tables[5].details.controlName][index][
            "ValidationId"
          ],
      };
      this.editingAlgorithmAndStandard =
        this.tables[5].form.value[this.tables[5].details.controlName][index][
          "algorithmAndStandard"
        ];

      this.editingModeMethod =
        this.tables[5].form.value[this.tables[5].details.controlName][index][
          "modeMethod"
        ];

      this.getAlgosByCert(
        this.tables[5].form.value[this.tables[5].details.controlName][index][
          "CAVPCert"
        ]
      );
    }
    if (custom === "entropyCert") {
      this.editingEntropyVendorName =
        this.tables[9].form.value[this.tables[9].details.controlName][index][
          "vendorName"
        ];
      this.editingEntropyCert =
        this.tables[9].form.value[this.tables[9].details.controlName][index][
          "entropyCert"
        ];
      this.editingEntropyCertificateId =
        this.tables[9].form.value[this.tables[9].details.controlName][index][
          "entropyCertificateId"
        ];
      this.getEditingEntropyCerts();
    }
  }
  deleteRow(form, arrayName, index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this item?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        const array = form.get(arrayName) as UntypedFormArray;
        array.removeAt(index);
      }
    });
  }
  saveRow() {
    this.editingRow = null;
    this.editingTable = null;
  }
  getRowAsArray(form, arrayName) {
    if (arrayName === "approvedAlgorithms") {
      let array = form.get(arrayName) as UntypedFormArray;
      const sortedArray = array.getRawValue().sort((a, b) => {
        if (a.CAVPCert < b.CAVPCert) {
          return -1;
        } else if (a.CAVPCert > b.CAVPCert) {
          return 1;
        } else {
          if (a.algorithmAndStandard < b.algorithmAndStandard) {
            return -1;
          } else if (a.algorithmAndStandard > b.algorithmAndStandard) {
            return 1;
          } else {
            return 0;
          }
        }
      });

      array.patchValue(sortedArray);
      return array as UntypedFormArray;
    } else {
      return form.get(arrayName) as UntypedFormArray;
    }
  }

  openImageDialog(form) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "700px";

    const dialogRef = this.dialog.open(ImageDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      if (data) {
        (<UntypedFormArray>form.controls.files).push(
          new UntypedFormControl({ file: data.file, title: data.title })
        );
      }
    });
  }

  findTable(title) {
    return this.tables.find((x) => x.title === title);
  }

  importSecurityPolicy() {}

  exportSecurityPolicy() {
    const tables = this.tables;
    const dialogConfig = new MatDialogConfig();
    dialogConfig.data = tables;
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    (dialogConfig.width = "900px"),
      this.dialog.open(ExportSecurityDialogComponent, dialogConfig);
  }

  addSecurityFile(event) {
    let self = this;
    let input = event.target;
    for (let index = 0; index < input.files.length; index++) {
      let reader = new FileReader();
      reader.onload = () => {
        self.formService.parseSecurityData(
          this.tables,
          reader.result.toString(),
          input.files[index].name
        );
      };
      reader.readAsText(input.files[index]);
    }
  }

  // Table A
  onEditingAlgorithmChangeTableA(event, form, i) {
    if (event) {
      form.algorithmAndStandard = event;
      let array = this.tables[21].form.get(
        "approvedAlgorithms"
      ) as UntypedFormArray;
      array.controls[i].get("algorithmAndStandard").setValue(event);
      const splits = event.split("-");
      this.editingModeMethodTableA = splits[0];
      form.modeMethod = splits[0];
      array.controls[i].get("modeMethod").setValue(splits[0]);

      if (
        this.editingValidationOEAlgorithmsTableA &&
        this.editingValidationOEAlgorithmsTableA.ValidationOEAlgorithms
      ) {
        let oe =
          this.editingValidationOEAlgorithmsTableA.ValidationOEAlgorithms.find(
            (a) => a.Algorithm === event
          );
        if (oe) {
        }
      }
    }
  }
  onEditModeMethodChangeTableA(event, form, i) {
    let array = this.tables[21].form.get(
      "approvedAlgorithms"
    ) as UntypedFormArray;
    array.controls[i].get("modeMethod").setValue(event);
    form.modeMethod = event;
  }

  onAlgorithmChangeTableA(event, form) {
    if (event) {
      form.controls["algorithmAndStandard"].setValue(event);

      const splits = event.split("-");
      this.modeMethodTableA = splits[0];
      form.controls["modeMethod"].setValue(this.modeMethodTableA);

      if (
        this.ValidationOEAlgorithmsTableA &&
        this.ValidationOEAlgorithmsTableA.ValidationOEAlgorithmsTableA
      ) {
        let oe = this.ValidationOEAlgorithmsTableA.ValidationOEAlgorithms.find(
          (a) => a.Algorithm === event
        );
        if (oe) {
        }
      }
    }
  }
  onModeMethodChangeTableA(event, form) {
    form.controls["modeMethod"].setValue(event);
  }
  onVendorNameChangeTableA(event, form) {
    form.controls["vendorName"].setValue(event);
    this.algorithmAndStandardOptionsTableA =
      this.algorithmAndStandardMapTableA[event];
  }
  onEditVendorNameChangeTableA(event, form, i) {
    this.editingAlgorithmAndStandardOptionsTableA =
      this.algorithmAndStandardMapTableA[event];

    let array = this.tables[21].form.get(
      "approvedAlgorithms"
    ) as UntypedFormArray;
    array.controls[i].get("vendorName").setValue(event);
    form.vendorName = event;
  }
  editFormInArrayTableA(index, question) {
    this.editingRow = index;
    this.editingTable = question;

    this.editingVendorNameTableA =
      this.tables[21].form.value[this.tables[21].details.controlName][index][
        "vendorName"
      ];
    this.editingAlgorithmAndStandardOptionsTableA =
      this.algorithmAndStandardMapTableA[this.editingVendorNameTableA];

    this.editingAlgorithmAndStandardTableA =
      this.tables[21].form.value[this.tables[21].details.controlName][index][
        "algorithmAndStandard"
      ];

    this.editingModeMethodTableA =
      this.tables[21].form.value[this.tables[21].details.controlName][index][
        "modeMethod"
      ];
  }

  onEditEntropyVendorNameChange(event, form, i) {
    let array = this.tables[9].form.get(
      "approvedAlgorithms"
    ) as UntypedFormArray;
    array.controls[i].get("vendorName").setValue(event);
    form.vendorName = event;
  }

  async getEntropyCerts() {
    let certs = await this.sectionService.getEntropyCerts(
      this.entropyVendorName
    );
    if (certs) {
      this.entropyCertOptions = <any[]>certs;
    }
  }
  async getEditingEntropyCerts() {
    let certs = await this.sectionService.getEntropyCerts(
      this.editingEntropyVendorName
    );

    if (certs) {
      this.editingEntropyCertOptions = <any[]>certs;
    }
  }
  async onEntropyCertChange(event, form: UntypedFormGroup) {
    if (event) {
      form.controls["entropyCert"].setValue(event.ValidationNumber);
      form.controls["entropyCertificateId"].setValue(event.ValidationId);
    }
  }
  async onEditingEntropyCertChange(event, form, i) {
    if (event) {
      form.entropyCert = event.ValidationNumber;

      let array = this.tables[9].form.get(
        this.tables[9].details.controlName
      ) as UntypedFormArray;
      array.controls[i].get("entropyCert").setValue(event.ValidationNumber);
      array.controls[i]
        .get("entropyCertificateId")
        .setValue(event.ValidationId);
    }
  }
  public isFiltered(option) {
    return this.sectionService.filteredTable9AlgoOptions.find(
      (item) => item.label === option.label
    );
  }
}
