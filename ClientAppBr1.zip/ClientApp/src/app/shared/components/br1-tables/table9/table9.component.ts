import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table9",
  templateUrl: "./table9.component.html",
  styleUrls: ["./table9.component.scss"],
})
export class Table9Component implements OnInit {
  public nonApprovedNotAllowedAlgoListForm: UntypedFormGroup;
  public nonApprovedNotAllowedAlgoListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.nonApprovedNotAllowedAlgoListForm = this.fb.group({
      name: ["", Validators.required],
      useFunction: ["", Validators.required],
    });
    this.nonApprovedNotAllowedAlgoListFormEdit = this.fb.group({
      name: ["", Validators.required],
      useFunction: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.nonApprovedNotAllowedAlgoListForm.valid) {
      this.br1Service.brTables["nonApprovedNotAllowedAlgoList"].push(
        this.nonApprovedNotAllowedAlgoListForm.value
      );
      this.nonApprovedNotAllowedAlgoListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.nonApprovedNotAllowedAlgoListFormEdit.setValue(
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.nonApprovedNotAllowedAlgoList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index] =
        form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.nonApprovedNotAllowedAlgoList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index],
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index - 1],
    ] = [
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index - 1],
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.nonApprovedNotAllowedAlgoList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index],
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index + 1],
    ] = [
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index + 1],
      this.br1Service.brTables.nonApprovedNotAllowedAlgoList[index],
    ];
  }
}
