import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  UntypedFormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { TableAlgoPropEditorComponent } from "../../table-algo-prop-editor/table-algo-prop-editor.component";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table7",
  templateUrl: "./table7.component.html",
  styleUrls: ["./table7.component.scss"],
})
export class Table7Component implements OnInit {
  public nonApprovedAllowedAlgoListForm: UntypedFormGroup;
  public nonApprovedAllowedAlgoListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;

  otherImplName;
  otherImplNameEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.nonApprovedAllowedAlgoListForm = this.fb.group({
      name: ["", Validators.required],
      algoPropList: [[]],
      implName: ["", Validators.required],
      reference: ["", Validators.required],
    });
    this.nonApprovedAllowedAlgoListFormEdit = this.fb.group({
      name: ["", Validators.required],
      algoPropList: [[]],
      implName: ["", Validators.required],
      reference: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.nonApprovedAllowedAlgoListForm.valid) {
      let { implName, ...rest } = this.nonApprovedAllowedAlgoListForm.value;

      this.br1Service.brTables["nonApprovedAllowedAlgoList"].push({
        implName: implName !== "Other" ? implName : this.otherImplName,
        ...rest,
      });
      this.nonApprovedAllowedAlgoListForm.reset();
      this.otherImplName = null;
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { implName, ...rest } =
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index];
    const isInOptions = this.br1Service.cavpCertSet.cavpCertList.findIndex(
      (c) => c.implName === implName
    );
    if (isInOptions > -1) {
      this.nonApprovedAllowedAlgoListForm.setValue(
        this.br1Service.brTables.nonApprovedAllowedAlgoList[index]
      );
    } else {
      this.nonApprovedAllowedAlgoListFormEdit.setValue({
        implName: "Other",
        ...rest,
      });

      this.otherImplNameEdit = implName;
    }
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.nonApprovedAllowedAlgoList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      let { implName, ...rest } = form.value;
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index] = {
        ...rest,
        implName: implName !== "Other" ? implName : this.otherImplNameEdit,
      };
      this.editingRow = null;
      this.otherImplNameEdit = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  editProp(row) {
    let prop;
    if (row === "new") {
      prop = this.nonApprovedAllowedAlgoListForm.value.algoPropList;
    } else {
      prop = this.nonApprovedAllowedAlgoListFormEdit.value.algoPropList;
    }
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      propList: prop,
      title: "Algorithm Properties",
    };
    const dialogRef = this.dialog.open(
      TableAlgoPropEditorComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      if (row === "new") {
        this.nonApprovedAllowedAlgoListForm
          .get("algoPropList")
          .setValue(data.propList as UntypedFormArray);
      } else {
        this.nonApprovedAllowedAlgoListFormEdit
          .get("algoPropList")
          .setValue(data.propList as UntypedFormArray);
      }
    });
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.nonApprovedAllowedAlgoList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index],
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index - 1],
    ] = [
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index - 1],
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.nonApprovedAllowedAlgoList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index],
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index + 1],
    ] = [
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index + 1],
      this.br1Service.brTables.nonApprovedAllowedAlgoList[index],
    ];
  }
}
