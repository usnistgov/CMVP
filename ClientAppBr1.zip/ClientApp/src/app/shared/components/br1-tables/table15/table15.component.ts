import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table15",
  templateUrl: "./table15.component.html",
  styleUrls: ["./table15.component.scss"],
})
export class Table15Component implements OnInit {
  public roleListForm: UntypedFormGroup;
  public roleListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  types = ["Role", "Identity", "Multi-Factor Identity"];
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.roleListForm = this.fb.group({
      name: ["", Validators.required],
      type: ["", Validators.required],
      operatorType: ["", Validators.required],
      authMethodList: [[], Validators.required],
    });
    this.roleListFormEdit = this.fb.group({
      name: ["", Validators.required],
      type: ["", Validators.required],
      operatorType: ["", Validators.required],
      authMethodList: [[], Validators.required],
    });
  }

  addArray() {
    // if (
    //   this.roleListForm.valid &&
    //   this.roleListForm.value.authMethodList.length > 0
    // ) {
      this.br1Service.brTables["roleList"].push(this.roleListForm.value);
      this.roleListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.roleListFormEdit.setValue(this.br1Service.brTables.roleList[index]);
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.roleList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid && form.value.authMethodList.length > 0) {
      this.br1Service.brTables.roleList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (index <= 0 || index >= this.br1Service.brTables.roleList.length) {
      return;
    }
    [
      this.br1Service.brTables.roleList[index],
      this.br1Service.brTables.roleList[index - 1],
    ] = [
      this.br1Service.brTables.roleList[index - 1],
      this.br1Service.brTables.roleList[index],
    ];
  }
  down(index) {
    if (index < 0 || index >= this.br1Service.brTables.roleList.length - 1) {
      return;
    }
    [
      this.br1Service.brTables.roleList[index],
      this.br1Service.brTables.roleList[index + 1],
    ] = [
      this.br1Service.brTables.roleList[index + 1],
      this.br1Service.brTables.roleList[index],
    ];
  }
}
