import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table13",
  templateUrl: "./table13.component.html",
  styleUrls: ["./table13.component.scss"],
})
export class Table13Component implements OnInit {
  public portInterfaceListForm: UntypedFormGroup;
  public portInterfaceListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  logicalInterfaces = [
    "Data Input",
    "Data Output",
    "Control Input",
    "Control Output",
    "Status Output",
    "Power",
    "None",
  ];
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.portInterfaceListForm = this.fb.group({
      physicalPort: ["", Validators.required],
      logicalInterfaceList: [[], Validators.required],
      dataPasses: ["", Validators.required],
    });
    this.portInterfaceListFormEdit = this.fb.group({
      physicalPort: ["", Validators.required],
      logicalInterfaceList: [[], Validators.required],
      dataPasses: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.portInterfaceListForm.valid) {
      this.br1Service.brTables["portInterfaceList"].push(
        this.portInterfaceListForm.value
      );
      this.portInterfaceListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.portInterfaceListFormEdit.setValue(
      this.br1Service.brTables.portInterfaceList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.portInterfaceList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.portInterfaceList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.portInterfaceList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.portInterfaceList[index],
      this.br1Service.brTables.portInterfaceList[index - 1],
    ] = [
      this.br1Service.brTables.portInterfaceList[index - 1],
      this.br1Service.brTables.portInterfaceList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.portInterfaceList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.portInterfaceList[index],
      this.br1Service.brTables.portInterfaceList[index + 1],
    ] = [
      this.br1Service.brTables.portInterfaceList[index + 1],
      this.br1Service.brTables.portInterfaceList[index],
    ];
  }
}
