import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";

@Component({
  selector: "app-table11",
  templateUrl: "./table11.component.html",
  styleUrls: ["./table11.component.scss"],
})
export class Table11Component implements OnInit {
  editingTable;
  editingRow;

  entropyCertOptions = [];
  entropyVendorName;
  entropyCert;

  entropyCertOptionsEdit = [];
  entropyVendorNameEdit;
  entropyCertEdit;

  editingTableA;
  editingRowA;
  entropyCertA;
  entropyCertAEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder
  ) {}

  ngOnInit() {}

  addArray() {
    if (this.entropyVendorName && this.entropyCert) {
      this.br1Service.brTables["esvCertList"].push({
        esvCertName: this.entropyCert.ValidationNumber,
        certId: this.entropyCert.ValidationId,
        vendorName: this.entropyVendorName,
      });
      this.entropyCert = null;
    }
  }

  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.esvCertList.splice(index, 1);
      }
    });
  }

  saveTableRow(index) {
    if (this.entropyVendorNameEdit && this.entropyCertEdit) {
      this.br1Service.brTables.esvCertList[index] = {
        esvCertName: this.entropyCertEdit.ValidationNumber,
        certId: this.entropyCertEdit.ValidationId,
        vendorName: this.entropyVendorNameEdit,
      };
      this.entropyCertEdit = null;
      this.entropyVendorNameEdit = null;
      this.editingRow = null;
    }
  }
  async editTableRow(index) {
    this.entropyVendorNameEdit =
      this.br1Service.brTables["esvCertList"][index].vendorName;
    await this.getEntropyCertsEdit();
    this.editingRow = index;
    this.entropyCertEdit = {
      ValidationNumber:
        this.br1Service.brTables["esvCertList"][index].esvCertName,
      ValidationId: this.br1Service.brTables["esvCertList"][index].certId,
    };
  }
  async getEntropyCerts() {
    let certs = await this.sectionService.getEntropyCerts(
      this.entropyVendorName
    );
    if (certs) {
      this.entropyCertOptions = <any[]>certs;
    }
  }
  async getEntropyCertsEdit() {
    let certs = await this.sectionService.getEntropyCerts(
      this.entropyVendorNameEdit
    );
    if (certs) {
      this.entropyCertOptionsEdit = <any[]>certs;
    }
  }

  // table a

  addArrayA() {
    if (this.entropyCertA) {
      this.br1Service.brTables["esvItarCertList"].push(this.entropyCertA);
      this.entropyCertA = null;
    }
  }

  deleteTableRowA(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.esvItarCertList.splice(index, 1);
      }
    });
  }

  saveTableRowA(index) {
    if (this.entropyCertAEdit) {
      this.br1Service.brTables.esvItarCertList[index] =
        this.entropyCertAEdit.toString();
      this.entropyCertAEdit = null;
      this.editingRowA = null;
    }
  }
  public isSameEntropy(entropyCertA?, entropyCertB?) {
    return (
      !!entropyCertA &&
      entropyCertA.ValidationNumber === entropyCertB?.ValidationNumber &&
      entropyCertA?.ValidationId === entropyCertB?.ValidationId
    );
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.esvItarCertList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.esvItarCertList[index],
      this.br1Service.brTables.esvItarCertList[index - 1],
    ] = [
      this.br1Service.brTables.esvItarCertList[index - 1],
      this.br1Service.brTables.esvItarCertList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.esvItarCertList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.esvItarCertList[index],
      this.br1Service.brTables.esvItarCertList[index + 1],
    ] = [
      this.br1Service.brTables.esvItarCertList[index + 1],
      this.br1Service.brTables.esvItarCertList[index],
    ];
  }
}
