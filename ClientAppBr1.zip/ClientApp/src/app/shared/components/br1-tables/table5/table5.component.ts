import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table5",
  templateUrl: "./table5.component.html",
  styleUrls: ["./table5.component.scss"],
})
export class Table5Component implements OnInit {
  public modeOfOpListForm: UntypedFormGroup;
  public modeOfOpListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.modeOfOpListForm = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      type: ["", Validators.required],
      statusIndicator: [""],
    });
    this.modeOfOpListFormEdit = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      type: ["", Validators.required],
      statusIndicator: [""],
    });
  }

  addArray() {
    // if (this.modeOfOpListForm.valid) {
      this.br1Service.brTables["modeOfOpList"].push(
        this.modeOfOpListForm.value
      );
      this.modeOfOpListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.modeOfOpListFormEdit.setValue(
      this.br1Service.brTables.modeOfOpList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.modeOfOpList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.modeOfOpList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (index <= 0 || index >= this.br1Service.brTables.modeOfOpList.length) {
      return;
    }
    [
      this.br1Service.brTables.modeOfOpList[index],
      this.br1Service.brTables.modeOfOpList[index - 1],
    ] = [
      this.br1Service.brTables.modeOfOpList[index - 1],
      this.br1Service.brTables.modeOfOpList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.modeOfOpList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.modeOfOpList[index],
      this.br1Service.brTables.modeOfOpList[index + 1],
    ] = [
      this.br1Service.brTables.modeOfOpList[index + 1],
      this.br1Service.brTables.modeOfOpList[index],
    ];
  }
}
