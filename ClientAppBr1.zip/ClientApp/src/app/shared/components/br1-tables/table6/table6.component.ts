import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  UntypedFormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { TableAlgoPropEditorComponent } from "../../table-algo-prop-editor/table-algo-prop-editor.component";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table6",
  templateUrl: "./table6.component.html",
  styleUrls: ["./table6.component.scss"],
})
export class Table6Component implements OnInit {
  public vendorAffirmedAlgoListForm: UntypedFormGroup;
  public vendorAffirmedAlgoListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  editingSelectableAlgorithmsIndex;

  otherImplName;
  otherImplNameEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.vendorAffirmedAlgoListForm = this.fb.group({
      name: ["", Validators.required],
      algoPropList: [[]],
      implName: ["", Validators.required],
      reference: ["", Validators.required],
    });
    this.vendorAffirmedAlgoListFormEdit = this.fb.group({
      name: ["", Validators.required],
      algoPropList: [[]],
      implName: ["", Validators.required],
      reference: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.vendorAffirmedAlgoListForm.valid) {
      let { implName, ...rest } = this.vendorAffirmedAlgoListForm.value;
      this.br1Service.brTables["vendorAffirmedAlgoList"].push({
        implName: implName !== "Other" ? implName : this.otherImplName,
        ...rest,
      });
      this.br1Service.selectableAlgorithms.push({
        algoDisplayName: this.vendorAffirmedAlgoListForm.value.name,
        algoPropList: JSON.parse(
          JSON.stringify(this.vendorAffirmedAlgoListForm.value.algoPropList)
        ),
        implName: this.vendorAffirmedAlgoListForm.value.implName,
        from: "vendorAffirmedAlgoList",
      });
      this.vendorAffirmedAlgoListForm.reset();
      this.otherImplName = null;
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { implName, ...rest } =
      this.br1Service.brTables.vendorAffirmedAlgoList[index];
    const isInOptions = this.br1Service.cavpCertSet.cavpCertList.findIndex(
      (c) => c.implName === implName
    );
    if (isInOptions > -1) {
      this.vendorAffirmedAlgoListFormEdit.setValue(
        this.br1Service.brTables.vendorAffirmedAlgoList[index]
      );
    } else {
      this.vendorAffirmedAlgoListFormEdit.setValue({
        implName: "Other",
        ...rest,
      });

      this.otherImplNameEdit = implName;
    }

    this.editingSelectableAlgorithmsIndex =
      this.br1Service.selectableAlgorithms.findIndex(
        (a) =>
          a.algoDisplayName ===
            this.br1Service.brTables.vendorAffirmedAlgoList[index].name &&
          a.from === "vendorAffirmedAlgoList"
      );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.vendorAffirmedAlgoList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      let { implName, ...rest } = form.value;
      this.br1Service.brTables.vendorAffirmedAlgoList[index] = {
        ...rest,
        implName: implName !== "Other" ? implName : this.otherImplNameEdit,
      };
      // this.br1Service.brTables.vendorAffirmedAlgoList[index] = form.value;
      const i = this.br1Service.selectableAlgorithms.findIndex(
        (a) =>
          a.algoDisplayName === form.value.name &&
          a.from === "vendorAffirmedAlgoList"
      );
      if (this.editingSelectableAlgorithmsIndex) {
        this.br1Service.selectableAlgorithms[
          this.editingSelectableAlgorithmsIndex
        ] = {
          algoDisplayName: form.value.name,
          algoPropList: JSON.parse(JSON.stringify(form.value.algoPropList)),
          implName: implName !== "Other" ? implName : this.otherImplNameEdit,
          from: "vendorAffirmedAlgoList",
        };
        this.editingSelectableAlgorithmsIndex = null;
      }
      this.editingRow = null;
      this.otherImplNameEdit = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editProp(row) {
    let prop;
    if (row === "new") {
      prop = this.vendorAffirmedAlgoListForm.value.algoPropList;
    } else {
      prop = this.vendorAffirmedAlgoListFormEdit.value.algoPropList;
    }
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      propList: prop,
      title: "Algorithm Properties",
    };
    const dialogRef = this.dialog.open(
      TableAlgoPropEditorComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      if (row === "new") {
        this.vendorAffirmedAlgoListForm
          .get("algoPropList")
          .setValue(data.propList as UntypedFormArray);
      } else {
        this.vendorAffirmedAlgoListFormEdit
          .get("algoPropList")
          .setValue(data.propList as UntypedFormArray);
      }
    });
  }

  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.vendorAffirmedAlgoList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.vendorAffirmedAlgoList[index],
      this.br1Service.brTables.vendorAffirmedAlgoList[index - 1],
    ] = [
      this.br1Service.brTables.vendorAffirmedAlgoList[index - 1],
      this.br1Service.brTables.vendorAffirmedAlgoList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.vendorAffirmedAlgoList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.vendorAffirmedAlgoList[index],
      this.br1Service.brTables.vendorAffirmedAlgoList[index + 1],
    ] = [
      this.br1Service.brTables.vendorAffirmedAlgoList[index + 1],
      this.br1Service.brTables.vendorAffirmedAlgoList[index],
    ];
  }
}
