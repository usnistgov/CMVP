import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table27",
  templateUrl: "./table27.component.html",
  styleUrls: ["./table27.component.scss"],
})
export class Table27Component implements OnInit {
  public errorStateListForm: UntypedFormGroup;
  public errorStateListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  conditions = [{ name: "" }];
  conditionsEdit = [];
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.errorStateListForm = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      // conditions: [[], Validators.required],
      recoveryMethod: ["", Validators.required],
      indicator: ["", Validators.required],
    });
    this.errorStateListFormEdit = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      // conditions: [[], Validators.required],
      recoveryMethod: ["", Validators.required],
      indicator: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.errorStateListForm.valid && this.conditions.length > 0) {
      this.br1Service.brTables["errorStateList"].push({
        ...this.errorStateListForm.value,
        conditions: this.conditions.map((c) => c.name),
      });
      this.errorStateListForm.reset();
      this.conditions = [];
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { conditions, ...value } =
      this.br1Service.brTables.errorStateList[index];
    this.errorStateListFormEdit.setValue({ ...value });
    this.conditionsEdit = conditions.map((c) => {
      return {
        name: c,
      };
    });
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.errorStateList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.errorStateList[index] = {
        ...form.value,
        conditions: this.conditionsEdit.map((c) => c.name),
      };
      this.editingRow = null;
      form.reset();
      this.conditionsEdit = [];
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  addCondition() {
    this.conditions.push({ name: "" });
  }
  addConditionEdit() {
    this.conditionsEdit.push({ name: "" });
  }
  up(index) {
    if (index <= 0 || index >= this.br1Service.brTables.errorStateList.length) {
      return;
    }
    [
      this.br1Service.brTables.errorStateList[index],
      this.br1Service.brTables.errorStateList[index - 1],
    ] = [
      this.br1Service.brTables.errorStateList[index - 1],
      this.br1Service.brTables.errorStateList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.errorStateList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.errorStateList[index],
      this.br1Service.brTables.errorStateList[index + 1],
    ] = [
      this.br1Service.brTables.errorStateList[index + 1],
      this.br1Service.brTables.errorStateList[index],
    ];
  }
}
