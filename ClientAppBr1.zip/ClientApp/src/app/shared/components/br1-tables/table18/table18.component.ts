import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table18",
  templateUrl: "./table18.component.html",
  styleUrls: ["./table18.component.scss"],
})
export class Table18Component implements OnInit {
  public phSecMechanismListForm: UntypedFormGroup;
  public phSecMechanismListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.phSecMechanismListForm = this.fb.group({
      mechanism: ["", Validators.required],
      inspectFreq: ["", Validators.required],
      inspectGuidance: ["", Validators.required],
    });
    this.phSecMechanismListFormEdit = this.fb.group({
      mechanism: ["", Validators.required],
      inspectFreq: ["", Validators.required],
      inspectGuidance: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.phSecMechanismListForm.valid) {
      this.br1Service.brTables["phSecMechanismList"].push(
        this.phSecMechanismListForm.value
      );
      this.phSecMechanismListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.phSecMechanismListFormEdit.setValue(
      this.br1Service.brTables.phSecMechanismList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.phSecMechanismList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.phSecMechanismList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.phSecMechanismList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.phSecMechanismList[index],
      this.br1Service.brTables.phSecMechanismList[index - 1],
    ] = [
      this.br1Service.brTables.phSecMechanismList[index - 1],
      this.br1Service.brTables.phSecMechanismList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.phSecMechanismList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.phSecMechanismList[index],
      this.br1Service.brTables.phSecMechanismList[index + 1],
    ] = [
      this.br1Service.brTables.phSecMechanismList[index + 1],
      this.br1Service.brTables.phSecMechanismList[index],
    ];
  }
}
