import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table23",
  templateUrl: "./table23.component.html",
  styleUrls: ["./table23.component.scss"],
})
export class Table23Component implements OnInit {
  public sspZeroizationListForm: UntypedFormGroup;
  public sspZeroizationListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.sspZeroizationListForm = this.fb.group({
      method: ["", Validators.required],
      description: ["", Validators.required],
      rationale: ["", Validators.required],
      operatorInitiation: ["", Validators.required],
    });
    this.sspZeroizationListFormEdit = this.fb.group({
      method: ["", Validators.required],
      description: ["", Validators.required],
      rationale: ["", Validators.required],
      operatorInitiation: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.sspZeroizationListForm.valid) {
      this.br1Service.brTables["sspZeroizationList"].push(
        this.sspZeroizationListForm.value
      );
      this.sspZeroizationListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.sspZeroizationListFormEdit.setValue(
      this.br1Service.brTables.sspZeroizationList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.sspZeroizationList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.sspZeroizationList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.sspZeroizationList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.sspZeroizationList[index],
      this.br1Service.brTables.sspZeroizationList[index - 1],
    ] = [
      this.br1Service.brTables.sspZeroizationList[index - 1],
      this.br1Service.brTables.sspZeroizationList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.sspZeroizationList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.sspZeroizationList[index],
      this.br1Service.brTables.sspZeroizationList[index + 1],
    ] = [
      this.br1Service.brTables.sspZeroizationList[index + 1],
      this.br1Service.brTables.sspZeroizationList[index],
    ];
  }
}
