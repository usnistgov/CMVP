import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table21",
  templateUrl: "./table21.component.html",
  styleUrls: ["./table21.component.scss"],
})
export class Table21Component implements OnInit {
  public storageAreaListForm: UntypedFormGroup;
  public storageAreaListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.storageAreaListForm = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      persistenceType: ["", Validators.required],
    });
    this.storageAreaListFormEdit = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      persistenceType: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.storageAreaListForm.valid) {
      this.br1Service.brTables["storageAreaList"].push(
        this.storageAreaListForm.value
      );
      this.storageAreaListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.storageAreaListFormEdit.setValue(
      this.br1Service.brTables.storageAreaList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.storageAreaList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.storageAreaList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.storageAreaList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.storageAreaList[index],
      this.br1Service.brTables.storageAreaList[index - 1],
    ] = [
      this.br1Service.brTables.storageAreaList[index - 1],
      this.br1Service.brTables.storageAreaList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.storageAreaList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.storageAreaList[index],
      this.br1Service.brTables.storageAreaList[index + 1],
    ] = [
      this.br1Service.brTables.storageAreaList[index + 1],
      this.br1Service.brTables.storageAreaList[index],
    ];
  }
}
