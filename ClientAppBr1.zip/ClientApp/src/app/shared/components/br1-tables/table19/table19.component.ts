import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog } from "@angular/material/dialog";

@Component({
  selector: "app-table19",
  templateUrl: "./table19.component.html",
  styleUrls: ["./table19.component.scss"],
})
export class Table19Component implements OnInit {
  editingTable;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder
  ) {}

  ngOnInit() {}
}
