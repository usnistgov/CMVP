import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table8",
  templateUrl: "./table8.component.html",
  styleUrls: ["./table8.component.scss"],
})
export class Table8Component implements OnInit {
  public nonApprovedAllowedAlgoNSCListForm: UntypedFormGroup;
  public nonApprovedAllowedAlgoNSCListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  editingSelectableAlgorithmsIndex;

  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.nonApprovedAllowedAlgoNSCListForm = this.fb.group({
      name: ["", Validators.required],
      caveat: ["", Validators.required],
      useFunction: ["", Validators.required],
    });
    this.nonApprovedAllowedAlgoNSCListFormEdit = this.fb.group({
      name: ["", Validators.required],
      caveat: ["", Validators.required],
      useFunction: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.nonApprovedAllowedAlgoNSCListForm.valid) {
      this.br1Service.brTables["nonApprovedAllowedAlgoNSCList"].push(
        this.nonApprovedAllowedAlgoNSCListForm.value
      );
      this.br1Service.selectableAlgorithms.push({
        algoDisplayName: this.nonApprovedAllowedAlgoNSCListForm.value.name,
        from: "nonApprovedAllowedAlgoNSCList",
      });
      this.nonApprovedAllowedAlgoNSCListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.nonApprovedAllowedAlgoNSCListFormEdit.setValue(
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index]
    );

    this.editingSelectableAlgorithmsIndex =
      this.br1Service.selectableAlgorithms.findIndex(
        (a) =>
          a.algoDisplayName ===
          this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index].name
      );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.nonApprovedAllowedAlgoNSCList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index] =
        form.value;

      if (this.editingSelectableAlgorithmsIndex) {
        this.br1Service.selectableAlgorithms[
          this.editingSelectableAlgorithmsIndex
        ] = {
          algoDisplayName: form.value.name,

          from: "nonApprovedAllowedAlgoNSCList",
        };
        this.editingSelectableAlgorithmsIndex = null;
      }
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.nonApprovedAllowedAlgoNSCList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index],
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index - 1],
    ] = [
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index - 1],
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.nonApprovedAllowedAlgoNSCList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index],
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index + 1],
    ] = [
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index + 1],
      this.br1Service.brTables.nonApprovedAllowedAlgoNSCList[index],
    ];
  }
}
