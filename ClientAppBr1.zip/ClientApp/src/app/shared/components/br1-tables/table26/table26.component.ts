import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table26",
  templateUrl: "./table26.component.html",
  styleUrls: ["./table26.component.scss"],
})
export class Table26Component implements OnInit {
  public condSelfTestListForm: UntypedFormGroup;
  public condSelfTestListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  types = [
    "CAST",
    "PCT",
    "SW/FW Load",
    "Manual Entry",
    "Bypass",
    "Critical Function",
  ];

  otherAlgorithmOrTest;
  otherAlgorithmOrTestEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.condSelfTestListForm = this.fb.group({
      algorithmOrTest: ["", Validators.required],
      testProps: ["", Validators.required],
      testMethod: ["", Validators.required],
      type: ["", Validators.required],
      indicator: ["", Validators.required],
      details: ["", Validators.required],
      conditions: ["", Validators.required],
      coverage: [[]],
      coverageNotes: [""],
      period: ["", Validators.required],
      periodicMethod: ["", Validators.required],
    });
    this.condSelfTestListFormEdit = this.fb.group({
      algorithmOrTest: ["", Validators.required],
      testProps: ["", Validators.required],
      testMethod: ["", Validators.required],
      type: ["", Validators.required],
      indicator: ["", Validators.required],
      details: ["", Validators.required],
      conditions: ["", Validators.required],
      coverage: [[]],
      coverageNotes: [""],
      period: ["", Validators.required],
      periodicMethod: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.condSelfTestListForm.valid) {
      let { algorithmOrTest, coverage, ...rest } =
        this.condSelfTestListForm.value;
      let coverageList = [];
      if (coverage) {
        coverage.forEach((coverageItem) => {
          const c = this.br1Service.selectableAlgorithms.find((s) =>
            s.certName
              ? s.algoDisplayName + " (" + s.certName + ")" === coverageItem
              : s.algoDisplayName === coverageItem
          );
          if (c) {
            coverageList.push({
              algoDisplayName: c.algoDisplayName,
              canonicalAlgorithmId: c.canonicalAlgorithmId,
              implName: c.implName,
              validationId: c.validationId,
              algoPropList: [],
              certName: c.certName,
            });
          }
        });
      }

      this.br1Service.brTables["condSelfTestList"].push({
        ...rest,
        algorithmOrTest:
          algorithmOrTest !== "Other"
            ? algorithmOrTest
            : this.otherAlgorithmOrTest,
        coverage: coverageList,
      });
      this.condSelfTestListForm.reset();
      this.otherAlgorithmOrTest = null;
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { algorithmOrTest, coverage, ...rest } =
      this.br1Service.brTables.condSelfTestList[index];
    let algoSearch = this.br1Service.selectableAlgorithms.find((s) =>
      s.certName
        ? s.algoDisplayName + " (" + s.certName + ")" === algorithmOrTest
        : s.algoDisplayName === algorithmOrTest
    );
    let coverageList = this.br1Service.brTables.condSelfTestList[
      index
    ].coverage.map((s) => s.algoDisplayName + " (" + s.certName + ")");
    if (algoSearch) {
      this.condSelfTestListFormEdit.setValue({
        ...rest,
        algorithmOrTest: algorithmOrTest,
        coverage: coverageList,
      });
    } else {
      this.condSelfTestListFormEdit.setValue({
        ...rest,
        algorithmOrTest: "Other",
        coverage: coverageList,
      });
      this.otherAlgorithmOrTestEdit = algorithmOrTest;
    }
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.condSelfTestList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      let { algorithmOrTest, coverage, ...rest } = form.value;
      let coverageList = [];
      coverage.forEach((coverageItem) => {
        const c = this.br1Service.selectableAlgorithms.find((s) =>
          s.certName
            ? s.algoDisplayName + " (" + s.certName + ")" === coverageItem
            : s.algoDisplayName === coverageItem
        );
        if (c) {
          coverageList.push({
            algoDisplayName: c.algoDisplayName,
            canonicalAlgorithmId: c.canonicalAlgorithmId,
            implName: c.implName,
            validationId: c.validationId,
            algoPropList: [],
            certName: c.certName,
          });
        }
      });
      this.br1Service.brTables.condSelfTestList[index] = {
        ...rest,
        algorithmOrTest:
          algorithmOrTest !== "Other"
            ? algorithmOrTest
            : this.otherAlgorithmOrTestEdit,
        coverage: coverageList,
      };
      this.editingRow = null;
      this.otherAlgorithmOrTestEdit = null;

      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.condSelfTestList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.condSelfTestList[index],
      this.br1Service.brTables.condSelfTestList[index - 1],
    ] = [
      this.br1Service.brTables.condSelfTestList[index - 1],
      this.br1Service.brTables.condSelfTestList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.condSelfTestList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.condSelfTestList[index],
      this.br1Service.brTables.condSelfTestList[index + 1],
    ] = [
      this.br1Service.brTables.condSelfTestList[index + 1],
      this.br1Service.brTables.condSelfTestList[index],
    ];
  }
}
