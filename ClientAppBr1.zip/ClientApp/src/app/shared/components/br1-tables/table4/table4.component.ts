import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table4",
  templateUrl: "./table4.component.html",
  styleUrls: ["./table4.component.scss"],
})
export class Table4Component implements OnInit {
  @Input() isTransaction;
  public opEnvSwFwHyVAListForm: UntypedFormGroup;
  public opEnvSwFwHyVAListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.opEnvSwFwHyVAListForm = this.fb.group({
      operatingSystem: ["", Validators.required],
      hardwarePlatform: ["", Validators.required],
    });
    this.opEnvSwFwHyVAListFormEdit = this.fb.group({
      operatingSystem: ["", Validators.required],
      hardwarePlatform: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.opEnvSwFwHyVAListForm.valid) {
      this.br1Service.brTables["opEnvSwFwHyVAList"].push(
        this.opEnvSwFwHyVAListForm.value
      );
      this.opEnvSwFwHyVAListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.opEnvSwFwHyVAListFormEdit.setValue(
      this.br1Service.brTables.opEnvSwFwHyVAList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.opEnvSwFwHyVAList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.opEnvSwFwHyVAList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.opEnvSwFwHyVAList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.opEnvSwFwHyVAList[index],
      this.br1Service.brTables.opEnvSwFwHyVAList[index - 1],
    ] = [
      this.br1Service.brTables.opEnvSwFwHyVAList[index - 1],
      this.br1Service.brTables.opEnvSwFwHyVAList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.opEnvSwFwHyVAList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.opEnvSwFwHyVAList[index],
      this.br1Service.brTables.opEnvSwFwHyVAList[index + 1],
    ] = [
      this.br1Service.brTables.opEnvSwFwHyVAList[index + 1],
      this.br1Service.brTables.opEnvSwFwHyVAList[index],
    ];
  }
}
