import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table22",
  templateUrl: "./table22.component.html",
  styleUrls: ["./table22.component.scss"],
})
export class Table22Component implements OnInit {
  public sspInputOutputListForm: UntypedFormGroup;
  public sspInputOutputListFormEdit: UntypedFormGroup;
  editingTable;
  editingRow;

  from;
  fromEdit;
  fromOtherValue;
  fromOtherValueEdit;

  to;
  toEdit;
  toOtherValue;
  toOtherValueEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.sspInputOutputListForm = this.fb.group({
      name: ["", Validators.required],
      // from: ["", Validators.required],
      // to: ["", Validators.required],
      formatType: ["", Validators.required],
      distributionType: ["", Validators.required],
      entryType: ["", Validators.required],
      relatedSFI: [[]],
    });
    this.sspInputOutputListFormEdit = this.fb.group({
      name: ["", Validators.required],
      // from: ["", Validators.required],
      // to: ["", Validators.required],
      formatType: ["", Validators.required],
      distributionType: ["", Validators.required],
      entryType: ["", Validators.required],
      relatedSFI: [[]],
    });
  }

  addArray() {
    // if (this.sspInputOutputListForm.valid && this.from && this.to) {
      this.br1Service.brTables["sspInputOutputList"].push({
        ...this.sspInputOutputListForm.value,
        from: this.from === "Other" ? this.fromOtherValue : this.from,
        to: this.to === "Other" ? this.toOtherValue : this.to,
      });
      this.from = null;
      this.to = null;
      this.fromOtherValue = null;
      this.toOtherValue = null;
      this.sspInputOutputListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { from, to, ...value } =
      this.br1Service.brTables.sspInputOutputList[index];
    this.sspInputOutputListFormEdit.setValue(value);
    const fromExist = this.br1Service.brTables["storageAreaList"].find(
      (s) => s.name === from
    );
    if (fromExist) {
      this.fromEdit = from;
    } else {
      this.fromEdit = "Other";
      this.fromOtherValueEdit = from;
    }

    const toExist = this.br1Service.brTables["storageAreaList"].find(
      (s) => s.name === to
    );
    if (toExist) {
      this.toEdit = to;
    } else {
      this.toEdit = "Other";
      this.toOtherValueEdit = to;
    }
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.sspInputOutputList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.sspInputOutputList[index] = {
        ...form.value,
        from:
          this.fromEdit === "Other" ? this.fromOtherValueEdit : this.fromEdit,
        to: this.toEdit === "Other" ? this.toOtherValueEdit : this.toEdit,
      };
      this.editingRow = null;
      this.fromEdit = null;
      this.toEdit = null;
      this.fromOtherValueEdit = null;
      this.toOtherValueEdit = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.sspInputOutputList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.sspInputOutputList[index],
      this.br1Service.brTables.sspInputOutputList[index - 1],
    ] = [
      this.br1Service.brTables.sspInputOutputList[index - 1],
      this.br1Service.brTables.sspInputOutputList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.sspInputOutputList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.sspInputOutputList[index],
      this.br1Service.brTables.sspInputOutputList[index + 1],
    ] = [
      this.br1Service.brTables.sspInputOutputList[index + 1],
      this.br1Service.brTables.sspInputOutputList[index],
    ];
  }
}
