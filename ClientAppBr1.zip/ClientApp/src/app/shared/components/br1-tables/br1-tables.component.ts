import { Component, OnInit, Input } from "@angular/core";
import { SectionService } from "../../services/section.service";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { ImageDialogComponent } from "../image-dialog/image-dialog.component";
import { FormService } from "../../services/form.service";
import { ExportSecurityDialogComponent } from "../export-security-dialog/export-security-dialog.component";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { Br1Service } from "../../services/br1.service";
import { MatDialog } from "@angular/material/dialog";

@Component({
  selector: "app-br1-tables",
  templateUrl: "./br1-tables.component.html",
  styleUrls: ["./br1-tables.component.scss"],
})
export class Br1TablesComponent implements OnInit {
  showedSections = ["2", "3", "4", "7", "9", "10"];
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder
  ) {}

  async ngOnInit() {}
}
