import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  UntypedFormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { TableStorageEditorComponent } from "../../table-storage-editor/table-storage-editor.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table24",
  templateUrl: "./table24.component.html",
  styleUrls: ["./table24.component.scss"],
})
export class Table24Component implements OnInit {
  public sspListForm: UntypedFormGroup;
  public sspListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;

  selectedSSP;
  relationship;
  relatedSSPs = [];
  relatedSSPsEdit = [];
  relationships = [
    "Derived From",
    "Paired With",
    "Used With",
    "Encrypts",
    "Decrypts",
    "Other",
  ];
  otherGeneratedBy;
  otherGeneratedByEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  initForm() {
    this.sspListForm = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      size: ["", Validators.required],
      strength: ["", Validators.required],
      type: ["", Validators.required],
      generatedByList: [[]],
      establishedByList: [[]],
      usedByList: [[]],
      inputOutputList: [[]],
      storageItemList: [[]],
      storageDuration: [""],
      zeroizationList: [[], Validators.required],
      category: ["", Validators.required],
      // relatedSspList: ["", Validators.required],
    });
  }

  ngOnInit() {
    this.initForm();
    this.sspListFormEdit = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      size: ["", Validators.required],
      strength: ["", Validators.required],
      type: ["", Validators.required],
      generatedByList: [[]],
      establishedByList: [[]],
      usedByList: [[]],
      inputOutputList: [[]],
      storageItemList: [[]],
      storageDuration: [""],
      zeroizationList: [[], Validators.required],
      category: ["", Validators.required],
      // relatedSspList: ["", Validators.required],
    });
  }

  editStorage(row) {
    let storage;
    if (row === "new") {
      storage = this.sspListForm.value.storageItemList;
    } else {
      storage = this.sspListFormEdit.value.storageItemList;
    }
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      storageList: storage,
    };
    const dialogRef = this.dialog.open(
      TableStorageEditorComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      if (row === "new") {
        this.sspListForm
          .get("storageItemList")
          .setValue(data.storageList as UntypedFormArray);
      } else {
        this.sspListFormEdit
          .get("storageItemList")
          .setValue(data.storageList as UntypedFormArray);
      }
    });
  }

  addArray() {
    // if (this.sspListForm.valid) {
      let obj = this.sspListForm.value;
      if (this.relatedSSPs.length > 0) {
        obj.relatedSspList = this.relatedSSPs.map((r) => {
          return {
            sspName: r.ssp,
            relationship: r.relationship
              ? r.relationship === "Other"
                ? r.other
                : r.relationship
              : null,
          };
        });

        obj.relatedSspList = obj.relatedSspList.filter(
          (r) => r.relationship && r.sspName
        );
      } else {
        obj.relatedSspList = [];
      }
      const generatedByOtherIndex = obj.generatedByList.findIndex(
        (g) => g === "Other"
      );
      if (generatedByOtherIndex > -1) {
        obj.generatedByList[generatedByOtherIndex] = this.otherGeneratedBy;
      }
      this.br1Service.brTables["sspList"].push(obj);
      this.initForm();

      this.relatedSSPs = [];
      this.otherGeneratedBy = null;
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let self = this;
    let { relatedSspList, generatedByList, ...value } =
      this.br1Service.brTables.sspList[index];
    let otherGeneratedByIndex = generatedByList.findIndex((g) => {
      let foundInSecFunImplList = this.br1Service.brTables[
        "secFunImplList"
      ].some((s) => g === s.name);

      let foundInSelectableAlgorithms =
        this.br1Service.selectableAlgorithms.some((algo) => {
          if (algo.certName) {
            return g === algo.algoDisplayName + " (" + algo.certName + ")";
          } else {
            return g === algo.algoDisplayName;
          }
        });

      return !foundInSecFunImplList && !foundInSelectableAlgorithms;
    });
    if (otherGeneratedByIndex > -1) {
      this.otherGeneratedByEdit = generatedByList[otherGeneratedByIndex];
      generatedByList[otherGeneratedByIndex] = "Other";
    }

    this.sspListFormEdit.setValue({ ...value, generatedByList });
    this.relatedSSPsEdit = relatedSspList
      ? relatedSspList.map((r) => {
          return {
            ssp: r.sspName,
            relationship: r.relationship
              ? this.relationships.includes(r.relationship)
                ? r.relationship
                : "Other"
              : null,
            other: this.relationships.includes(r.relationship)
              ? null
              : r.relationship,
          };
        })
      : [];
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.sspList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      let obj = form.value;
      if (this.relatedSSPsEdit.length > 0) {
        obj.relatedSspList = this.relatedSSPsEdit.map((r) => {
          return {
            sspName: r.ssp,
            relationship: r.relationship
              ? r.relationship === "Other"
                ? r.other
                : r.relationship
              : null,
          };
        });
        obj.relatedSspList = obj.relatedSspList.filter(
          (r) => r.relationship && r.sspName
        );
      } else {
        obj.relatedSspList = [];
      }

      const generatedByOtherIndex = obj.generatedByList.findIndex(
        (g) => g === "Other"
      );
      if (generatedByOtherIndex > -1) {
        obj.generatedByList[generatedByOtherIndex] = this.otherGeneratedByEdit;
      }

      this.br1Service.brTables.sspList[index] = obj;
      this.editingRow = null;
      form.reset();
      this.relatedSSPsEdit = [];
      this.otherGeneratedByEdit = null;
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  public isSameSsp(sspA?, sspB?) {
    return !!sspA && sspA === sspB;
  }
  onRelationshipChange(event) {}
  addRelatedSSP() {
    this.relatedSSPs.push({
      sspName: null,
      relationship: null,
      other: null,
    });
  }

  addRelatedSSPEdit() {
    this.relatedSSPsEdit.push({
      sspName: null,
      relationship: null,
      other: null,
    });
  }
  deleteRelatedSSPItemEdit(index) {
    this.relatedSSPsEdit.splice(index, 1);
  }
  deleteRelatedSSPItem(index) {
    this.relatedSSPs.splice(index, 1);
  }
  up(index) {
    if (index <= 0 || index >= this.br1Service.brTables.sspList.length) {
      return;
    }
    [
      this.br1Service.brTables.sspList[index],
      this.br1Service.brTables.sspList[index - 1],
    ] = [
      this.br1Service.brTables.sspList[index - 1],
      this.br1Service.brTables.sspList[index],
    ];
  }
  down(index) {
    if (index < 0 || index >= this.br1Service.brTables.sspList.length - 1) {
      return;
    }
    [
      this.br1Service.brTables.sspList[index],
      this.br1Service.brTables.sspList[index + 1],
    ] = [
      this.br1Service.brTables.sspList[index + 1],
      this.br1Service.brTables.sspList[index],
    ];
  }
}
