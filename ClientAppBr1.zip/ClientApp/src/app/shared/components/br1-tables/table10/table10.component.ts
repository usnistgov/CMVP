import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  UntypedFormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { TableAlgoPropEditorComponent } from "../../table-algo-prop-editor/table-algo-prop-editor.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table10",
  templateUrl: "./table10.component.html",
  styleUrls: ["./table10.component.scss"],
})
export class Table10Component implements OnInit {
  public secFunImplListForm: UntypedFormGroup;
  public secFunImplListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;
  securityFunctions = [];
  securityFunction;
  securityFunctionEdit;

  algorithmList = [
    {
      algoDisplayName: null,
      canonicalAlgorithmId: null,
      implName: null,
      validationId: null,
      algoPropList: [],
      certName: null,
    },
  ];
  algorithmListEdit = [
    {
      algoDisplayName: null,
      canonicalAlgorithmId: null,
      implName: null,
      validationId: null,
      algoPropList: [],
      certName: null,
    },
  ];
  selectedAlgorithmIds = [];
  selectedAlgorithmIdsEdit = [];
  showTable = true;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {
    this.getSecurityFunctions();
  }

  ngOnInit() {
    this.secFunImplListForm = this.fb.group({
      name: ["", Validators.required],
      // type: ["", Validators.required],
      description: [""],
      sfPropList: [[]],
      // algorithmList: [[], Validators.required],
    });
    this.secFunImplListFormEdit = this.fb.group({
      name: ["", Validators.required],
      // type: ["", Validators.required],
      description: [""],
      sfPropList: [[]],
      // algorithmList: [[], Validators.required],
    });
  }
  toggleTable() {
    this.showTable = !this.showTable;
  }

  onAlgorithmChanged(id, index) {
    // let algo = this.br1Service.cavpCertSet.cavpImplAlgoList.find(
    //   (s) =>
    //     s.algoDisplayName + " (" + s.certName + ")" ===
    //     this.selectedAlgorithmIds[index]
    // );
    let algo = this.br1Service.selectableAlgorithms.find(
      (s) => {
        if (
          s.from === "vendorAffirmedAlgoList" ||
          s.from === "nonApprovedAllowedAlgoNSCList"
        ) {
          return (
            s.algoDisplayName ===
            this.selectedAlgorithmIds[index].algoDisplayName
          );
        } else {
          return (
            s.canonicalAlgorithmId ===
              this.selectedAlgorithmIds[index].canonicalAlgorithmId &&
            s.validationId === this.selectedAlgorithmIds[index].validationId
          );
        }
      }
      // this.selectedAlgorithmIds[index].canonicalAlgorithmId
      //   ? s.canonicalAlgorithmId ===
      //       this.selectedAlgorithmIds[index].canonicalAlgorithmId &&
      //     s.validationId === this.selectedAlgorithmIds[index].validationId
      //   : s.algoDisplayName === s.algoDisplayName &&
      //     s.from === "vendorAffirmedAlgoList"
    );

    if (algo) {
      this.algorithmList[index] = {
        algoDisplayName: algo.algoDisplayName,
        canonicalAlgorithmId: algo.canonicalAlgorithmId,
        implName: algo.implName,
        validationId: algo.validationId,
        algoPropList: this.algorithmList[index].algoPropList,
        certName: algo.certName,
      };
    }
    // let vendorAffirmedAlgo =
    //   this.br1Service.brTables.vendorAffirmedAlgoList.find(
    //     (s) => s.name === this.selectedAlgorithmIds[index]
    //   );
    // if (vendorAffirmedAlgo) {
    //   this.algorithmList[index] = {
    //     algoDisplayName: vendorAffirmedAlgo.name,
    //     implName: vendorAffirmedAlgo.implName,
    //     algoPropList: vendorAffirmedAlgo.algoPropList,
    //     canonicalAlgorithmId: null,
    //     validationId: null,
    //     certName: null,
    //   };
    // }
  }
  onAlgorithmChangedEdit(id, index) {
    // let algo = this.br1Service.cavpCertSet.cavpImplAlgoList.find(
    //   (s) =>
    //     s.algoDisplayName + " (" + s.certName + ")" ===
    //     this.selectedAlgorithmIdsEdit[index]
    // );
    let algo = this.br1Service.selectableAlgorithms.find(
      (s) => {
        if (
          s.from === "vendorAffirmedAlgoList" ||
          s.from === "nonApprovedAllowedAlgoNSCList"
        ) {
          return (
            s.algoDisplayName ===
            this.selectedAlgorithmIdsEdit[index].algoDisplayName
          );
        } else {
          return (
            s.canonicalAlgorithmId ===
              this.selectedAlgorithmIdsEdit[index].canonicalAlgorithmId &&
            s.validationId === this.selectedAlgorithmIdsEdit[index].validationId
          );
        }
      }
      // this.selectedAlgorithmIdsEdit[index].canonicalAlgorithmId
      //   ? s.canonicalAlgorithmId ===
      //   this.selectedAlgorithmIdsEdit[index].canonicalAlgorithmId &&
      //   s.validationId === this.selectedAlgorithmIdsEdit[index].validationId
      //   : s.algoDisplayName === s.algoDisplayName &&
      //   s.from === "vendorAffirmedAlgoList"
    );
    if (algo) {
      this.algorithmListEdit[index] = {
        algoDisplayName: algo.algoDisplayName,
        canonicalAlgorithmId: algo.canonicalAlgorithmId,
        implName: algo.implName,
        validationId: algo.validationId,
        algoPropList: this.algorithmListEdit[index].algoPropList,
        certName: algo.certName,
      };
    }
    // let vendorAffirmedAlgo =
    //   this.br1Service.brTables.vendorAffirmedAlgoList.find(
    //     (s) => s.name === this.selectedAlgorithmIdsEdit[index]
    //   );
    // if (vendorAffirmedAlgo) {
    //   this.algorithmListEdit[index] = {
    //     algoDisplayName: vendorAffirmedAlgo.name,
    //     implName: vendorAffirmedAlgo.implName,
    //     algoPropList: vendorAffirmedAlgo.algoPropList,
    //     canonicalAlgorithmId: null,
    //     validationId: null,
    //     certName: null,
    //   };
    // }
  }

  addArray() {

    // if (this.secFunImplListForm.valid && this.securityFunction) {
      this.algorithmList = this.algorithmList.filter(
        (algo) => algo.algoDisplayName
      );

      this.br1Service.brTables["secFunImplList"].push({
        ...this.secFunImplListForm.value,
        sfTypeList: this.securityFunction,
        algorithmList: this.algorithmList,
      });
      this.securityFunction = null;
      this.algorithmList = [
        {
          algoDisplayName: null,
          canonicalAlgorithmId: null,
          implName: null,
          validationId: null,
          algoPropList: [],
          certName: null,
        },
      ];
      this.selectedAlgorithmIds = [];

      this.secFunImplListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { sfTypeList, algorithmList, ...form } =
      this.br1Service.brTables.secFunImplList[index];
    this.securityFunctionEdit = sfTypeList;
    this.algorithmListEdit = algorithmList;
    this.selectedAlgorithmIdsEdit = algorithmList;
    this.secFunImplListFormEdit.setValue(form);
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.secFunImplList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid && this.securityFunctionEdit) {
      this.algorithmListEdit = this.algorithmListEdit.filter(
        (algo) => algo.algoDisplayName
      );
      this.br1Service.brTables.secFunImplList[index] = {
        ...form.value,
        sfTypeList: this.securityFunctionEdit,
        algorithmList: this.algorithmListEdit,
      };

      this.editingRow = null;
      form.reset();
      this.securityFunctionEdit = null;
      this.algorithmListEdit = [
        {
          algoDisplayName: null,
          canonicalAlgorithmId: null,
          implName: null,
          validationId: null,
          algoPropList: [],
          certName: null,
        },
      ];
      this.selectedAlgorithmIdsEdit = [];
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  editCap(row) {
    let prop;
    if (row === "new") {
      prop = this.secFunImplListForm.value.sfPropList;
    } else {
      prop = this.secFunImplListFormEdit.value.sfPropList;
    }
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      propList: prop,
      title: "SF Properties",
    };
    const dialogRef = this.dialog.open(
      TableAlgoPropEditorComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      if (row === "new") {
        this.secFunImplListForm
          .get("sfPropList")
          .setValue(data.propList as UntypedFormArray);
      } else {
        this.secFunImplListFormEdit
          .get("sfPropList")
          .setValue(data.propList as UntypedFormArray);
      }
    });
  }
  editAlgoProp(row, algoRow) {
    let prop;
    if (row === "new") {
      prop = this.algorithmList[algoRow].algoPropList;
    } else {
      prop = this.algorithmListEdit[algoRow].algoPropList;
    }
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      propList: prop,
      title: "Algorithm Properties",
    };
    const dialogRef = this.dialog.open(
      TableAlgoPropEditorComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      if (row === "new") {
        this.algorithmList[algoRow].algoPropList = data.propList;
      } else {
        this.algorithmListEdit[algoRow].algoPropList = data.propList;
      }
    });
  }
  async getSecurityFunctions() {
    let securityFunctions =
      (await this.sectionService.getSecurityFunctionData()) as any;
    this.securityFunctions = securityFunctions ? securityFunctions : [];
  }
  public isSameSecurityFunction(secA?, secB?) {
    return !!secA && secA.sfId === secB?.sfId;
  }

  addAlgorithm() {
    this.algorithmList.push({
      algoDisplayName: null,
      canonicalAlgorithmId: null,
      implName: null,
      validationId: null,
      algoPropList: [],
      certName: null,
    });
  }
  addAlgorithmEdit() {
    this.algorithmListEdit.push({
      algoDisplayName: null,
      canonicalAlgorithmId: null,
      implName: null,
      validationId: null,
      algoPropList: [],
      certName: null,
    });
  }

  deleteAlgorithmRow(i) {
    this.selectedAlgorithmIds.splice(i, 1);
    this.algorithmList.splice(i, 1);
  }
  deleteAlgorithmRowEdit(i) {
    this.selectedAlgorithmIdsEdit.splice(i, 1);
    // this.algorithmListEdit.splice(i, 1);
  }
  public isSameAlgo(algoA?, algoB?) {
    if (algoA?.canonicalAlgorithmId && algoB?.canonicalAlgorithmId) {
      return (
        !!algoA &&
        algoA.canonicalAlgorithmId === algoB?.canonicalAlgorithmId &&
        algoA.validationId === algoB?.validationId
      );
    } else {
      return !!algoA && algoA.algoDisplayName === algoB?.algoDisplayName;
    }
  }
  public isSameType(typeA?, typeB?) {
    return !!typeA && typeA.sfId === typeB.sfId;
  }

  up(index) {
    if (index <= 0 || index >= this.br1Service.brTables.secFunImplList.length) {
      return;
    }
    [
      this.br1Service.brTables.secFunImplList[index],
      this.br1Service.brTables.secFunImplList[index - 1],
    ] = [
      this.br1Service.brTables.secFunImplList[index - 1],
      this.br1Service.brTables.secFunImplList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.secFunImplList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.secFunImplList[index],
      this.br1Service.brTables.secFunImplList[index + 1],
    ] = [
      this.br1Service.brTables.secFunImplList[index + 1],
      this.br1Service.brTables.secFunImplList[index],
    ];
  }
}
