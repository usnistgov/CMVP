import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table16",
  templateUrl: "./table16.component.html",
  styleUrls: ["./table16.component.scss"],
})
export class Table16Component implements OnInit {
  public approvedServiceListForm: UntypedFormGroup;
  public approvedServiceListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;

  roleSspAccessList = [];
  roleSspAccessListEdit = [];
  accessTypes = ["G", "R", "W", "E", "Z", "None"];

  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.approvedServiceListForm = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      indicator: ["", Validators.required],
      inputs: ["", Validators.required],
      outputs: ["", Validators.required],
      secFunImplList: [[], Validators.required],
      // roleSspAccessList: [[], Validators.required],
    });
    this.approvedServiceListFormEdit = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      indicator: ["", Validators.required],
      inputs: ["", Validators.required],
      outputs: ["", Validators.required],
      secFunImplList: [[], Validators.required],
      // roleSspAccessList: [[], Validators.required],
    });
  }
  addRole() {
    this.roleSspAccessList.push({
      roleName: "",
      sspAccessList: [],
    });
  }
  addRoleEdit() {
    this.roleSspAccessListEdit.push({
      roleName: "",
      sspAccessList: [],
    });
  }
  addAccess(i) {
    this.roleSspAccessList[i].sspAccessList.push({
      sspName: "",
      accessType: [],
    });
  }
  addAccessEdit(i) {
    this.roleSspAccessListEdit[i].sspAccessList.push({
      sspName: "",
      accessType: [],
    });
  }

  addArray() {
    // if (
    //   this.approvedServiceListForm.valid &&
    //   this.roleSspAccessList.length > 0
    // ) {
      this.br1Service.brTables["approvedServiceList"].push({
        ...this.approvedServiceListForm.value,
        roleSspAccessList: this.roleSspAccessList,
      });
      this.approvedServiceListForm.reset();
      this.roleSspAccessList = [];
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  addArrayEdit(i) {
    if (
      this.approvedServiceListFormEdit.valid &&
      this.roleSspAccessListEdit.length > 0
    ) {
      this.br1Service.brTables["approvedServiceList"][i] = {
        ...this.approvedServiceListFormEdit.value,
        roleSspAccessList: this.roleSspAccessListEdit,
      };

      this.approvedServiceListFormEdit.reset();
      this.roleSspAccessListEdit = [];
      this.editingRow = null;
    }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { roleSspAccessList, ...value } =
      this.br1Service.brTables.approvedServiceList[index];
    this.approvedServiceListFormEdit.setValue(value);
    this.roleSspAccessListEdit = roleSspAccessList;
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.approvedServiceList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.approvedServiceList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  deleteRoleSspAccessItemEdit(index) {
    this.roleSspAccessListEdit.splice(index, 1);
  }
  deleteRoleSspAccessItem(index) {
    this.roleSspAccessList.splice(index, 1);
  }
  deleteSspAccessItemEdit(roleIndex, index) {
    this.roleSspAccessListEdit[roleIndex].sspAccessList.splice(index, 1);
  }
  deleteSspAccessItem(roleIndex, index) {
    this.roleSspAccessList[roleIndex].sspAccessList.splice(index, 1);
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.approvedServiceList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.approvedServiceList[index],
      this.br1Service.brTables.approvedServiceList[index - 1],
    ] = [
      this.br1Service.brTables.approvedServiceList[index - 1],
      this.br1Service.brTables.approvedServiceList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.approvedServiceList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.approvedServiceList[index],
      this.br1Service.brTables.approvedServiceList[index + 1],
    ] = [
      this.br1Service.brTables.approvedServiceList[index + 1],
      this.br1Service.brTables.approvedServiceList[index],
    ];
  }
}
