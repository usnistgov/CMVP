import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table1",
  templateUrl: "./table1.component.html",
  styleUrls: ["./table1.component.scss"],
})
export class Table1Component implements OnInit {
  public testedHwListForm: UntypedFormGroup;
  public testedHwListFormEdit: UntypedFormGroup;
  editingRow;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.testedHwListForm = this.fb.group({
      modelPartNum: ["", Validators.required],
      hwVersion: ["", Validators.required],
      fwVersion: ["", Validators.required],
      processors: ["", Validators.required],
      features: [""],
    });
    this.testedHwListFormEdit = this.fb.group({
      modelPartNum: ["", Validators.required],
      hwVersion: ["", Validators.required],
      fwVersion: ["", Validators.required],
      processors: ["", Validators.required],
      features: [""],
    });
  }

  addArray() {
    // if (this.testedHwListForm.valid) {
      this.br1Service.brTables["testedHwList"].push(
        this.testedHwListForm.value
      );
      this.testedHwListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  editTableRow(index) {
    this.editingRow = index;
    this.testedHwListFormEdit.setValue(
      this.br1Service.brTables.testedHwList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.testedHwList.splice(index, 1);
      }
    });
  }
  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.testedHwList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (index <= 0 || index >= this.br1Service.brTables.testedHwList.length) {
      return;
    }
    [
      this.br1Service.brTables.testedHwList[index],
      this.br1Service.brTables.testedHwList[index - 1],
    ] = [
      this.br1Service.brTables.testedHwList[index - 1],
      this.br1Service.brTables.testedHwList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.testedHwList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.testedHwList[index],
      this.br1Service.brTables.testedHwList[index + 1],
    ] = [
      this.br1Service.brTables.testedHwList[index + 1],
      this.br1Service.brTables.testedHwList[index],
    ];
  }
}
