import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table25",
  templateUrl: "./table25.component.html",
  styleUrls: ["./table25.component.scss"],
})
export class Table25Component implements OnInit {
  public preOpSelfTestListForm: UntypedFormGroup;
  public preOpSelfTestListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;

  otherAlgorithmOrTest;
  otherAlgorithmOrTestEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.preOpSelfTestListForm = this.fb.group({
      algorithmOrTest: ["", Validators.required],
      testProps: ["", Validators.required],
      testMethod: ["", Validators.required],
      type: ["", Validators.required],
      indicator: ["", Validators.required],
      details: ["", Validators.required],
      period: ["", Validators.required],
      periodicMethod: ["", Validators.required],
    });
    this.preOpSelfTestListFormEdit = this.fb.group({
      algorithmOrTest: ["", Validators.required],
      testProps: ["", Validators.required],
      testMethod: ["", Validators.required],
      type: ["", Validators.required],
      indicator: ["", Validators.required],
      details: ["", Validators.required],
      period: ["", Validators.required],
      periodicMethod: ["", Validators.required],
    });
  }

  addArray() {
    // if (this.preOpSelfTestListForm.valid) {
      let { algorithmOrTest, ...rest } = this.preOpSelfTestListForm.value;

      this.br1Service.brTables["preOpSelfTestList"].push({
        ...rest,
        algorithmOrTest:
          algorithmOrTest !== "Other"
            ? algorithmOrTest
            : this.otherAlgorithmOrTest,
      });
      this.preOpSelfTestListForm.reset();
      this.otherAlgorithmOrTest = null;
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { algorithmOrTest, ...rest } =
      this.br1Service.brTables.preOpSelfTestList[index];
    let algoSearch = this.br1Service.selectableAlgorithms.find((s) =>
      s.certName
        ? s.algoDisplayName + " (" + s.certName + ")" === algorithmOrTest
        : s.algoDisplayName === algorithmOrTest
    );
    if (algoSearch) {
      this.preOpSelfTestListFormEdit.setValue(
        this.br1Service.brTables.preOpSelfTestList[index]
      );
    } else {
      this.preOpSelfTestListFormEdit.setValue({
        ...rest,
        algorithmOrTest: "Other",
      });
      this.otherAlgorithmOrTestEdit = algorithmOrTest;
    }
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.preOpSelfTestList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      let { algorithmOrTest, ...rest } = form.value;

      this.br1Service.brTables.preOpSelfTestList[index] = {
        ...rest,
        algorithmOrTest:
          algorithmOrTest !== "Other"
            ? algorithmOrTest
            : this.otherAlgorithmOrTestEdit,
      };
      this.editingRow = null;
      this.otherAlgorithmOrTestEdit = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.preOpSelfTestList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.preOpSelfTestList[index],
      this.br1Service.brTables.preOpSelfTestList[index - 1],
    ] = [
      this.br1Service.brTables.preOpSelfTestList[index - 1],
      this.br1Service.brTables.preOpSelfTestList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.preOpSelfTestList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.preOpSelfTestList[index],
      this.br1Service.brTables.preOpSelfTestList[index + 1],
    ] = [
      this.br1Service.brTables.preOpSelfTestList[index + 1],
      this.br1Service.brTables.preOpSelfTestList[index],
    ];
  }
}
