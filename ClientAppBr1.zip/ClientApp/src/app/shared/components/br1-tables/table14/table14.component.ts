import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table14",
  templateUrl: "./table14.component.html",
  styleUrls: ["./table14.component.scss"],
})
export class Table14Component implements OnInit {
  public authMethodListForm: UntypedFormGroup;
  public authMethodListFormEdit: UntypedFormGroup;

  editingTable;
  editingRow;

  otherMechanism;
  otherMechanismEdit;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.authMethodListForm = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      mechanism: ["", Validators.required],
      strengthEachAttempt: ["", Validators.required],
      strengthPerMin: [""],
    });
    this.authMethodListFormEdit = this.fb.group({
      name: ["", Validators.required],
      description: ["", Validators.required],
      mechanism: ["", Validators.required],
      strengthEachAttempt: ["", Validators.required],
      strengthPerMin: [""],
    });
  }

  addArray() {
    // if (this.authMethodListForm.valid) {
      let { mechanism, ...rest } = this.authMethodListForm.value;
      this.br1Service.brTables["authMethodList"].push({
        ...rest,
        mechanism: mechanism !== "Other" ? mechanism : this.otherMechanism,
      });

      this.authMethodListForm.reset();
      this.otherMechanism = null;
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    let { mechanism, ...rest } = this.br1Service.brTables.authMethodList[index];
    let sfiSearch = this.br1Service.brTables["secFunImplList"].find(
      (s) => s.name === mechanism
    );
    let algoSearch = this.br1Service.selectableAlgorithms.find((s) =>
      s.certName
        ? s.algoDisplayName + " (" + s.certName + ")" === mechanism
        : s.algoDisplayName === mechanism
    );
    if (sfiSearch || algoSearch) {
      this.authMethodListFormEdit.setValue(
        this.br1Service.brTables.authMethodList[index]
      );
    } else {
      this.authMethodListFormEdit.setValue({
        ...rest,
        mechanism: "Other",
      });
      this.otherMechanismEdit = mechanism;
    }
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.authMethodList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      let { mechanism, ...rest } = form.value;

      this.br1Service.brTables.authMethodList[index] = {
        ...rest,
        mechanism: mechanism !== "Other" ? mechanism : this.otherMechanismEdit,
      };
      this.editingRow = null;
      this.otherMechanismEdit = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (index <= 0 || index >= this.br1Service.brTables.authMethodList.length) {
      return;
    }
    [
      this.br1Service.brTables.authMethodList[index],
      this.br1Service.brTables.authMethodList[index - 1],
    ] = [
      this.br1Service.brTables.authMethodList[index - 1],
      this.br1Service.brTables.authMethodList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.authMethodList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.authMethodList[index],
      this.br1Service.brTables.authMethodList[index + 1],
    ] = [
      this.br1Service.brTables.authMethodList[index + 1],
      this.br1Service.brTables.authMethodList[index],
    ];
  }
}
