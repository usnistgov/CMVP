import { Component, OnInit, Input } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  UntypedFormBuilder,
  FormControl,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import * as _ from "underscore";
import { Br1Service } from "src/app/shared/services/br1.service";
import { FormService } from "src/app/shared/services/form.service";
import { SectionService } from "src/app/shared/services/section.service";
import { ConfirmDialogComponent } from "../../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { ToastrService } from "ngx-toastr";

@Component({
  selector: "app-table2",
  templateUrl: "./table2.component.html",
  styleUrls: ["./table2.component.scss"],
})
export class Table2Component implements OnInit {
  public testedSwFwHyListForm: UntypedFormGroup;
  public testedSwFwHyListFormEdit: UntypedFormGroup;

  public testedHyHwListForm: UntypedFormGroup;
  public testedHyHwListFormEdit: UntypedFormGroup;
  editingTableA;
  editingRowA;

  editingTable;
  editingRow;
  moduleType;
  constructor(
    private dialog: MatDialog,
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.moduleType = this.formService.moduleType;

    this.testedSwFwHyListForm = this.fb.group({
      packageFileName: ["", Validators.required],
      swFwVersion: ["", Validators.required],
      features: [""],
      integrityTest: ["", Validators.required],
    });
    this.testedSwFwHyListFormEdit = this.fb.group({
      packageFileName: ["", Validators.required],
      swFwVersion: ["", Validators.required],
      features: [""],
      integrityTest: ["", Validators.required],
    });

    this.testedHyHwListForm = this.fb.group({
      modelPartNum: ["", Validators.required],
      hwVersion: ["", Validators.required],
      fwVersion: [""],
      processors: [""],
      features: [""],
    });
    this.testedHyHwListFormEdit = this.fb.group({
      modelPartNum: ["", Validators.required],
      hwVersion: ["", Validators.required],
      fwVersion: [""],
      processors: [""],
      features: [""],
    });
  }

  addArray() {
    // if (this.testedSwFwHyListForm.valid) {
      this.br1Service.brTables["testedSwFwHyList"].push(
        this.testedSwFwHyListForm.value
      );
      this.testedSwFwHyListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRow(index) {
    this.editingRow = index;
    this.testedSwFwHyListFormEdit.setValue(
      this.br1Service.brTables.testedSwFwHyList[index]
    );
  }
  deleteTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.testedSwFwHyList.splice(index, 1);
      }
    });
  }

  saveTableRow(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.testedSwFwHyList[index] = form.value;
      this.editingRow = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  // Table 2a

  addArrayA() {
    // if (this.testedHyHwListForm.valid) {
      this.br1Service.brTables["testedHyHwList"].push(
        this.testedHyHwListForm.value
      );
      this.testedHyHwListForm.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }

  editTableRowA(index) {
    this.editingRowA = index;
    this.testedHyHwListFormEdit.setValue(
      this.br1Service.brTables.testedHyHwList[index]
    );
  }
  deleteTableRowA(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.brTables.testedHyHwList.splice(index, 1);
      }
    });
  }

  saveTableRowA(index, form: UntypedFormGroup) {
    // if (form.valid) {
      this.br1Service.brTables.testedHyHwList[index] = form.value;
      this.editingRowA = null;
      form.reset();
    // } else {
    //   this.toastr.error("Invalid form");
    // }
  }
  up(index) {
    if (
      index <= 0 ||
      index >= this.br1Service.brTables.testedSwFwHyList.length
    ) {
      return;
    }
    [
      this.br1Service.brTables.testedSwFwHyList[index],
      this.br1Service.brTables.testedSwFwHyList[index - 1],
    ] = [
      this.br1Service.brTables.testedSwFwHyList[index - 1],
      this.br1Service.brTables.testedSwFwHyList[index],
    ];
  }
  down(index) {
    if (
      index < 0 ||
      index >= this.br1Service.brTables.testedSwFwHyList.length - 1
    ) {
      return;
    }
    [
      this.br1Service.brTables.testedSwFwHyList[index],
      this.br1Service.brTables.testedSwFwHyList[index + 1],
    ] = [
      this.br1Service.brTables.testedSwFwHyList[index + 1],
      this.br1Service.brTables.testedSwFwHyList[index],
    ];
  }
}
