import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  SimpleChanges,
} from "@angular/core";
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
} from "@angular/forms";
import { MatDatepickerInputEvent } from "@angular/material/datepicker";
import { MAT_DATE_FORMATS } from "@angular/material/core";
import { SectionService } from "../../services/section.service";
import { FormService } from "../../services/form.service";
import { Br1Service } from "../../services/br1.service";
import { ConfirmDialogComponent } from "../confirm-dialog/confirm-dialog.component";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { CapabilitiesEditorComponent } from "../capabilities-editor/capabilities-editor.component";
import { ToastrService } from "ngx-toastr";

export const MY_FORMATS = {
  parse: {
    dateInput: "YYYY-MM-DD",
  },
  display: {
    dateInput: "YYYY-MM-DD",
    monthYearLabel: "YYYY",
    dateA11yLabel: "LL",
    monthYearA11yLabel: "YYYY",
  },
};

@Component({
  selector: "app-cavp-builder",
  templateUrl: "./cavp-builder.component.html",
  styleUrls: ["./cavp-builder.component.scss"],
  providers: [{ provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }],
})
export class CavpBuilderComponent implements OnInit {
  vendorName;
  searchedVendorName;
  CAVPCertOptions = [];
  filteredCAVPCertOptions = [];
  OEOptions = [];
  addedCAVPCerts = [];
  addedAlgos = [];
  all = false;

  editingCavpOeAlgoRow;
  oeAlgosOptions = [];
  oeAlgosOptionsEdit = [];
  searchCertNumberList = [];
  searchedCertNumber;
  includeCategory = false;
  category = "";

  cavpItarAlgo = {
    certName: "",
    capabilities: "",
    category: "",
  };
  cavpItarAlgoEdit = {
    certName: "",
    capabilities: "",
    category: "",
  };
  itarAlgo;
  itarAlgoEdit;
  editingItarRow;
  canonicalAlgorithms;
  editingSelectableAlgorithmsIndex;
  cavpFilter;
  @Input()
  set cavpBuilderReval(revalCert: string) {
    this.initData()
  }


  constructor(
    public sectionService: SectionService,
    public formService: FormService,
    public br1Service: Br1Service,
    private fb: UntypedFormBuilder,
    private dialog: MatDialog,
    private toastr: ToastrService,

  ) { }

  async ngOnInit() {
    this.initData();
  }

  async initData() {
    this.getCanonicalAlgorithms();
    this.addedCAVPCerts = this.br1Service.cavpCertSet.cavpCertList.map(
      (c) => c.validationId
    );
    this.addedAlgos = this.br1Service.cavpCertSet.cavpOeAlgoList.map(
      (c) => c.validationOeAlgorithmId
    );
    if (this.addedCAVPCerts.length > 0) {
      await this.getOEs();
      this.br1Service.cavpCertSet.cavpOeList.forEach((oe) => {
        let obj = this.OEOptions.find((o) => o.oeId === oe.oeId);
        if (obj) {
          obj.checked = true;
        }
      });
    }
  }

  async selectCapabilities(algo) {
    let VOEACapabilities = await this.sectionService.getVOEACapabilitiesData(
      algo.validationOeAlgorithmId
    );
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      selectedCapabilities: algo.selectedCapList,
      allCapabilities: VOEACapabilities,
    };
    const dialogRef = this.dialog.open(
      CapabilitiesEditorComponent,
      dialogConfig
    );
    dialogRef.afterClosed().subscribe((data) => {
      algo.selectedCapList = data;
    });
  }
  async getCanonicalAlgorithms() {
    this.canonicalAlgorithms =
      await this.sectionService.getCanonalicalAlgorithms();
  }

  async getCAVPCerts() {
    let certs = await this.sectionService.getCAVPData(this.vendorName);
    if (certs) {
      this.searchedVendorName = JSON.parse(JSON.stringify(this.vendorName));
      this.CAVPCertOptions = <any[]>certs;
      this.CAVPCertOptions = this.CAVPCertOptions.map((cert) => ({
        ...cert,
        validationId:
          typeof cert.validationId === "string"
            ? +cert.validationId
            : cert.validationId,
      }));
      this.filteredCAVPCertOptions = [...this.CAVPCertOptions];
    }
  }
  cavpFilterChanged() {
    this.filteredCAVPCertOptions = this.CAVPCertOptions.filter(option =>
      option.name.toLowerCase().includes(this.cavpFilter.toLowerCase()) || option.implName.toLowerCase().includes(this.cavpFilter.toLowerCase())
    );

  }
  async getOEs() {
    let oes = await this.sectionService.getOEData(this.addedCAVPCerts);
    if (oes) {
      this.OEOptions = <any[]>oes;
    }
  }
  addCAVPCert(cavp) {
    const { name, ...rest } = cavp;
    this.br1Service.cavpCertSet.cavpCertList.push({
      vendorName: this.searchedVendorName,
      certName: name,
      ...rest,
    });
    this.addedCAVPCerts.push(cavp.validationId);
  }
  removeCAVPCert(validationId) {
    let index = this.br1Service.cavpCertSet.cavpCertList.findIndex(
      (c) => c.validationId === validationId
    );
    if (index > -1) {
      this.br1Service.cavpCertSet.cavpCertList.splice(index, 1);
    }
    this.addedCAVPCerts = this.addedCAVPCerts.filter((c) => c !== validationId);
  }
  oeUpdated() {
    let checked = this.OEOptions.filter((o) => o.checked);
    if (checked) {
      this.br1Service.cavpCertSet.cavpOeList = JSON.parse(
        JSON.stringify(checked)
      ).map((o) => {
        return { name: o.name, oeId: o.oeId };
      });
    }
  }
  allUpdated() {
    this.OEOptions = this.OEOptions.map((o) => {
      return { ...o, checked: this.all };
    });
    this.oeUpdated();
  }

  deleteCavpOeAlgoTableRow(index) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "900px";
    dialogConfig.data = {
      message: "Are you sure you want to delete this row?",
      btnLabel: "Delete",
      btnClass: "btn-danger",
    };

    let dialogRef = this.dialog.open(ConfirmDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.br1Service.cavpCertSet["cavpOeAlgoList"].splice(index, 1);
      }
    });
  }

  saveCavpOeAlgoTableRow(index, form: UntypedFormGroup) {
    if (form.valid) {
      this.br1Service.cavpCertSet["cavpOeAlgoList"][index] = form.value;
      this.editingCavpOeAlgoRow = null;
      form.reset();
    } else {
      this.toastr.error("Invalid form");
    }
  }

  async getOEAlgos() {
    this.searchedCertNumber = JSON.parse(JSON.stringify(this.searchCertNumberList));
    let oes = this.OEOptions.filter((o) => o.checked);
    oes = oes.map((o) => o.oeId);
    let promises = []
    this.searchCertNumberList.forEach(searchCertNumber => {
      promises.push(this.sectionService.getOEAlgoData(
        searchCertNumber.validationId,
        oes
      ))
    });
    let algos = await Promise.all(promises);
    let algoOptions = [];
    algos.forEach((algo, index) => {
      algo.forEach(a => {
        algoOptions.push({
          ...a,
          certName: this.searchCertNumberList[index].certName,
          implName: this.searchCertNumberList[index].implName,
          validationId: this.searchCertNumberList[index].validationId,

        })

      });
    });
    // if(algos){
    //   algos = [].concat(...algos)
    //   console.log(algos)
    // }
    // let algos = (await this.sectionService.getOEAlgoData(
    //   this.searchedCertNumber.validationId,
    //   oes
    // )) as any;
    this.oeAlgosOptions = algoOptions ? algoOptions : [];
    // if (algos) {
    //   // this.OEOptions = <any[]>oes;

    // }
  }

  addAlgo(algo) {
    this.addedAlgos.push(algo.validationOeAlgorithmId);
    const oeAlgo = {
      validationOeAlgorithmId: algo.validationOeAlgorithmId,
      algoDisplayName: algo.algoDisplayName,
      canonicalAlgorithmId: algo.canonicalAlgorithmId,
      validationId: algo.validationId,
      certName: algo.certName,
      implName: algo.implName,
      oeId: algo.oeId,
      selectedCapList: [],
    };
    this.br1Service.cavpCertSet.cavpOeAlgoList.push(oeAlgo);
    this.br1Service.cavpCertSet.cavpOeAlgoList.sort((a, b) =>
      a.algoDisplayName.toLowerCase().localeCompare(b.algoDisplayName.toLowerCase()) ||
      a.certName.toLowerCase().localeCompare(b.certName.toLowerCase())
    );
    this.addCavpImplAlgoToList(oeAlgo);
  }
  addAllAlgos() {
    this.oeAlgosOptions.forEach((algo) => {
      let addedAlgo = this.addedAlgos.find(
        (a) => a === algo.validationOeAlgorithmId
      );
      if (!addedAlgo) {
        this.addedAlgos.push(algo.validationOeAlgorithmId);
        const oeAlgo = {
          validationOeAlgorithmId: algo.validationOeAlgorithmId,
          algoDisplayName: algo.algoDisplayName,
          canonicalAlgorithmId: algo.canonicalAlgorithmId,
          validationId: algo.validationId,
          certName: algo.certName,
          implName: algo.implName,
          oeId: algo.oeId,
          selectedCapList: [],
        };
        this.br1Service.cavpCertSet.cavpOeAlgoList.push(oeAlgo);
        this.br1Service.cavpCertSet.cavpOeAlgoList.sort((a, b) =>
          a.algoDisplayName.toLowerCase().localeCompare(b.algoDisplayName.toLowerCase()) ||
          a.certName.toLowerCase().localeCompare(b.certName.toLowerCase())
        );
        this.addCavpImplAlgoToList(oeAlgo);
      }
    });
  }
  removeAlgo(algo) {
    let index = this.br1Service.cavpCertSet.cavpOeAlgoList.findIndex(
      (c) => c.validationOeAlgorithmId === algo.validationOeAlgorithmId
    );
    if (index > -1) {
      this.br1Service.cavpCertSet.cavpOeAlgoList.splice(index, 1);
    }
    this.addedAlgos = this.addedAlgos.filter(
      (c) => c !== algo.validationOeAlgorithmId
    );

    let remainingAlgo = this.br1Service.cavpCertSet.cavpOeAlgoList.find(
      (r) =>
        r.canonicalAlgorithmId === algo.canonicalAlgorithmId &&
        r.validationId === algo.validationId
    );
    if (!remainingAlgo) {
      let algoIndex = this.br1Service.cavpCertSet.cavpImplAlgoList.findIndex(
        (r) =>
          r.canonicalAlgorithmId === algo.canonicalAlgorithmId &&
          r.validationId === algo.validationId
      );
      if (algoIndex > -1) {
        this.br1Service.cavpCertSet.cavpImplAlgoList.splice(algoIndex, 1);
      }

      const selectableAlgoIndex =
        this.br1Service.selectableAlgorithms.findIndex(
          (a) =>
            a.canonicalAlgorithmId ===
            algo.canonicalAlgorithmId.algoDisplayName &&
            a.from === "cavpImplAlgoList"
        );
      if (selectableAlgoIndex > -1) {
        this.br1Service.selectableAlgorithms.splice(selectableAlgoIndex, 1);
      }
    }
  }
  removeAllAlgos() {
    this.br1Service.cavpCertSet.cavpOeAlgoList = [];
    this.br1Service.cavpCertSet.cavpImplAlgoList = [];
    this.br1Service.selectableAlgorithms =
      this.br1Service.selectableAlgorithms.filter(
        (a) => a.from !== "cavpImplAlgoList"
      );
    this.addedAlgos = [];
  }
  includeCategoryFn() {
    this.includeCategory = !this.includeCategory;
  }
  removeCategoryFn() {
    this.category = "";
    this.includeCategory = !this.includeCategory;
  }
  addCavpImplAlgoToList(oeAlgo) {
    const cavpAlgo = this.br1Service.cavpCertSet.cavpImplAlgoList.find(
      (r) =>
        r.algoDisplayName === oeAlgo.algoDisplayName &&
        r.certName === oeAlgo.certName
    );
    if (!cavpAlgo) {
      this.br1Service.cavpCertSet.cavpImplAlgoList.push({
        algoDisplayName: oeAlgo.algoDisplayName,
        canonicalAlgorithmId: oeAlgo.canonicalAlgorithmId,
        validationId: oeAlgo.validationId,
        certName: oeAlgo.certName,
        propertiesList: [],
        category: "",
        implName: oeAlgo.implName,
      });
      this.br1Service.cavpCertSet.cavpImplAlgoList.sort((a, b) =>
        a.algoDisplayName.toLowerCase().localeCompare(b.algoDisplayName.toLowerCase()) ||
        a.certName.toLowerCase().localeCompare(b.certName.toLowerCase())
      );
      this.br1Service.selectableAlgorithms.push({
        algoDisplayName: oeAlgo.algoDisplayName,
        canonicalAlgorithmId: oeAlgo.canonicalAlgorithmId,
        validationId: oeAlgo.validationId,
        certName: oeAlgo.certName,
        propertiesList: [],
        implName: oeAlgo.implName,
        from: "cavpImplAlgoList",
      });
    }
  }
  removeItarAlgo(index) {
    this.br1Service.cavpCertSet.cavpItarAlgoList.splice(index, 1);
  }
  addItarArray() {
    if (this.itarAlgo && this.cavpItarAlgo.certName) {
      this.br1Service.cavpCertSet.cavpItarAlgoList.push({
        ...this.cavpItarAlgo,
        algoDisplayName: this.itarAlgo.algoDisplayName,
        canonicalAlgorithmId: this.itarAlgo.canonicalAlgorithmId,
      });
      this.br1Service.selectableAlgorithms.push({
        algoDisplayName: this.itarAlgo.algoDisplayName,
        canonicalAlgorithmId: this.itarAlgo.canonicalAlgorithmId,
        certName: this.cavpItarAlgo.certName,
        from: "cavpItarAlgoList",
      });
      this.cavpItarAlgo = {
        certName: "",
        capabilities: "",
        category: "",
      };
      this.itarAlgo = null;
    }
  }
  editItarAlgo(index) {
    this.editingItarRow = index;
    this.cavpItarAlgoEdit = {
      certName: this.br1Service.cavpCertSet.cavpItarAlgoList[index].certName,
      capabilities:
        this.br1Service.cavpCertSet.cavpItarAlgoList[index].capabilities,
      category: this.br1Service.cavpCertSet.cavpItarAlgoList[index].category,
    };
    this.itarAlgoEdit = {
      algoDisplayName:
        this.br1Service.cavpCertSet.cavpItarAlgoList[index].algoDisplayName,
      canonicalAlgorithmId:
        this.br1Service.cavpCertSet.cavpItarAlgoList[index]
          .canonicalAlgorithmId,
    };
    this.editingSelectableAlgorithmsIndex =
      this.br1Service.selectableAlgorithms.findIndex(
        (a) =>
          a.algoDisplayName ===
          this.br1Service.cavpCertSet.cavpItarAlgoList[index]
            .algoDisplayName && a.from === "cavpItarAlgoList"
      );
  }
  saveItarAlgo() {
    if (this.itarAlgoEdit && this.cavpItarAlgoEdit.certName) {
      this.br1Service.cavpCertSet.cavpItarAlgoList[this.editingItarRow] = {
        ...this.cavpItarAlgoEdit,
        algoDisplayName: this.itarAlgoEdit.algoDisplayName,
        canonicalAlgorithmId: this.itarAlgoEdit.canonicalAlgorithmId,
      };
      if (this.editingSelectableAlgorithmsIndex) {
        this.br1Service.selectableAlgorithms[
          this.editingSelectableAlgorithmsIndex
        ] = {
          algoDisplayName: this.itarAlgoEdit.algoDisplayName,
          canonicalAlgorithmId: this.itarAlgoEdit.canonicalAlgorithmId,
          certName: this.cavpItarAlgoEdit.certName,
          from: "cavpItarAlgoList",
        };
        this.editingSelectableAlgorithmsIndex = null;
      }

      this.cavpItarAlgoEdit = {
        certName: "",
        capabilities: "",
        category: "",
      };
      this.itarAlgoEdit = null;
      this.editingItarRow = null;
    }
  }
  public isSameAlgo(algoA?, algoB?) {
    return (
      !!algoA && algoA.canonicalAlgorithmId === algoB?.canonicalAlgorithmId
    );
  }
}
