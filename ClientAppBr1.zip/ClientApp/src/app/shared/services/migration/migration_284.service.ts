
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class Migration284Service {
  constructor() { }

  migrateMISTables(data) {
    let result = {
      testedHwList: this.migrateTable1(data.testedHwList),
      testedSwFwHyList: this.migrateTable2(data.testedSwFwHyList),
      testedHyHwList: this.migrateTable2a(data.testedHyHwList),
      opEnvSwFwHyTestedList: this.migrateTable3(data.opEnvSwFwHyTestedList),
      opEnvSwFwHyVAList: this.migrateTable4(data.opEnvSwFwHyVAList),
      modeOfOpList: this.migrateTable5(data.modeOfOpList),
      vendorAffirmedAlgoList: this.migrateTable6(data.vendorAffirmedAlgoList),
      nonApprovedAllowedAlgoList: this.migrateTable7(data.nonApprovedAllowedAlgoList),
      nonApprovedAllowedAlgoNSCList: this.migrateTable8(data.nonApprovedAllowedAlgoNSCList),
      nonApprovedNotAllowedAlgoList: this.migrateTable9(data.nonApprovedNotAllowedAlgoList),
      secFunImplList: this.migrateTable10(data.secFunImplList),
      esvCertList: this.migrateTable11(data.esvCertList),
      esvItarCertList: this.migrateTable11a(data.esvItarCertList),
      entropySourceList: this.migrateTable12(data.entropySourceList),
      portInterfaceList: this.migrateTable13(data.portInterfaceList),
      authMethodList: this.migrateTable14(data.authMethodList),
      roleList: this.migrateTable15(data.roleList),
      approvedServiceList: this.migrateTable16(data.approvedServiceList),
      nonApprovedServiceList: this.migrateTable17(data.nonApprovedServiceList),
      phSecMechanismList: this.migrateTable18(data.phSecMechanismList),
      efpEftInfoList: this.migrateTable19(data.efpEftInfoList),
      hardnessTestTempList: this.migrateTable20(data.hardnessTestTempList),
      storageAreaList: this.migrateTable21(data.storageAreaList),
      sspInputOutputList: this.migrateTable22(data.sspInputOutputList),
      sspZeroizationList: this.migrateTable23(data.sspZeroizationList),
      sspList: this.migrateTable24(data.sspList),
      preOpSelfTestList: this.migrateTable25(data.preOpSelfTestList),
      condSelfTestList: this.migrateTable26(data.condSelfTestList),
      errorStateList: this.migrateTable27(data.errorStateList),

    }
    return result;

  }
  migrateCavpCertSet(data) {
    let result = {
      cavpCertList: this.migrateCavpCertList(data.cavpCertList),
      cavpOeList: this.migrateCavpOeList(data.cavpOeList),
      cavpOeAlgoList: this.migrateCavpOeAlgoList(data.cavpOeAlgoList),
      cavpImplAlgoList: this.migrateCavpImplAlgoList(data.cavpImplAlgoList),
      cavpItarAlgoList: this.migrateCavpItarAlgoList(data.cavpItarAlgoList),

    }
    return result;
  }
  migrateCavpCertList(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          vendorName: d.vendorName,
          certName: d.certName,
          validationId: d.validationId,
          implName: d.implName,
          implVersion: d.implVersion,
          implType: d.implType,
          implOrganization: d.implOrganization,
        }
      })
    }
    return res;
  }
  migrateCavpOeList(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          oeId: d.oeId
        }
      })
    }
    return res;
  }
  migrateCavpOeAlgoList(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          validationOeAlgorithmId: d.validationOeAlgorithmId,
          algoDisplayName: d.algoDisplayName,
          canonicalAlgorithmId: d.canonicalAlgorithmId,
          validationId: d.validationId,
          certName: d.certName,
          implName: d.implName,
          oeId: d.oeId,
          selectedCapList: this.migrateCapList(d.selectedCapList)

        }
      });
      res.sort((a, b) =>
        a.algoDisplayName.toLowerCase().localeCompare(b.algoDisplayName.toLowerCase()) ||
        a.certName.toLowerCase().localeCompare(b.certName.toLowerCase())
      );
    }
    return res;
  }
  migrateCapList(data) {
    let res = [];
    if (data) {
      res = data.map(d => {
        return {
          capabilityId: d.capabilityId,
          displayText: d.displayText,
          childCapabilities: this.migrateCapList(d.childCapabilities),
        }
      })
    }
    return res;
  }
  migrateCavpImplAlgoList(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          algoDisplayName: d.algoDisplayName,
          canonicalAlgorithmId: d.canonicalAlgorithmId,
          implName: d.implName,
          validationId: d.validationId,
          certName: d.certName,
          category: d.category,
        }
      })
      res.sort((a, b) =>
        a.algoDisplayName.toLowerCase().localeCompare(b.algoDisplayName.toLowerCase()) ||
        a.certName.toLowerCase().localeCompare(b.certName.toLowerCase())
      );
    }
    return res;
  }
  migrateCavpItarAlgoList(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          certName: d.certName,
          algoDisplayName: d.algoDisplayName,
          canonicalAlgorithmId: d.canonicalAlgorithmId,
          capabilities: d.capabilities,
          category: d.category,
        }
      })
    }
    return res;
  }
  migrateTable1(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          modelPartNum: d.modelPartNum,
          hwVersion: d.hwVersion,
          fwVersion: d.fwVersion,
          processors: d.processors,
          features: d.features,
        }
      })
    }
    return res;
  }
  migrateTable2(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          packageFileName: d.packageFileName,
          swFwVersion: d.swFwVersion,
          features: d.features,
          integrityTest: d.integrityTest,
        }
      })
    }
    return res;
  }
  migrateTable2a(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          modelPartNum: d.modelPartNum,
          hwVersion: d.hwVersion,
          fwVersion: d.fwVersion,
          processors: d.processors,
          features: d.features,
        }
      })
    }
    return res;
  }
  migrateTable3(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          operatingSystem: d.operatingSystem,
          hardwarePlatform: d.hardwarePlatform,
          processors: d.processors,
          paaPai: d.paaPai,
          hypervisorHostOs: d.hypervisorHostOs,
          swFwVersionList: d.swFwVersionList
        }
      })
    }
    return res;
  }
  migrateTable4(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          operatingSystem: d.operatingSystem,
          hardwarePlatform: d.hardwarePlatform
        }
      })
    }
    return res;
  }
  migrateTable5(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          type: d.type,
          statusIndicator: d.statusIndicator
        }
      })
    }
    return res;
  }
  migrateTable6(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          implName: d.implName,
          reference: d.reference,
          algoPropList: d.algoPropList ? d.algoPropList.map(a => {
            return {
              name: a.name,
              value: a.value,
              propertyId: a.propertyId
            }
          }) : []
        }
      })
    }
    return res;
  }
  migrateTable7(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          implName: d.implName,
          reference: d.reference,
          algoPropList: d.algoPropList ? d.algoPropList.map(a => {
            return {
              name: a.name,
              value: a.value,
              propertyId: a.propertyId
            }
          }) : []
        }
      })
    }
    return res;
  }
  migrateTable8(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          caveat: d.caveat,
          useFunction: d.useFunction,
        }
      })
    }
    return res;
  }
  migrateTable9(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          useFunction: d.useFunction,
        }
      })
    }
    return res;
  }
  migrateTable10(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          sfTypeList: d.sfTypeList ? d.sfTypeList.map(a => {
            return {
              sfAbbrev: a.sfAbbrev,
              sfId: a.sfId,
            }
          }) : [],
          sfPropList: d.sfPropList ? d.sfPropList.map(a => {
            return {
              name: a.name,
              value: a.value,
              propertyId: a.propertyId,
            }
          }) : [],
          algorithmList: d.algorithmList ? d.algorithmList.map(a => {
            return {
              algoDisplayName: a.algoDisplayName,
              canonicalAlgorithmId: a.canonicalAlgorithmId,
              implName: a.implName,
              validationId: a.validationId,
              certName: a.certName,
              algoPropList: a.algoPropList ? a.algoPropList.map(b => {
                return {
                  name: b.name,
                  value: b.value,
                  propertyId: b.propertyId,
                }
              }) : [],

            }
          }) : [],

        }
      })
    }
    return res;
  }
  migrateTable11(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          esvCertName: d.esvCertName,
          certId: d.certId,
          vendorName: d.vendorName,
        }
      })
    }
    return res;
  }
  migrateTable11a(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          items: d.items,
        }
      })
    }
    return res;
  }
  migrateTable12(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          type: d.type,
          opEnv: d.opEnv,
          sampleSize: d.sampleSize,
          entropyPerSample: d.entropyPerSample,
          conditioningComp: d.conditioningComp,

        }
      })
    }
    return res;
  }
  migrateTable13(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          physicalPort: d.physicalPort,
          dataPasses: d.dataPasses,
          logicalInterfaceList: d.logicalInterfaceList
        }
      })
    }
    return res;
  }
  migrateTable14(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          mechanism: d.mechanism,
          strengthEachAttempt: d.strengthEachAttempt,
          strengthPerMin: d.strengthPerMin,

        }
      })
    }
    return res;
  }
  migrateTable15(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          type: d.type,
          operatorType: d.operatorType,
          authMethodList: d.authMethodList
        }
      })
    }
    return res;
  }
  migrateTable16(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          indicator: d.indicator,
          inputs: d.inputs,
          outputs: d.outputs,
          secFunImplList: d.secFunImplList,
          roleSspAccessList: d.roleSspAccessList ? d.roleSspAccessList.map(a => {
            return {
              roleName: a.roleName,
              sspAccessList: a.sspAccessList ? a.sspAccessList.map(b => {
                return {
                  sspName: b.sspName,
                  accessType: b.accessType
                }
              }) : []
            }
          }) : []
        }
      })
    }
    return res;
  }
  migrateTable17(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          role: d.role,
          nonApprovedAlgoList: d.nonApprovedAlgoList
        }
      })
    }
    return res;
  }
  migrateTable18(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          mechanism: d.mechanism,
          inspectFreq: d.inspectFreq,
          inspectGuidance: d.inspectGuidance,
        }
      })
    }
    return res;
  }
  migrateTable19(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          tempVoltType: d.tempVoltType,
          tempVolt: d.tempVolt,
          efpOrEft: d.efpOrEft,
          result: d.result,
        }
      })
    }
    return res;
  }
  migrateTable20(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          tempType: d.tempType,
          temp: d.temp,
        }
      })
    }
    return res;
  }
  migrateTable21(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          persistenceType: d.persistenceType,
        }
      })
    }
    return res;
  }
  migrateTable22(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          from: d.from,
          to: d.to,
          formatType: d.formatType,
          distributionType: d.distributionType,
          entryType: d.entryType,
          relatedSFI: d.relatedSFI,

        }
      })
    }
    return res;
  }
  migrateTable23(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          method: d.method,
          description: d.description,
          rationale: d.rationale,
          operatorInitiation: d.operatorInitiation,
        }
      })
    }
    return res;
  }
  migrateTable24(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          size: d.size,
          strength: d.strength,
          type: d.type,
          generatedByList: d.generatedByList,
          establishedByList: d.establishedByList,
          usedByList: d.usedByList,
          inputOutputList: d.inputOutputList,
          storageItemList: d.storageItemList ? d.storageItemList.map(a => {
            return {
              areaName: a.areaName,
              format: a.format,
              algorithmName: a.algorithmName,
            }
          }) : [],
          storageDuration: d.storageDuration,
          zeroizationList: d.zeroizationList,
          category: d.category,
          relatedSspList: d.relatedSspList ? d.relatedSspList.map(a => {
            return {
              sspName: a.sspName,
              relationship: a.relationship
            }
          }) : [],



        }
      })
    }
    return res;
  }
  migrateTable25(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          algorithmOrTest: d.algorithmOrTest,
          testProps: d.testProps,
          testMethod: d.testMethod,
          type: d.type,
          indicator: d.indicator,
          details: d.details,
          period: d.period,
          periodicMethod: d.periodicMethod,

        }
      })
    }
    return res;
  }
  migrateTable26(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          algorithmOrTest: d.algorithmOrTest,
          testProps: d.testProps,
          testMethod: d.testMethod,
          type: d.type,
          indicator: d.indicator,
          details: d.details,
          conditions: d.conditions,
          coverage: d.coverage ? d.coverage.map(a => {
            return {
              algoDisplayName: a.algoDisplayName,
              canonicalAlgorithmId: a.canonicalAlgorithmId,
              implName: a.implName,
              validationId: a.validationId,
              certName: a.certName,
              algoPropList: a.algoPropList ? a.algoPropList.map(b => {
                return {
                  name: b.name,
                  value: b.value,
                  propertyId: b.propertyId,
                }
              }) : [],

            }
          }) : [],
          coverageNotes: d.coverageNotes,
          period: d.period,
          periodicMethod: d.periodicMethod,


        }
      })
    }
    return res;
  }
  migrateTable27(data) {
    let res = []
    if (data) {
      res = data.map(d => {
        return {
          name: d.name,
          description: d.description,
          conditions: d.conditions ? d.conditions.map(a => {
            return a
          }) : [],
          recoveryMethod: d.recoveryMethod,
          indicator: d.indicator,
        }
      })
    }
    return res;
  }
}