import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { parse } from "date-fns";
import { SectionService } from "./section.service";
import { DatePipe } from "@angular/common";
// var parseString = require('xml2js').parseString;
import xml2js from "xml2js";
import {
  UntypedFormGroup,
  UntypedFormControl,
  UntypedFormBuilder,
} from "@angular/forms";
import Ajv from "ajv";
import schema from "../../../assets/schema/schema-vendor.json";
import { Br1Service } from "./br1.service";
import Ajv2020 from "ajv/dist/2020";

@Injectable({
  providedIn: "root",
})
export class FormService {
  moduleType: string;
  type = "submission";
  updateVersionNumber;
  labs;
  labNames = [];
  constructor(
    public datepipe: DatePipe,
    private sectionService: SectionService,
    private fb: UntypedFormBuilder,
    public br1Service: Br1Service
  ) {}

  async parseReportSectionData(form, data, format) {
    if (format === "xml") {
      // Without parser
      data = await xml2js.parseStringPromise(data, { explicitArray: false });
      data = data.section;
    } else if (format === "json") {
      data = JSON.parse(data);
    }
    form.patchValue(data);
    if (data["TEB.01.01"]) {
      this.setArrayList(form, "SFHTestedOperationalEnvironments", data);
      this.setArrayList(form, "SFHAffirmedOperationalEnvironment", data);
      this.setArrayList(form, "approvedAlgorithms", data);
      this.setArrayList(form, "approvedServices", data);
      this.setArrayList(form, "hardwareTestedConfiguration", data);
      this.setArrayList(form, "nonApprovedAlgorithms", data);
      this.setArrayList(form, "nonApprovedAllowedNoSecurityClaimed", data);
      this.setArrayList(
        form,
        "nonApprovedAllowedNoSecurityClaimedNotAllowed",
        data
      );
      this.setArrayList(form, "nonApprovedServices", data);
      this.setArrayList(
        form,
        "nonDeterministicRandomNumberGenerationSpecification",
        data
      );
      this.setArrayList(form, "physicalSecurityInspectionGuidelines", data);
      this.setArrayList(form, "portsAndInterfaces", data);
      this.setArrayList(form, "rolesAuthentication", data);
      this.setArrayList(form, "rolesServicesInputOutput", data);
      this.setArrayList(form, "ssps", data);
      this.setArrayList(form, "vendorAffirmedApprovedAlgorithms", data);
      this.setArrayList(form, "sfi", data);

      if (data["TEB.01.01"].entp) {
        this.sectionService.securityPolicyContent["entp"] =
          data["TEB.01.01"].entp;
      } else {
        this.sectionService.securityPolicyContent["entp"] = false;
      }

      if (data["TEB.01.01"].entnp) {
        this.sectionService.securityPolicyContent["entnp"] =
          data["TEB.01.01"].entnp;
      } else {
        this.sectionService.securityPolicyContent["entnp"] = false;
      }
      this.updateTable9AlgoOptions(data["TEB.01.01"]["approvedAlgorithms"]);
    }
  }

  //Update table 9 options with cert/algo from table 5
  updateTable9AlgoOptions(table5Values) {
    let result = [];
    if (table5Values) {
      table5Values.forEach((row) => {
        const exists = result.find(
          (r) =>
            r.CAVPCert === row.CAVPCert &&
            r.algorithmAndStandard === row.algorithmAndStandard
        );
        if (!exists) {
          result.push({
            algorithmAndStandard: row.algorithmAndStandard,
            ValidationId: row.ValidationId,
            CAVPCert: row.CAVPCert,
            label: `${row.algorithmAndStandard}/${row.CAVPCert}`,
          });
        }
      });
    }
    this.sectionService.table9AlgoOptions = result;

    this.sectionService.filteredTable9AlgoOptions =
      this.sectionService.table9AlgoOptions.slice();
  }

  setArrayList(form: UntypedFormGroup, fieldName, data) {
    if (
      data["TEB.01.01"][fieldName] &&
      data["TEB.01.01"][fieldName].length > 0
    ) {
      let resList = [];
      const list = data["TEB.01.01"][fieldName];

      list.forEach((element) => {
        let formGroup = {};
        for (let key in element) {
          formGroup[key] = new UntypedFormControl(element[key]);
        }
        resList.push(this.fb.group(formGroup));
      });
      (form.controls["TEB.01.01"] as UntypedFormGroup).setControl(
        fieldName,
        this.fb.array(resList)
      );
    }
  }
  async parseVendoInfoData(form, data, format) {
    if (format === "xml") {
      // const parser = new DOMParser();
      // const parsedXml = parser.parseFromString(data, "text/xml");
      // data = this.ngxXml2jsonService.xmlToJson(parsedXml);
      // data = data["general-info"];
      data = await xml2js.parseStringPromise(data, { explicitArray: false });
      data = data["general-info"];
    } else if (format === "json") {
      data = JSON.parse(data);
    }
    // const ajv = new Ajv({ allErrors: true, strict: false });
    // const validate = ajv.compile(schema);
    // const isValid = validate(data);
    // console.log("----", isValid);
    // if (!isValid) {
    //   console.log(validate.errors);
    // }

    if (data.referenceList) {
      this.sectionService.references = this.fb.array(data.referenceList);
    }

    // parse Security levels
    data.moduleInfo["overall-level"] =
      data.securityLevelInfo.overallLevel.toString();
    data.securityLevelInfo.secLevels.forEach((level) => {
      data.moduleInfo[`section${level.section}-level`] =
        level.level === 0 ? "NA" : level.level.toString();
    });

    form.controls["laboratory"].patchValue(
      this.parseJson(data["labInfo"], form.controls["laboratory"].value)
    );
    form.controls["module"].patchValue(
      this.parseJson(data["moduleInfo"], form.controls["module"].value)
    );
    form.controls["vendor"].patchValue(
      this.parseJson(data["vendorInfo"], form.controls["vendor"].value)
    );
    form.get("module").get("csecTid").enable(); // Enable the control
    form.controls["module"]
      .get("csecTid")
      .patchValue(data["moduleInfo"]["csecTid"]); // Update the value
    form.controls["module"].get("csecTid").disable(); // Disable the control again

    form.get("laboratory").get("labCode").enable(); // Enable the control
    form.controls["laboratory"]
      .get("labCode")
      .patchValue(data["labInfo"]["labCode"]); // Update the value
    form.controls["laboratory"].get("labCode").disable(); // Disable the control again
    this.moduleType = form.controls["module"].value.type;

    this.br1Service.setBr1Data(data);
    this.br1Service.setCAVPData(data.cavpCertSet);
    this.br1Service.setSupplementalSettingList(data.supplementalSettingList);

    this.br1Service.populateSelectableAlgorithm();
    // if (data["module"] && data["module"]["update-version-label"]) {
    //   this.updateVersionNumber = parseInt(
    //     data["module"]["update-version-label"]
    //   );
    // } else {
    //   this.updateVersionNumber = null;
    // }
  }
  populateSectionLine(line) {
    let secNumber = line[1];
    if (secNumber.startsWith("0")) {
      secNumber = secNumber.substring(1);
    }
    let form_name =
      line[0] +
      "" +
      line[1] +
      "." +
      line[2] +
      (line[3] && line[3] !== "00" ? "." + line[3] : "");
    let form = this.sectionService.sections[secNumber];

    if (form && form.controls[form_name]) {
      if (!line[5]) {
        if (form.controls[form_name].controls["assessment"]) {
          form.controls[form_name].controls["assessment"].setValue(" ");
        }
        if (form.controls[form_name].controls["notes"]) {
          form.controls[form_name].controls["notes"].setValue(" ");
        }
      } else {
        if (form.controls[form_name].controls["assessment"]) {
          form.controls[form_name].controls["assessment"].setValue(line[5]);
        }
        if (form.controls[form_name].controls["notes"]) {
          form.controls[form_name].controls["notes"].setValue(line[5]);
        }
      }
      if (!line[9]) {
        if (form.controls[form_name].controls["reval-assessment"]) {
          form.controls[form_name].controls["reval-assessment"].setValue(" ");
        }
      } else {
        if (form.controls[form_name].controls["reval-assessment"]) {
          form.controls[form_name].controls["reval-assessment"].setValue(
            line[9]
          );
        }
      }
      if (!line[8]) {
        form.controls[form_name].controls["test-status"].setValue(" ");
      } else {
        // let status = "Open";
        // if (line[8] === "0") {
        //   status = "Open";
        // }
        // if (line[8] === "1") {
        //   status = "Passed";
        // }
        // if (line[8] === "2") {
        //   status = "Failed";
        // }
        // if (line[8] === "4") {
        //   status = "ReVal Passed";
        // }
        // if (line[8] === "3") {
        //   status = "Not Applicable";
        // }
        // form.controls[form_name].controls["test-status"].setValue(status);

        form.controls[form_name].controls["test-status"].setValue(line[8]);
      }
    }
  }
  parseReportsInfoTxt(text: string) {
    let results = text.split("\n"); // fix empty answers
    let index, len;

    for (index = 0, len = results.length; index < len - 1; index++) {
      let question = results[index].split(",");
      question[0] = question[0].replace(/\"/g, "");
      if (question[1].toString().length < 2) question[1] = "0" + question[1];
      if (question[2].toString().length < 2) question[2] = "0" + question[2];
      if (question[3].toString().length < 2) question[3] = "0" + question[3];
      let form_name =
        question[0] + "" + question[1] + "." + question[2] + "." + question[3];
      this.populateSectionLine(question);
      if (question[1].match("01")) {
        // only working section 1
        if (question[0].match("AS")) {
          form_name = question[0] + "" + question[1] + "." + question[2];
        }
        // if (form.controls[form_name]) {
        //   if (typeof question[5] === 'undefined') {
        //     if (form.controls[form_name].controls["assessment"]) {
        //       form.controls[form_name].controls["assessment"].setValue(" ");
        //     }
        //     if (form.controls[form_name].controls["notes"]) {
        //       form.controls[form_name].controls["notes"].setValue(" ");
        //     }
        //   } else {
        //     if (form.controls[form_name].controls["assessment"]) {
        //       form.controls[form_name].controls["assessment"].setValue(question[5]);
        //     }
        //     if (form.controls[form_name].controls["notes"]) {
        //       form.controls[form_name].controls["notes"].setValue(question[5]);
        //     }
        //   }
        //   if (typeof question[9] === 'undefined') {
        //     if (form.controls[form_name].controls["reval-assessment"]) {
        //       form.controls[form_name].controls["reval-assessment"].setValue(" ");
        //     }
        //   } else {
        //     if (form.controls[form_name].controls["reval-assessment"]) {
        //       form.controls[form_name].controls["reval-assessment"].setValue(question[9]);
        //     }
        //   }
        //   if (typeof question[8] === 'undefined') {
        //     form.controls[form_name].controls["test-status"].setValue(" ");
        //   } else {
        //     form.controls[form_name].controls["test-status"].setValue(question[8]);
        //   }
        // }
      }
    } // for loop
  }

  prepareSectionInfoTxt() {
    let result = "";
    for (let key in this.sectionService.sections) {
      let section = this.sectionService.sections[key].value;
      for (let question in section) {
        let answer = section[question];
        let parts = question.split(".");
        if (parts.length === 2) {
          parts.push("00");
        }
        const name = parts[0].substring(0, 2);
        const question1 = this.extractNumber(parts[0].substring(2, 4));
        const question2 = this.extractNumber(parts[1]);
        const question3 = this.extractNumber(parts[2]);
        let line = `${name},${question1},${question2},${question3},0,${
          answer.notes
            ? answer.notes
            : answer.assessment
            ? answer.assessment
            : ""
        },,,${answer["test-status"]}`;
        result += line + "\n";
      }
    }
    return result;
  }
  extractNumber(txt) {
    if (txt.startsWith("0")) {
      txt = txt.substring(1);
    }
    return txt;
  }

  parseSectionInfo(form, text: string) {
    let results = text.split("\n"); // fix empty answers
    let index, len;

    for (index = 0, len = results.length; index < len - 1; index++) {
      let question = results[index].split(",");
      //alert(question + index);
      question[0] = question[0].replace(/\"/g, "");
      if (question[1].toString().length < 2) question[1] = "0" + question[1];
      if (question[2].toString().length < 2) question[2] = "0" + question[2];
      if (question[3].toString().length < 2) question[3] = "0" + question[3];
      let form_name =
        question[0] + "" + question[1] + "." + question[2] + "." + question[3];

      //alert(form_name);
      if (question[1].match("01")) {
        // only working section 1
        if (question[0].match("AS")) {
          //  alert("AS: " + form_name + "_assessment" + "  Counter " + index + ' ' + question[5]);
          form_name = question[0] + "" + question[1] + "." + question[2];
          // if (typeof question[5] === 'undefined') {
          //   form.get(form_name).controls["assessment"].setValue(" ");
          // } else {
          //   form.controls[form_name].controls["assessment"].setValue(question[5]);
          // }
          // if (typeof question[9] === 'undefined') {
          //   form.controls[form_name].controls["reval-assessment"].setValue(" ");
          // } else {
          //   form.controls[form_name].controls["reval-assessment"].setValue(question[9]);
          // }
          // if (typeof question[8] === 'undefined') {
          //   form.controls[form_name].controls["test-status"].setValue(" ");
          // } else {
          //   form.controls[form_name].controls["test-status"].setValue(question[8]);
          // }
        }
        if (form.controls[form_name]) {
          if (!question[5]) {
            if (form.controls[form_name].controls["assessment"]) {
              form.controls[form_name].controls["assessment"].setValue(" ");
            }
            if (form.controls[form_name].controls["notes"]) {
              form.controls[form_name].controls["notes"].setValue(" ");
            }
          } else {
            if (form.controls[form_name].controls["assessment"]) {
              form.controls[form_name].controls["assessment"].setValue(
                question[5]
              );
            }
            if (form.controls[form_name].controls["notes"]) {
              form.controls[form_name].controls["notes"].setValue(question[5]);
            }
          }
          if (typeof question[9] === "undefined") {
            if (form.controls[form_name].controls["reval-assessment"]) {
              form.controls[form_name].controls["reval-assessment"].setValue(
                " "
              );
            }
          } else {
            if (form.controls[form_name].controls["reval-assessment"]) {
              form.controls[form_name].controls["reval-assessment"].setValue(
                question[9]
              );
            }
          }
          if (typeof question[8] === "undefined") {
            form.controls[form_name].controls["test-status"].setValue(" ");
          } else {
            form.controls[form_name].controls["test-status"].setValue(
              question[8]
            );
          }
        }

        // if (question[0].match("TE")) {

        //   if (typeof question[5] === 'undefined') {
        //     form.controls[form_name + "_assessment"].setValue(" ");
        //   } else {
        //     form.controls[form_name + "_assessment"].setValue(question[5]);
        //   }
        //   if (typeof question[9] === 'undefined') {
        //     form.controls[form_name + "_re-assessment"].setValue(" ");

        //   } else {
        //     form.controls[form_name + "_re-assessment"].setValue(question[9]);
        //   }
        //   if (typeof question[8] === 'undefined') {
        //     form.controls[form_name + "_status"].setValue(" ");
        //   } else {
        //     form.controls[form_name + "_status"].setValue(question[8]);
        //   }
        // }
      }
    } // for loop
  }

  parseJson(obj, model) {
    let result = {};
    for (let key in model) {
      if (key === "date") {
        if (obj[key]) {
          const date = parse(obj[key], "yyyy-MM-dd", new Date());
          result[key] = date;
        } else {
          result[key] = "";
        }
      } else {
        result[key] = obj[key];
      }
    }
    return result;
  }

  isEmpty(obj) {
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) return false;
    }
    return true;
  }

  getFileName(form) {
    try {
      const module = form.module;
      const vendor = form.vendor;
      const date = this.formatDateForFileName(new Date());
      const labs = this.labs;
      let FCLC = "";
      if (labs) {
        const lab = labs.find((l) => l.name === form.laboratory["labName"]);
        let code = "xx";
        if (lab) {
          code = lab.code;
        }
        let submissionCode = module["transmissionCode"];
        let submissionType = module["transmissionCode"];

        if (submissionCode === "sCMn") {
          submissionCode = `${module["scenario"]}CM${module["commentsRound"]}`;
        } else if (submissionCode === "sHLD") {
          submissionCode = `${submissionType ? submissionType[0] : ""}HLD`;
        } else if (submissionCode === "FCLC_OK") {
          submissionCode = "FCLC";
          FCLC = "-OK";
        }

        let vendorName = vendor["vendorName"]
          .trim()
          .split(" ")
          .join("_")
          .substring(0, 10);
        let filename = `TID-${code}-${module["cstlTid"]}-${module["csecTid"]}-${submissionCode}-${vendorName}-${date}-V1${FCLC}`;
        return filename;
      } else {
        console.log("no labs");
        let filename = `TID---${module["csecTid"]}----V1`;
        return filename;
      }
    } catch (error) {
      console.log(error);
      alert("Missing labs");
      let filename = `TID---${module["csecTid"]}----V1`;
      return filename;
    }
  }
  prepareDataForSchema() {
    let data = {
      ...this.sectionService.vendorFormGroup.getRawValue(),
      ...this.br1Service.brTables,
      cavpCertSet: this.br1Service.cavpCertSet,
      supplementalSettingList: this.br1Service.supplementalSettingList,
    };

    // Update the field names to match the schema without affecting the code
    data.referenceList = this.sectionService.references.value;
    data.schemaVersion = schema.properties.schemaVersion.const;
    data.securityLevelInfo = {
      overallLevel: parseInt(data.module["overall-level"]),
      secLevels: [
        {
          section: 1,
          level:
            data.module["section1-level"] === "NA"
              ? 0
              : parseInt(data.module["section1-level"]),
        },
        {
          section: 2,
          level:
            data.module["section2-level"] === "NA"
              ? 0
              : parseInt(data.module["section2-level"]),
        },
        {
          section: 3,
          level:
            data.module["section3-level"] === "NA"
              ? 0
              : parseInt(data.module["section3-level"]),
        },
        {
          section: 4,
          level:
            data.module["section4-level"] === "NA"
              ? 0
              : parseInt(data.module["section4-level"]),
        },
        {
          section: 5,
          level:
            data.module["section5-level"] === "NA"
              ? 0
              : parseInt(data.module["section5-level"]),
        },
        {
          section: 6,
          level:
            data.module["section6-level"] === "NA"
              ? 0
              : parseInt(data.module["section6-level"]),
        },
        {
          section: 7,
          level:
            data.module["section7-level"] === "NA"
              ? 0
              : parseInt(data.module["section7-level"]),
        },
        {
          section: 8,
          level:
            data.module["section8-level"] === "NA"
              ? 0
              : parseInt(data.module["section8-level"]),
        },
        {
          section: 9,
          level:
            data.module["section9-level"] === "NA"
              ? 0
              : parseInt(data.module["section9-level"]),
        },
        {
          section: 10,
          level:
            data.module["section10-level"] === "NA"
              ? 0
              : parseInt(data.module["section10-level"]),
        },
        {
          section: 11,
          level:
            data.module["section11-level"] === "NA"
              ? 0
              : parseInt(data.module["section11-level"]),
        },
        {
          section: 12,
          level:
            data.module["section12-level"] === "NA"
              ? 0
              : parseInt(data.module["section12-level"]),
        },
      ],
    };
    delete data.module["overall-level"];
    delete data.module["section1-level"];
    delete data.module["section2-level"];
    delete data.module["section3-level"];
    delete data.module["section4-level"];
    delete data.module["section5-level"];
    delete data.module["section6-level"];
    delete data.module["section7-level"];
    delete data.module["section8-level"];
    delete data.module["section9-level"];
    delete data.module["section10-level"];
    delete data.module["section11-level"];
    delete data.module["section12-level"];

    data.vendorInfo = data.vendor;
    delete data.vendor;

    data.labInfo = data.laboratory;
    delete data.laboratory;

    data.moduleInfo = data.module;
    delete data.module;

    return data;
  }

  formatDateForFileName(date) {
    let splits;
    if (date) {
      date = this.datepipe.transform(date, "MM/dd/yyyy");
      splits = date.split(" ");
      splits = date[0];
      splits = date.split("/");
      if (splits.length === 3) {
        const year = splits[2].substring(2, 4);
        const month = splits[0];
        const day = splits[1];
        return `${year}${month}${day}`;
      }
    }
    return "";
  }
  formatDateForPdf(date) {
    let splits;
    if (date) {
      date = this.datepipe.transform(date, "MM/dd/yyyy");
     return date
    }
    return "";
  }

  async parseSecurityData(tables, data, name) {
    if (name.endsWith("xml")) {
      // const parser = new DOMParser();
      // const parsedXml = parser.parseFromString(data, "text/xml");
      // data = this.ngxXml2jsonService.xmlToJson(parsedXml);

      data = await xml2js.parseStringPromise(data, { explicitArray: false });
      data = data["Tables"]["Tables"];
    } else if (name.endsWith("json")) {
      data = JSON.parse(data);
    }
    data.forEach((table, i) => {
      let tableForm = tables.find(
        (t) => t.position === parseInt(table[`Table${i + 2}`].position)
      );
      if (tableForm) {
        const d = table[`Table${i + 2}`];
        for (const key in d) {
          if (d.hasOwnProperty(key)) {
            const element = d[key];
            if (tableForm.form.controls[key]) {
              tableForm.form.controls[key].setValue(element);
            }
          }
        }

        // tableForm.form.patchValue(table[`Table${i+2}`])
      }
    });
  }
  validateMISTables(){
    let valid = true;
    let data = this.prepareDataForSchema();
    const ajv = new Ajv2020({ allErrors: true, strict: false });

    const validate = ajv.compile(schema);
    const isValid = validate(data);
    // const isValid = ajv.validate(schema, data)
  }
}
