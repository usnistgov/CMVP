import { Injectable } from "@angular/core";
import { Br1Service } from "./br1.service";
import { DatePipe } from "@angular/common";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BehaviorSubject } from "rxjs";
import { filter, pairwise, tap } from "rxjs/operators";
import { initial } from "underscore";
import { SectionService } from "./section.service";

@Injectable({
    providedIn: "root",
})
export class ValidationService {
    selectedValidation: string;

    constructor(private _formBuilder: FormBuilder, private br1Service: Br1Service, public datepipe: DatePipe, private sectionService: SectionService) {
       
     
    }

}