import { Injectable } from "@angular/core";
import * as _ from "underscore";
import { sectionsList } from "../../../assets/sections-list";
import {
  FormGroup,
  FormControl,
  UntypedFormBuilder,
  Validators,
  FormArray,
} from "@angular/forms";
import { VendorForms } from "src/assets/vendor-forms";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { SectionService } from "./section.service";
import { Migration284Service } from "./migration/migration_284.service";

@Injectable({
  providedIn: "root",
})
export class Br1Service {
  brTables = {
    testedHwList: [],
    opEnvSwFwHyTestedList: [],
    testedSwFwHyList: [],
    testedHyHwList: [],
    opEnvSwFwHyVAList: [],
    modeOfOpList: [],
    vendorAffirmedAlgoList: [],
    nonApprovedAllowedAlgoList: [],
    nonApprovedAllowedAlgoNSCList: [],
    nonApprovedNotAllowedAlgoList: [],
    secFunImplList: [],
    esvCertList: [],
    esvItarCertList: [],
    entropySourceList: [],
    portInterfaceList: [],
    authMethodList: [],
    roleList: [],
    approvedServiceList: [],
    nonApprovedServiceList: [],
    phSecMechanismList: [],
    efpEftInfoList: [
      {
        tempVoltType: "LowTemperature",
        tempVolt: "",
        efpOrEft: "",
        result: "",
      },
      {
        tempVoltType: "HighTemperature",
        tempVolt: "",
        efpOrEft: "",
        result: "",
      },
      {
        tempVoltType: "LowVoltage",
        tempVolt: "",
        efpOrEft: "",
        result: "",
      },
      {
        tempVoltType: "HighVoltage",
        tempVolt: "",
        efpOrEft: "",
        result: "",
      },
    ],
    hardnessTestTempList: [
      {
        tempType: "LowTemperature",
        temp: "",
      },
      {
        tempType: "HighTemperature",
        temp: "",
      },
    ],
    storageAreaList: [],
    sspInputOutputList: [],
    sspZeroizationList: [],
    sspList: [],
    preOpSelfTestList: [],
    condSelfTestList: [],
    errorStateList: [],
  };

  supplementalSettingList = [];
  supplementalSections = [];
  sectionsData;
  selectedSupplementalAnswers: { [suppId: number]: boolean } = {};

  cavpCertSet = {
    cavpCertList: [],
    cavpOeList: [],
    cavpOeAlgoList: [],
    cavpImplAlgoList: [],
    cavpItarAlgoList: [],
  };

  selectableAlgorithms = [];
  constructor(
    private fb: UntypedFormBuilder,
    private http: HttpClient,
    private sectionService: SectionService,
    private migration284Service: Migration284Service,
  ) {
    this.initTables();
    this.initSupplementalInformation();
  }
  populateSelectableAlgorithm() {
    this.selectableAlgorithms = [
      ...this.cavpCertSet.cavpImplAlgoList.map((a) => {
        return {
          algoDisplayName: a.algoDisplayName,
          canonicalAlgorithmId: a.canonicalAlgorithmId,
          validationId: a.validationId,
          certName: a.certName,
          propertiesList: [],
          implName: a.implName,
          from: "cavpImplAlgoList",
        };
      }),
      ...this.brTables.vendorAffirmedAlgoList.map((a) => {
        return {
          algoDisplayName: a.name,
          algoPropList: a.algoPropList,
          implName: a.implName,
          from: "vendorAffirmedAlgoList",
        };
      }),
      ...this.cavpCertSet.cavpItarAlgoList.map((a) => {
        return {
          algoDisplayName: a.algoDisplayName,
          canonicalAlgorithmId: a.canonicalAlgorithmId,
          certName: a.certName,
          from: "cavpItarAlgoList",
        };
      }),
      ...this.brTables.nonApprovedAllowedAlgoNSCList.map((a) => {
        return {
          algoDisplayName: a.name,
          from: "nonApprovedAllowedAlgoNSCList",
        };
      }),
    ];
  }
  async initSupplementalInformation() {
    let supplementalData = await this.sectionService.getSupplementalData();
    this.sectionsData = await this.sectionService.getSectionsData();
    this.sectionsData = this.sectionsData.sort(
      (a, b) => a.sectionNum - b.sectionNum
    );
    this.supplementalSections = this.transformData(supplementalData);
  }
  transformData(list) {
    const sectionsMap = new Map<number, any[]>();

    list.forEach((item) => {
      if (!sectionsMap.has(item.sectionId)) {
        sectionsMap.set(item.sectionId, []);
      }
      sectionsMap.get(item.sectionId).push(item);
      this.supplementalSettingList.push({
        suppId: item.suppId,
        name: item.name,
        setting: null,
      });
    });

    const sectionsArray = [];

    sectionsMap.forEach((questions, sectionId) => {
      sectionsArray.push({
        sectionId,
        questions,
      });
    });

    return sectionsArray.sort((a, b) => a.sectionId - b.sectionId);
  }
  setCAVPData(data) {
    if (data) {
      this.cavpCertSet = this.migration284Service.migrateCavpCertSet(data);
    }
  }
  setSupplementalSettingList(data) {
    if (data) {
      this.supplementalSettingList.forEach((supp) => {
        const setting = data.find((s) => s.suppId === supp.suppId);
        if (setting && setting.setting !== null) {
          supp.setting = setting.setting;
          this.selectedSupplementalAnswers[supp.suppId] = setting.setting;
        }
      });
    }
  }
  setBr1Data(data) {
    this.brTables = this.migration284Service.migrateMISTables(data);
    // this.brTables = {
    //   testedHwList: data.testedHwList ? data.testedHwList : [],
    //   opEnvSwFwHyTestedList: data.opEnvSwFwHyTestedList
    //     ? data.opEnvSwFwHyTestedList
    //     : [],
    //   testedSwFwHyList: data.testedSwFwHyList ? data.testedSwFwHyList : [],
    //   testedHyHwList: data.testedHyHwList ? data.testedHyHwList : [],
    //   opEnvSwFwHyVAList: data.opEnvSwFwHyVAList ? data.opEnvSwFwHyVAList : [],
    //   modeOfOpList: data.modeOfOpList ? data.modeOfOpList : [],
    //   vendorAffirmedAlgoList: data.vendorAffirmedAlgoList
    //     ? data.vendorAffirmedAlgoList
    //     : [],
    //   nonApprovedAllowedAlgoList: data.nonApprovedAllowedAlgoList
    //     ? data.nonApprovedAllowedAlgoList
    //     : [],
    //   nonApprovedAllowedAlgoNSCList: data.nonApprovedAllowedAlgoNSCList
    //     ? data.nonApprovedAllowedAlgoNSCList
    //     : [],
    //   nonApprovedNotAllowedAlgoList: data.nonApprovedNotAllowedAlgoList
    //     ? data.nonApprovedNotAllowedAlgoList
    //     : [],
    //   secFunImplList: data.secFunImplList ? data.secFunImplList : [],
    //   esvCertList: data.esvCertList ? data.esvCertList : [],
    //   esvItarCertList: data.esvItarCertList ? data.esvItarCertList : [],

    //   entropySourceList: data.entropySourceList ? data.entropySourceList : [],
    //   portInterfaceList: data.portInterfaceList ? data.portInterfaceList : [],
    //   authMethodList: data.authMethodList ? data.authMethodList : [],
    //   roleList: data.roleList ? data.roleList : [],
    //   approvedServiceList: data.approvedServiceList
    //     ? data.approvedServiceList
    //     : [],
    //   nonApprovedServiceList: data.nonApprovedServiceList
    //     ? data.nonApprovedServiceList
    //     : [],
    //   phSecMechanismList: data.phSecMechanismList
    //     ? data.phSecMechanismList
    //     : [],
    //   efpEftInfoList: data.efpEftInfoList
    //     ? data.efpEftInfoList
    //     : [
    //         {
    //           tempVoltType: "LowTemperature",
    //           tempVolt: "",
    //           efpOrEft: "",
    //           result: "",
    //         },
    //         {
    //           tempVoltType: "HighTemperature",
    //           tempVolt: "",
    //           efpOrEft: "",
    //           result: "",
    //         },
    //         {
    //           tempVoltType: "LowVoltage",
    //           tempVolt: "",
    //           efpOrEft: "",
    //           result: "",
    //         },
    //         {
    //           tempVoltType: "HighVoltage",
    //           tempVolt: "",
    //           efpOrEft: "",
    //           result: "",
    //         },
    //       ],
    //   hardnessTestTempList: data.hardnessTestTempList
    //     ? data.hardnessTestTempList
    //     : [
    //         {
    //           tempType: "LowTemperature",
    //           temp: "",
    //         },
    //         {
    //           tempType: "HighTemperature",
    //           temp: "",
    //         },
    //       ],
    //   storageAreaList: data.storageAreaList ? data.storageAreaList : [],
    //   sspInputOutputList: data.sspInputOutputList
    //     ? data.sspInputOutputList
    //     : [],
    //   sspZeroizationList: data.sspZeroizationList
    //     ? data.sspZeroizationList
    //     : [],
    //   sspList: data.sspList ? data.sspList : [],
    //   preOpSelfTestList: data.preOpSelfTestList ? data.preOpSelfTestList : [],
    //   condSelfTestList: data.condSelfTestList ? data.condSelfTestList : [],
    //   errorStateList: data.errorStateList ? data.errorStateList : [],
    // };
  }

  initTables() {}
}
