import { Injectable } from "@angular/core";
import * as _ from "underscore";
import htmlToText from "html-to-text";

import { SectionService } from "./section.service";
import { DatePipe } from "@angular/common";
import { environment } from "src/environments/environment";
import { Labs } from "src/assets/labs";
import { FormService } from "./form.service";

@Injectable({
  providedIn: "root",
})
export class PdfService {
  sections = [
    {
      number: "1",
      tocTitle: "1. General",
      title: "SECTION 1: General",
      levelField: "section1-level",
    },
    {
      number: "2",
      tocTitle: "2. Cryptographic module specification",
      title: "SECTION 2: Cryptographic module specification",
      levelField: "section2-level",
    },
    {
      number: "3",
      tocTitle: "3. Cryptographic module interfaces",
      title: "SECTION 3: Cryptographic module interfaces",
      levelField: "section3-level",
    },
    {
      number: "4",
      tocTitle: "4. Roles, services, and authentication",
      title: "SECTION 4: Roles, services, and authentication",
      levelField: "section4-level",
    },
    {
      number: "5",
      tocTitle: "5. Software/Firmware security",
      title: "SECTION 5: Software/Firmware security",
      levelField: "section5-level",
    },
    {
      number: "6",
      tocTitle: "6. Operational environment",
      title: "SECTION 6: Operational environment",
      levelField: "section6-level",
    },
    {
      number: "7",
      tocTitle: "7. Physical security",
      title: "SECTION 7: Physical security",
      levelField: "section7-level",
    },
    {
      number: "8",
      tocTitle: "8. Non-invasive security",
      title: "SECTION 8: Non-invasive security",
      levelField: "section8-level",
    },
    {
      number: "9",
      tocTitle: "9. Sensitive security parameter management",
      title: "SECTION 9: Sensitive security parameter management",
      levelField: "section9-level",
    },
    {
      number: "10",
      tocTitle: "10. Self-tests",
      title: "SECTION 10: Self-tests",
      levelField: "section10-level",
    },
    {
      number: "11",
      tocTitle: "11. Life-cycle assurance",
      title: "SECTION 11: Life-cycle assurance",
      levelField: "section11-level",
    },
    {
      number: "12",
      tocTitle: "12. Mitigation of other attacks",
      title: "SECTION 12: Mitigation of other attacks",
      levelField: "section12-level",
    },
    {
      number: "A",
      tocTitle: "Appendix A",
      title: "Appendix A",
      levelField: "section13-level",
    },
    {
      number: "B",
      tocTitle: "Appendix B",
      title: "Appendix B",
      levelField: "section14-level",
    },

  ];
  constructor(
    public sectionService: SectionService,
    public formService: FormService,

    public datepipe: DatePipe
  ) { }

  getPdfData() {
    const vendor = this.sectionService.vendorFormGroup.getRawValue();
    let date = this.datepipe.transform(vendor.module["date"], "yyyy-MM-dd");
    let year = "";
    let month = "";
    let day = "";
    let formattedDate = "";
    if (date) {
      year = date.substring(0, 4);
      month = date.substring(5, 7);
      day = date.substring(8, 10);
      formattedDate = `${month}/${day}/${year}`;
    }
    let labs = this.formService.labs;
    labs = []
    if (labs) {
      const lab = labs.find((l) => l.name === vendor.laboratory["labName"]);
      let code = "xx";
      if (lab) {
        code = lab.code;
      }
      let dd = {
        content: [
          {
            text: "CMVP TID: " + code + "-" + vendor.module["cstlTid"],
            style: ["small_text", "cmvp_tid"],
          },
          {
            text: `© ${vendor.laboratory["labName"].toLowerCase()}, ${year}`, //  "© Test Lab, 2017"
            style: ["test_lab"],
          },
          {
            text: `${vendor.module["fipsVersion"]} \nValidation Report`,
            style: ["document_title"],
          },
          {
            text: vendor.module["name"],
            style: ["document_name"],
          },
          {
            text: "by \n " + vendor.vendor["vendorName"],
            style: ["document_name"],
          },
          {
            text: "Created on " + this.formService.formatDateForPdf(new Date()),
            style: ["document_name"],
          },

          {
            text: "Overall Level " + vendor.module["overall-level"],
            style: ["medium_text", "centered", "bold"],
          },
          {
            text:
              "Tested by " +
              vendor.laboratory["tester1Name"] +
              " " +
              vendor.laboratory["tester1Cvp"] +
              " " +
              (vendor.laboratory["tester2Name"]
                ? `; ${vendor.laboratory["tester2Name"]}`
                : "") +
              " " +
              (vendor.laboratory["tester2Cvp"]
                ? ` ${vendor.laboratory["tester2Cvp"]}`
                : ""),
            style: ["medium_text", "centered"],
          },
          {
            text:
              "Reviewed by " +
              vendor.laboratory["reviewer1Name"] +
              (vendor.laboratory["reviewer2Name"]
                ? `; ${vendor.laboratory["reviewer2Name"]}`
                : ""),
            style: ["medium_text", "centered"],
          },
          {
            text: `${formattedDate}`,
            style: ["medium_text", "centered", "bold"],
          },
          // {
          //   text: "_ Algorithm Testing performed by the CST Laboratory",
          //   style: ["small_text", "left"]
          // },
          // {
          //   text: "_ Algorithm Testing performed by the CST Laboratory",
          //   style: ["small_text", "left"]
          // },
          // {
          //   text:
          //     "_ Algorithm Testing performed by the vendor and direclty observed by the CST Laboratory",
          //   style: ["small_text", "left"]
          // },
          // {
          //   text:
          //     "_ Algorithm Testing performed by the vendor unobserved by the CST Laboratory. The signature below affirms the Algorithm Testing was performed on the above IUT on the specified version(s) and referenced OE's.",
          //   style: ["small_text", "left"]
          // },
          // {
          //   text:
          //     "\n Vendor Representative Name: ______________________________________________",
          //   style: ["small_text", "left"]
          // },
          // {
          //   text:
          //     "\n Vendor Representative Title: ________________________________________________",
          //   style: ["small_text", "left"]
          // },
          // {
          //   text:
          //     "\n Vendor Representative Signature: ___________________________________________  \t Date: __________",
          //   style: ["small_text", "left"]
          // },
          {
            text: `Signed by: `,
            style: ["medium_text", "centered", "bold"],
          },
          {
            text: `${vendor.laboratory["signature1"]} ${vendor.laboratory["title1"]}`,
            style: ["medium_text", "centered", "bold"],
          },
          {
            text: `${vendor.laboratory["signature2"]} ${vendor.laboratory["title2"]}`,
            style: ["medium_text", "centered", "bold"],
          },
          {
            text: `${vendor.laboratory["signature3"]} ${vendor.laboratory["title3"]}`,
            style: ["medium_text", "centered", "bold"],
            pageBreak: "after",
          },
          // TOC
          {
            toc: {
              title: { text: 'Table of Contents', style: ["large_text", "centered"] },
              //textMargin: [0, 0, 0, 0],
              textStyle: { bold: true },
              numberStyle: { bold: true },
            },
            pageBreak: "after",
          },
          {
            text: "CMVP TID: " + code + "-" + vendor.module["cstlTid"],
            style: ["small_text", "cmvp_tid"],
          },
          {
            text: "170-12",
            style: ["small_text", "centered"],
          },
          {
            text: "General Vendor/Module Information",
            style: ["large_text", "centered", "bold"],
            tocItem: true,
          },
          {
            text: "Test By",
            style: ["small_text", "centered", "bold"],
          },
          {
            text: `CRYPTIK Version ${environment.version}`,
            style: ["small_text", "centered"],
          },
          {
            text: `${formattedDate}  \n \n`,
            style: ["small_text", "centered"],
          },
          {
            columns: [
              {
                text: "Module Name(s)",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.module["name"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Vendor",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["vendorName"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Module Type",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.module["type"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Embodiment",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: this.getEmbo(vendor.module["embodiment"]),
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Classification",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.module["module-classification"],
                style: ["medium_text"],
              },
            ],
          },

          {
            columns: [
              {
                text: "Certificate Caveat",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.module["certificateCaveat"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Web Site",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["website"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "ProductLink",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["productLink"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Address",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: `${vendor.vendor["addressLine1"]} ${vendor.vendor["addressLine2"]} ${vendor.vendor["addressLine3"]}, ${vendor.vendor["city"]}, ${vendor.vendor["stateProvince"]}, ${vendor.vendor["postalCode"]}, ${vendor.vendor["country"]} `,
                style: ["medium_text"],
              },
            ],
          },
          {
            text: "Primary Contact",
            decoration: "underline",
            style: ["large_text", "left", "bold"],
          },
          {
            columns: [
              {
                text: "Contact 1",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["contactName1"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Phone Number",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["phone1"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Email Address",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["email1"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "FaxNumber",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["fax1"],
                style: ["medium_text"],
              },
            ],
          },
          {
            text: "Alternate Contact",
            decoration: "underline",
            style: ["large_text", "left", "bold"],
          },
          {
            columns: [
              {
                text: "Contact 2",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["contactName2"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "Phone Number",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["phone2"],
                style: ["medium_text"],
              },
            ],
          },

          {
            columns: [
              {
                text: "Email Address",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["email2"],
                style: ["medium_text"],
              },
            ],
          },
          {
            columns: [
              {
                text: "FaxNumber",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: vendor.vendor["fax2"] + " \n",
                style: ["medium_text"],
              },
            ],
          },

          {
            columns: [
              {
                text: "Pre-Validation List",
                width: 150,
                style: ["medium_text", "bold"],
              },
              {
                text: "√",
                style: ["medium_text"],
              },
            ],
          },
          {
            text: "Certificate:",
            decoration: "underline",
            style: ["large_text", "left", "bold"],
          },

          //sections start
          {
            columns: [
              {
                text: "Section",
                width: 300,
                style: ["large_text", "bold"],
              },
              {
                text: "Level",
                style: ["large_text", "bold"],
              },
            ],
          },
          ...this.getSectionToc(),

          //section

          ...this.getSectionsPage(code),

          {
            text: "End of Document",
            alignment: 'center',
            fontSize: 23,
            bold: true,
            margin: [0, 250]
          }
        ],
        styles: {
          cmvp_tid: {
            alignment: "right",
            italics: true,
            margin: [0, 0, 100, 0],
          },
          test_lab: {
            alignment: "center",
            fontSize: 10,
          },
          document_title: {
            alignment: "center",
            fontSize: 25,
            margin: [0, 20, 0, 0],
          },
          document_name: {
            alignment: "center",
            margin: [0, 30, 0, 10],
            italics: true,
            bold: true,
            fontSize: 15,
          },
          small_text: {
            margin: [0, 5, 0, 5],
            fontSize: 10,
          },
          medium_text: {
            margin: [0, 5, 0, 5],
            fontSize: 12,
          },
          large_text: {
            margin: [0, 5, 0, 5],
            fontSize: 17,
          },
          centered: {
            alignment: "center",
          },
          left: {
            alignment: "left",
          },
          bold: {
            bold: true,
          },
          blue: {
            color: "#25257d",
          },
        },
      };
      return dd;
    }
  }

  getEmbo(embodiment) {
    switch (embodiment) {
      case "1":
        return "Single Chip";
      case "2":
        return "Multi-Chip Embedded";
      case "3":
        return "Multi-Chip standalone";

      default:
        return "";
    }
  }

  getSectionToc() {
    const vendor = this.sectionService.vendorFormGroup.getRawValue();
    let res = [];
    this.sections.forEach((sec) => {
      res.push({
        columns: [

          {
            text: sec.tocTitle,
            width: 300,
            style: ["medium_text", "bold"],
          },
          {
            text: vendor.module[sec.levelField]
              ? vendor.module[sec.levelField]
              : "NA",
            style: ["medium_text"],
          },
        ],
      });
    });
    return res;
  }
  getSectionsPage(code) {
    const vendor = this.sectionService.vendorFormGroup.getRawValue();
    let res = [];
    res.push({
      text: "",
      pageBreak: "after",
    });
    this.sections.forEach((sec) => {
      const section = this.sectionService.getSectionByNumber(sec.number);

      res.push({
        text: "CMVP TID: " + code + "-" + vendor.module["cstlTid"],
        style: ["small_text", "cmvp_tid"],
      });
      res.push({
        columns: [
          {
            text: sec.title,
            width: 450,
            style: ["large_text", "bold"],
            tocItem: true,
          },
          {
            text:
              "Level: " +
              (vendor.module[sec.levelField]
                ? vendor.module[sec.levelField]
                : "NA"),
            style: ["medium_text", "bold"],
          },
        ],
      });
      const questions = this.sectionService.sections[sec.number].value;
      section.dtrs.forEach((dtr) => {
        let answer = questions[dtr.dtrId];
        if (answer) {
          if (dtr.dtrId.startsWith("AS") || dtr.dtrId.startsWith("VE")) {
            res.push(
              ...[
                {
                  columns: [
                    {
                      width: 100,
                      columns: [
                        [
                          {
                            text: dtr.dtrId,
                            width: 15,
                            style: ["medium_text", "bold", "centered"],
                          },
                          {
                            text: "Level: " + dtr.level,
                            width: 15,
                            style: ["medium_text", "centered"],
                          },
                          {
                            text: this.getStatus(answer["test-status"]),
                            width: 15,
                            style: ["medium_text", "centered"],
                          },
                        ],
                      ],
                    },
                    {
                      // text: dtr.requirement,
                      text: htmlToText.fromString(dtr.requirement, {
                        wordwrap: false,
                      }),
                      style: ["small_text"],
                    },
                  ],
                },

                {
                  columns: [
                    {
                      text: "Notes:",
                      width: 100,
                      style: ["medium_text", "bold", "centered", "blue"],
                    },
                    {
                      text: answer["notes"],
                      style: ["medium_text", "blue"],
                    },
                  ],
                },
              ]
            );
          } else {
            res.push(
              ...[
                {
                  columns: [
                    {
                      width: 100,
                      columns: [
                        [
                          {
                            text: dtr.dtrId,
                            width: 15,
                            style: ["medium_text", "bold", "centered"],
                          },
                          {
                            text: "Level: " + dtr.level,
                            width: 15,
                            style: ["medium_text", "centered"],
                          },
                          {
                            text: this.getStatus(answer["test-status"]),
                            width: 15,
                            style: ["medium_text", "centered"],
                          },
                        ],
                      ],
                    },
                    {
                      //   text: dtr.requirement,
                      text: htmlToText.fromString(dtr.requirement, {
                        wordwrap: false,
                      }),
                      style: ["small_text"],
                    },
                  ],
                },

                {
                  columns: [
                    {
                      text: "Assessment:",
                      width: 100,
                      style: ["medium_text", "bold", "centered", "blue"],
                    },
                    {
                      text: answer["assessment"],
                      style: ["medium_text", "blue"],
                    },
                  ],
                },
                this.getRevalAssessment(answer["reval-assessment"]),
              ]
            );
          }
        }
      });

      res.push({
        text: "",
        pageBreak: "after",
      });
    });

    return res;
  }

  getRevalAssessment(reval) {
    return {};
  }

  getStatus(number) {
    switch (number) {
      case "0":
        return "Open";
      case "1":
        return "Passed";
      case "2":
        return "Failed";
      case "3":
        return "Not Applicable";
      case "4":
        return "ReVal Passed";
    }
  }
}
