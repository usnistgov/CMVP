import { Injectable } from "@angular/core";
import { Br1Service } from "./br1.service";
import { DatePipe } from "@angular/common";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BehaviorSubject } from "rxjs";
import { filter, pairwise, tap } from "rxjs/operators";
import { initial } from "underscore";
import { SectionService } from "./section.service";

@Injectable({
    providedIn: "root",
})
export class TransactionService {
    form: FormGroup;
    lastConfirmedValue = new BehaviorSubject<any>(null);
    transactionTypeForm: FormGroup;
    revals = [];
    labs = [];
    usedCertificateNumber;
    cert;
    selectedReval;
    initialFormValues;
    deletedCollections = [];

    constructor(private _formBuilder: FormBuilder, private br1Service: Br1Service, public datepipe: DatePipe, private sectionService: SectionService) {
        this.transactionTypeForm = this._formBuilder.group({
            transactionCode: ["", Validators.required],
        });
        this.lastConfirmedValue.next(this.transactionTypeForm
            .get("transactionCode").value);

        this.transactionTypeForm.get("transactionCode").valueChanges.pipe(
            pairwise<string>(),
            filter(([prev, curr]) => prev !== null && prev !== '' && curr !== this.lastConfirmedValue.value),
            tap(([prev, curr]) => this.confirmChange(prev, curr))
        ).subscribe();
    }
    confirmChange(prevValue: string, currentValue: string): void {
        const confirmed = confirm('Do you want to proceed with this selection?');
        if (confirmed) {
            this.lastConfirmedValue.next(currentValue);
            this.clearData();
        } else {
            if (!this.lastConfirmedValue.value || this.lastConfirmedValue.value === '') {
                this.lastConfirmedValue.next(prevValue);
            }
            this.transactionTypeForm
                .get("transactionCode").setValue(this.lastConfirmedValue.value, { emitEvent: false }); // Revert the change without emitting an event
        }
    }
    clearData() {
        this.revals = [];
        this.labs = [];
        this.usedCertificateNumber = null;
        this.cert = null;
        this.selectedReval = null;
        this.initialFormValues = null;

    }

    populateVupForm(form, cert) {
        this.populateFormGroup(form.get('payload').get('vendorInfo'), cert.vendorInfo);
        this.populateFormGroup(form.get('payload').get('moduleInfo'), cert.moduleInfo);
    }

    populateOeupForm(form, cert) {
        this.populateFormGroup(form.get('payload').get('moduleInfo'), cert.moduleInfo);
        // this.br1Service.brTables.opEnvSwFwHyVAList = cert.opEnvSwFwHyVAList;
        // this.br1Service.cavpCertSet = cert.cavpCertSet;
        this.br1Service.setBr1Data(cert);
        this.br1Service.setCAVPData(cert.cavpCertSet);
        this.br1Service.setSupplementalSettingList(cert.supplementalSettingList);
        this.br1Service.populateSelectableAlgorithm();
    }
    populateRbndForm(form, cert) {
        this.populateFormGroup(form.get('payload').get('vendorInfo'), cert.vendorInfo);
        this.br1Service.setBr1Data(cert);
        this.br1Service.setCAVPData(cert.cavpCertSet);
        this.br1Service.setSupplementalSettingList(cert.supplementalSettingList);
        this.br1Service.populateSelectableAlgorithm();
    }

    populateFormGroup(form, info) {
        Object.keys(form.controls).forEach(key => {
            if (info.hasOwnProperty(key)) {
                form.controls[key].setValue(info[key]);
            }
        });
    }
    formatDateForFileName(date) {
        if (date) {
            date = this.datepipe.transform(date, "yyMMddHHmm");
            return date;
        }
        return "";
    }

    async importTransaction(data: string) {
        const transaction = JSON.parse(data);
        const transactionCode = transaction.transaction.transactionCode;
        this.selectedReval = transaction.payload.certificateNumber;
        this.initializeForm(transactionCode);
        await this.getCert(transactionCode);
        this.importForm(transactionCode, transaction)

    }
    importVUPForm(transaction) {
        if (transaction.payload.vendorInfo) {
            this.populateFormGroup(this.form.get('payload').get('vendorInfo'), transaction.payload.vendorInfo);
        }
        if (transaction.payload.moduleInfo) {
            this.populateFormGroup(this.form.get('payload').get('moduleInfo'), transaction.payload.moduleInfo);
        }
        if (transaction.transaction.labInfo) {
            this.populateFormGroup(this.form.get('transaction').get('labInfo'), transaction.transaction.labInfo);
        }
        this.form.get("payload").get("certificateNumber").setValue(transaction.payload.certificateNumber);
    }
    importVAOEForm(transaction){
        if (transaction.payload.moduleInfo) {
            this.populateFormGroup(this.form.get('payload').get('moduleInfo'), transaction.payload.moduleInfo);
        }
        if (transaction.transaction.labInfo) {
            this.populateFormGroup(this.form.get('transaction').get('labInfo'), transaction.transaction.labInfo);
        }   
        this.form.get("payload").get("certificateNumber").setValue(transaction.payload.certificateNumber);
        this.br1Service.setBr1Data(transaction.payload);

    }
    importRBNDForm(transaction){
        if (transaction.payload.vendorInfo) {
            this.populateFormGroup(this.form.get('payload').get('vendorInfo'), transaction.payload.vendorInfo);
        }
        if (transaction.transaction.labInfo) {
            this.populateFormGroup(this.form.get('transaction').get('labInfo'), transaction.transaction.labInfo);
        }   
        this.form.get("payload").get("certificateNumber").setValue(transaction.payload.certificateNumber);
    }

    async getRevals(transaction) {
        let revals = await this.sectionService.getRevals(transaction);
        if (revals) {
            this.revals = <any[]>revals;
        }
    }
    async getLabs() {
        let labs = await this.sectionService.getLabs();
        if (labs) {
            this.labs = <any[]>labs;
        }
    }
    initializeVUPForm() {
        if (this.revals.length === 0) {
            this.getRevals("VUP");
            this.getLabs();
            this.form = this._formBuilder.group({
                schemaVersion: ['1.0.0'],
                transaction: this._formBuilder.group({
                    transactionCode: ['VUP'],
                    payloadFormat: ['Br1'],
                    labInfo: this._formBuilder.group({
                        labName: [''],
                        labCode: [{ value: '', disabled: true }],
                        labInternalId: [''],
                        signature1: [''],
                        title1: [''],
                        signature2: [''],
                        title2: [''],
                        signature3: [''],
                        title3: [''],
                        tester1Name: [''],
                        tester1Cvp: [''],
                        tester2Name: [''],
                        tester2Cvp: [''],
                        reviewer1Name: [''],
                        reviewer2Name: [''],
                    }),
                }),
                payload: this._formBuilder.group({
                    scenario: [''],
                    certificateNumber: [''],
                    moduleInfo: this._formBuilder.group({
                        description: [''],
                        specialInstructions: ['']
                    }),
                    vendorInfo: this._formBuilder.group({
                        vendorName: [''],
                        addressLine1: [''],
                        addressLine2: [''],
                        addressLine3: [''],
                        city: [''],
                        stateProvince: [''],
                        postalCode: [''],
                        country: [''],
                        website: [''],
                        productLink: [''],
                        contactName1: [''],
                        email1: [''],
                        phone1: [''],
                        fax1: [''],
                        contactName2: [''],
                        email2: [''],
                        phone2: [''],
                        fax2: [''],
                        contactName3: [''],
                        email3: [''],
                        phone3: [''],
                        fax3: [''],
                    })
                })
            });
        }
        this.form
            .get("transaction")
            .get("labInfo")
            .get("labName")
            .valueChanges.subscribe((val) => {
                if (val) {
                    const lab = this.labs.find((l) => l.name == val);
                    if (lab) {
                        let code = lab.code;
                        this.form
                            .get("transaction")
                            .get("labInfo")
                            .get("labCode")
                            .setValue(code, { emitEvent: false });
                    }
                }
            });
    }
    initializeVAOEForm() {
        if (this.revals.length === 0) {
            this.getRevals("VAOE");
            this.getLabs();
            this.form = this._formBuilder.group({
                schemaVersion: ['1.0.0'],
                transaction: this._formBuilder.group({
                    transactionCode: ['VAOE'],
                    payloadFormat: ['Br1'],
                    labInfo: this._formBuilder.group({
                        labName: [''],
                        labCode: [{ value: '', disabled: true }],
                        labInternalId: [''],
                        signature1: [''],
                        title1: [''],
                        signature2: [''],
                        title2: [''],
                        signature3: [''],
                        title3: [''],
                        tester1Name: [''],
                        tester1Cvp: [''],
                        tester2Name: [''],
                        tester2Cvp: [''],
                        reviewer1Name: [''],
                        reviewer2Name: [''],
                    }),

                }),
                payload: this._formBuilder.group({
                    scenario: [''],
                    certificateNumber: [''],
                    moduleInfo: this._formBuilder.group({
                        description: [''],
                        addToMipList: [false],
                        specialInstructions: ['']
                    }),
                })
            });
        }
        this.form
            .get("transaction")
            .get("labInfo")
            .get("labName")
            .valueChanges.subscribe((val) => {
                if (val) {
                    const lab = this.labs.find((l) => l.name == val);
                    if (lab) {
                        let code = lab.code;
                        this.form
                            .get("transaction")
                            .get("labInfo")
                            .get("labCode")
                            .setValue(code, { emitEvent: false });
                    }
                }
            });
    }
    initializeRBNDForm() {
        if (this.revals.length === 0) {
            this.getRevals("RBND");
            this.getLabs();
            this.form = this._formBuilder.group({
                schemaVersion: ['1.0.0'],
                transaction: this._formBuilder.group({
                    transactionCode: ['RBND'],
                    payloadFormat: ['Br1'],
                    labInfo: this._formBuilder.group({
                        labName: [''],
                        labCode: [{ value: '', disabled: true }],
                        labInternalId: [''],
                        signature1: [''],
                        title1: [''],
                        signature2: [''],
                        title2: [''],
                        signature3: [''],
                        title3: [''],
                        tester1Name: [''],
                        tester1Cvp: [''],
                        tester2Name: [''],
                        tester2Cvp: [''],
                        reviewer1Name: [''],
                        reviewer2Name: [''],
                    }),
                }),
                payload: this._formBuilder.group({
                    scenario: [''],
                    certificateNumber: [''],
                    vendorInfo: this._formBuilder.group({
                        vendorName: [''],
                        addressLine1: [''],
                        addressLine2: [''],
                        addressLine3: [''],
                        city: [''],
                        stateProvince: [''],
                        postalCode: [''],
                        country: [''],
                        website: [''],
                        productLink: [''],
                        contactName1: [''],
                        email1: [''],
                        phone1: [''],
                        fax1: [''],
                        contactName2: [''],
                        email2: [''],
                        phone2: [''],
                        fax2: [''],
                        contactName3: [''],
                        email3: [''],
                        phone3: [''],
                        fax3: [''],
                    })
                })
            });
        }
        this.form
            .get("transaction")
            .get("labInfo")
            .get("labName")
            .valueChanges.subscribe((val) => {
                if (val) {
                    const lab = this.labs.find((l) => l.name == val);
                    if (lab) {
                        let code = lab.code;
                        this.form
                            .get("transaction")
                            .get("labInfo")
                            .get("labCode")
                            .setValue(code, { emitEvent: false });
                    }
                }
            });
    }
    async getCert(revalidation: string) {
        let cert = await this.sectionService.getCert(this.selectedReval);
        if (cert) {
            this.cert = <any[]>cert;
            this.populateForm(revalidation, cert);
            this.initialFormValues = this.form.get('payload').getRawValue();
            this.usedCertificateNumber = this.selectedReval;
        }
    }
  
    importForm(revalidation, transaction) {
        switch (revalidation) {
            case "VUP":
                this.importVUPForm(transaction);
                break;
            case "VAOE":
                this.importVAOEForm(transaction)
                break;
            case "RBND":
                this.importRBNDForm(transaction)

            default:
                break;
        }
    }
    initializeForm(revalidation) {
        switch (revalidation) {
            case "VUP":
                this.initializeVUPForm();
                break;
            case "VAOE":
                this.initializeVAOEForm();
                break;
            case "RBRN":
                this.initializeRBNDForm();
            default:
                break;
        }
    }
    populateForm(revalidation, cert) {
        switch (revalidation) {
            case "VUP":
                this.populateVupForm(this.form, cert);
                break;
            case "VAOE":
                this.populateOeupForm(this.form, cert);
            case "RBND":
                this.populateRbndForm(this.form, cert);

            default:
                break;
        }
    }
}