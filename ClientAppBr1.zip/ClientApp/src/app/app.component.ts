import { Component, HostListener } from "@angular/core";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { SectionService } from "./shared/services/section.service";

import { DatePipe } from "@angular/common";
import { FormService } from "./shared/services/form.service";

import { SubmissionDialogComponent } from "./shared/components/submission-dialog/submission-dialog.component";
import { ImportDialogComponent } from "./shared/components/import-dialog/import-dialog.component";
import { DisclaimerDialogComponent } from "./shared/components/disclaimer-dialog/disclaimer-dialog.component";
import { SaveDialogComponent } from "./shared/components/save-dialog/save-dialog.component";
import { environment } from "src/environments/environment.prod";
import { TypeDialogComponent } from "./shared/components/type-dialog/type-dialog.component";
import { Br1Service } from "./shared/services/br1.service";
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { TransactionService } from "./shared/services/transaction.service";
import { saveAs } from "file-saver";
import { ToastrService } from "ngx-toastr";
import * as JSZip from "jszip";
import { ImportTransactionDialogComponent } from "./shared/components/import-transaction-dialog/import-transaction-dialog.component";
import { ValidationService } from "./shared/services/validation.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent {
  title = "cryptik";
  version = environment.version;
  submissionType = {
    value: "new_validation",
    label: "New Validation"
  }
  constructor(
    private dialog: MatDialog,
    public datepipe: DatePipe,
    public sectionService: SectionService,
    public formService: FormService,
    private router: Router,
    public br1Service: Br1Service,
    public transactionService: TransactionService,
    private toastr: ToastrService,
    public validationService: ValidationService
  ) {
    let self = this;
    this.openDisclaimerDialog();

    // this.router.events.subscribe(event => {
    //   if (event instanceof NavigationStart) {
    //     // Hide loading indicator
    //     if (event.url.startsWith("/artifact")) {
    //       this.formService.type = "artifact";
    //       this.openDisclaimerDialog();
    //     } else {
    //       this.formService.type = "submission";
    //       this.openDisclaimerDialog();
    //     }
    //   }
    // });
  }

  @HostListener("window:beforeunload", ["$event"])
  canLeavePage($event: any) {
    $event.preventDefault();
    $event.returnValue = "Unsaved modifications";
    return event;
  }

  @HostListener("window:onclose", ["$event"])
  onClose($event: any) {
    $event.preventDefault();
    $event.returnValue = "Unsaved modifications";
    return event;
  }
  cancelValidation() {
    this.validationService.selectedValidation = null;
    this.transactionService.clearData();
    this.router.navigate(["/validations"]).then(() => {
      console.log("navigated");
      window.location.reload();
    });

  }
  isDataValid() {
    return this.sectionService.vendorFormGroup.valid;
  }

  createPackage() {
    let hasError = true;
    const data = this.sectionService.vendorFormGroup.value;
    if (
      data.module.transmissionCode === "IUTA" ||
      data.module.transmissionCode === "IUTB" ||
      data.module.transmissionCode === "IUTC" ||
      data.module.transmissionCode === "IUTR" ||
      data.module.transmissionCode === "IUTM"
    ) {
      // Validate IUTs form
      if (
        data.laboratory.labName &&
        data.module.cstlTid &&
        data.module.name &&
        data.vendor.vendorName
      ) {
        hasError = false;
      }
    } else {
      if (this.sectionService.vendorFormGroup.valid) {
        hasError = false;
      }
    }

    if (!hasError) {
      const dialogConfig = new MatDialogConfig();

      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      (dialogConfig.width = "900px"),
        this.dialog.open(SubmissionDialogComponent, dialogConfig);
    } else {
      this.toastr.error("Invalid New Validation data");
      return;
    }


  }

  createTransactionPackage() {
    // const changedFields = this.getChangedFields(this.form.getRawValue(), this.initialFormValues);
    if (!this.transactionService.form || !this.transactionService.form.valid) {
      this.toastr.error("Invalid Revalidation data");
      return;
    }
    if (!this.transactionService.selectedReval) {
      this.toastr.error("Revalidation certificate is required.");
      return;
    }
    try {
      const self = this;
      const jszip = new JSZip();
      const folder = jszip.folder(
        "transaction"
      );
      const filename = this.saveTransactionFormAsJson(folder);
      jszip.generateAsync({ type: "blob" }).then(function (content) {
        saveAs(
          content,
          `${filename}.zip`
        );
      });
    } catch (error) {
      console.error(error)
      this.toastr.error("Error while creating package.");

    }

  }
  getChangedFields(currentValues: any, initialValues: any): any {
    const changedFields: any = {};
    Object.keys(currentValues).forEach(key => {
      if (typeof currentValues[key] === 'object' && currentValues[key] !== null && !Array.isArray(currentValues[key])) {
        const diff = this.getChangedFields(currentValues[key], initialValues[key]);
        if (Object.keys(diff).length > 0) {
          changedFields[key] = diff;
        }
      } else if (currentValues[key] !== initialValues[key]) {
        changedFields[key] = currentValues[key];
      }
    });
    return changedFields;
  }
  saveTransactionFormAsJson(jszip) {
    let data = this.transactionService.form.getRawValue();
    const payload = this.getChangedFields(this.transactionService.form.get('payload').getRawValue(), this.transactionService.initialFormValues);
    data.payload = payload;
    if (this.transactionService.deletedCollections.length > 0) {
      data.payload.deletedCollections = this.transactionService.deletedCollections;
    }
    data.payload.certificateNumber = this.transactionService.usedCertificateNumber;
    if (this.br1Service.brTables.opEnvSwFwHyVAList && this.br1Service.brTables.opEnvSwFwHyVAList.length > 0) {
      data.payload.opEnvSwFwHyVAList = this.br1Service.brTables.opEnvSwFwHyVAList
    }

    const blob = new Blob([JSON.stringify(data)], { type: "text/json" });
    const date = this.transactionService.formatDateForFileName(new Date());
    const filename = `TID-${data.transaction.labInfo.labCode}-${data.transaction.labInfo.labInternalId}-${data.transaction.transactionCode}-${date}_transaction`
    jszip.file(filename + ".json", blob);
    return filename;
  }

  openImportDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    (dialogConfig.width = "900px"),
      this.dialog.open(ImportDialogComponent, dialogConfig);
  }
  openImportTransactionDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    (dialogConfig.width = "900px"),
      this.dialog.open(ImportTransactionDialogComponent, dialogConfig);
  }

  openSaveDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    (dialogConfig.width = "900px"),
      this.dialog.open(SaveDialogComponent, dialogConfig);
  }

  openDisclaimerDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "700px";
    const dialogRef = this.dialog.open(DisclaimerDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      // this.openTypeDialog();
    });
  }
  openTypeDialog() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "700px";
    const dialogRef = this.dialog.open(TypeDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((data) => {
      this.formService.type = data;
    });
  }
}
